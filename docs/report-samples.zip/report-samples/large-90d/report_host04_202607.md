# host04 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host04 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 298 (SEVERE: 21, FATAL: 129, WARN: 148, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 21 | 129 | 148 | 298 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260706-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→17→15→16→…→14→13→12→14
* 開始   : 2026-07-06 02:00:00 (UTC)
* 終了   : 2026-07-06 19:50:00 (UTC)
* 現象   : 2026-07-06 19:50:00 (UTC)を境に水準が 11.84から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.113σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.792, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host04-001 active_connections の推移](charts/EVT-20260706-host04-001.svg)

# イベントID( EVT-20260706-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→15→14→16→…→12→11→12→11
* 開始   : 2026-07-06 02:05:00 (UTC)
* 終了   : 2026-07-06 21:25:00 (UTC)
* 現象   : 2026-07-06 21:25:00 (UTC)を境に水準が 11.78から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.023, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host04-002 active_connections の推移](charts/EVT-20260706-host04-002.svg)

# イベントID( EVT-20260706-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→16→15→16→…→15→14→11→14
* 開始   : 2026-07-06 02:10:00 (UTC)
* 終了   : 2026-07-06 21:10:00 (UTC)
* 現象   : 2026-07-06 21:10:00 (UTC)を境に水準が 11.8から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.446σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.868, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.994, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host04-003 active_connections の推移](charts/EVT-20260706-host04-003.svg)

# イベントID( EVT-20260706-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→14→15→17→…→14→15→14→13
* 開始   : 2026-07-06 02:45:00 (UTC)
* 終了   : 2026-07-06 19:40:00 (UTC)
* 現象   : 2026-07-06 19:40:00 (UTC)を境に水準が 11.8から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.535σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.892, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.87, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host04-004 active_connections の推移](charts/EVT-20260706-host04-004.svg)

# イベントID( EVT-20260706-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→14→18→15→…→11→13→11→12
* 開始   : 2026-07-06 03:30:00 (UTC)
* 終了   : 2026-07-06 21:40:00 (UTC)
* 現象   : 2026-07-06 21:40:00 (UTC)を境に水準が 12.01から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.628, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.408, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host04-005 active_connections の推移](charts/EVT-20260706-host04-005.svg)

# イベントID( EVT-20260706-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 16→18→16→15→…→12→13→15→12
* 開始   : 2026-07-06 03:50:00 (UTC)
* 終了   : 2026-07-06 19:45:00 (UTC)
* 現象   : 2026-07-06 19:45:00 (UTC)を境に水準が 11.9から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.98, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.829, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host04-006 active_connections の推移](charts/EVT-20260706-host04-006.svg)

# イベントID( EVT-20260713-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→15→14→13→…→11→13→11→12
* 開始   : 2026-07-13 02:05:00 (UTC)
* 終了   : 2026-07-13 20:20:00 (UTC)
* 現象   : 2026-07-13 20:20:00 (UTC)を境に水準が 11.79から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.362σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.953, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.522, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host04-001 active_connections の推移](charts/EVT-20260713-host04-001.svg)

# イベントID( EVT-20260713-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→15→16→15→…→16→13→14→15
* 開始   : 2026-07-13 02:05:00 (UTC)
* 終了   : 2026-07-13 22:35:00 (UTC)
* 現象   : 2026-07-13 22:35:00 (UTC)を境に水準が 11.85から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.668, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host04-002 active_connections の推移](charts/EVT-20260713-host04-002.svg)

# イベントID( EVT-20260713-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→16→15→16→…→13→14→15→13
* 開始   : 2026-07-13 02:15:00 (UTC)
* 終了   : 2026-07-13 20:10:00 (UTC)
* 現象   : 2026-07-13 20:10:00 (UTC)を境に水準が 11.84から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.686, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.88, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host04-003 active_connections の推移](charts/EVT-20260713-host04-003.svg)

# イベントID( EVT-20260713-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 14→11→18→15→…→14→13→14→13
* 開始   : 2026-07-13 02:40:00 (UTC)
* 終了   : 2026-07-13 19:55:00 (UTC)
* 現象   : 2026-07-13 19:55:00 (UTC)を境に水準が 11.93から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.972σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.738, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host04-005 active_connections の推移](charts/EVT-20260713-host04-005.svg)

# イベントID( EVT-20260713-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→14→17→15→…→13→14→12→15
* 開始   : 2026-07-13 03:20:00 (UTC)
* 終了   : 2026-07-13 20:30:00 (UTC)
* 現象   : 2026-07-13 20:30:00 (UTC)を境に水準が 11.92から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.846, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host04-006 active_connections の推移](charts/EVT-20260713-host04-006.svg)

# イベントID( EVT-20260720-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→16→13→16→…→13→11→12→11
* 開始   : 2026-07-20 01:45:00 (UTC)
* 終了   : 2026-07-20 22:35:00 (UTC)
* 現象   : 2026-07-20 22:35:00 (UTC)を境に水準が 11.67から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.681, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.043, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host04-001 active_connections の推移](charts/EVT-20260720-host04-001.svg)

# イベントID( EVT-20260720-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→14→16→14→…→15→13→12→13
* 開始   : 2026-07-20 02:25:00 (UTC)
* 終了   : 2026-07-20 21:05:00 (UTC)
* 現象   : 2026-07-20 21:05:00 (UTC)を境に水準が 11.69から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.625σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.054, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host04-002 active_connections の推移](charts/EVT-20260720-host04-002.svg)

# イベントID( EVT-20260720-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 14→13→15→13→…→14→10→11→13
* 開始   : 2026-07-20 03:00:00 (UTC)
* 終了   : 2026-07-20 20:50:00 (UTC)
* 現象   : 2026-07-20 20:50:00 (UTC)を境に水準が 11.84から14.81へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.212σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.821, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.493, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host04-004 active_connections の推移](charts/EVT-20260720-host04-004.svg)

# イベントID( EVT-20260720-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→16→18→16→…→13→12→13→12
* 開始   : 2026-07-20 03:30:00 (UTC)
* 終了   : 2026-07-20 19:50:00 (UTC)
* 現象   : 2026-07-20 19:50:00 (UTC)を境に水準が 11.89から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.786, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host04-005 active_connections の推移](charts/EVT-20260720-host04-005.svg)

# イベントID( EVT-20260720-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→14→15→14→…→13→15→13→14
* 開始   : 2026-07-20 03:50:00 (UTC)
* 終了   : 2026-07-20 21:35:00 (UTC)
* 現象   : 2026-07-20 21:35:00 (UTC)を境に水準が 11.9から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.058, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.304, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host04-006 active_connections の推移](charts/EVT-20260720-host04-006.svg)

# イベントID( EVT-20260727-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 16→13→16→15→…→12→14→13→12
* 開始   : 2026-07-27 02:10:00 (UTC)
* 終了   : 2026-07-27 19:00:00 (UTC)
* 現象   : 2026-07-27 19:00:00 (UTC)を境に水準が 11.92から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.897, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.332, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host04-001 active_connections の推移](charts/EVT-20260727-host04-001.svg)

# イベントID( EVT-20260727-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→17→18→17→…→14→16→12→14
* 開始   : 2026-07-27 03:00:00 (UTC)
* 終了   : 2026-07-27 19:50:00 (UTC)
* 現象   : 2026-07-27 19:50:00 (UTC)を境に水準が 12.02から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.535σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.925, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host04-003 active_connections の推移](charts/EVT-20260727-host04-003.svg)

# イベントID( EVT-20260727-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 14→17→15→14→…→17→13→12→13
* 開始   : 2026-07-27 03:05:00 (UTC)
* 終了   : 2026-07-27 21:00:00 (UTC)
* 現象   : 2026-07-27 21:00:00 (UTC)を境に水準が 11.81から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.212σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.824, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.495, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host04-004 active_connections の推移](charts/EVT-20260727-host04-004.svg)

# イベントID( EVT-20260727-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→14→13→15→…→15→14→13→14
* 開始   : 2026-07-27 03:30:00 (UTC)
* 終了   : 2026-07-27 19:50:00 (UTC)
* 現象   : 2026-07-27 19:50:00 (UTC)を境に水準が 11.78から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.802, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.232, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host04-005 active_connections の推移](charts/EVT-20260727-host04-005.svg)

# イベントID( EVT-20260727-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 17→16→17→15→…→15→12→13→12
* 開始   : 2026-07-27 04:15:00 (UTC)
* 終了   : 2026-07-27 19:55:00 (UTC)
* 現象   : 2026-07-27 19:55:00 (UTC)を境に水準が 11.91から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.114, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host04-006 active_connections の推移](charts/EVT-20260727-host04-006.svg)

# イベントID( EVT-20260701-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 15→16→18→19→…→19→18→17→16
* 開始   : 2026-07-01 06:35:00 (UTC)
* 終了   : 2026-07-01 06:45:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 18→17→21→16→19
* 開始   : 2026-07-01 07:30:00 (UTC)
* 終了   : 2026-07-01 07:30:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 20→20→24→21→18
* 開始   : 2026-07-01 09:15:00 (UTC)
* 終了   : 2026-07-01 09:15:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 21→21→25→21→23
* 開始   : 2026-07-01 10:10:00 (UTC)
* 終了   : 2026-07-01 10:10:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260701-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 21→22→25→27→…→25→27→23→21
* 開始   : 2026-07-01 12:10:00 (UTC)
* 終了   : 2026-07-01 12:15:00 (UTC)
* 現象   : 平常時(21.75)に対し 1.149倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 20→19→16→21→18
* 開始   : 2026-07-01 15:15:00 (UTC)
* 終了   : 2026-07-01 15:15:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.7773(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→17→15→18→14→15→18→14→17
* 開始   : 2026-07-01 16:30:00 (UTC)
* 終了   : 2026-07-01 16:40:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.786(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.858σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260701-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→12→8→10→13
* 開始   : 2026-07-01 20:05:00 (UTC)
* 終了   : 2026-07-01 20:05:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.6275(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 8→7→13→8→6
* 開始   : 2026-07-02 01:40:00 (UTC)
* 終了   : 2026-07-02 01:40:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.642倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.535σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-004 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host04-001 active_connections の推移](charts/EVT-20260702-host04-001.svg)

# イベントID( EVT-20260702-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 16→13→19→15→17
* 開始   : 2026-07-02 06:35:00 (UTC)
* 終了   : 2026-07-02 06:35:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 18→19→22→21→…→22→21→18→19
* 開始   : 2026-07-02 08:05:00 (UTC)
* 終了   : 2026-07-02 08:10:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 20→22→26→22→21
* 開始   : 2026-07-02 11:00:00 (UTC)
* 終了   : 2026-07-02 11:00:00 (UTC)
* 現象   : 平常時(21.25)に対し 1.224倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 21→21→17→23→22
* 開始   : 2026-07-02 12:10:00 (UTC)
* 終了   : 2026-07-02 12:10:00 (UTC)
* 現象   : 平常時(21.83)に対し 0.7786(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 18→17→14→17→20
* 開始   : 2026-07-02 16:10:00 (UTC)
* 終了   : 2026-07-02 16:10:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→15→13→12→13→13→14→13→13
* 開始   : 2026-07-02 18:50:00 (UTC)
* 終了   : 2026-07-02 20:10:00 (UTC)
* 現象   : 2026-07-02 20:10:00 (UTC)を境に水準が 15.05から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.244, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host04-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 14→16→9→14→15
* 開始   : 2026-07-02 18:55:00 (UTC)
* 終了   : 2026-07-02 18:55:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6136(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.975σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260702-host04-015 active_connections の推移](charts/EVT-20260702-host04-015.svg)

# イベントID( EVT-20260702-host04-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→13→7→12→8→7→12→8→10
* 開始   : 2026-07-02 20:00:00 (UTC)
* 終了   : 2026-07-02 21:10:00 (UTC)
* 現象   : 平常時(13)に対し 0.6154(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.5σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260702-host02-020 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host07-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host13-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-077 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 25 分
  - EVT-20260702-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260702-host04-016 active_connections の推移](charts/EVT-20260702-host04-016.svg)

# イベントID( EVT-20260703-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→19→22→18→19
* 開始   : 2026-07-03 07:50:00 (UTC)
* 終了   : 2026-07-03 07:50:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.263倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→19→22→19→20
* 開始   : 2026-07-03 08:20:00 (UTC)
* 終了   : 2026-07-03 08:20:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 22→21→17→20→21
* 開始   : 2026-07-03 13:55:00 (UTC)
* 終了   : 2026-07-03 13:55:00 (UTC)
* 現象   : 平常時(21.58)に対し 0.7876(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.188σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-046 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260703-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 19→19→16→22→19
* 開始   : 2026-07-03 15:10:00 (UTC)
* 終了   : 2026-07-03 15:10:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260703-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 11→9→6→9→9
* 開始   : 2026-07-03 20:45:00 (UTC)
* 終了   : 2026-07-03 20:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.5294(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.709σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-078 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host04-009 active_connections の推移](charts/EVT-20260703-host04-009.svg)

# イベントID( EVT-20260703-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→10→6→10→10
* 開始   : 2026-07-03 21:05:00 (UTC)
* 終了   : 2026-07-03 21:05:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-080 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260703-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→12→10→13→…→12→13→11→14
* 開始   : 2026-07-04 04:40:00 (UTC)
* 終了   : 2026-07-04 18:40:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.767, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260704-host04-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260704-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260704-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260704-host04-002 active_connections の推移](charts/EVT-20260704-host04-002.svg)

# イベントID( EVT-20260704-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 10→12→13→11→…→12→15→13→12
* 開始   : 2026-07-04 05:00:00 (UTC)
* 終了   : 2026-07-04 19:20:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.535σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.828, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260704-host04-003 active_connections の推移](charts/EVT-20260704-host04-003.svg)

# イベントID( EVT-20260704-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→11→9→10→…→13→11→12→10
* 開始   : 2026-07-04 05:05:00 (UTC)
* 終了   : 2026-07-04 18:45:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.743, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260704-host04-004 active_connections の推移](charts/EVT-20260704-host04-004.svg)

# イベントID( EVT-20260704-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→13→10→11→…→13→12→13→12
* 開始   : 2026-07-04 05:45:00 (UTC)
* 終了   : 2026-07-04 20:00:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.781σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.013, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260704-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260704-host04-005 active_connections の推移](charts/EVT-20260704-host04-005.svg)

# イベントID( EVT-20260704-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→15→12→13→…→10→11→12→13
* 開始   : 2026-07-04 06:15:00 (UTC)
* 終了   : 2026-07-04 19:00:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.859, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間

![EVT-20260704-host04-006 active_connections の推移](charts/EVT-20260704-host04-006.svg)

# イベントID( EVT-20260704-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→12→11→13→…→11→12→13→12
* 開始   : 2026-07-04 06:25:00 (UTC)
* 終了   : 2026-07-04 19:05:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.878, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260704-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間

![EVT-20260704-host04-007 active_connections の推移](charts/EVT-20260704-host04-007.svg)

# イベントID( EVT-20260704-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→10→6→10→12
* 開始   : 2026-07-04 20:15:00 (UTC)
* 終了   : 2026-07-04 20:15:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260704-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 8→9→5→9→5→9→5→8→9
* 開始   : 2026-07-04 21:10:00 (UTC)
* 終了   : 2026-07-04 21:20:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260704-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260704-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→10→7→10→10
* 開始   : 2026-07-05 19:30:00 (UTC)
* 終了   : 2026-07-05 19:30:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6043(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260705-lsfhost01-038 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260705-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 9→10→4→7→8
* 開始   : 2026-07-05 23:35:00 (UTC)
* 終了   : 2026-07-05 23:35:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 17→18→13→16→15
* 開始   : 2026-07-07 17:25:00 (UTC)
* 終了   : 2026-07-07 17:25:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→10→7→11→10
* 開始   : 2026-07-07 20:30:00 (UTC)
* 終了   : 2026-07-07 20:30:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.5874(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.418σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host04-005 active_connections の推移](charts/EVT-20260707-host04-005.svg)

# イベントID( EVT-20260708-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→17→20→17→16
* 開始   : 2026-07-08 06:30:00 (UTC)
* 終了   : 2026-07-08 06:30:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.36σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→11→8→11→12
* 開始   : 2026-07-08 20:05:00 (UTC)
* 終了   : 2026-07-08 20:05:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260708-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→15→11→14→14
* 開始   : 2026-07-09 18:55:00 (UTC)
* 終了   : 2026-07-09 18:55:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260709-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→11→14→13→10→11→12→11→12
* 開始   : 2026-07-09 19:30:00 (UTC)
* 終了   : 2026-07-09 20:50:00 (UTC)
* 現象   : 2026-07-09 20:50:00 (UTC)を境に水準が 15.03から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.212σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→7→13→11→…→11→12→10→9
* 開始   : 2026-07-10 02:20:00 (UTC)
* 終了   : 2026-07-10 02:30:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-005 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→16→19→16→17
* 開始   : 2026-07-10 06:05:00 (UTC)
* 終了   : 2026-07-10 06:05:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260710-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 21→23→26→22→22
* 開始   : 2026-07-10 12:45:00 (UTC)
* 終了   : 2026-07-10 12:45:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 14→14→11→13→15
* 開始   : 2026-07-10 18:15:00 (UTC)
* 終了   : 2026-07-10 18:15:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 7→7→12→7→9
* 開始   : 2026-07-11 00:35:00 (UTC)
* 終了   : 2026-07-11 00:35:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260711-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 9→9→13→10→10
* 開始   : 2026-07-11 04:15:00 (UTC)
* 終了   : 2026-07-11 04:15:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260711-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260711-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260711-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host04-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→12→10→13→…→12→11→13→11
* 開始   : 2026-07-11 05:10:00 (UTC)
* 終了   : 2026-07-11 19:10:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.754, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.0 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260711-host04-004 active_connections の推移](charts/EVT-20260711-host04-004.svg)

# イベントID( EVT-20260711-host04-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→11→10→9→…→11→9→7→11
* 開始   : 2026-07-11 05:10:00 (UTC)
* 終了   : 2026-07-11 19:10:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.886, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.0 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260711-host04-005 active_connections の推移](charts/EVT-20260711-host04-005.svg)

# イベントID( EVT-20260711-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→12→14→16→…→11→13→14→10
* 開始   : 2026-07-11 05:45:00 (UTC)
* 終了   : 2026-07-11 18:35:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.892, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260711-host04-006 active_connections の推移](charts/EVT-20260711-host04-006.svg)

# イベントID( EVT-20260711-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→10→12→10→…→13→12→14→12
* 開始   : 2026-07-11 06:10:00 (UTC)
* 終了   : 2026-07-11 20:05:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.219, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 13.9 時間
  - EVT-20260711-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260711-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260711-host04-007 active_connections の推移](charts/EVT-20260711-host04-007.svg)

# イベントID( EVT-20260711-host04-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→10→11→12→…→10→12→13→12
* 開始   : 2026-07-11 06:20:00 (UTC)
* 終了   : 2026-07-11 19:40:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.083, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260711-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260711-host04-008 active_connections の推移](charts/EVT-20260711-host04-008.svg)

# イベントID( EVT-20260711-host04-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→12→13→12→…→12→9→12→11
* 開始   : 2026-07-11 06:50:00 (UTC)
* 終了   : 2026-07-11 19:00:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.209, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260711-host04-009 active_connections の推移](charts/EVT-20260711-host04-009.svg)

# イベントID( EVT-20260712-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 7→9→13→6→7
* 開始   : 2026-07-12 03:10:00 (UTC)
* 終了   : 2026-07-12 03:10:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.608倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.442σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→12→8→12→13
* 開始   : 2026-07-12 18:15:00 (UTC)
* 終了   : 2026-07-12 18:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260712-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host04-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→15→16→14→…→15→14→12→14
* 開始   : 2026-07-13 02:35:00 (UTC)
* 終了   : 2026-07-13 21:35:00 (UTC)
* 現象   : 2026-07-13 21:35:00 (UTC)を境に水準が 11.75から14.9へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.695, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.132, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→11→15→10→14
* 開始   : 2026-07-14 04:25:00 (UTC)
* 終了   : 2026-07-14 04:25:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.452倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→13→10→12→12
* 開始   : 2026-07-14 18:45:00 (UTC)
* 終了   : 2026-07-14 18:45:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→13→16→13→13
* 開始   : 2026-07-15 04:35:00 (UTC)
* 終了   : 2026-07-15 04:35:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260715-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 20→19→24→20→21
* 開始   : 2026-07-15 09:35:00 (UTC)
* 終了   : 2026-07-15 09:35:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.13σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→13→9→12→12
* 開始   : 2026-07-15 19:00:00 (UTC)
* 終了   : 2026-07-15 19:00:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.6391(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.535σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260715-host04-006 active_connections の推移](charts/EVT-20260715-host04-006.svg)

# イベントID( EVT-20260715-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→12→5→6→8→12→5→6→8
* 開始   : 2026-07-15 21:55:00 (UTC)
* 終了   : 2026-07-15 22:00:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.4762(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.835σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 4.047 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host04-008 active_connections の推移](charts/EVT-20260715-host04-008.svg)

# イベントID( EVT-20260716-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→9→13→9→9
* 開始   : 2026-07-16 02:45:00 (UTC)
* 終了   : 2026-07-16 02:45:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→14→10→11→…→11→8→11→15
* 開始   : 2026-07-16 19:10:00 (UTC)
* 終了   : 2026-07-16 19:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.246σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-076 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260716-host04-010 active_connections の推移](charts/EVT-20260716-host04-010.svg)

# イベントID( EVT-20260716-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→13→8→10→13
* 開始   : 2026-07-16 19:55:00 (UTC)
* 終了   : 2026-07-16 19:55:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.6194(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260716-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→11→6→10→10
* 開始   : 2026-07-16 21:00:00 (UTC)
* 終了   : 2026-07-16 21:00:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.5414(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host04-012 active_connections の推移](charts/EVT-20260716-host04-012.svg)

# イベントID( EVT-20260716-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 11→10→5→10→10
* 開始   : 2026-07-16 22:35:00 (UTC)
* 終了   : 2026-07-16 22:35:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.13σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260716-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→11→16→11→13
* 開始   : 2026-07-17 04:30:00 (UTC)
* 終了   : 2026-07-17 04:30:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.512倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.8σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host04-001 active_connections の推移](charts/EVT-20260717-host04-001.svg)

# イベントID( EVT-20260717-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→15→18→14→14
* 開始   : 2026-07-17 05:40:00 (UTC)
* 終了   : 2026-07-17 05:40:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→12→7→9→8
* 開始   : 2026-07-17 20:55:00 (UTC)
* 終了   : 2026-07-17 20:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260717-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→9→14→10→10
* 開始   : 2026-07-18 03:55:00 (UTC)
* 終了   : 2026-07-18 03:55:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260718-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260718-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host04-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→13→11→12→…→10→12→13→10
* 開始   : 2026-07-18 05:35:00 (UTC)
* 終了   : 2026-07-18 18:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.274, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host04-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260718-host04-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260718-host04-004 active_connections の推移](charts/EVT-20260718-host04-004.svg)

# イベントID( EVT-20260718-host04-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→11→9→11→…→11→13→12→11
* 開始   : 2026-07-18 05:40:00 (UTC)
* 終了   : 2026-07-18 18:15:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.892, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260718-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260718-host04-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260718-host04-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260718-host04-005 active_connections の推移](charts/EVT-20260718-host04-005.svg)

# イベントID( EVT-20260718-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→11→13→11→…→14→11→14→13
* 開始   : 2026-07-18 05:55:00 (UTC)
* 終了   : 2026-07-18 19:00:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.774, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260718-host04-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260718-host04-007 active_connections の推移](charts/EVT-20260718-host04-007.svg)

# イベントID( EVT-20260718-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→11→13→11→…→12→11→14→13
* 開始   : 2026-07-18 06:00:00 (UTC)
* 終了   : 2026-07-18 18:30:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.811, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host04-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260718-host04-008 active_connections の推移](charts/EVT-20260718-host04-008.svg)

# イベントID( EVT-20260718-host04-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→14→12→14→…→12→11→12→11
* 開始   : 2026-07-18 06:15:00 (UTC)
* 終了   : 2026-07-18 19:20:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.068, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host04-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260718-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260718-host04-009 active_connections の推移](charts/EVT-20260718-host04-009.svg)

# イベントID( EVT-20260718-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→12→13→15→…→12→13→10→11
* 開始   : 2026-07-18 06:55:00 (UTC)
* 終了   : 2026-07-18 19:35:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.037σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.862, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260718-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260718-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260718-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260718-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260718-host04-010 active_connections の推移](charts/EVT-20260718-host04-010.svg)

# イベントID( EVT-20260719-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→16→11→15→16
* 開始   : 2026-07-19 10:45:00 (UTC)
* 終了   : 2026-07-19 10:45:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.6984(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→11→9→12→14
* 開始   : 2026-07-19 17:30:00 (UTC)
* 終了   : 2026-07-19 17:30:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260719-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host04-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 16→17→16→15→…→14→15→12→13
* 開始   : 2026-07-20 03:00:00 (UTC)
* 終了   : 2026-07-20 19:20:00 (UTC)
* 現象   : 2026-07-20 19:20:00 (UTC)を境に水準が 11.81から15へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.913, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host04-003 active_connections の推移](charts/EVT-20260720-host04-003.svg)

# イベントID( EVT-20260720-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 11→12→7→13→12
* 開始   : 2026-07-20 20:40:00 (UTC)
* 終了   : 2026-07-20 20:40:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260720-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→14→17→14→13
* 開始   : 2026-07-21 05:10:00 (UTC)
* 終了   : 2026-07-21 05:10:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.437倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.603σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host04-002 active_connections の推移](charts/EVT-20260721-host04-002.svg)

# イベントID( EVT-20260721-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 17→18→21→17→17
* 開始   : 2026-07-21 07:50:00 (UTC)
* 終了   : 2026-07-21 07:50:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 22→21→26→24→24
* 開始   : 2026-07-21 11:05:00 (UTC)
* 終了   : 2026-07-21 11:05:00 (UTC)
* 現象   : 平常時(21.25)に対し 1.224倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→9→7→10→9
* 開始   : 2026-07-21 20:45:00 (UTC)
* 終了   : 2026-07-21 20:45:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→11→9→12→12→9
* 開始   : 2026-07-21 21:25:00 (UTC)
* 終了   : 2026-07-21 22:15:00 (UTC)
* 現象   : 2026-07-21 22:15:00 (UTC)を境に水準が 15.03から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.212σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→7→4→11→6
* 開始   : 2026-07-21 23:50:00 (UTC)
* 終了   : 2026-07-21 23:50:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260721-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 8→7→4→9→8
* 開始   : 2026-07-22 00:40:00 (UTC)
* 終了   : 2026-07-22 00:40:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260722-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 18→20→21→22→…→21→22→19→20
* 開始   : 2026-07-22 08:05:00 (UTC)
* 終了   : 2026-07-22 08:10:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分

![EVT-20260722-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 21→20→25→22→21
* 開始   : 2026-07-22 10:05:00 (UTC)
* 終了   : 2026-07-22 10:05:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260722-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→13→16→12→13
* 開始   : 2026-07-23 04:30:00 (UTC)
* 終了   : 2026-07-23 04:30:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.466倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.545σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host02-003 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260723-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host04-001 active_connections の推移](charts/EVT-20260723-host04-001.svg)

# イベントID( EVT-20260723-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→17→19→13→17→19→13→16
* 開始   : 2026-07-23 05:45:00 (UTC)
* 終了   : 2026-07-23 05:50:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host04-002 active_connections の推移](charts/EVT-20260723-host04-002.svg)

# イベントID( EVT-20260723-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 18→20→22→19→19
* 開始   : 2026-07-23 08:25:00 (UTC)
* 終了   : 2026-07-23 08:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 24→21→17→21→21
* 開始   : 2026-07-23 14:00:00 (UTC)
* 終了   : 2026-07-23 14:00:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.7757(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host04-008 active_connections の推移](charts/EVT-20260723-host04-008.svg)

# イベントID( EVT-20260723-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→19→15→20→19
* 開始   : 2026-07-23 15:50:00 (UTC)
* 終了   : 2026-07-23 15:50:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.7438(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.616σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260723-host04-010 active_connections の推移](charts/EVT-20260723-host04-010.svg)

# イベントID( EVT-20260723-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→15→11→12→15
* 開始   : 2026-07-23 18:30:00 (UTC)
* 終了   : 2026-07-23 18:30:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host14-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 9→6→11→7→…→7→6→8→9
* 開始   : 2026-07-23 21:20:00 (UTC)
* 終了   : 2026-07-23 21:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-076 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260723-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→12→15→12→13
* 開始   : 2026-07-24 04:15:00 (UTC)
* 終了   : 2026-07-24 04:15:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260724-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→16→19→16→16
* 開始   : 2026-07-24 06:30:00 (UTC)
* 終了   : 2026-07-24 06:30:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 21→21→25→22→22
* 開始   : 2026-07-24 10:30:00 (UTC)
* 終了   : 2026-07-24 10:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 20→21→17→21→22
* 開始   : 2026-07-24 14:15:00 (UTC)
* 終了   : 2026-07-24 14:15:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260724-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 21→16→13→16→18
* 開始   : 2026-07-24 16:45:00 (UTC)
* 終了   : 2026-07-24 16:45:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.7123(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.679σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260724-host04-007 active_connections の推移](charts/EVT-20260724-host04-007.svg)

# イベントID( EVT-20260724-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 16→17→13→16→14
* 開始   : 2026-07-24 17:30:00 (UTC)
* 終了   : 2026-07-24 17:30:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260724-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→16→11→15→15
* 開始   : 2026-07-24 18:10:00 (UTC)
* 終了   : 2026-07-24 18:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 7→8→4→9→8
* 開始   : 2026-07-24 23:15:00 (UTC)
* 終了   : 2026-07-24 23:15:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 8→8→13→8→8
* 開始   : 2026-07-25 02:00:00 (UTC)
* 終了   : 2026-07-25 02:00:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.66倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.603σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260725-host04-001 active_connections の推移](charts/EVT-20260725-host04-001.svg)

# イベントID( EVT-20260725-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 11→10→11→10→…→13→14→12→13
* 開始   : 2026-07-25 05:05:00 (UTC)
* 終了   : 2026-07-25 19:25:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.13σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.258, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host04-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260725-host04-003 active_connections の推移](charts/EVT-20260725-host04-003.svg)

# イベントID( EVT-20260725-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→11→10→13→…→11→12→13→14
* 開始   : 2026-07-25 05:40:00 (UTC)
* 終了   : 2026-07-25 18:10:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.325σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.946, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260725-host04-004 active_connections の推移](charts/EVT-20260725-host04-004.svg)

# イベントID( EVT-20260725-host04-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→14→12→14→…→10→12→10→12
* 開始   : 2026-07-25 05:40:00 (UTC)
* 終了   : 2026-07-25 19:20:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.45, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260725-host04-005 active_connections の推移](charts/EVT-20260725-host04-005.svg)

# イベントID( EVT-20260725-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→13→11→14→…→11→12→11→13
* 開始   : 2026-07-25 06:00:00 (UTC)
* 終了   : 2026-07-25 18:45:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.92σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.845, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260725-host04-006 active_connections の推移](charts/EVT-20260725-host04-006.svg)

# イベントID( EVT-20260725-host04-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→15→11→13→…→12→11→10→11
* 開始   : 2026-07-25 06:10:00 (UTC)
* 終了   : 2026-07-25 19:35:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.044, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host04-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260725-host04-007 active_connections の推移](charts/EVT-20260725-host04-007.svg)

# イベントID( EVT-20260725-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→10→12→15→…→13→12→13→10
* 開始   : 2026-07-25 06:35:00 (UTC)
* 終了   : 2026-07-25 18:35:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.755, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.0 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260725-host04-008 active_connections の推移](charts/EVT-20260725-host04-008.svg)

# イベントID( EVT-20260727-host04-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→16→14→16→…→14→12→13→12
* 開始   : 2026-07-27 02:55:00 (UTC)
* 終了   : 2026-07-27 21:10:00 (UTC)
* 現象   : 2026-07-27 21:10:00 (UTC)を境に水準が 11.83から15.05へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.665, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→13→17→15→13
* 開始   : 2026-07-28 05:35:00 (UTC)
* 終了   : 2026-07-28 05:35:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.388倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260728-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 20→18→23→19→21
* 開始   : 2026-07-28 08:45:00 (UTC)
* 終了   : 2026-07-28 08:45:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260728-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 18→18→15→19→18
* 開始   : 2026-07-28 15:55:00 (UTC)
* 終了   : 2026-07-28 15:55:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260728-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 18→20→16→14→…→16→14→16→17
* 開始   : 2026-07-28 16:35:00 (UTC)
* 終了   : 2026-07-28 16:40:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.8458(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 22→22→26→23→22
* 開始   : 2026-07-29 11:45:00 (UTC)
* 終了   : 2026-07-29 11:45:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 18→15→12→16→15
* 開始   : 2026-07-29 18:00:00 (UTC)
* 終了   : 2026-07-29 18:00:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7236(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260729-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→14→18→15→15
* 開始   : 2026-07-30 05:45:00 (UTC)
* 終了   : 2026-07-30 05:45:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 23→24→21→20→23→22→23→22→22
* 開始   : 2026-07-30 13:10:00 (UTC)
* 終了   : 2026-07-30 14:50:00 (UTC)
* 現象   : 2026-07-30 14:50:00 (UTC)を境に水準が 14.88から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.095σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 22→21→18→21→20
* 開始   : 2026-07-30 13:15:00 (UTC)
* 終了   : 2026-07-30 13:15:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 18→16→14→20→14→20→14→16
* 開始   : 2026-07-30 16:40:00 (UTC)
* 終了   : 2026-07-30 16:50:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260730-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 10→12→8→10→10
* 開始   : 2026-07-30 19:45:00 (UTC)
* 終了   : 2026-07-30 19:45:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 10→9→10→12
* 開始   : 2026-07-30 20:40:00 (UTC)
* 終了   : 2026-07-30 21:55:00 (UTC)
* 現象   : 2026-07-30 21:55:00 (UTC)を境に水準が 14.89から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.095σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.998, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 8→7→9→7→8→10→9→9→10
* 開始   : 2026-07-30 23:05:00 (UTC)
* 終了   : 2026-07-31 01:15:00 (UTC)
* 現象   : 2026-07-31 01:15:00 (UTC)を境に水準が 14.97から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 17→15→19→17→17
* 開始   : 2026-07-31 06:30:00 (UTC)
* 終了   : 2026-07-31 06:30:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host04-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host04-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host02-008 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260731-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→22→26→22→23
* 開始   : 2026-07-31 11:55:00 (UTC)
* 終了   : 2026-07-31 11:55:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 17→13→21→18→17→13→21→18→17
* 開始   : 2026-07-31 17:05:00 (UTC)
* 終了   : 2026-07-31 17:10:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7256(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.418σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host04-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260731-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host04-009 active_connections の推移](charts/EVT-20260731-host04-009.svg)

# イベントID( EVT-20260731-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 17→17→13→15→18
* 開始   : 2026-07-31 17:10:00 (UTC)
* 終了   : 2026-07-31 17:10:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7256(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.42σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host04-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host04-010 active_connections の推移](charts/EVT-20260731-host04-010.svg)

# イベントID( EVT-20260731-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→17→11→15→16
* 開始   : 2026-07-31 18:20:00 (UTC)
* 終了   : 2026-07-31 18:20:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→13→12→15→13→12→15→14
* 開始   : 2026-07-01 18:25:00 (UTC)
* 終了   : 2026-07-01 18:30:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 16→14→12→13→11→12→13→11→16
* 開始   : 2026-07-01 18:35:00 (UTC)
* 終了   : 2026-07-01 18:45:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260701-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260701-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→8→11→8→11→8→10→11
* 開始   : 2026-07-01 20:30:00 (UTC)
* 終了   : 2026-07-01 20:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-067 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260701-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 9→11→8→12→…→7→9→7→9
* 開始   : 2026-07-01 21:00:00 (UTC)
* 終了   : 2026-07-01 21:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-069 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260701-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host06-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host04-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→9→9→12
* 開始   : 2026-07-01 21:50:00 (UTC)
* 終了   : 2026-07-01 22:05:00 (UTC)
* 現象   : 2026-07-01 22:05:00 (UTC)を境に水準が 14.95から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.435, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host04-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→8→12→13→11→11→13→11→13
* 開始   : 2026-07-02 02:55:00 (UTC)
* 終了   : 2026-07-02 03:45:00 (UTC)
* 現象   : 2026-07-02 03:45:00 (UTC)を境に水準が 14.97から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host04-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→13→11→11→14→9→12→14→11
* 開始   : 2026-07-02 03:20:00 (UTC)
* 終了   : 2026-07-02 04:10:00 (UTC)
* 現象   : 2026-07-02 04:10:00 (UTC)を境に水準が 15.08から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.793, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 15→12→17→14→12→17→14→15
* 開始   : 2026-07-02 05:45:00 (UTC)
* 終了   : 2026-07-02 05:50:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.299倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.748σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260702-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→21→20→22→21→20→22→18→20
* 開始   : 2026-07-02 08:20:00 (UTC)
* 終了   : 2026-07-02 08:30:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.161倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 23→19→25→21→23→19→25→21
* 開始   : 2026-07-02 12:35:00 (UTC)
* 終了   : 2026-07-02 12:40:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8444(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 17→20→20→17→19→18→17→19→19
* 開始   : 2026-07-02 16:30:00 (UTC)
* 終了   : 2026-07-02 17:55:00 (UTC)
* 現象   : 2026-07-02 17:55:00 (UTC)を境に水準が 15.07から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→14→13→14→…→14→19→13→16
* 開始   : 2026-07-02 17:55:00 (UTC)
* 終了   : 2026-07-02 18:05:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260702-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 20→22→24→21→24→21→24→21→22
* 開始   : 2026-07-03 11:05:00 (UTC)
* 終了   : 2026-07-03 11:15:00 (UTC)
* 現象   : 平常時(20.75)に対し 1.157倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 21→22→19→22→19→22→19
* 開始   : 2026-07-03 13:45:00 (UTC)
* 終了   : 2026-07-03 13:50:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260703-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 18→15→12→16→…→12→11→15→12
* 開始   : 2026-07-03 18:30:00 (UTC)
* 終了   : 2026-07-03 18:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host04-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host03-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260703-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→14→12→16→12→16→12→13
* 開始   : 2026-07-03 18:35:00 (UTC)
* 終了   : 2026-07-03 18:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host04-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host03-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260703-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host04-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 9→8→10→8→…→12→10→11→12
* 開始   : 2026-07-04 04:25:00 (UTC)
* 終了   : 2026-07-04 04:50:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.729, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260704-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260704-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 25 分
  - EVT-20260704-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260704-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 20 分
  - EVT-20260704-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260704-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260704-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260704-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 8→10→6→12→9→10→6→12→9
* 開始   : 2026-07-04 21:30:00 (UTC)
* 終了   : 2026-07-04 21:35:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260704-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→11→10→10→11→9→12→10→13
* 開始   : 2026-07-05 03:35:00 (UTC)
* 終了   : 2026-07-05 04:30:00 (UTC)
* 現象   : 2026-07-05 04:30:00 (UTC)を境に水準が 11.93から11.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.83, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→11→14→15→…→14→15→13→12
* 開始   : 2026-07-05 06:05:00 (UTC)
* 終了   : 2026-07-05 06:10:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260705-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 9→10→8→14→…→8→14→12→9
* 開始   : 2026-07-05 18:55:00 (UTC)
* 終了   : 2026-07-05 19:00:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host04-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→9→9→9→10→11→9→10→10
* 開始   : 2026-07-05 20:25:00 (UTC)
* 終了   : 2026-07-05 21:10:00 (UTC)
* 現象   : 2026-07-05 21:10:00 (UTC)を境に水準が 11.79から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→8→6→8→6→8→10
* 開始   : 2026-07-05 21:10:00 (UTC)
* 終了   : 2026-07-05 21:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 11→14→15→13→11→14→15→13
* 開始   : 2026-07-07 04:45:00 (UTC)
* 終了   : 2026-07-07 04:50:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260707-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260707-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→17→15→13→17→15
* 開始   : 2026-07-07 05:40:00 (UTC)
* 終了   : 2026-07-07 05:45:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.325倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.92σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260707-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 18→19→21→19→21→19
* 開始   : 2026-07-07 07:55:00 (UTC)
* 終了   : 2026-07-07 08:00:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.212倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.567σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260707-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 9→12→9→12→9→12→9→7
* 開始   : 2026-07-08 02:25:00 (UTC)
* 終了   : 2026-07-08 02:35:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→11→13→10→13→10→13→10→12
* 開始   : 2026-07-08 03:35:00 (UTC)
* 終了   : 2026-07-08 03:45:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260708-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260708-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→13→15→14→…→14→16→13→15
* 開始   : 2026-07-08 04:05:00 (UTC)
* 終了   : 2026-07-08 05:20:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.55σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 40 分
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260708-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 55 分
  - EVT-20260708-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260708-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260708-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260708-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host04-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 19→20→20→19→18→19→19→22→20
* 開始   : 2026-07-08 07:50:00 (UTC)
* 終了   : 2026-07-08 08:30:00 (UTC)
* 現象   : 2026-07-08 08:30:00 (UTC)を境に水準が 14.96から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.246, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→16→11→15→11→15→11→15→13
* 開始   : 2026-07-08 17:55:00 (UTC)
* 終了   : 2026-07-08 19:05:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.7685(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.741σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host04-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260708-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 50 分

![EVT-20260708-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→14→12→14→12→14→12
* 開始   : 2026-07-08 18:40:00 (UTC)
* 終了   : 2026-07-08 18:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host04-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→12→10→9→12→10→9→12→11
* 開始   : 2026-07-08 19:55:00 (UTC)
* 終了   : 2026-07-08 20:00:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260708-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→9→11→9→11→9→11→10
* 開始   : 2026-07-08 20:10:00 (UTC)
* 終了   : 2026-07-08 20:20:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.549σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host04-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→11→12→11→10→8→8→10→11
* 開始   : 2026-07-08 21:00:00 (UTC)
* 終了   : 2026-07-08 21:50:00 (UTC)
* 現象   : 2026-07-08 21:50:00 (UTC)を境に水準が 14.92から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 8→9→6→9→6→9→8
* 開始   : 2026-07-08 22:30:00 (UTC)
* 終了   : 2026-07-08 22:35:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260708-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 7→10→11→8→…→4→5→9→8
* 開始   : 2026-07-08 23:10:00 (UTC)
* 終了   : 2026-07-08 23:55:00 (UTC)
* 現象   : 45分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-083 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260708-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→8→12→8→12→8→12→9→7
* 開始   : 2026-07-09 02:45:00 (UTC)
* 終了   : 2026-07-09 02:55:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-005 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-006 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host04-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→12→14→14→15→14→14→15→16
* 開始   : 2026-07-09 04:30:00 (UTC)
* 終了   : 2026-07-09 05:15:00 (UTC)
* 現象   : 2026-07-09 05:15:00 (UTC)を境に水準が 14.97から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.087, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→16→14→17→16→14→17→15→14
* 開始   : 2026-07-09 05:15:00 (UTC)
* 終了   : 2026-07-09 05:25:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260709-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 22→20→23→24→…→21→18→21→23
* 開始   : 2026-07-09 09:55:00 (UTC)
* 終了   : 2026-07-09 10:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260709-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260709-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 19→18→15→18→15→18→15→18→16
* 開始   : 2026-07-09 16:40:00 (UTC)
* 終了   : 2026-07-09 16:50:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-056 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host04-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 17→15→16
* 開始   : 2026-07-10 05:10:00 (UTC)
* 終了   : 2026-07-10 05:20:00 (UTC)
* 現象   : 2026-07-10 05:20:00 (UTC)を境に水準が 14.88から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.957, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→13→15→12→…→12→16→15→13
* 開始   : 2026-07-10 05:20:00 (UTC)
* 終了   : 2026-07-10 05:30:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 16→14→18→15→14→18→15→17
* 開始   : 2026-07-10 06:30:00 (UTC)
* 終了   : 2026-07-10 07:25:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.256倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260710-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 15 分
  - EVT-20260710-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260710-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 19→18→20→20→18→17
* 開始   : 2026-07-10 16:20:00 (UTC)
* 終了   : 2026-07-10 17:15:00 (UTC)
* 現象   : 2026-07-10 17:15:00 (UTC)を境に水準が 14.95から12.33へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 18→19→17→19→16→17→15→17→17
* 開始   : 2026-07-10 16:40:00 (UTC)
* 終了   : 2026-07-10 18:20:00 (UTC)
* 現象   : 2026-07-10 18:20:00 (UTC)を境に水準が 15.1から11.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.758, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→12→9→12→9→12→9→10→12
* 開始   : 2026-07-10 20:05:00 (UTC)
* 終了   : 2026-07-10 20:15:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.55σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-076 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260710-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-078 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-080 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 7→9→6→5→…→6→5→8→9
* 開始   : 2026-07-10 23:05:00 (UTC)
* 終了   : 2026-07-10 23:10:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-088 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260710-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host04-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 9→11→7→11→…→7→11→9→8
* 開始   : 2026-07-11 03:35:00 (UTC)
* 終了   : 2026-07-11 03:40:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.752, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260711-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host04-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→12→10→9→9→12→10
* 開始   : 2026-07-12 03:20:00 (UTC)
* 終了   : 2026-07-12 03:50:00 (UTC)
* 現象   : 2026-07-12 03:50:00 (UTC)を境に水準が 11.84から11.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→13→7→6→13→7→6→10→7
* 開始   : 2026-07-12 21:40:00 (UTC)
* 終了   : 2026-07-12 21:50:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.393倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.567σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260712-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-lsfhost01-045 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260712-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→7→5→8→…→8→11→8→9
* 開始   : 2026-07-13 23:30:00 (UTC)
* 終了   : 2026-07-13 23:40:00 (UTC)
* 現象   : 平常時(7.917)に対し 0.6316(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260713-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260713-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260713-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→10→13→12→14→13→12→14→12
* 開始   : 2026-07-14 03:25:00 (UTC)
* 終了   : 2026-07-14 03:35:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-006 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260714-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→12→9→13→…→13→15→14→12
* 開始   : 2026-07-14 04:35:00 (UTC)
* 終了   : 2026-07-14 04:45:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260714-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→14→16→14→16→14→16→12→14
* 開始   : 2026-07-14 04:50:00 (UTC)
* 終了   : 2026-07-14 05:00:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260714-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260714-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 16→15→19→17→…→18→20→18→20
* 開始   : 2026-07-14 07:05:00 (UTC)
* 終了   : 2026-07-14 07:30:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.979σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host04-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260714-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260714-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260714-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 17→16→20→18→20→18→20→19→17
* 開始   : 2026-07-14 07:15:00 (UTC)
* 終了   : 2026-07-14 07:25:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host04-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260714-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 20→21→22→23→…→22→23→19→21
* 開始   : 2026-07-14 08:45:00 (UTC)
* 終了   : 2026-07-14 08:50:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260714-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260714-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 21→22→26→24→…→24→19→24→21
* 開始   : 2026-07-14 12:10:00 (UTC)
* 終了   : 2026-07-14 12:20:00 (UTC)
* 現象   : 平常時(21.92)に対し 1.186倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.838σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260714-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 21→20→16→15→…→16→15→18→17
* 開始   : 2026-07-14 16:00:00 (UTC)
* 終了   : 2026-07-14 16:05:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260714-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 17→16→15→19→…→19→14→16→15
* 開始   : 2026-07-14 16:50:00 (UTC)
* 終了   : 2026-07-14 17:00:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260714-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 16→14→15→14→15→14→18→15
* 開始   : 2026-07-14 17:25:00 (UTC)
* 終了   : 2026-07-14 17:35:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260714-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 7→9→11→9→…→9→12→9→8
* 開始   : 2026-07-15 01:50:00 (UTC)
* 終了   : 2026-07-15 02:00:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→16→15→15→15→18→16
* 開始   : 2026-07-15 05:40:00 (UTC)
* 終了   : 2026-07-15 07:00:00 (UTC)
* 現象   : 2026-07-15 07:00:00 (UTC)を境に水準が 14.87から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.747, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 17→18→19→16→17→18→19→16
* 開始   : 2026-07-15 06:50:00 (UTC)
* 終了   : 2026-07-15 06:55:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260715-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→13→11→10→…→11→10→12→13
* 開始   : 2026-07-15 19:05:00 (UTC)
* 終了   : 2026-07-15 19:10:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260715-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 9→10→12→11→…→11→13→10→11
* 開始   : 2026-07-16 02:55:00 (UTC)
* 終了   : 2026-07-16 03:05:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host04-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260716-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host04-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→10→9→12→12→10→12→13→14
* 開始   : 2026-07-16 03:00:00 (UTC)
* 終了   : 2026-07-16 03:55:00 (UTC)
* 現象   : 2026-07-16 03:55:00 (UTC)を境に水準が 14.87から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.112, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 8→10→12→9→…→9→13→10→11
* 開始   : 2026-07-16 03:05:00 (UTC)
* 終了   : 2026-07-16 03:15:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host04-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260716-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260716-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host04-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 17→20→19→18→20→18
* 開始   : 2026-07-16 07:15:00 (UTC)
* 終了   : 2026-07-16 07:40:00 (UTC)
* 現象   : 2026-07-16 07:40:00 (UTC)を境に水準が 14.9から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 17→20→21→20→21→20
* 開始   : 2026-07-16 08:45:00 (UTC)
* 終了   : 2026-07-16 08:50:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 18→21→22→20→…→21→23→22→23
* 開始   : 2026-07-16 09:20:00 (UTC)
* 終了   : 2026-07-16 09:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260716-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-041 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260716-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260716-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260716-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 20→23→25→18→22→23→25→18→22
* 開始   : 2026-07-16 12:30:00 (UTC)
* 終了   : 2026-07-16 12:35:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.172倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.55σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260716-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host04-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→14→15→13→15→14→12
* 開始   : 2026-07-16 19:05:00 (UTC)
* 終了   : 2026-07-16 19:35:00 (UTC)
* 現象   : 2026-07-16 19:35:00 (UTC)を境に水準が 14.79から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→13→14→7→…→7→8→9→10
* 開始   : 2026-07-16 21:20:00 (UTC)
* 終了   : 2026-07-16 21:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-083 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260716-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260716-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host04-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 10→8→9→9→9→8
* 開始   : 2026-07-16 23:10:00 (UTC)
* 終了   : 2026-07-16 23:35:00 (UTC)
* 現象   : 2026-07-16 23:35:00 (UTC)を境に水準が 14.91から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host04-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host04-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 20→20→19→20→20→18→21→19→22
* 開始   : 2026-07-17 08:00:00 (UTC)
* 終了   : 2026-07-17 09:05:00 (UTC)
* 現象   : 2026-07-17 09:05:00 (UTC)を境に水準が 14.92から14.42へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.493, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host04-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 21→22→23→23→23→21→24→21→24
* 開始   : 2026-07-17 12:15:00 (UTC)
* 終了   : 2026-07-17 13:00:00 (UTC)
* 現象   : 2026-07-17 13:00:00 (UTC)を境に水準が 14.94から13.39へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.495, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→16→12→13→12→13→12→15→14
* 開始   : 2026-07-17 18:20:00 (UTC)
* 終了   : 2026-07-17 19:40:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260717-lsfhost01-079 (他ホスト) lsf_queue / pend : FATAL / 重なり 20 分
  - EVT-20260717-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260717-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-078 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-082 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-083 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分

![EVT-20260717-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host04-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→15→12→13
* 開始   : 2026-07-17 19:10:00 (UTC)
* 終了   : 2026-07-17 19:25:00 (UTC)
* 現象   : 2026-07-17 19:25:00 (UTC)を境に水準が 15.09から12.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.435, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→7→9→8→9→10→7→8→10
* 開始   : 2026-07-17 21:40:00 (UTC)
* 終了   : 2026-07-18 01:10:00 (UTC)
* 現象   : 2026-07-18 01:10:00 (UTC)を境に水準が 14.88から11.83へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.379, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→9→8→8→10→8→9→8→10
* 開始   : 2026-07-18 00:00:00 (UTC)
* 終了   : 2026-07-18 00:50:00 (UTC)
* 現象   : 2026-07-18 00:50:00 (UTC)を境に水準が 15.04から11.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260718-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host04-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→8→9→10→11→8→9→10→11
* 開始   : 2026-07-18 04:50:00 (UTC)
* 終了   : 2026-07-18 04:55:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.794, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260718-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 10→13→10→11→…→10→11→12→14
* 開始   : 2026-07-18 05:45:00 (UTC)
* 終了   : 2026-07-18 05:50:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(10)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.844, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260718-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260718-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 8→12→13→8→12→13→12→13→12
* 開始   : 2026-07-19 04:35:00 (UTC)
* 終了   : 2026-07-19 04:45:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260719-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260719-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260719-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 17→15→19→13→15→19→13→15
* 開始   : 2026-07-19 11:35:00 (UTC)
* 終了   : 2026-07-19 11:40:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260719-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 16→14→18→17→12→18→17→12→17
* 開始   : 2026-07-19 12:50:00 (UTC)
* 終了   : 2026-07-19 13:00:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host04-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 16→17→16→13→14→16→17
* 開始   : 2026-07-19 14:30:00 (UTC)
* 終了   : 2026-07-19 15:00:00 (UTC)
* 現象   : 2026-07-19 15:00:00 (UTC)を境に水準が 11.74から14.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.747, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→14→18→16→14→18→16→15
* 開始   : 2026-07-19 15:30:00 (UTC)
* 終了   : 2026-07-19 15:35:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.615σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260719-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260719-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host04-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→12→13→10→10→11→11
* 開始   : 2026-07-19 19:35:00 (UTC)
* 終了   : 2026-07-19 20:05:00 (UTC)
* 現象   : 2026-07-19 20:05:00 (UTC)を境に水準が 11.85から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 9→10→6→9→6→9→6→8
* 開始   : 2026-07-19 21:20:00 (UTC)
* 終了   : 2026-07-19 21:30:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host02-015 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260719-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host04-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 10→9→10
* 開始   : 2026-07-19 23:35:00 (UTC)
* 終了   : 2026-07-19 23:45:00 (UTC)
* 現象   : 2026-07-19 23:45:00 (UTC)を境に水準が 11.77から14.77へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.749, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 8→10→12→9→10→12→9→10
* 開始   : 2026-07-21 02:45:00 (UTC)
* 終了   : 2026-07-21 02:50:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host04-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 16→15→14→16→17
* 開始   : 2026-07-21 05:15:00 (UTC)
* 終了   : 2026-07-21 05:35:00 (UTC)
* 現象   : 2026-07-21 05:35:00 (UTC)を境に水準が 15.11から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host04-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→14→16→14→14→16→17→17→17
* 開始   : 2026-07-21 05:30:00 (UTC)
* 終了   : 2026-07-21 06:30:00 (UTC)
* 現象   : 2026-07-21 06:30:00 (UTC)を境に水準が 14.86から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→17→19→15→19→15→19→18→14
* 開始   : 2026-07-21 06:55:00 (UTC)
* 終了   : 2026-07-21 07:05:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260721-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→21→23→22→23→22→23→20→21
* 開始   : 2026-07-21 09:15:00 (UTC)
* 終了   : 2026-07-21 09:25:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.567σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host04-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 24→20→20→21→21→22→20→21→21
* 開始   : 2026-07-21 13:30:00 (UTC)
* 終了   : 2026-07-21 15:25:00 (UTC)
* 現象   : 2026-07-21 15:25:00 (UTC)を境に水準が 14.98から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.988, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→10→6→9→6→9→6→9→10
* 開始   : 2026-07-21 22:10:00 (UTC)
* 終了   : 2026-07-21 22:20:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host09-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260721-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 14→18→17→14→18→17→15
* 開始   : 2026-07-22 06:25:00 (UTC)
* 終了   : 2026-07-22 06:30:00 (UTC)
* 現象   : 平常時(14)に対し 1.286倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.806σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host04-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260722-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→17→18→19→…→18→19→18→16
* 開始   : 2026-07-22 06:30:00 (UTC)
* 終了   : 2026-07-22 06:35:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host04-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260722-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 21→20→18→24→…→18→24→21→19
* 開始   : 2026-07-22 14:30:00 (UTC)
* 終了   : 2026-07-22 14:35:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host04-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 21→22→21→22→22→20
* 開始   : 2026-07-22 14:45:00 (UTC)
* 終了   : 2026-07-22 15:10:00 (UTC)
* 現象   : 2026-07-22 15:10:00 (UTC)を境に水準が 15.04から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.056, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→16→13→15→…→14→11→14→13
* 開始   : 2026-07-22 17:50:00 (UTC)
* 終了   : 2026-07-22 18:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-062 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260722-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 16→15→13→12→…→13→12→16→15
* 開始   : 2026-07-22 18:20:00 (UTC)
* 終了   : 2026-07-22 18:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260722-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→13→10→11→10→11→10→11
* 開始   : 2026-07-22 19:45:00 (UTC)
* 終了   : 2026-07-22 19:55:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host15-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260722-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host15-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-074 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 17→19→22→21→19→22→21→19
* 開始   : 2026-07-23 08:55:00 (UTC)
* 終了   : 2026-07-23 09:00:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 19→20→22→20→22→20→22→21→20
* 開始   : 2026-07-23 09:10:00 (UTC)
* 終了   : 2026-07-23 09:20:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host04-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260723-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 18→19→22→18→22→18→22→21→20
* 開始   : 2026-07-23 09:15:00 (UTC)
* 終了   : 2026-07-23 09:25:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host04-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260723-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 22→20→18→24→25→18→24→25→21
* 開始   : 2026-07-23 11:40:00 (UTC)
* 終了   : 2026-07-23 11:50:00 (UTC)
* 現象   : 平常時(22)に対し 0.8182(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.806σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 20→18→19→17→18→19→17→20→21
* 開始   : 2026-07-23 14:45:00 (UTC)
* 終了   : 2026-07-23 14:55:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-048 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260723-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 16→17→16→17→18→15→13→16→15
* 開始   : 2026-07-23 17:15:00 (UTC)
* 終了   : 2026-07-23 18:45:00 (UTC)
* 現象   : 2026-07-23 18:45:00 (UTC)を境に水準が 14.95から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.829, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→9→12→9→12→9→11→12
* 開始   : 2026-07-23 20:05:00 (UTC)
* 終了   : 2026-07-23 20:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host14-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 19→18→21→20→21→20→21→17→19
* 開始   : 2026-07-24 07:40:00 (UTC)
* 終了   : 2026-07-24 07:50:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.212倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 22→19→23→24→20→19→23→24→20
* 開始   : 2026-07-24 09:40:00 (UTC)
* 終了   : 2026-07-24 09:45:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.185倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260724-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 18→17→15→14→15→17→15→14→15
* 開始   : 2026-07-24 16:55:00 (UTC)
* 終了   : 2026-07-24 17:00:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→12→9→8→…→9→8→11→9
* 開始   : 2026-07-24 20:15:00 (UTC)
* 終了   : 2026-07-24 20:20:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260724-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 6→8→5→9→11→5→9→11→7
* 開始   : 2026-07-24 23:25:00 (UTC)
* 終了   : 2026-07-24 23:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260724-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→10→8→10→8→10→12
* 開始   : 2026-07-25 05:00:00 (UTC)
* 終了   : 2026-07-25 05:05:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260725-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host04-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 8→10→9→8→…→10→9→8→10
* 開始   : 2026-07-25 19:55:00 (UTC)
* 終了   : 2026-07-25 20:05:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.921, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260725-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260725-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host04-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→10→8→10→9→9→6→9→11
* 開始   : 2026-07-25 22:50:00 (UTC)
* 終了   : 2026-07-26 00:10:00 (UTC)
* 現象   : 2026-07-26 00:10:00 (UTC)を境に水準が 11.81から11.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.992, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260725-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→16→16→15→15→17→16→16→17
* 開始   : 2026-07-26 09:00:00 (UTC)
* 終了   : 2026-07-26 09:55:00 (UTC)
* 現象   : 2026-07-26 09:55:00 (UTC)を境に水準が 11.92から12.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.304, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→11→8→7→10→11→8→7→10
* 開始   : 2026-07-26 19:45:00 (UTC)
* 終了   : 2026-07-26 19:50:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260726-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→15→18→16→18→16→18→17→16
* 開始   : 2026-07-28 06:40:00 (UTC)
* 終了   : 2026-07-28 06:50:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260728-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 20→21→22→17→…→17→23→20→21
* 開始   : 2026-07-28 09:05:00 (UTC)
* 終了   : 2026-07-28 10:15:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260728-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260728-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260728-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260728-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260728-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host04-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 25→24→24→22→22→23
* 開始   : 2026-07-28 12:10:00 (UTC)
* 終了   : 2026-07-28 12:35:00 (UTC)
* 現象   : 2026-07-28 12:35:00 (UTC)を境に水準が 15.06から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→13→12→11→13→12→11→13
* 開始   : 2026-07-28 18:35:00 (UTC)
* 終了   : 2026-07-28 18:40:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260728-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→14→16→14→16
* 開始   : 2026-07-29 05:35:00 (UTC)
* 終了   : 2026-07-29 05:40:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260729-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 22→23→19→20→23→19→20→19
* 開始   : 2026-07-29 14:25:00 (UTC)
* 終了   : 2026-07-29 14:30:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 22→19→17→18→…→18→16→18→17
* 開始   : 2026-07-29 15:40:00 (UTC)
* 終了   : 2026-07-29 15:50:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-053 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260729-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 18→21→16→18→15→16→18→15→17
* 開始   : 2026-07-29 16:30:00 (UTC)
* 終了   : 2026-07-29 16:40:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host04-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→13→13→11→14→11→12→13→12
* 開始   : 2026-07-29 19:35:00 (UTC)
* 終了   : 2026-07-29 20:15:00 (UTC)
* 現象   : 2026-07-29 20:15:00 (UTC)を境に水準が 14.97から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.978, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→10→9→7→8→7→9→9
* 開始   : 2026-07-29 22:00:00 (UTC)
* 終了   : 2026-07-29 23:40:00 (UTC)
* 現象   : 2026-07-29 23:40:00 (UTC)を境に水準が 14.89から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.408, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 7→6→11→5→…→11→5→7→8
* 開始   : 2026-07-30 00:20:00 (UTC)
* 終了   : 2026-07-30 00:25:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→12→14→15→…→14→15→12→11
* 開始   : 2026-07-30 04:25:00 (UTC)
* 終了   : 2026-07-30 04:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-lsfhost01-024 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-025 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260730-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 21→21→20→20→21→20→20→20→23
* 開始   : 2026-07-30 07:50:00 (UTC)
* 終了   : 2026-07-30 08:50:00 (UTC)
* 現象   : 2026-07-30 08:50:00 (UTC)を境に水準が 15.03から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.288, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 20→22→19→20→…→22→19→22→21
* 開始   : 2026-07-30 08:55:00 (UTC)
* 終了   : 2026-07-30 09:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host04-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260730-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 19→21→23→20→21→23→20→22
* 開始   : 2026-07-30 09:10:00 (UTC)
* 終了   : 2026-07-30 09:15:00 (UTC)
* 現象   : 平常時(19.25)に対し 1.195倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.607σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host04-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→8→7→8→10→8→7→8→10
* 開始   : 2026-07-30 21:15:00 (UTC)
* 終了   : 2026-07-30 21:20:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-085 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260730-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→10→13→10→13→10→11
* 開始   : 2026-07-31 03:40:00 (UTC)
* 終了   : 2026-07-31 03:45:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260731-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→14→16→17→18→14
* 開始   : 2026-07-31 05:15:00 (UTC)
* 終了   : 2026-07-31 05:40:00 (UTC)
* 現象   : 2026-07-31 05:40:00 (UTC)を境に水準が 14.97から14.71へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→16→18→17→18→17→18→16→15
* 開始   : 2026-07-31 06:25:00 (UTC)
* 終了   : 2026-07-31 06:35:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host02-008 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260731-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→16→18→17→18→17→18→15→17
* 開始   : 2026-07-31 06:30:00 (UTC)
* 終了   : 2026-07-31 07:30:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.608σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260731-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260731-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-021 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260731-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260731-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host04-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 24→20→21→25→23→22→24→22→23
* 開始   : 2026-07-31 10:50:00 (UTC)
* 終了   : 2026-07-31 12:15:00 (UTC)
* 現象   : 2026-07-31 12:15:00 (UTC)を境に水準が 15.06から13.35へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 19→17→18→16→17→18→16→19→18
* 開始   : 2026-07-31 15:35:00 (UTC)
* 終了   : 2026-07-31 15:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host04-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→14→12→11→11→11→12→13→13
* 開始   : 2026-07-31 19:30:00 (UTC)
* 終了   : 2026-07-31 20:20:00 (UTC)
* 現象   : 2026-07-31 20:20:00 (UTC)を境に水準が 14.96から11.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.196, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host04-013 )

* イベント種別 : ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→10→7→13→…→7→13→11→10
* 開始   : 2026-07-31 20:55:00 (UTC)
* 終了   : 2026-07-31 21:00:00 (UTC)
* 現象   : 金曜20時台の平常値(10.63)に対し 7であった
* 説明   : ALG-A5: 同じ曜日・時刻帯の平常値から 3.039σ 外れた (平常値=10.63)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260731-host15-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260731-host04-013 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
