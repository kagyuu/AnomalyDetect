# host05 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host05 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 299 (SEVERE: 21, FATAL: 118, WARN: 160, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 21 | 118 | 160 | 299 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260803-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→18→17→18→…→14→13→14→12
* 開始   : 2026-08-03 02:40:00 (UTC)
* 終了   : 2026-08-03 19:55:00 (UTC)
* 現象   : 2026-08-03 19:55:00 (UTC)を境に水準が 11.89から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.784σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.038, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host05-002 active_connections の推移](charts/EVT-20260803-host05-002.svg)

# イベントID( EVT-20260803-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→14→15→16→…→12→13→12→14
* 開始   : 2026-08-03 03:00:00 (UTC)
* 終了   : 2026-08-03 21:45:00 (UTC)
* 現象   : 2026-08-03 21:45:00 (UTC)を境に水準が 11.74から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.682, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host05-004 active_connections の推移](charts/EVT-20260803-host05-004.svg)

# イベントID( EVT-20260803-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→14→…→10→12→10→13
* 開始   : 2026-08-03 03:00:00 (UTC)
* 終了   : 2026-08-03 20:15:00 (UTC)
* 現象   : 2026-08-03 20:15:00 (UTC)を境に水準が 11.9から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.357σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.758, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.437, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host05-005 active_connections の推移](charts/EVT-20260803-host05-005.svg)

# イベントID( EVT-20260803-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→13→16→13→…→11→13→11→13
* 開始   : 2026-08-03 03:15:00 (UTC)
* 終了   : 2026-08-03 19:35:00 (UTC)
* 現象   : 2026-08-03 19:35:00 (UTC)を境に水準が 11.9から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.885, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.924, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host05-006 active_connections の推移](charts/EVT-20260803-host05-006.svg)

# イベントID( EVT-20260803-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→15→16→17→…→14→15→14→15
* 開始   : 2026-08-03 03:30:00 (UTC)
* 終了   : 2026-08-03 21:45:00 (UTC)
* 現象   : 2026-08-03 21:45:00 (UTC)を境に水準が 11.85から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.519σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.26, 限界=2.689)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.081σ 外れた (平常値=20.39)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.473, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host05-007 active_connections の推移](charts/EVT-20260803-host05-007.svg)

# イベントID( EVT-20260810-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→17→16→15→…→13→14→12→13
* 開始   : 2026-08-10 02:00:00 (UTC)
* 終了   : 2026-08-10 21:50:00 (UTC)
* 現象   : 2026-08-10 21:50:00 (UTC)を境に水準が 11.77から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.16σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.777, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.573, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host05-001 active_connections の推移](charts/EVT-20260810-host05-001.svg)

# イベントID( EVT-20260810-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→15→14→13→…→14→12→14→11
* 開始   : 2026-08-10 02:10:00 (UTC)
* 終了   : 2026-08-10 19:35:00 (UTC)
* 現象   : 2026-08-10 19:35:00 (UTC)を境に水準が 11.81から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.852, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host05-002 active_connections の推移](charts/EVT-20260810-host05-002.svg)

# イベントID( EVT-20260810-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 14→15→16→15→…→18→15→11→14
* 開始   : 2026-08-10 02:30:00 (UTC)
* 終了   : 2026-08-10 19:25:00 (UTC)
* 現象   : 2026-08-10 19:25:00 (UTC)を境に水準が 11.78から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.487σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.116, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.919, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host05-003 active_connections の推移](charts/EVT-20260810-host05-003.svg)

# イベントID( EVT-20260810-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→14→19→15→…→11→13→12→11
* 開始   : 2026-08-10 02:40:00 (UTC)
* 終了   : 2026-08-10 22:15:00 (UTC)
* 現象   : 2026-08-10 22:15:00 (UTC)を境に水準が 11.81から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.659, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.43, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host05-004 active_connections の推移](charts/EVT-20260810-host05-004.svg)

# イベントID( EVT-20260810-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→18→14→18→…→12→11→10→11
* 開始   : 2026-08-10 02:50:00 (UTC)
* 終了   : 2026-08-10 19:55:00 (UTC)
* 現象   : 2026-08-10 19:55:00 (UTC)を境に水準が 11.76から14.83へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.376σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.78, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host05-005 active_connections の推移](charts/EVT-20260810-host05-005.svg)

# イベントID( EVT-20260817-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→16→17→15→…→15→17→15→16
* 開始   : 2026-08-17 02:35:00 (UTC)
* 終了   : 2026-08-17 19:45:00 (UTC)
* 現象   : 2026-08-17 19:45:00 (UTC)を境に水準が 11.81から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.982, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host05-002 active_connections の推移](charts/EVT-20260817-host05-002.svg)

# イベントID( EVT-20260817-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→13→15→14→…→13→12→11→13
* 開始   : 2026-08-17 02:55:00 (UTC)
* 終了   : 2026-08-17 22:00:00 (UTC)
* 現象   : 2026-08-17 22:00:00 (UTC)を境に水準が 11.87から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.737, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.864, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host05-003 active_connections の推移](charts/EVT-20260817-host05-003.svg)

# イベントID( EVT-20260817-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→17→18→16→…→12→14→12→11
* 開始   : 2026-08-17 03:05:00 (UTC)
* 終了   : 2026-08-17 20:15:00 (UTC)
* 現象   : 2026-08-17 20:15:00 (UTC)を境に水準が 11.79から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.79, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host05-004 active_connections の推移](charts/EVT-20260817-host05-004.svg)

# イベントID( EVT-20260817-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 15→17→15→17→…→15→13→15→13
* 開始   : 2026-08-17 03:05:00 (UTC)
* 終了   : 2026-08-17 20:00:00 (UTC)
* 現象   : 2026-08-17 20:00:00 (UTC)を境に水準が 11.96から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.721, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host05-005 active_connections の推移](charts/EVT-20260817-host05-005.svg)

# イベントID( EVT-20260817-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→16→15→14→…→12→14→12→14
* 開始   : 2026-08-17 03:30:00 (UTC)
* 終了   : 2026-08-17 21:15:00 (UTC)
* 現象   : 2026-08-17 21:15:00 (UTC)を境に水準が 11.94から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.758, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host05-006 active_connections の推移](charts/EVT-20260817-host05-006.svg)

# イベントID( EVT-20260817-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→17→15→16→…→13→14→11→12
* 開始   : 2026-08-17 03:50:00 (UTC)
* 終了   : 2026-08-17 20:55:00 (UTC)
* 現象   : 2026-08-17 20:55:00 (UTC)を境に水準が 11.88から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.023σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.044, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host05-007 active_connections の推移](charts/EVT-20260817-host05-007.svg)

# イベントID( EVT-20260821-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→17→15
* 開始   : 2026-08-21 05:40:00 (UTC)
* 終了   : 2026-08-21 05:50:00 (UTC)
* 現象   : 2026-08-21 05:50:00 (UTC)を境に水準が 14.87から14.67へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.709σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 4.721 倍に達した (閾値 3)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.085, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host05-005 active_connections の推移](charts/EVT-20260821-host05-005.svg)

# イベントID( EVT-20260824-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→13→15→16→…→15→14→15→14
* 開始   : 2026-08-24 03:00:00 (UTC)
* 終了   : 2026-08-24 20:20:00 (UTC)
* 現象   : 2026-08-24 20:20:00 (UTC)を境に水準が 11.86から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.841, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host05-002 active_connections の推移](charts/EVT-20260824-host05-002.svg)

# イベントID( EVT-20260824-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→15→18→16→…→15→14→12→13
* 開始   : 2026-08-24 03:10:00 (UTC)
* 終了   : 2026-08-24 20:05:00 (UTC)
* 現象   : 2026-08-24 20:05:00 (UTC)を境に水準が 11.83から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.431σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.609, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.862, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host05-003 active_connections の推移](charts/EVT-20260824-host05-003.svg)

# イベントID( EVT-20260824-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 15→12→15→17→…→15→13→14→16
* 開始   : 2026-08-24 03:30:00 (UTC)
* 終了   : 2026-08-24 19:25:00 (UTC)
* 現象   : 2026-08-24 19:25:00 (UTC)を境に水準が 11.85から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.696, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.93, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host05-004 active_connections の推移](charts/EVT-20260824-host05-004.svg)

# イベントID( EVT-20260824-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→16→17→14→…→14→11→10→14
* 開始   : 2026-08-24 03:55:00 (UTC)
* 終了   : 2026-08-24 20:15:00 (UTC)
* 現象   : 2026-08-24 20:15:00 (UTC)を境に水準が 11.84から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.794σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.998, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host05-005 active_connections の推移](charts/EVT-20260824-host05-005.svg)

# イベントID( EVT-20260801-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→12→11→13→…→13→12→10→13
* 開始   : 2026-08-01 05:10:00 (UTC)
* 終了   : 2026-08-01 19:05:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.769, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260801-host05-001 active_connections の推移](charts/EVT-20260801-host05-001.svg)

# イベントID( EVT-20260801-host05-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→9→11→10→…→10→11→10→11
* 開始   : 2026-08-01 05:20:00 (UTC)
* 終了   : 2026-08-01 18:55:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.809, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260801-host05-002 active_connections の推移](charts/EVT-20260801-host05-002.svg)

# イベントID( EVT-20260801-host05-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→12→10→12→…→12→11→13→12
* 開始   : 2026-08-01 05:35:00 (UTC)
* 終了   : 2026-08-01 18:55:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.903, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260801-host05-003 active_connections の推移](charts/EVT-20260801-host05-003.svg)

# イベントID( EVT-20260801-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→12→…→11→10→12→11
* 開始   : 2026-08-01 05:35:00 (UTC)
* 終了   : 2026-08-01 19:05:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.763, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260801-host05-004 active_connections の推移](charts/EVT-20260801-host05-004.svg)

# イベントID( EVT-20260801-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→11→12→11→…→10→11→13→12
* 開始   : 2026-08-01 06:00:00 (UTC)
* 終了   : 2026-08-01 18:55:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.848, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260801-host05-005 active_connections の推移](charts/EVT-20260801-host05-005.svg)

# イベントID( EVT-20260801-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→12→13→12→…→11→12→11→12
* 開始   : 2026-08-01 06:30:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.726, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260801-host05-006 active_connections の推移](charts/EVT-20260801-host05-006.svg)

# イベントID( EVT-20260802-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→12→15→11→11
* 開始   : 2026-08-02 05:25:00 (UTC)
* 終了   : 2026-08-02 06:05:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260802-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260802-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260802-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260802-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260802-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260802-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260802-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→16→21→15→15
* 開始   : 2026-08-02 10:35:00 (UTC)
* 終了   : 2026-08-02 10:35:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.385倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260802-host05-004 active_connections の推移](charts/EVT-20260802-host05-004.svg)

# イベントID( EVT-20260803-host05-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→16→18→15→…→13→14→13→12
* 開始   : 2026-08-03 02:55:00 (UTC)
* 終了   : 2026-08-03 20:30:00 (UTC)
* 現象   : 2026-08-03 20:30:00 (UTC)を境に水準が 11.87から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.088, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.34, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host05-003 active_connections の推移](charts/EVT-20260803-host05-003.svg)

# イベントID( EVT-20260804-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 17→21→20→23→21→20→23→19→20
* 開始   : 2026-08-04 08:35:00 (UTC)
* 終了   : 2026-08-04 08:45:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260804-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host05-003 active_connections の推移](charts/EVT-20260804-host05-003.svg)

# イベントID( EVT-20260804-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 19→21→24→20→20
* 開始   : 2026-08-04 10:05:00 (UTC)
* 終了   : 2026-08-04 10:05:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 18→19→17→18→17→17→20
* 開始   : 2026-08-04 16:55:00 (UTC)
* 終了   : 2026-08-04 18:15:00 (UTC)
* 現象   : 2026-08-04 18:15:00 (UTC)を境に水準が 14.93から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.61, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 12→11→7→13→9
* 開始   : 2026-08-04 20:40:00 (UTC)
* 終了   : 2026-08-04 20:40:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260804-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→12→10→10
* 開始   : 2026-08-04 21:00:00 (UTC)
* 終了   : 2026-08-04 22:00:00 (UTC)
* 現象   : 2026-08-04 22:00:00 (UTC)を境に水準が 14.95から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 22→19→18→19→20→21→19→22→24
* 開始   : 2026-08-05 07:45:00 (UTC)
* 終了   : 2026-08-05 09:30:00 (UTC)
* 現象   : 2026-08-05 09:30:00 (UTC)を境に水準が 15.09から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.318σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.631, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 22→20→17→19→20
* 開始   : 2026-08-05 14:15:00 (UTC)
* 終了   : 2026-08-05 14:15:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260805-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→14→11→12→14→11→12→14→13
* 開始   : 2026-08-05 18:20:00 (UTC)
* 終了   : 2026-08-05 18:25:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.6984(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host05-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→16→9→12→12
* 開始   : 2026-08-05 18:50:00 (UTC)
* 終了   : 2026-08-05 18:50:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.6102(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.011σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host01-015 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260805-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-053 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260805-host05-010 active_connections の推移](charts/EVT-20260805-host05-010.svg)

# イベントID( EVT-20260805-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→10→7→12→9
* 開始   : 2026-08-05 20:45:00 (UTC)
* 終了   : 2026-08-05 20:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6043(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→12→6→10→10
* 開始   : 2026-08-05 21:15:00 (UTC)
* 終了   : 2026-08-05 21:15:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.5625(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260805-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→10→15→12→11
* 開始   : 2026-08-06 03:55:00 (UTC)
* 終了   : 2026-08-06 03:55:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260806-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→17→21→18→19
* 開始   : 2026-08-06 07:45:00 (UTC)
* 終了   : 2026-08-06 07:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 21→18→24→21→22
* 開始   : 2026-08-06 09:20:00 (UTC)
* 終了   : 2026-08-06 09:20:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.241倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260806-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 21→20→16→22→17→16→22→17→19
* 開始   : 2026-08-06 15:00:00 (UTC)
* 終了   : 2026-08-06 16:05:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260806-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260806-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260806-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 9→8→5→8→8
* 開始   : 2026-08-06 22:15:00 (UTC)
* 終了   : 2026-08-06 22:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260806-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→10→13→10→8
* 開始   : 2026-08-07 02:35:00 (UTC)
* 終了   : 2026-08-07 02:35:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260807-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→13→18→14→17→18→14→17→15
* 開始   : 2026-08-07 05:40:00 (UTC)
* 終了   : 2026-08-07 05:50:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260807-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→15→17→14→…→17→18→15→17
* 開始   : 2026-08-07 06:05:00 (UTC)
* 終了   : 2026-08-07 06:50:00 (UTC)
* 現象   : 45分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-019 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260807-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 17→17→22→17→18
* 開始   : 2026-08-07 07:45:00 (UTC)
* 終了   : 2026-08-07 07:45:00 (UTC)
* 現象   : 平常時(16.75)に対し 1.313倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.677σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host05-006 active_connections の推移](charts/EVT-20260807-host05-006.svg)

# イベントID( EVT-20260807-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 20→21→24→20→19
* 開始   : 2026-08-07 09:30:00 (UTC)
* 終了   : 2026-08-07 09:30:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→19→15→19→18
* 開始   : 2026-08-07 15:55:00 (UTC)
* 終了   : 2026-08-07 15:55:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 17→19→16→14→18→19→16→14→18
* 開始   : 2026-08-07 16:40:00 (UTC)
* 終了   : 2026-08-07 16:45:00 (UTC)
* 現象   : 平常時(19)に対し 0.8421(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260807-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→13→9→13→…→12→13→12→11
* 開始   : 2026-08-08 05:15:00 (UTC)
* 終了   : 2026-08-08 18:20:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.107, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260808-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260808-host05-003 active_connections の推移](charts/EVT-20260808-host05-003.svg)

# イベントID( EVT-20260808-host05-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→11→14→13→…→13→12→14→13
* 開始   : 2026-08-08 05:15:00 (UTC)
* 終了   : 2026-08-08 18:35:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.961, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260808-host05-004 active_connections の推移](charts/EVT-20260808-host05-004.svg)

# イベントID( EVT-20260808-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→11→9→11→…→13→12→13→12
* 開始   : 2026-08-08 05:35:00 (UTC)
* 終了   : 2026-08-08 19:30:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.085, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260808-host05-005 active_connections の推移](charts/EVT-20260808-host05-005.svg)

# イベントID( EVT-20260808-host05-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→12→11→12→…→12→9→11→10
* 開始   : 2026-08-08 05:40:00 (UTC)
* 終了   : 2026-08-08 19:40:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.809, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.0 時間

![EVT-20260808-host05-006 active_connections の推移](charts/EVT-20260808-host05-006.svg)

# イベントID( EVT-20260808-host05-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→11→12→11→…→13→12→13→12
* 開始   : 2026-08-08 05:55:00 (UTC)
* 終了   : 2026-08-08 19:00:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.969, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260808-host05-007 active_connections の推移](charts/EVT-20260808-host05-007.svg)

# イベントID( EVT-20260808-host05-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→13→12→10→…→13→11→14→13
* 開始   : 2026-08-08 06:05:00 (UTC)
* 終了   : 2026-08-08 19:55:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.954, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 13.8 時間

![EVT-20260808-host05-008 active_connections の推移](charts/EVT-20260808-host05-008.svg)

# イベントID( EVT-20260808-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 8→10→5→7→9
* 開始   : 2026-08-08 21:40:00 (UTC)
* 終了   : 2026-08-08 21:40:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260808-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→12→7→12→11
* 開始   : 2026-08-09 18:05:00 (UTC)
* 終了   : 2026-08-09 18:05:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.5526(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.952σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host05-005 active_connections の推移](charts/EVT-20260809-host05-005.svg)

# イベントID( EVT-20260810-host05-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→14→15→16→…→12→14→13→14
* 開始   : 2026-08-10 03:25:00 (UTC)
* 終了   : 2026-08-10 20:45:00 (UTC)
* 現象   : 2026-08-10 20:45:00 (UTC)を境に水準が 11.84から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.749, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 8→7→5→4→9→7→5→4→9
* 開始   : 2026-08-10 23:35:00 (UTC)
* 終了   : 2026-08-10 23:40:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.5607(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.732σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260810-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 7→8→4→11→…→4→11→7→8
* 開始   : 2026-08-10 23:45:00 (UTC)
* 終了   : 2026-08-11 00:15:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.4948倍(4)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.848σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host05-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-001 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260810-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260811-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260810-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→14→18→17→14→18→17→14→17
* 開始   : 2026-08-11 06:05:00 (UTC)
* 終了   : 2026-08-11 06:10:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 16→19→20→17→16→19→20→17→14
* 開始   : 2026-08-11 06:30:00 (UTC)
* 終了   : 2026-08-11 06:35:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.253倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.685σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 19→21→24→20→…→20→24→23→21
* 開始   : 2026-08-11 09:40:00 (UTC)
* 終了   : 2026-08-11 10:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.241σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→13→7→10→10
* 開始   : 2026-08-11 20:35:00 (UTC)
* 終了   : 2026-08-11 20:35:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6043(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 21→23→18→22→22
* 開始   : 2026-08-12 13:20:00 (UTC)
* 終了   : 2026-08-12 13:20:00 (UTC)
* 現象   : 平常時(22.58)に対し 0.797(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-038 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260812-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 22→22→17→20→22
* 開始   : 2026-08-12 14:20:00 (UTC)
* 終了   : 2026-08-12 14:20:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-040 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260812-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 16→14→13→15→16→14→13→15→16
* 開始   : 2026-08-12 17:50:00 (UTC)
* 終了   : 2026-08-12 18:15:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260812-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260812-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260812-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260812-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→13→10→12→12
* 開始   : 2026-08-12 18:40:00 (UTC)
* 終了   : 2026-08-12 18:40:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260812-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→16→13→16→16
* 開始   : 2026-08-13 17:15:00 (UTC)
* 終了   : 2026-08-13 17:15:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 17→14→11→15→13
* 開始   : 2026-08-13 18:20:00 (UTC)
* 終了   : 2026-08-13 18:20:00 (UTC)
* 現象   : 平常時(16)に対し 0.6875(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.502σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260813-host05-010 active_connections の推移](charts/EVT-20260813-host05-010.svg)

# イベントID( EVT-20260814-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 10→8→4→6→7
* 開始   : 2026-08-14 00:05:00 (UTC)
* 終了   : 2026-08-14 00:05:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260814-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host05-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→11→14→12→…→11→12→10→11
* 開始   : 2026-08-15 04:20:00 (UTC)
* 終了   : 2026-08-15 18:45:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.991, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260815-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260815-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間
  - EVT-20260815-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260815-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260815-host05-003 active_connections の推移](charts/EVT-20260815-host05-003.svg)

# イベントID( EVT-20260815-host05-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 9→11→9→11→…→12→11→12→11
* 開始   : 2026-08-15 04:50:00 (UTC)
* 終了   : 2026-08-15 18:55:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.977, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260815-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260815-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260815-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260815-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260815-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260815-host05-004 active_connections の推移](charts/EVT-20260815-host05-004.svg)

# イベントID( EVT-20260815-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 16→13→12→14→…→12→11→12→11
* 開始   : 2026-08-15 05:05:00 (UTC)
* 終了   : 2026-08-15 18:30:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.751, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260815-host05-005 active_connections の推移](charts/EVT-20260815-host05-005.svg)

# イベントID( EVT-20260815-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→11→9→11→…→13→12→13→12
* 開始   : 2026-08-15 05:20:00 (UTC)
* 終了   : 2026-08-15 18:25:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.385σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.867, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260815-host05-006 active_connections の推移](charts/EVT-20260815-host05-006.svg)

# イベントID( EVT-20260815-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→10→11→10→…→15→12→15→14
* 開始   : 2026-08-15 05:45:00 (UTC)
* 終了   : 2026-08-15 19:30:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.316, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260815-host05-007 active_connections の推移](charts/EVT-20260815-host05-007.svg)

# イベントID( EVT-20260815-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→14→11→12→…→12→11→13→11
* 開始   : 2026-08-15 06:10:00 (UTC)
* 終了   : 2026-08-15 19:25:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.241σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.823, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260815-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260815-host05-008 active_connections の推移](charts/EVT-20260815-host05-008.svg)

# イベントID( EVT-20260818-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→9→14→13→9→14→13
* 開始   : 2026-08-18 03:50:00 (UTC)
* 終了   : 2026-08-18 03:55:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-008 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260818-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 17→14→12→14
* 開始   : 2026-08-18 05:05:00 (UTC)
* 終了   : 2026-08-18 05:20:00 (UTC)
* 現象   : 2026-08-18 05:20:00 (UTC)を境に水準が 15.06から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.575, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→16→17→18→…→17→18→17→15
* 開始   : 2026-08-18 06:05:00 (UTC)
* 終了   : 2026-08-18 06:40:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260818-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260818-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→15→20→15→16
* 開始   : 2026-08-18 06:30:00 (UTC)
* 終了   : 2026-08-18 06:30:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.364倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.704σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260818-host05-006 active_connections の推移](charts/EVT-20260818-host05-006.svg)

# イベントID( EVT-20260818-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 19→20→24→19→…→19→23→20→21
* 開始   : 2026-08-18 09:25:00 (UTC)
* 終了   : 2026-08-18 09:35:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260818-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→13→8→12→12
* 開始   : 2026-08-18 20:00:00 (UTC)
* 終了   : 2026-08-18 20:00:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.6316(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.241σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260818-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→11→7→10→10
* 開始   : 2026-08-18 20:40:00 (UTC)
* 終了   : 2026-08-18 20:40:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→14→17→13→14
* 開始   : 2026-08-19 04:40:00 (UTC)
* 終了   : 2026-08-19 04:40:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.447倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.667σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host05-004 active_connections の推移](charts/EVT-20260819-host05-004.svg)

# イベントID( EVT-20260819-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 10→14→15→11→10→14→15→11→13
* 開始   : 2026-08-19 04:50:00 (UTC)
* 終了   : 2026-08-19 05:25:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260819-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260819-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260819-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 18→20→18→16→18→20
* 開始   : 2026-08-19 07:00:00 (UTC)
* 終了   : 2026-08-19 07:25:00 (UTC)
* 現象   : 2026-08-19 07:25:00 (UTC)を境に水準が 14.88から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.965, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→14→10→12→14
* 開始   : 2026-08-19 18:55:00 (UTC)
* 終了   : 2026-08-19 18:55:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→16→9→14→11
* 開始   : 2026-08-19 19:25:00 (UTC)
* 終了   : 2026-08-19 19:25:00 (UTC)
* 現象   : 平常時(14)に対し 0.6429(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host05-012 active_connections の推移](charts/EVT-20260819-host05-012.svg)

# イベントID( EVT-20260820-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→13→10→12→13→10→12→10→9
* 開始   : 2026-08-20 02:25:00 (UTC)
* 終了   : 2026-08-20 02:35:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→16→19→15→…→15→18→15→17
* 開始   : 2026-08-20 06:35:00 (UTC)
* 終了   : 2026-08-20 06:45:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.365倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.546σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260820-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260820-host05-005 active_connections の推移](charts/EVT-20260820-host05-005.svg)

# イベントID( EVT-20260820-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 20→21→27→20→23
* 開始   : 2026-08-20 13:55:00 (UTC)
* 終了   : 2026-08-20 13:55:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.251倍(27)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.762σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260820-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 19→18→15→18→18
* 開始   : 2026-08-20 15:55:00 (UTC)
* 終了   : 2026-08-20 15:55:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→19→14→16→16
* 開始   : 2026-08-20 16:40:00 (UTC)
* 終了   : 2026-08-20 16:40:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→16→19→16→…→16→19→16→17
* 開始   : 2026-08-21 06:30:00 (UTC)
* 終了   : 2026-08-21 06:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260821-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 15→15→19→16→15
* 開始   : 2026-08-21 06:30:00 (UTC)
* 終了   : 2026-08-21 06:30:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 24→23→22→22→20→22→22→22
* 開始   : 2026-08-21 14:05:00 (UTC)
* 終了   : 2026-08-21 15:05:00 (UTC)
* 現象   : 2026-08-21 15:05:00 (UTC)を境に水準が 15.01から12.75へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.954, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 17→18→14→17→19
* 開始   : 2026-08-21 16:45:00 (UTC)
* 終了   : 2026-08-21 16:45:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.75(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-049 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→16→13→17→16
* 開始   : 2026-08-21 17:40:00 (UTC)
* 終了   : 2026-08-21 17:40:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→14→18→17→18→17→18→16→15
* 開始   : 2026-08-21 18:00:00 (UTC)
* 終了   : 2026-08-21 18:25:00 (UTC)
* 現象   : 金曜18時台の平常値(14.01)に対し 18であった
* 説明   : ALG-A1: 移動平均からの残差が 3.668σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.117σ 外れた (平常値=14.01)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 25 分
  - EVT-20260821-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260821-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260821-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host05-012 active_connections の推移](charts/EVT-20260821-host05-012.svg)

# イベントID( EVT-20260821-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→15→15→14→14→16→13→13→15
* 開始   : 2026-08-21 18:05:00 (UTC)
* 終了   : 2026-08-21 21:15:00 (UTC)
* 現象   : 2026-08-21 21:15:00 (UTC)を境に水準が 15.1から12.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.344σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.473, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→12→9→11→12
* 開始   : 2026-08-21 19:35:00 (UTC)
* 終了   : 2026-08-21 19:35:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→12→8→11→10
* 開始   : 2026-08-21 20:10:00 (UTC)
* 終了   : 2026-08-21 20:10:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260821-host05-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→11→12→14→…→9→11→9→10
* 開始   : 2026-08-22 04:55:00 (UTC)
* 終了   : 2026-08-22 19:55:00 (UTC)
* 現象   : 15.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.574σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.139, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260822-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260822-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260822-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260822-host05-003 active_connections の推移](charts/EVT-20260822-host05-003.svg)

# イベントID( EVT-20260822-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→11→9→13→…→12→11→12→11
* 開始   : 2026-08-22 05:05:00 (UTC)
* 終了   : 2026-08-22 19:20:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.953, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260822-host05-004 active_connections の推移](charts/EVT-20260822-host05-004.svg)

# イベントID( EVT-20260822-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→13→12→10→…→10→9→10→9
* 開始   : 2026-08-22 05:35:00 (UTC)
* 終了   : 2026-08-22 19:45:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.018, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260822-host05-005 active_connections の推移](charts/EVT-20260822-host05-005.svg)

# イベントID( EVT-20260822-host05-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 11→10→9→11→…→9→12→10→14
* 開始   : 2026-08-22 05:40:00 (UTC)
* 終了   : 2026-08-22 18:50:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.099, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260822-host05-006 active_connections の推移](charts/EVT-20260822-host05-006.svg)

# イベントID( EVT-20260822-host05-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→12→11→14→…→12→10→12→11
* 開始   : 2026-08-22 05:55:00 (UTC)
* 終了   : 2026-08-22 19:50:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.745, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260822-host05-007 active_connections の推移](charts/EVT-20260822-host05-007.svg)

# イベントID( EVT-20260822-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→13→10→12→…→11→10→13→11
* 開始   : 2026-08-22 06:00:00 (UTC)
* 終了   : 2026-08-22 19:30:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.831, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host05-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260822-host05-008 active_connections の推移](charts/EVT-20260822-host05-008.svg)

# イベントID( EVT-20260823-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→17→16→15→14→17→16→15→13
* 開始   : 2026-08-23 07:30:00 (UTC)
* 終了   : 2026-08-23 07:35:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260823-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260823-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host05-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→16→15→16→…→12→14→13→12
* 開始   : 2026-08-24 02:55:00 (UTC)
* 終了   : 2026-08-24 21:15:00 (UTC)
* 現象   : 2026-08-24 21:15:00 (UTC)を境に水準が 11.77から14.93へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.742, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.982, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host05-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→11→14→15→…→15→13→12→13
* 開始   : 2026-08-24 04:00:00 (UTC)
* 終了   : 2026-08-24 21:15:00 (UTC)
* 現象   : 2026-08-24 21:15:00 (UTC)を境に水準が 11.98から14.94へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.659, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→17→21→16→17
* 開始   : 2026-08-25 07:15:00 (UTC)
* 終了   : 2026-08-25 07:15:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.292倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→14→11→14→15
* 開始   : 2026-08-25 18:20:00 (UTC)
* 終了   : 2026-08-25 18:20:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 17→17→21→18→18
* 開始   : 2026-08-26 07:35:00 (UTC)
* 終了   : 2026-08-26 07:35:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.279倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 19→18→22→19→20
* 開始   : 2026-08-26 08:05:00 (UTC)
* 終了   : 2026-08-26 08:05:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 20→19→15→18→17
* 開始   : 2026-08-26 16:05:00 (UTC)
* 終了   : 2026-08-26 16:05:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 18→17→12→15→18
* 開始   : 2026-08-26 16:50:00 (UTC)
* 終了   : 2026-08-26 16:50:00 (UTC)
* 現象   : 平常時(18)に対し 0.6667(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260826-host05-010 active_connections の推移](charts/EVT-20260826-host05-010.svg)

# イベントID( EVT-20260826-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→16→12→16→13→12→16→13→14
* 開始   : 2026-08-26 18:10:00 (UTC)
* 終了   : 2026-08-26 18:35:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.7423(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.893σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host05-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260826-lsfhost01-060 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260826-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260826-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260826-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host05-013 active_connections の推移](charts/EVT-20260826-host05-013.svg)

# イベントID( EVT-20260827-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 8→9→4→8→7
* 開始   : 2026-08-27 00:00:00 (UTC)
* 終了   : 2026-08-27 00:00:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→11→16→12→12
* 開始   : 2026-08-27 04:20:00 (UTC)
* 終了   : 2026-08-27 04:20:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.444倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.43σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 20→21→24→20→21
* 開始   : 2026-08-27 09:15:00 (UTC)
* 終了   : 2026-08-27 09:15:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260827-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 21→22→17→23→24
* 開始   : 2026-08-27 11:00:00 (UTC)
* 終了   : 2026-08-27 11:00:00 (UTC)
* 現象   : 平常時(21.58)に対し 0.7876(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260827-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 20→18→17→18→17→19→14→15→17
* 開始   : 2026-08-27 15:50:00 (UTC)
* 終了   : 2026-08-27 18:25:00 (UTC)
* 現象   : 2026-08-27 18:25:00 (UTC)を境に水準が 14.94から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.281σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.946, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→13→10→14→14
* 開始   : 2026-08-27 19:10:00 (UTC)
* 終了   : 2026-08-27 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→9→5→8→9
* 開始   : 2026-08-27 21:50:00 (UTC)
* 終了   : 2026-08-27 21:50:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.435σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→11→15→12→13
* 開始   : 2026-08-28 04:20:00 (UTC)
* 終了   : 2026-08-28 04:20:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 12→14→16→14→15
* 開始   : 2026-08-28 05:00:00 (UTC)
* 終了   : 2026-08-28 05:00:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 16→14→12→15→13
* 開始   : 2026-08-28 17:50:00 (UTC)
* 終了   : 2026-08-28 17:50:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260828-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 13→11→8→10→…→9→10→14→11
* 開始   : 2026-08-29 05:05:00 (UTC)
* 終了   : 2026-08-29 19:45:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.023σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.266, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260829-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260829-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260829-host05-001 active_connections の推移](charts/EVT-20260829-host05-001.svg)

# イベントID( EVT-20260829-host05-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→12→11→12→…→13→10→11→10
* 開始   : 2026-08-29 05:05:00 (UTC)
* 終了   : 2026-08-29 18:55:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.754, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260829-host05-002 active_connections の推移](charts/EVT-20260829-host05-002.svg)

# イベントID( EVT-20260829-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→12→11→13→…→11→13→11→13
* 開始   : 2026-08-29 05:10:00 (UTC)
* 終了   : 2026-08-29 17:45:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.042, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260829-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260829-host05-003 active_connections の推移](charts/EVT-20260829-host05-003.svg)

# イベントID( EVT-20260829-host05-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 12→13→12→11→…→10→11→10→11
* 開始   : 2026-08-29 05:20:00 (UTC)
* 終了   : 2026-08-29 19:35:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.916, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260829-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260829-host05-004 active_connections の推移](charts/EVT-20260829-host05-004.svg)

# イベントID( EVT-20260829-host05-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→15→11→14→…→11→12→11→12
* 開始   : 2026-08-29 05:30:00 (UTC)
* 終了   : 2026-08-29 19:45:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.816, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260829-host05-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260829-host05-005 active_connections の推移](charts/EVT-20260829-host05-005.svg)

# イベントID( EVT-20260829-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 9→11→13→9→…→11→9→11→9
* 開始   : 2026-08-29 05:35:00 (UTC)
* 終了   : 2026-08-29 19:30:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.969, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host05-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host05-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host05-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host05-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260829-host05-006 active_connections の推移](charts/EVT-20260829-host05-006.svg)

# イベントID( EVT-20260801-host05-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→9→6→11→…→11→7→10→9
* 開始   : 2026-08-01 20:25:00 (UTC)
* 終了   : 2026-08-01 20:35:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(6)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.958, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260801-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260801-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260801-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260801-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→10→10→8→9→10
* 開始   : 2026-08-02 01:00:00 (UTC)
* 終了   : 2026-08-02 01:25:00 (UTC)
* 現象   : 2026-08-02 01:25:00 (UTC)を境に水準が 11.79から11.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→9→12→11→…→11→13→8→10
* 開始   : 2026-08-02 03:15:00 (UTC)
* 終了   : 2026-08-02 03:25:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260802-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260802-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260802-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260802-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→15→15→15→16→13→15→15→15
* 開始   : 2026-08-02 15:00:00 (UTC)
* 終了   : 2026-08-02 15:50:00 (UTC)
* 現象   : 2026-08-02 15:50:00 (UTC)を境に水準が 11.81から14.25へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→9→7→7→9→9→8→7→9
* 開始   : 2026-08-03 00:00:00 (UTC)
* 終了   : 2026-08-03 01:00:00 (UTC)
* 現象   : 2026-08-03 01:00:00 (UTC)を境に水準が 11.79から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.868, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 8→9→6→5→8→9→6→5→8
* 開始   : 2026-08-03 23:25:00 (UTC)
* 終了   : 2026-08-03 23:30:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260803-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260803-host02-012 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260803-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260803-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→8→7→8→9→8→9→9→10
* 開始   : 2026-08-04 00:35:00 (UTC)
* 終了   : 2026-08-04 01:20:00 (UTC)
* 現象   : 2026-08-04 01:20:00 (UTC)を境に水準が 14.81から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.727, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 13→11→15→11→15→11→15→14→11
* 開始   : 2026-08-04 04:25:00 (UTC)
* 終了   : 2026-08-04 04:35:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260804-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260804-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 22→21→25→22→…→22→19→20→21
* 開始   : 2026-08-04 12:20:00 (UTC)
* 終了   : 2026-08-04 12:30:00 (UTC)
* 現象   : 平常時(21.92)に対し 1.141倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260804-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 21→22→18→19→…→19→17→20→19
* 開始   : 2026-08-04 14:25:00 (UTC)
* 終了   : 2026-08-04 14:35:00 (UTC)
* 現象   : 平常時(21.58)に対し 0.834(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.488σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 17→16→14→16→14→16→14→16
* 開始   : 2026-08-04 16:55:00 (UTC)
* 終了   : 2026-08-04 17:05:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.558σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260804-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 19→18→14→17→…→17→13→15→17
* 開始   : 2026-08-04 17:30:00 (UTC)
* 終了   : 2026-08-04 17:40:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→12→13→14→12→13→14
* 開始   : 2026-08-04 18:45:00 (UTC)
* 終了   : 2026-08-04 18:50:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260804-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→12→9→12→9→12→9→12
* 開始   : 2026-08-04 19:55:00 (UTC)
* 終了   : 2026-08-04 20:05:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260804-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 9→12→6→10→9→12→6→10→8
* 開始   : 2026-08-04 22:15:00 (UTC)
* 終了   : 2026-08-04 22:20:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→14→13→12→14→16→15→14→18
* 開始   : 2026-08-05 04:50:00 (UTC)
* 終了   : 2026-08-05 06:10:00 (UTC)
* 現象   : 2026-08-05 06:10:00 (UTC)を境に水準が 14.99から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.461σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.337, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 15→17→19→16→…→16→20→17→18
* 開始   : 2026-08-05 07:00:00 (UTC)
* 終了   : 2026-08-05 07:10:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 18→19→21→22→21→22→20→22
* 開始   : 2026-08-05 08:30:00 (UTC)
* 終了   : 2026-08-05 08:40:00 (UTC)
* 現象   : 平常時(18)に対し 1.167倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 23→23→21→22→24→21→22→22→24
* 開始   : 2026-08-05 10:40:00 (UTC)
* 終了   : 2026-08-05 11:20:00 (UTC)
* 現象   : 2026-08-05 11:20:00 (UTC)を境に水準が 15.06から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.355, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→17→17→19
* 開始   : 2026-08-05 16:50:00 (UTC)
* 終了   : 2026-08-05 17:45:00 (UTC)
* 現象   : 2026-08-05 17:45:00 (UTC)を境に水準が 14.9から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.113, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→16→12→15→12→15→12→13→15
* 開始   : 2026-08-05 18:15:00 (UTC)
* 終了   : 2026-08-05 18:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.766(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host05-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host12-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→12→11→14→12→11→14→13
* 開始   : 2026-08-05 19:05:00 (UTC)
* 終了   : 2026-08-05 19:10:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 9→9→10→10→10→9→11→8→11
* 開始   : 2026-08-06 01:25:00 (UTC)
* 終了   : 2026-08-06 02:10:00 (UTC)
* 現象   : 2026-08-06 02:10:00 (UTC)を境に水準が 15.02から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 10→7→12→8→7→12→8→10
* 開始   : 2026-08-06 02:50:00 (UTC)
* 終了   : 2026-08-06 02:55:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260806-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→11→15→12→11→15→12→13
* 開始   : 2026-08-06 04:30:00 (UTC)
* 終了   : 2026-08-06 04:35:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260806-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 24→23→26
* 開始   : 2026-08-06 12:20:00 (UTC)
* 終了   : 2026-08-06 12:30:00 (UTC)
* 現象   : 2026-08-06 12:30:00 (UTC)を境に水準が 15.05から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.431, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 19→17→15→17→15
* 開始   : 2026-08-06 16:50:00 (UTC)
* 終了   : 2026-08-06 16:55:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host05-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 17→17→15→15→15→15→15→15→14
* 開始   : 2026-08-06 18:00:00 (UTC)
* 終了   : 2026-08-06 18:45:00 (UTC)
* 現象   : 2026-08-06 18:45:00 (UTC)を境に水準が 15.07から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.727, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→11→13→11→13→11→14
* 開始   : 2026-08-06 19:00:00 (UTC)
* 終了   : 2026-08-06 19:10:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.75(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260806-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-062 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260806-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→10→13→10→13→10→13→12
* 開始   : 2026-08-06 19:15:00 (UTC)
* 終了   : 2026-08-06 19:25:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7018(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.951σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260806-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→13→15→14→…→16→17→12→15
* 開始   : 2026-08-07 05:10:00 (UTC)
* 終了   : 2026-08-07 05:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260807-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 14→16→17→14→…→14→18→17→16
* 開始   : 2026-08-07 06:05:00 (UTC)
* 終了   : 2026-08-07 06:15:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-019 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 19→20→23→22→20→23→22→21
* 開始   : 2026-08-07 10:10:00 (UTC)
* 終了   : 2026-08-07 10:15:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260807-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 19→20→17→18→17→18→17→20→18
* 開始   : 2026-08-07 15:25:00 (UTC)
* 終了   : 2026-08-07 15:35:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→9→8→10→12→9→8→10→11
* 開始   : 2026-08-07 20:30:00 (UTC)
* 終了   : 2026-08-07 20:35:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-079 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260807-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-080 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260807-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 6→8→5→8→…→8→11→10→9
* 開始   : 2026-08-08 00:45:00 (UTC)
* 終了   : 2026-08-08 00:55:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260808-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host05-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→10→11→9→…→9→11→9→11
* 開始   : 2026-08-08 04:45:00 (UTC)
* 終了   : 2026-08-08 05:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.866, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260808-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260808-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260808-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260808-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260808-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260808-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260808-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→9→9→10→8→9→10
* 開始   : 2026-08-09 01:55:00 (UTC)
* 終了   : 2026-08-09 02:25:00 (UTC)
* 現象   : 2026-08-09 02:25:00 (UTC)を境に水準が 11.86から11.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.96, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→12→11→13→12→11→11
* 開始   : 2026-08-09 04:50:00 (UTC)
* 終了   : 2026-08-09 05:20:00 (UTC)
* 現象   : 2026-08-09 05:20:00 (UTC)を境に水準が 11.87から12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.609, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 11→12→15→12→15→12→15
* 開始   : 2026-08-09 07:30:00 (UTC)
* 終了   : 2026-08-09 07:35:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260809-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host05-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 16→18→17→18
* 開始   : 2026-08-09 12:15:00 (UTC)
* 終了   : 2026-08-09 12:30:00 (UTC)
* 現象   : 2026-08-09 12:30:00 (UTC)を境に水準が 11.87から13.5へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.575, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host05-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→11→13→10→10→12→12→11→11
* 開始   : 2026-08-09 19:15:00 (UTC)
* 終了   : 2026-08-09 19:55:00 (UTC)
* 現象   : 2026-08-09 19:55:00 (UTC)を境に水準が 11.85から14.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.29, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host05-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 9→10→9→9→9→8→10
* 開始   : 2026-08-10 23:50:00 (UTC)
* 終了   : 2026-08-11 00:20:00 (UTC)
* 現象   : 2026-08-11 00:20:00 (UTC)を境に水準が 14.93から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.006, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→7→11→8→…→8→5→9→5
* 開始   : 2026-08-11 00:10:00 (UTC)
* 終了   : 2026-08-11 00:20:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260810-host05-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260811-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→14→15→16→…→15→16→13→15
* 開始   : 2026-08-11 04:55:00 (UTC)
* 終了   : 2026-08-11 05:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260811-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 19→18→21→22→…→20→22→19→18
* 開始   : 2026-08-11 08:50:00 (UTC)
* 終了   : 2026-08-11 09:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 18→17→16→18→16→18→16→19
* 開始   : 2026-08-11 16:40:00 (UTC)
* 終了   : 2026-08-11 16:50:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→17→14→15→14→15→14→17→16
* 開始   : 2026-08-11 17:30:00 (UTC)
* 終了   : 2026-08-11 17:40:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.5σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260811-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→8→5→8→…→8→11→7→6
* 開始   : 2026-08-12 00:30:00 (UTC)
* 終了   : 2026-08-12 00:40:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分

![EVT-20260812-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 8→11→13→11→13→11→10
* 開始   : 2026-08-12 03:25:00 (UTC)
* 終了   : 2026-08-12 03:30:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.405倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.636σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 17→18→20→17→20→17→20→19
* 開始   : 2026-08-12 07:35:00 (UTC)
* 終了   : 2026-08-12 07:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260812-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 22→19→23→22→19→23→22→20
* 開始   : 2026-08-12 09:40:00 (UTC)
* 終了   : 2026-08-12 09:45:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260812-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 25→23→23→23→21→21→24
* 開始   : 2026-08-12 11:30:00 (UTC)
* 終了   : 2026-08-12 12:00:00 (UTC)
* 現象   : 2026-08-12 12:00:00 (UTC)を境に水準が 14.83から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.837, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 21→17→21→17→19
* 開始   : 2026-08-12 15:15:00 (UTC)
* 終了   : 2026-08-12 15:20:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.5σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 18→20→20→18→20→20→18→18→18
* 開始   : 2026-08-12 15:20:00 (UTC)
* 終了   : 2026-08-12 16:50:00 (UTC)
* 現象   : 2026-08-12 16:50:00 (UTC)を境に水準が 14.93から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.082, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 19→17→15→18→15→18→15→18→16
* 開始   : 2026-08-12 16:30:00 (UTC)
* 終了   : 2026-08-12 16:40:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.8(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.626σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-047 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260812-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260812-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→14→10→14→9→10→14→9→13
* 開始   : 2026-08-12 19:25:00 (UTC)
* 終了   : 2026-08-12 19:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 13→13→12→12→11→13
* 開始   : 2026-08-12 20:05:00 (UTC)
* 終了   : 2026-08-12 20:30:00 (UTC)
* 現象   : 2026-08-12 20:30:00 (UTC)を境に水準が 14.93から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host05-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 11→12→8→10→8→10→8→13→12
* 開始   : 2026-08-12 20:25:00 (UTC)
* 終了   : 2026-08-12 20:35:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260812-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260812-host05-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→12→15→16→…→15→16→13→15
* 開始   : 2026-08-13 05:15:00 (UTC)
* 終了   : 2026-08-13 05:20:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 14→17→16→14→17→16
* 開始   : 2026-08-13 05:50:00 (UTC)
* 終了   : 2026-08-13 05:55:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260813-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host05-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→17→17→17→19→19
* 開始   : 2026-08-13 07:05:00 (UTC)
* 終了   : 2026-08-13 07:30:00 (UTC)
* 現象   : 2026-08-13 07:30:00 (UTC)を境に水準が 14.97から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host05-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 20→23→22→20→23→21→22
* 開始   : 2026-08-13 09:30:00 (UTC)
* 終了   : 2026-08-13 10:00:00 (UTC)
* 現象   : 2026-08-13 10:00:00 (UTC)を境に水準が 14.87から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.006, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 20→21→17→21→…→21→23→21→19
* 開始   : 2026-08-13 14:45:00 (UTC)
* 終了   : 2026-08-13 14:55:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260813-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host05-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 21→21→20→21
* 開始   : 2026-08-13 15:15:00 (UTC)
* 終了   : 2026-08-13 15:30:00 (UTC)
* 現象   : 2026-08-13 15:30:00 (UTC)を境に水準が 14.97から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.113, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 19→20→17→16→19→20→17→16→19
* 開始   : 2026-08-13 15:45:00 (UTC)
* 終了   : 2026-08-13 15:50:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→13→15→13→15→13→15→13→15
* 開始   : 2026-08-13 17:45:00 (UTC)
* 終了   : 2026-08-13 18:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260813-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260813-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260813-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 14→11→9→14→11→9→14→13
* 開始   : 2026-08-13 20:05:00 (UTC)
* 終了   : 2026-08-13 20:10:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→10→10→9→8→11
* 開始   : 2026-08-14 01:45:00 (UTC)
* 終了   : 2026-08-14 02:10:00 (UTC)
* 現象   : 2026-08-14 02:10:00 (UTC)を境に水準が 14.9から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host05-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→12→12→15→13→13→12→13→13
* 開始   : 2026-08-14 03:35:00 (UTC)
* 終了   : 2026-08-14 04:20:00 (UTC)
* 現象   : 2026-08-14 04:20:00 (UTC)を境に水準が 14.95から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.283, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host05-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→13→11→13→14
* 開始   : 2026-08-14 03:50:00 (UTC)
* 終了   : 2026-08-14 04:10:00 (UTC)
* 現象   : 2026-08-14 04:10:00 (UTC)を境に水準が 14.92から14.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.864, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→11→16→17→15→11→16→17→15
* 開始   : 2026-08-14 05:40:00 (UTC)
* 終了   : 2026-08-14 05:45:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 18→17→20→16→20→16→20→18→17
* 開始   : 2026-08-14 07:10:00 (UTC)
* 終了   : 2026-08-14 07:20:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.244倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.732σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 24→24→21→23→23→22
* 開始   : 2026-08-14 12:45:00 (UTC)
* 終了   : 2026-08-14 13:10:00 (UTC)
* 現象   : 2026-08-14 13:10:00 (UTC)を境に水準が 14.95から13.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→20→23→19→17→23→19→17→20
* 開始   : 2026-08-14 15:50:00 (UTC)
* 終了   : 2026-08-14 16:00:00 (UTC)
* 現象   : 平常時(19.92)に対し 1.155倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260814-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 17→13→16→17→13→16
* 開始   : 2026-08-14 17:45:00 (UTC)
* 終了   : 2026-08-14 17:50:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7839(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260814-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260814-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 13→15→11→11→14→11→13→14→11
* 開始   : 2026-08-14 17:55:00 (UTC)
* 終了   : 2026-08-14 20:55:00 (UTC)
* 現象   : 2026-08-14 20:55:00 (UTC)を境に水準が 14.89から11.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.573, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→15→12→15→12→15→12→14
* 開始   : 2026-08-14 18:15:00 (UTC)
* 終了   : 2026-08-14 18:25:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260814-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260814-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host05-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 11→7→10→11→10→10→10
* 開始   : 2026-08-14 22:55:00 (UTC)
* 終了   : 2026-08-14 23:25:00 (UTC)
* 現象   : 2026-08-14 23:25:00 (UTC)を境に水準が 15.03から11.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 8→10→11→12→…→11→12→9→8
* 開始   : 2026-08-15 02:00:00 (UTC)
* 終了   : 2026-08-15 02:05:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host05-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260815-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 8→11→8→12→11→8→12→7→10
* 開始   : 2026-08-15 02:05:00 (UTC)
* 終了   : 2026-08-15 02:15:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host05-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260815-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260815-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-lsfhost01-005 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260815-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host05-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→9→8→11→9→8→11→12
* 開始   : 2026-08-15 19:45:00 (UTC)
* 終了   : 2026-08-15 19:50:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.731, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260815-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 8→11→7→8→11→7→9
* 開始   : 2026-08-15 23:20:00 (UTC)
* 終了   : 2026-08-15 23:25:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260815-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→15→18→16→18→17→15→17→15
* 開始   : 2026-08-16 11:55:00 (UTC)
* 終了   : 2026-08-16 12:45:00 (UTC)
* 現象   : 2026-08-16 12:45:00 (UTC)を境に水準が 11.85から13.64へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→17→16→18→15→14
* 開始   : 2026-08-16 14:05:00 (UTC)
* 終了   : 2026-08-16 14:30:00 (UTC)
* 現象   : 2026-08-16 14:30:00 (UTC)を境に水準が 11.9から14.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 8→9→12→9→…→9→6→8→9
* 開始   : 2026-08-17 01:20:00 (UTC)
* 終了   : 2026-08-17 01:30:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260817-lsfhost01-005 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260817-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260817-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host05-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→9→8→11→9→9→10→10→11
* 開始   : 2026-08-17 21:40:00 (UTC)
* 終了   : 2026-08-17 22:25:00 (UTC)
* 現象   : 2026-08-17 22:25:00 (UTC)を境に水準が 14.83から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 8→9→11→7→11→7→11→10→9
* 開始   : 2026-08-18 02:20:00 (UTC)
* 終了   : 2026-08-18 02:30:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260818-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→10→14→11→14→11→14→12→14
* 開始   : 2026-08-18 04:05:00 (UTC)
* 終了   : 2026-08-18 04:15:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 18→20→19→21→20→19→21→19→20
* 開始   : 2026-08-18 08:05:00 (UTC)
* 終了   : 2026-08-18 08:15:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260818-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 21→20→17→20→…→17→16→19→18
* 開始   : 2026-08-18 16:00:00 (UTC)
* 終了   : 2026-08-18 16:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260818-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260818-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260818-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 17→14→15→17→14→15→16
* 開始   : 2026-08-18 17:15:00 (UTC)
* 終了   : 2026-08-18 17:20:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7925(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→14→12→15→12→15→12→14
* 開始   : 2026-08-18 18:30:00 (UTC)
* 終了   : 2026-08-18 18:40:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→5→7→5→7→5→9→8
* 開始   : 2026-08-18 23:15:00 (UTC)
* 終了   : 2026-08-18 23:25:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.5825(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.488σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 7→11→9→11→9→11→8→10
* 開始   : 2026-08-19 00:50:00 (UTC)
* 終了   : 2026-08-19 01:00:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260819-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 7→11→7→11→7→9
* 開始   : 2026-08-19 01:35:00 (UTC)
* 終了   : 2026-08-19 01:40:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260819-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 8→11→12→11→8→11→12→11→8
* 開始   : 2026-08-19 02:00:00 (UTC)
* 終了   : 2026-08-19 02:05:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260819-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 23→23→22→22→22→24→23
* 開始   : 2026-08-19 10:15:00 (UTC)
* 終了   : 2026-08-19 10:45:00 (UTC)
* 現象   : 2026-08-19 10:45:00 (UTC)を境に水準が 14.98から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.006, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 23→22→19→22→19→22→20
* 開始   : 2026-08-19 13:10:00 (UTC)
* 終了   : 2026-08-19 13:15:00 (UTC)
* 現象   : 平常時(22.58)に対し 0.8413(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.488σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 21→25→23→25→23→25→20
* 開始   : 2026-08-19 13:25:00 (UTC)
* 終了   : 2026-08-19 13:35:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260819-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 21→19→24→18→20→19→24→18→20
* 開始   : 2026-08-19 14:25:00 (UTC)
* 終了   : 2026-08-19 14:30:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 9→7→9→6→7→9→6→10→11
* 開始   : 2026-08-19 21:10:00 (UTC)
* 終了   : 2026-08-19 21:20:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.344σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260819-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 10→9→13→11→…→11→14→13→10
* 開始   : 2026-08-20 03:50:00 (UTC)
* 終了   : 2026-08-20 04:00:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260820-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260820-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→14→16→13→14→16→13→15
* 開始   : 2026-08-20 05:15:00 (UTC)
* 終了   : 2026-08-20 05:20:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→13→17→14→…→14→18→16→15
* 開始   : 2026-08-20 06:10:00 (UTC)
* 終了   : 2026-08-20 06:20:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host02-005 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260820-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 19→20→22→19→20→22→19
* 開始   : 2026-08-20 09:05:00 (UTC)
* 終了   : 2026-08-20 09:10:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260820-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 19→17→16→15→…→16→15→18→19
* 開始   : 2026-08-20 16:25:00 (UTC)
* 終了   : 2026-08-20 16:30:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260820-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 13→12→9→15→16→9→15→16→12
* 開始   : 2026-08-20 19:40:00 (UTC)
* 終了   : 2026-08-20 19:50:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.6835(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.893σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→10→6→8→6→8→6→9
* 開始   : 2026-08-20 21:40:00 (UTC)
* 終了   : 2026-08-20 21:50:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 9→11→13→10→11→13→10→11
* 開始   : 2026-08-21 02:45:00 (UTC)
* 終了   : 2026-08-21 02:50:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.489σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-008 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260821-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 11→12→14→10→…→15→13→15→14
* 開始   : 2026-08-21 04:15:00 (UTC)
* 終了   : 2026-08-21 04:35:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host05-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260821-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260821-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260821-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260821-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260821-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→12→15→13→…→13→8→14→11
* 開始   : 2026-08-21 04:25:00 (UTC)
* 終了   : 2026-08-21 04:35:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.616σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host05-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260821-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260821-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260821-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→13→15→12→…→12→16→14→13
* 開始   : 2026-08-21 04:40:00 (UTC)
* 終了   : 2026-08-21 04:50:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260821-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260821-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 22→24→22→24→24→24→23→22→21
* 開始   : 2026-08-21 10:20:00 (UTC)
* 終了   : 2026-08-21 11:25:00 (UTC)
* 現象   : 2026-08-21 11:25:00 (UTC)を境に水準が 15.13から13.69へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.355, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→12→9→8→…→9→8→11→12
* 開始   : 2026-08-21 20:15:00 (UTC)
* 終了   : 2026-08-21 20:20:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260821-host05-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host05-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→12→6→8→6→8→6→7→9
* 開始   : 2026-08-21 22:15:00 (UTC)
* 終了   : 2026-08-21 22:25:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.6102(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.685σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host08-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host05-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host05-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 9→10→8→9→…→10→9→12→10
* 開始   : 2026-08-22 04:15:00 (UTC)
* 終了   : 2026-08-22 04:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.752, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host05-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260822-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260822-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260822-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260822-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host05-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 9→8→12→10→9→8→12→10→11
* 開始   : 2026-08-22 04:20:00 (UTC)
* 終了   : 2026-08-22 04:25:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.567, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host05-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260822-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260822-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260822-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 9→12→7→9→…→9→7→11→8
* 開始   : 2026-08-22 20:55:00 (UTC)
* 終了   : 2026-08-22 21:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.674σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host05-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260822-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260822-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260822-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260822-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host05-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→9→5→8→9→5→8→9→8
* 開始   : 2026-08-22 21:10:00 (UTC)
* 終了   : 2026-08-22 21:15:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(5)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.823, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host05-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260822-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260822-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host05-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 12→11→12→11→11→10→9→11→11
* 開始   : 2026-08-23 03:20:00 (UTC)
* 終了   : 2026-08-23 04:15:00 (UTC)
* 現象   : 2026-08-23 04:15:00 (UTC)を境に水準が 11.75から11.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.435, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 11→10→14→12→10→14→12→13
* 開始   : 2026-08-23 05:45:00 (UTC)
* 終了   : 2026-08-23 05:50:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260823-lsfhost01-013 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260823-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 12→10→14→12→10→14→12→11
* 開始   : 2026-08-23 06:00:00 (UTC)
* 終了   : 2026-08-23 06:05:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260823-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 14→13→17→17→15→15
* 開始   : 2026-08-23 15:35:00 (UTC)
* 終了   : 2026-08-23 16:00:00 (UTC)
* 現象   : 2026-08-23 16:00:00 (UTC)を境に水準が 11.69から14.27へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.236, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 12→14→10→11→…→11→9→10→11
* 開始   : 2026-08-23 17:25:00 (UTC)
* 終了   : 2026-08-23 17:35:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260823-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host05-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 15→14
* 開始   : 2026-08-23 17:50:00 (UTC)
* 終了   : 2026-08-23 17:55:00 (UTC)
* 現象   : 2026-08-23 17:55:00 (UTC)を境に水準が 11.73から14.57へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host05-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→10→9→10→11→8→9→10→10
* 開始   : 2026-08-23 19:05:00 (UTC)
* 終了   : 2026-08-23 21:40:00 (UTC)
* 現象   : 2026-08-23 21:40:00 (UTC)を境に水準が 11.74から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.293, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 9→13→8→7→13→8→7→8→10
* 開始   : 2026-08-23 20:15:00 (UTC)
* 終了   : 2026-08-23 20:25:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260823-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 9→8→6→11→…→8→11→6→8
* 開始   : 2026-08-23 21:05:00 (UTC)
* 終了   : 2026-08-23 21:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.558σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260823-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260823-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260823-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 9→8→5→7→11→5→7→11→9
* 開始   : 2026-08-25 00:40:00 (UTC)
* 終了   : 2026-08-25 00:50:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260825-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host05-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 10→8→10→9→9→10→10→11→12
* 開始   : 2026-08-25 01:35:00 (UTC)
* 終了   : 2026-08-25 02:45:00 (UTC)
* 現象   : 2026-08-25 02:45:00 (UTC)を境に水準が 14.86から14.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.591, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host05-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 10→9→10→10→11→9→9→10→11
* 開始   : 2026-08-25 02:00:00 (UTC)
* 終了   : 2026-08-25 02:50:00 (UTC)
* 現象   : 2026-08-25 02:50:00 (UTC)を境に水準が 15.02から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 8→11→13→11→…→14→10→14→12
* 開始   : 2026-08-25 03:35:00 (UTC)
* 終了   : 2026-08-25 03:55:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→10→14→13→10→14→13
* 開始   : 2026-08-25 04:20:00 (UTC)
* 終了   : 2026-08-25 04:25:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.519σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 14→10→15→12→…→12→16→10→13
* 開始   : 2026-08-25 05:00:00 (UTC)
* 終了   : 2026-08-25 05:10:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→16→13→16→13→16→13→14→15
* 開始   : 2026-08-25 17:55:00 (UTC)
* 終了   : 2026-08-25 18:05:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260825-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260825-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 12→9→8→11→8→11→8→9→10
* 開始   : 2026-08-25 20:50:00 (UTC)
* 終了   : 2026-08-25 21:00:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-077 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-076 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260825-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260825-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host05-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 7→9→4→6→…→6→11→6→7
* 開始   : 2026-08-26 00:15:00 (UTC)
* 終了   : 2026-08-26 00:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host05-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host05-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 18→22→18→22→18→20
* 開始   : 2026-08-26 08:35:00 (UTC)
* 終了   : 2026-08-26 08:40:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.228倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.86σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 24→21→21→24→23→22→22→21→24
* 開始   : 2026-08-26 11:50:00 (UTC)
* 終了   : 2026-08-26 13:10:00 (UTC)
* 現象   : 2026-08-26 13:10:00 (UTC)を境に水準が 14.87から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.337, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host05-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 23→23→23→23→22→22→24→22→22
* 開始   : 2026-08-26 12:25:00 (UTC)
* 終了   : 2026-08-26 13:15:00 (UTC)
* 現象   : 2026-08-26 13:15:00 (UTC)を境に水準が 14.87から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host05-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 20→21→18→22→…→22→17→22→19
* 開始   : 2026-08-26 14:05:00 (UTC)
* 終了   : 2026-08-26 14:15:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.8372(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.431σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260826-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host05-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 21→17→18→17→18→17→21→20
* 開始   : 2026-08-26 15:00:00 (UTC)
* 終了   : 2026-08-26 15:10:00 (UTC)
* 現象   : 平常時(20.83)に対し 0.816(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.674σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-046 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260826-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260826-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host05-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 16→18→14→13→…→14→13→15→16
* 開始   : 2026-08-26 17:25:00 (UTC)
* 終了   : 2026-08-26 17:30:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260826-host05-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host05-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_2
* 値     : 15→13→15→13→15→13→15
* 開始   : 2026-08-26 18:10:00 (UTC)
* 終了   : 2026-08-26 18:20:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7879(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host05-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260826-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-060 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host05-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 12→9→10→12→9→10
* 開始   : 2026-08-26 20:15:00 (UTC)
* 終了   : 2026-08-26 20:20:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260826-host05-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host05-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 7→8→11→8→11→8
* 開始   : 2026-08-27 01:50:00 (UTC)
* 終了   : 2026-08-27 01:55:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-005 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260827-host05-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 9→11→12→8→11→12→8→9
* 開始   : 2026-08-27 02:35:00 (UTC)
* 終了   : 2026-08-27 02:40:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260827-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host05-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 17→18→21→19→21→19→21→19
* 開始   : 2026-08-27 08:00:00 (UTC)
* 終了   : 2026-08-27 08:10:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.223倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.678σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260827-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 19→18→15→16→14→15→16→14→16
* 開始   : 2026-08-27 16:30:00 (UTC)
* 終了   : 2026-08-27 16:40:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260827-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260827-host05-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host05-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 17→19→14→16→…→15→13→14→13
* 開始   : 2026-08-27 17:30:00 (UTC)
* 終了   : 2026-08-27 18:05:00 (UTC)
* 現象   : 35分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.662σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260827-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260827-host05-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host05-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 15→15→13→14
* 開始   : 2026-08-27 19:10:00 (UTC)
* 終了   : 2026-08-27 20:05:00 (UTC)
* 現象   : 2026-08-27 20:05:00 (UTC)を境に水準が 14.91から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.575, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host05-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host05-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 13→12→9→10→9→10→9→12→11
* 開始   : 2026-08-27 20:00:00 (UTC)
* 終了   : 2026-08-27 20:10:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.6792(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.964σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-lsfhost01-076 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-lsfhost01-075 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260827-host05-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host05-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 11→8→6→7→8→6→7→8
* 開始   : 2026-08-27 22:25:00 (UTC)
* 終了   : 2026-08-27 22:30:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host05-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host05-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→15→18→15→18→17
* 開始   : 2026-08-28 06:40:00 (UTC)
* 終了   : 2026-08-28 07:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.256倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 25 分
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260828-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 20 分
  - EVT-20260828-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host05-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host05-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_3
* 値     : 23→23→23→23→24
* 開始   : 2026-08-28 11:10:00 (UTC)
* 終了   : 2026-08-28 11:30:00 (UTC)
* 現象   : 2026-08-28 11:30:00 (UTC)を境に水準が 15.01から13.54へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.718, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host05-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host05-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 23→20→22→21→18→20→20→21→22
* 開始   : 2026-08-28 14:25:00 (UTC)
* 終了   : 2026-08-28 15:10:00 (UTC)
* 現象   : 2026-08-28 15:10:00 (UTC)を境に水準が 14.97から12.65へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.727, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host05-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host05-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_6
* 値     : 16→15→14→16→14→16→14→16
* 開始   : 2026-08-28 17:05:00 (UTC)
* 終了   : 2026-08-28 17:15:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host05-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host05-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_5
* 値     : 11→9→12→11→9→12
* 開始   : 2026-08-28 20:15:00 (UTC)
* 終了   : 2026-08-28 20:20:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host05-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host05-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host05, port=7003, datasource=OraclePool_1
* 値     : 10→12→7→9→7→9→7→8→9
* 開始   : 2026-08-28 22:00:00 (UTC)
* 終了   : 2026-08-28 22:10:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260828-host05-009 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
