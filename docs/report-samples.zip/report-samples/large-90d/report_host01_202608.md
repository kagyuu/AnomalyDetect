# host01 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host01 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 303 (SEVERE: 20, FATAL: 126, WARN: 157, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 17 | 107 | 130 | 254 | ALG-A1, ALG-A4, ALG-B4 |
| eu | 3 | 19 | 27 | 49 | ALG-A1, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260803-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→17→15→17→…→11→12→15→11
* 開始   : 2026-08-03 01:55:00 (UTC)
* 終了   : 2026-08-03 19:55:00 (UTC)
* 現象   : 2026-08-03 19:55:00 (UTC)を境に水準が 11.84から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.153σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.341, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host01-003 active_connections の推移](charts/EVT-20260803-host01-003.svg)

# イベントID( EVT-20260803-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 15→14→16→15→…→15→12→13→14
* 開始   : 2026-08-03 02:35:00 (UTC)
* 終了   : 2026-08-03 21:25:00 (UTC)
* 現象   : 2026-08-03 21:25:00 (UTC)を境に水準が 11.79から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.677σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.869, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.022, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host01-004 active_connections の推移](charts/EVT-20260803-host01-004.svg)

# イベントID( EVT-20260803-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→14→15→12→…→14→15→11→14
* 開始   : 2026-08-03 02:55:00 (UTC)
* 終了   : 2026-08-03 20:15:00 (UTC)
* 現象   : 2026-08-03 20:15:00 (UTC)を境に水準が 11.86から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.011σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.212, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.847, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host01-005 active_connections の推移](charts/EVT-20260803-host01-005.svg)

# イベントID( EVT-20260803-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→16→14→16→…→14→13→9→13
* 開始   : 2026-08-03 03:15:00 (UTC)
* 終了   : 2026-08-03 20:50:00 (UTC)
* 現象   : 2026-08-03 20:50:00 (UTC)を境に水準が 11.99から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.908, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.381, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host01-007 active_connections の推移](charts/EVT-20260803-host01-007.svg)

# イベントID( EVT-20260803-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 40.59→48.74→50.75→48.67→…→43.65→42.72→44.75→39.4
* 開始   : 2026-08-03 03:45:00 (UTC)
* 終了   : 2026-08-03 21:40:00 (UTC)
* 現象   : 2026-08-03 21:40:00 (UTC)を境に水準が 40.82から50.14へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=8.266, 限界=7.23)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=23.99, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host01-008 eu の推移](charts/EVT-20260803-host01-008.svg)

# イベントID( EVT-20260810-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→15→16→12→…→14→15→13→12
* 開始   : 2026-08-10 02:35:00 (UTC)
* 終了   : 2026-08-10 20:05:00 (UTC)
* 現象   : 2026-08-10 20:05:00 (UTC)を境に水準が 11.88から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.938σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.881, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host01-002 active_connections の推移](charts/EVT-20260810-host01-002.svg)

# イベントID( EVT-20260810-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→16→17→15→…→13→16→12→13
* 開始   : 2026-08-10 03:05:00 (UTC)
* 終了   : 2026-08-10 21:35:00 (UTC)
* 現象   : 2026-08-10 21:35:00 (UTC)を境に水準が 11.89から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.682, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.255, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host01-004 active_connections の推移](charts/EVT-20260810-host01-004.svg)

# イベントID( EVT-20260810-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→17→16→17→…→14→16→14→13
* 開始   : 2026-08-10 03:15:00 (UTC)
* 終了   : 2026-08-10 20:15:00 (UTC)
* 現象   : 2026-08-10 20:15:00 (UTC)を境に水準が 11.96から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.036, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host01-005 active_connections の推移](charts/EVT-20260810-host01-005.svg)

# イベントID( EVT-20260810-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 16→15→16→15→…→13→14→13→11
* 開始   : 2026-08-10 03:45:00 (UTC)
* 終了   : 2026-08-10 19:55:00 (UTC)
* 現象   : 2026-08-10 19:55:00 (UTC)を境に水準が 11.88から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.095σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.077, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host01-006 active_connections の推移](charts/EVT-20260810-host01-006.svg)

# イベントID( EVT-20260810-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→13→14→15→…→15→13→11→14
* 開始   : 2026-08-10 04:05:00 (UTC)
* 終了   : 2026-08-10 20:20:00 (UTC)
* 現象   : 2026-08-10 20:20:00 (UTC)を境に水準が 11.84から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.191, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.894, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host01-007 active_connections の推移](charts/EVT-20260810-host01-007.svg)

# イベントID( EVT-20260817-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→13→16→14→…→11→13→11→12
* 開始   : 2026-08-17 01:50:00 (UTC)
* 終了   : 2026-08-17 20:55:00 (UTC)
* 現象   : 2026-08-17 20:55:00 (UTC)を境に水準が 11.77から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.259σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.944, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.703, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host01-002 active_connections の推移](charts/EVT-20260817-host01-002.svg)

# イベントID( EVT-20260817-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→15→14→13→…→13→14→13→15
* 開始   : 2026-08-17 02:00:00 (UTC)
* 終了   : 2026-08-17 19:45:00 (UTC)
* 現象   : 2026-08-17 19:45:00 (UTC)を境に水準が 11.89から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.679, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.894, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host01-003 active_connections の推移](charts/EVT-20260817-host01-003.svg)

# イベントID( EVT-20260817-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 12→14→15→12→…→12→14→12→13
* 開始   : 2026-08-17 02:30:00 (UTC)
* 終了   : 2026-08-17 20:25:00 (UTC)
* 現象   : 2026-08-17 20:25:00 (UTC)を境に水準が 11.81から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.691, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host01-005 active_connections の推移](charts/EVT-20260817-host01-005.svg)

# イベントID( EVT-20260817-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 42.85→47.92→53.21→44.85→…→41.45→44.71→39.83→45.75
* 開始   : 2026-08-17 02:30:00 (UTC)
* 終了   : 2026-08-17 21:30:00 (UTC)
* 現象   : 2026-08-17 21:30:00 (UTC)を境に水準が 41から49.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.591σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=8.312, 限界=7.23)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=21.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host01-006 eu の推移](charts/EVT-20260817-host01-006.svg)

# イベントID( EVT-20260817-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→18→16→18→…→13→14→13→15
* 開始   : 2026-08-17 03:40:00 (UTC)
* 終了   : 2026-08-17 20:30:00 (UTC)
* 現象   : 2026-08-17 20:30:00 (UTC)を境に水準が 11.87から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.142σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.721, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.708, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host01-008 active_connections の推移](charts/EVT-20260817-host01-008.svg)

# イベントID( EVT-20260824-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→16→17→16→…→13→14→15→13
* 開始   : 2026-08-24 02:05:00 (UTC)
* 終了   : 2026-08-24 22:35:00 (UTC)
* 現象   : 2026-08-24 22:35:00 (UTC)を境に水準が 11.78から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.932, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.09, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host01-002 active_connections の推移](charts/EVT-20260824-host01-002.svg)

# イベントID( EVT-20260824-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 46.89→55.37→54.8→53.61→…→43.15→48.46→43.61→43.3
* 開始   : 2026-08-24 02:10:00 (UTC)
* 終了   : 2026-08-24 20:45:00 (UTC)
* 現象   : 2026-08-24 20:45:00 (UTC)を境に水準が 40.9から50.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.253σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=7.613, 限界=7.23)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=23.99, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host01-003 eu の推移](charts/EVT-20260824-host01-003.svg)

# イベントID( EVT-20260824-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→13→17→11→…→15→11→13→11
* 開始   : 2026-08-24 02:30:00 (UTC)
* 終了   : 2026-08-24 21:55:00 (UTC)
* 現象   : 2026-08-24 21:55:00 (UTC)を境に水準が 11.87から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.739, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host01-004 active_connections の推移](charts/EVT-20260824-host01-004.svg)

# イベントID( EVT-20260824-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→13→17→15→…→14→13→14→13
* 開始   : 2026-08-24 02:50:00 (UTC)
* 終了   : 2026-08-24 20:55:00 (UTC)
* 現象   : 2026-08-24 20:55:00 (UTC)を境に水準が 11.84から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.906, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.795, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host01-005 active_connections の推移](charts/EVT-20260824-host01-005.svg)

# イベントID( EVT-20260824-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→15→17→15→…→13→15→14→12
* 開始   : 2026-08-24 03:30:00 (UTC)
* 終了   : 2026-08-24 20:50:00 (UTC)
* 現象   : 2026-08-24 20:50:00 (UTC)を境に水準が 11.82から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.729σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.972, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.831, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host01-007 active_connections の推移](charts/EVT-20260824-host01-007.svg)

# イベントID( EVT-20260801-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→13→11→12→…→9→15→12→11
* 開始   : 2026-08-01 04:45:00 (UTC)
* 終了   : 2026-08-01 18:25:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.785, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host01-007 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260801-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260801-host01-002 active_connections の推移](charts/EVT-20260801-host01-002.svg)

# イベントID( EVT-20260801-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→14→12→13→…→9→11→12→11
* 開始   : 2026-08-01 05:10:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.962, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host01-007 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260801-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260801-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→14→11→12→…→10→14→10→13
* 開始   : 2026-08-01 05:10:00 (UTC)
* 終了   : 2026-08-01 18:55:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.005, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host01-007 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260801-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260801-host01-004 active_connections の推移](charts/EVT-20260801-host01-004.svg)

# イベントID( EVT-20260801-host01-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→13→…→13→14→12→13
* 開始   : 2026-08-01 05:10:00 (UTC)
* 終了   : 2026-08-01 19:05:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.836, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host01-007 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260801-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260801-host01-005 active_connections の推移](charts/EVT-20260801-host01-005.svg)

# イベントID( EVT-20260801-host01-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 13→16→12→11→…→11→12→10→11
* 開始   : 2026-08-01 05:50:00 (UTC)
* 終了   : 2026-08-01 18:50:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.407, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host01-007 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260801-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260801-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 49.44→39.59→35.56→44.01→…→36.53→36.48→39.89→38.35
* 開始   : 2026-08-01 06:10:00 (UTC)
* 終了   : 2026-08-01 19:00:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-8.769, 限界=7.23)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260801-host01-007 eu の推移](charts/EVT-20260801-host01-007.svg)

# イベントID( EVT-20260801-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→12→14→13→…→10→11→13→11
* 開始   : 2026-08-01 06:45:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.763, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host01-007 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260801-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.0 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.9 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260801-host01-008 active_connections の推移](charts/EVT-20260801-host01-008.svg)

# イベントID( EVT-20260802-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 12→11→15→12→13
* 開始   : 2026-08-02 05:40:00 (UTC)
* 終了   : 2026-08-02 05:40:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260802-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host01-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 16→15→16→15→…→13→15→14→13
* 開始   : 2026-08-03 01:35:00 (UTC)
* 終了   : 2026-08-03 20:50:00 (UTC)
* 現象   : 2026-08-03 20:50:00 (UTC)を境に水準が 11.76から14.98へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.591, 限界=3.181)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.86, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host01-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 15→16→15→16→…→14→13→12→13
* 開始   : 2026-08-03 03:00:00 (UTC)
* 終了   : 2026-08-03 21:10:00 (UTC)
* 現象   : 2026-08-03 21:10:00 (UTC)を境に水準が 11.78から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.801, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.81, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 10→9→12→10→…→10→14→11→10
* 開始   : 2026-08-04 02:50:00 (UTC)
* 終了   : 2026-08-04 03:00:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-006 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260804-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260804-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 16→16→12→15→14
* 開始   : 2026-08-04 17:45:00 (UTC)
* 終了   : 2026-08-04 17:45:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260804-host04-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→14→8→9→12→14→8→9→12
* 開始   : 2026-08-04 19:50:00 (UTC)
* 終了   : 2026-08-04 19:55:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.6275(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host02-015 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260804-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 10→11→7→10→12
* 開始   : 2026-08-04 20:45:00 (UTC)
* 終了   : 2026-08-04 20:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.011σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260804-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 35.11→40.23→45.77→39.82→36.04
* 開始   : 2026-08-05 03:45:00 (UTC)
* 終了   : 2026-08-05 04:35:00 (UTC)
* 現象   : 平常時(34.13)に対し 1.341倍(45.77)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260805-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 14→15→18→12→15
* 開始   : 2026-08-05 05:40:00 (UTC)
* 終了   : 2026-08-05 05:40:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→16→20→18→18
* 開始   : 2026-08-05 07:00:00 (UTC)
* 終了   : 2026-08-05 07:00:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.326倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 20→23→17→21→23→17→21→17→20
* 開始   : 2026-08-05 08:15:00 (UTC)
* 終了   : 2026-08-05 08:25:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.308倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.785σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260805-host01-010 active_connections の推移](charts/EVT-20260805-host01-010.svg)

# イベントID( EVT-20260805-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 19→18→13→18→17
* 開始   : 2026-08-05 16:55:00 (UTC)
* 終了   : 2026-08-05 16:55:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.7123(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.671σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260805-host01-014 active_connections の推移](charts/EVT-20260805-host01-014.svg)

# イベントID( EVT-20260805-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→11→5→9→9
* 開始   : 2026-08-05 21:30:00 (UTC)
* 終了   : 2026-08-05 21:30:00 (UTC)
* 現象   : 平常時(10)に対し 0.5(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host01-016 active_connections の推移](charts/EVT-20260805-host01-016.svg)

# イベントID( EVT-20260806-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 38.01→36.42→32.34→37.94→45.69→36.21→40.31→37.17→39.06
* 開始   : 2026-08-06 02:45:00 (UTC)
* 終了   : 2026-08-06 03:30:00 (UTC)
* 現象   : 2026-08-06 03:30:00 (UTC)を境に水準が 50.04から49.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=23.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 20→19→15→18→18
* 開始   : 2026-08-06 15:55:00 (UTC)
* 終了   : 2026-08-06 15:55:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.7531(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260806-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 16→15→11→14→14
* 開始   : 2026-08-06 18:30:00 (UTC)
* 終了   : 2026-08-06 18:30:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host01-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 7→7→4→7→9
* 開始   : 2026-08-06 22:40:00 (UTC)
* 終了   : 2026-08-06 22:40:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260806-host01-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→11→15→9→12
* 開始   : 2026-08-07 03:10:00 (UTC)
* 終了   : 2026-08-07 03:10:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.552倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.729σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260807-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 15→13→12→13→…→10→11→14→12
* 開始   : 2026-08-08 05:00:00 (UTC)
* 終了   : 2026-08-08 18:10:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.848, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260808-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260808-host01-003 active_connections の推移](charts/EVT-20260808-host01-003.svg)

# イベントID( EVT-20260808-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→13→12→11→…→12→13→12→13
* 開始   : 2026-08-08 05:50:00 (UTC)
* 終了   : 2026-08-08 19:25:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.21, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260808-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260808-host01-004 active_connections の推移](charts/EVT-20260808-host01-004.svg)

# イベントID( EVT-20260808-host01-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 45.18→37.44→40.16→43.06→…→36.07→35.16→40.01→34.42
* 開始   : 2026-08-08 05:55:00 (UTC)
* 終了   : 2026-08-08 19:25:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.563, 限界=7.23)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260808-host01-005 eu の推移](charts/EVT-20260808-host01-005.svg)

# イベントID( EVT-20260808-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→13→11→12→…→13→9→14→11
* 開始   : 2026-08-08 06:00:00 (UTC)
* 終了   : 2026-08-08 19:05:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.474σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.938, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260808-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260808-host01-006 active_connections の推移](charts/EVT-20260808-host01-006.svg)

# イベントID( EVT-20260808-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→13→10→13→…→8→9→11→10
* 開始   : 2026-08-08 06:00:00 (UTC)
* 終了   : 2026-08-08 19:40:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.87, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260808-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260808-host01-007 active_connections の推移](charts/EVT-20260808-host01-007.svg)

# イベントID( EVT-20260808-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→10→12→11→…→9→10→9→10
* 開始   : 2026-08-08 06:10:00 (UTC)
* 終了   : 2026-08-08 19:45:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.793σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.91, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260808-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260808-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260808-host01-008 active_connections の推移](charts/EVT-20260808-host01-008.svg)

# イベントID( EVT-20260808-host01-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 15→12→13→11→…→12→13→12→13
* 開始   : 2026-08-08 06:20:00 (UTC)
* 終了   : 2026-08-08 18:00:00 (UTC)
* 現象   : 11.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.417, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 11.7 時間
  - EVT-20260808-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host02-006 (他ホスト) jvm_gc / ou : FATAL / 重なり 11.7 時間
  - EVT-20260808-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間

![EVT-20260808-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→8→4→8→7
* 開始   : 2026-08-08 22:35:00 (UTC)
* 終了   : 2026-08-08 22:35:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260808-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host01-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 44.39→49.81→53.14→54→…→47.89→43.19→40.8→41.47
* 開始   : 2026-08-10 00:45:00 (UTC)
* 終了   : 2026-08-10 22:00:00 (UTC)
* 現象   : 2026-08-10 22:00:00 (UTC)を境に水準が 40.71から49.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=7.85, 限界=7.23)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=27.86, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 15→17→15→17→…→18→17→15→16
* 開始   : 2026-08-10 02:45:00 (UTC)
* 終了   : 2026-08-10 19:15:00 (UTC)
* 現象   : 2026-08-10 19:15:00 (UTC)を境に水準が 11.92から14.9へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.268, 限界=3.181)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.93, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 48.7→40.99→55.58→44.25→46.84
* 開始   : 2026-08-11 05:30:00 (UTC)
* 終了   : 2026-08-11 05:30:00 (UTC)
* 現象   : 平常時(44.52)に対し 1.248倍(55.58)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.057σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 63.5→55.47→73.36→63→56.1
* 開始   : 2026-08-11 08:35:00 (UTC)
* 終了   : 2026-08-11 08:35:00 (UTC)
* 現象   : 平常時(59.67)に対し 1.229倍(73.36)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.783σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260811-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host01-005 eu の推移](charts/EVT-20260811-host01-005.svg)

# イベントID( EVT-20260811-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 21→18→24→19→20
* 開始   : 2026-08-11 09:35:00 (UTC)
* 終了   : 2026-08-11 09:35:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 17→14→20→14→15
* 開始   : 2026-08-11 18:05:00 (UTC)
* 終了   : 2026-08-11 18:05:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→11→8→11→10
* 開始   : 2026-08-11 20:20:00 (UTC)
* 終了   : 2026-08-11 20:20:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host10-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→9→4→8→9
* 開始   : 2026-08-11 23:30:00 (UTC)
* 終了   : 2026-08-11 23:30:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.4364(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.62σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 8→7→12→8→9
* 開始   : 2026-08-12 00:50:00 (UTC)
* 終了   : 2026-08-12 00:50:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-003 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260811-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260812-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→12→15→9→11→12→15→9→11
* 開始   : 2026-08-12 04:45:00 (UTC)
* 終了   : 2026-08-12 05:40:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260812-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260812-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260812-host01-004 active_connections の推移](charts/EVT-20260812-host01-004.svg)

# イベントID( EVT-20260812-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 19→19→14→18→16
* 開始   : 2026-08-12 16:40:00 (UTC)
* 終了   : 2026-08-12 16:40:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.7401(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→12→7→9→9
* 開始   : 2026-08-12 20:40:00 (UTC)
* 終了   : 2026-08-12 20:40:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260812-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 6→7→12→9→8
* 開始   : 2026-08-13 01:15:00 (UTC)
* 終了   : 2026-08-13 01:15:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260813-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 8→8→13→10→9
* 開始   : 2026-08-13 02:05:00 (UTC)
* 終了   : 2026-08-13 02:05:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 16→17→22→18→16
* 開始   : 2026-08-13 08:10:00 (UTC)
* 終了   : 2026-08-13 08:10:00 (UTC)
* 現象   : 平常時(17.25)に対し 1.275倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→10→15→12→11
* 開始   : 2026-08-14 04:00:00 (UTC)
* 終了   : 2026-08-14 04:00:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 16→17→21→17→19
* 開始   : 2026-08-14 07:05:00 (UTC)
* 終了   : 2026-08-14 07:05:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.319倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host01-003 active_connections の推移](charts/EVT-20260814-host01-003.svg)

# イベントID( EVT-20260814-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 61.37→58.08→52.7→47.5→…→52.7→47.5→57.17→52.21
* 開始   : 2026-08-14 16:45:00 (UTC)
* 終了   : 2026-08-14 16:50:00 (UTC)
* 現象   : 平常時(60.51)に対し 0.8709(52.7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260814-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 18→15→16→18→17→17
* 開始   : 2026-08-14 17:45:00 (UTC)
* 終了   : 2026-08-14 18:25:00 (UTC)
* 現象   : 2026-08-14 18:25:00 (UTC)を境に水準が 14.82から12.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.638, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→13→11→12→…→13→11→12→13
* 開始   : 2026-08-15 05:00:00 (UTC)
* 終了   : 2026-08-15 18:05:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.9, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260815-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260815-host01-002 active_connections の推移](charts/EVT-20260815-host01-002.svg)

# イベントID( EVT-20260815-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→10→12→10→…→11→9→8→10
* 開始   : 2026-08-15 05:15:00 (UTC)
* 終了   : 2026-08-15 19:35:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.772, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260815-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260815-host01-003 active_connections の推移](charts/EVT-20260815-host01-003.svg)

# イベントID( EVT-20260815-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→12→14→12→…→10→12→10→12
* 開始   : 2026-08-15 05:35:00 (UTC)
* 終了   : 2026-08-15 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.775, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260815-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260815-host01-004 active_connections の推移](charts/EVT-20260815-host01-004.svg)

# イベントID( EVT-20260815-host01-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 39.42→39.61→41.38→38.03→…→38.14→40.84→37.96→41.61
* 開始   : 2026-08-15 05:45:00 (UTC)
* 終了   : 2026-08-15 19:25:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.343, 限界=7.23)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260815-host01-005 eu の推移](charts/EVT-20260815-host01-005.svg)

# イベントID( EVT-20260815-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→12→10→12→…→13→14→16→13
* 開始   : 2026-08-15 05:50:00 (UTC)
* 終了   : 2026-08-15 17:40:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.024, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260815-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間

![EVT-20260815-host01-006 active_connections の推移](charts/EVT-20260815-host01-006.svg)

# イベントID( EVT-20260815-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→11→12→11→…→9→11→12→9
* 開始   : 2026-08-15 06:00:00 (UTC)
* 終了   : 2026-08-15 19:15:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.432σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.824, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260815-host01-007 active_connections の推移](charts/EVT-20260815-host01-007.svg)

# イベントID( EVT-20260815-host01-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 13→11→12→11→…→13→11→13→10
* 開始   : 2026-08-15 06:20:00 (UTC)
* 終了   : 2026-08-15 18:25:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.29, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260815-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→12→8→10→10
* 開始   : 2026-08-15 18:55:00 (UTC)
* 終了   : 2026-08-15 18:55:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host01-005 (同一ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260815-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260815-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 9→11→15→14→11→15→14→11→12
* 開始   : 2026-08-16 06:00:00 (UTC)
* 終了   : 2026-08-16 06:05:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260816-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→13→9→14→13
* 開始   : 2026-08-16 16:40:00 (UTC)
* 終了   : 2026-08-16 16:40:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.243σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260816-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 43.23→40.72→33.48→43.17→39.03
* 開始   : 2026-08-16 17:35:00 (UTC)
* 終了   : 2026-08-16 17:35:00 (UTC)
* 現象   : 平常時(44.67)に対し 0.7496(33.48)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260816-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260816-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260816-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→13→7→12→13
* 開始   : 2026-08-16 18:20:00 (UTC)
* 終了   : 2026-08-16 18:20:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.5915(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260816-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260816-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260816-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 14→16→15→18→…→16→14→15→16
* 開始   : 2026-08-17 02:25:00 (UTC)
* 終了   : 2026-08-17 21:45:00 (UTC)
* 現象   : 2026-08-17 21:45:00 (UTC)を境に水準が 11.84から15.08へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.402, 限界=3.181)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→14→15→13→…→16→14→12→13
* 開始   : 2026-08-17 02:45:00 (UTC)
* 終了   : 2026-08-17 19:55:00 (UTC)
* 現象   : 2026-08-17 19:55:00 (UTC)を境に水準が 11.8から14.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.826, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.251, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 33.75→34.5→21.28→30.55→27.27
* 開始   : 2026-08-17 22:45:00 (UTC)
* 終了   : 2026-08-17 22:45:00 (UTC)
* 現象   : 平常時(32.7)に対し 0.6508(21.28)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260817-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 20→18→18→19→20→18→19→21→22
* 開始   : 2026-08-18 07:30:00 (UTC)
* 終了   : 2026-08-18 09:55:00 (UTC)
* 現象   : 2026-08-18 09:55:00 (UTC)を境に水準が 14.9から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.341, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 22→20→14→18→18
* 開始   : 2026-08-18 16:10:00 (UTC)
* 終了   : 2026-08-18 16:10:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.721(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.784σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host01-006 active_connections の推移](charts/EVT-20260818-host01-006.svg)

# イベントID( EVT-20260818-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 54.16→49.95→48.57→50.01→…→50.01→42.95→57.74→51.93
* 開始   : 2026-08-18 17:35:00 (UTC)
* 終了   : 2026-08-18 17:45:00 (UTC)
* 現象   : 平常時(55.91)に対し 0.8687(48.57)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260818-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 46.23→44.38→33.49→40.59→42
* 開始   : 2026-08-18 19:35:00 (UTC)
* 終了   : 2026-08-18 19:35:00 (UTC)
* 現象   : 平常時(45.32)に対し 0.7389(33.49)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260818-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 37.32→33.79→23.34→34.03→42.19
* 開始   : 2026-08-18 21:20:00 (UTC)
* 終了   : 2026-08-18 21:20:00 (UTC)
* 現象   : 平常時(38.33)に対し 0.609(23.34)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-071 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260818-host01-014 eu の推移](charts/EVT-20260818-host01-014.svg)

# イベントID( EVT-20260819-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→15→18→14→13
* 開始   : 2026-08-19 05:40:00 (UTC)
* 終了   : 2026-08-19 05:40:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260819-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 15→17→22→17→17
* 開始   : 2026-08-19 07:35:00 (UTC)
* 終了   : 2026-08-19 07:35:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.397倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.364σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260819-host01-007 active_connections の推移](charts/EVT-20260819-host01-007.svg)

# イベントID( EVT-20260819-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 20→21→20→21→21→25
* 開始   : 2026-08-19 09:10:00 (UTC)
* 終了   : 2026-08-19 09:35:00 (UTC)
* 現象   : 2026-08-19 09:35:00 (UTC)を境に水準が 15から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.27σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.795, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→10→12→7→10→12→7→10→11
* 開始   : 2026-08-19 19:50:00 (UTC)
* 終了   : 2026-08-19 20:20:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.447σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260819-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host02-014 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260819-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-063 (他ホスト) lsf_queue / susp : WARN / 重なり 30 分
  - EVT-20260819-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260819-host01-012 active_connections の推移](charts/EVT-20260819-host01-012.svg)

# イベントID( EVT-20260820-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 8→9→13→10→8
* 開始   : 2026-08-20 02:35:00 (UTC)
* 終了   : 2026-08-20 02:35:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 9→10→14→9→10
* 開始   : 2026-08-20 02:45:00 (UTC)
* 終了   : 2026-08-20 02:45:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.435σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 17→18→21→18→19
* 開始   : 2026-08-20 07:25:00 (UTC)
* 終了   : 2026-08-20 07:25:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.279倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.185σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260820-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→17→21→16→18
* 開始   : 2026-08-20 07:25:00 (UTC)
* 終了   : 2026-08-20 07:25:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260820-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 20→19→24→21→21
* 開始   : 2026-08-20 09:10:00 (UTC)
* 終了   : 2026-08-20 09:10:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 17→16→13→18→16
* 開始   : 2026-08-20 17:40:00 (UTC)
* 終了   : 2026-08-20 17:40:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→12→6→10→…→10→7→11→10
* 開始   : 2026-08-20 20:45:00 (UTC)
* 終了   : 2026-08-20 20:55:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.5143(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.957σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260820-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-070 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260820-host01-015 active_connections の推移](charts/EVT-20260820-host01-015.svg)

# イベントID( EVT-20260821-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 8→9→13→10→10
* 開始   : 2026-08-21 02:50:00 (UTC)
* 終了   : 2026-08-21 02:50:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-008 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260821-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→11→15→11→12
* 開始   : 2026-08-21 03:45:00 (UTC)
* 終了   : 2026-08-21 03:45:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.475倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260821-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→12→16→12→13
* 開始   : 2026-08-21 04:50:00 (UTC)
* 終了   : 2026-08-21 04:50:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260821-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 21→20→17→20→20
* 開始   : 2026-08-21 14:05:00 (UTC)
* 終了   : 2026-08-21 14:05:00 (UTC)
* 現象   : 平常時(22)に対し 0.7727(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.475σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-046 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260821-host01-009 active_connections の推移](charts/EVT-20260821-host01-009.svg)

# イベントID( EVT-20260821-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 20→19→16→19→20
* 開始   : 2026-08-21 15:10:00 (UTC)
* 終了   : 2026-08-21 15:10:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→11→8→13→11
* 開始   : 2026-08-21 19:25:00 (UTC)
* 終了   : 2026-08-21 19:25:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.6038(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.648σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host01-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host01-012 active_connections の推移](charts/EVT-20260821-host01-012.svg)

# イベントID( EVT-20260821-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→11→13→12→10→12
* 開始   : 2026-08-21 20:30:00 (UTC)
* 終了   : 2026-08-21 21:25:00 (UTC)
* 現象   : 2026-08-21 21:25:00 (UTC)を境に水準が 15.05から11.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.638, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→11→6→10→8
* 開始   : 2026-08-21 21:10:00 (UTC)
* 終了   : 2026-08-21 21:10:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.5581(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.301σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→11→8→10→…→11→13→14→11
* 開始   : 2026-08-22 04:50:00 (UTC)
* 終了   : 2026-08-22 19:15:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.511σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.219, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260822-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host01-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260822-host01-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260822-host01-001 active_connections の推移](charts/EVT-20260822-host01-001.svg)

# イベントID( EVT-20260822-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 33.77→37.5→33.68→29.56→…→42.48→34.04→37.93→38.07
* 開始   : 2026-08-22 05:05:00 (UTC)
* 終了   : 2026-08-22 18:55:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.642, 限界=7.23)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260822-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host01-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260822-host01-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260822-host01-003 eu の推移](charts/EVT-20260822-host01-003.svg)

# イベントID( EVT-20260822-host01-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→12→10→11→…→9→12→13→11
* 開始   : 2026-08-22 05:30:00 (UTC)
* 終了   : 2026-08-22 19:35:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.837, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260822-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260822-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260822-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260822-host01-005 active_connections の推移](charts/EVT-20260822-host01-005.svg)

# イベントID( EVT-20260822-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→12→13→12→…→11→14→12→11
* 開始   : 2026-08-22 06:20:00 (UTC)
* 終了   : 2026-08-22 20:05:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.836, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260822-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260822-host01-006 active_connections の推移](charts/EVT-20260822-host01-006.svg)

# イベントID( EVT-20260822-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→14→13→12→…→11→12→13→11
* 開始   : 2026-08-22 06:25:00 (UTC)
* 終了   : 2026-08-22 18:55:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.78, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260822-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260822-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260822-host01-007 active_connections の推移](charts/EVT-20260822-host01-007.svg)

# イベントID( EVT-20260822-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→14→10→12→…→12→13→12→13
* 開始   : 2026-08-22 06:30:00 (UTC)
* 終了   : 2026-08-22 20:00:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.433σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.943, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260822-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260822-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260822-host01-008 active_connections の推移](charts/EVT-20260822-host01-008.svg)

# イベントID( EVT-20260822-host01-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 13→12→14→12→…→12→11→12→14
* 開始   : 2026-08-22 06:35:00 (UTC)
* 終了   : 2026-08-22 18:20:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.315, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間
  - EVT-20260822-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間

![EVT-20260822-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→17→12→15→14
* 開始   : 2026-08-23 13:20:00 (UTC)
* 終了   : 2026-08-23 13:20:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260823-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 32.69→29.49→17.63→22.08→35.03
* 開始   : 2026-08-23 23:10:00 (UTC)
* 終了   : 2026-08-23 23:10:00 (UTC)
* 現象   : 平常時(29.58)に対し 0.596(17.63)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.303σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260823-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260823-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host01-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→16→17→16→…→14→15→14→12
* 開始   : 2026-08-24 01:55:00 (UTC)
* 終了   : 2026-08-24 19:15:00 (UTC)
* 現象   : 2026-08-24 19:15:00 (UTC)を境に水準が 11.91から15.07へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.844, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.852, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host01-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 17→16→18→17→…→12→14→12→11
* 開始   : 2026-08-24 03:00:00 (UTC)
* 終了   : 2026-08-24 22:50:00 (UTC)
* 現象   : 2026-08-24 22:50:00 (UTC)を境に水準が 11.87から15.06へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.242, 限界=3.181)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 21→20→25→21→21
* 開始   : 2026-08-25 09:30:00 (UTC)
* 終了   : 2026-08-25 09:30:00 (UTC)
* 現象   : 平常時(20)に対し 1.25倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.494σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host01-007 active_connections の推移](charts/EVT-20260825-host01-007.svg)

# イベントID( EVT-20260825-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 21→22→16→18→19
* 開始   : 2026-08-25 15:40:00 (UTC)
* 終了   : 2026-08-25 15:40:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 57.47→62.33→49.49→53.32→55.8
* 開始   : 2026-08-25 16:20:00 (UTC)
* 終了   : 2026-08-25 16:20:00 (UTC)
* 現象   : 平常時(60.8)に対し 0.8139(49.49)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→12→7→10→9
* 開始   : 2026-08-25 20:40:00 (UTC)
* 終了   : 2026-08-25 20:40:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.5793(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.554σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host01-015 active_connections の推移](charts/EVT-20260825-host01-015.svg)

# イベントID( EVT-20260826-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→9→14→13→…→13→14→11→12
* 開始   : 2026-08-26 03:50:00 (UTC)
* 終了   : 2026-08-26 04:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260826-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 46.41→42.96→35.78→49.65→43.81
* 開始   : 2026-08-26 18:55:00 (UTC)
* 終了   : 2026-08-26 18:55:00 (UTC)
* 現象   : 平常時(48.49)に対し 0.7379(35.78)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.513σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host01-006 eu の推移](charts/EVT-20260826-host01-006.svg)

# イベントID( EVT-20260826-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→12→9→12→…→12→10→11→12
* 開始   : 2026-08-26 19:55:00 (UTC)
* 終了   : 2026-08-26 20:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260826-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260826-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→10→6→9→9
* 開始   : 2026-08-26 21:00:00 (UTC)
* 終了   : 2026-08-26 21:00:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 15→14→19→17→17
* 開始   : 2026-08-27 06:40:00 (UTC)
* 終了   : 2026-08-27 06:40:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260827-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 19→20→24→21→22
* 開始   : 2026-08-27 09:30:00 (UTC)
* 終了   : 2026-08-27 09:30:00 (UTC)
* 現象   : 平常時(19.25)に対し 1.247倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 19→20→15→19→21
* 開始   : 2026-08-27 16:00:00 (UTC)
* 終了   : 2026-08-27 16:00:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.7595(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→13→10→12→14
* 開始   : 2026-08-27 19:05:00 (UTC)
* 終了   : 2026-08-27 19:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-073 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→12→13→11→9→11→12→13→10
* 開始   : 2026-08-27 19:30:00 (UTC)
* 終了   : 2026-08-27 21:10:00 (UTC)
* 現象   : 2026-08-27 21:10:00 (UTC)を境に水準が 14.89から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.255, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→11→7→9→10
* 開始   : 2026-08-27 20:45:00 (UTC)
* 終了   : 2026-08-27 20:45:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-079 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260827-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 18→15→22→21→15→22→21→19
* 開始   : 2026-08-28 08:20:00 (UTC)
* 終了   : 2026-08-28 08:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260828-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 21→22→18→21→23
* 開始   : 2026-08-28 12:50:00 (UTC)
* 終了   : 2026-08-28 12:50:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260828-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 18→17→13→18→16
* 開始   : 2026-08-28 16:50:00 (UTC)
* 終了   : 2026-08-28 16:50:00 (UTC)
* 現象   : 平常時(18.83)に対し 0.6903(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.054σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host14-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host01-006 active_connections の推移](charts/EVT-20260828-host01-006.svg)

# イベントID( EVT-20260829-host01-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 8→10→9→12→…→14→12→13→14
* 開始   : 2026-08-29 04:55:00 (UTC)
* 終了   : 2026-08-29 19:20:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.967, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260829-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260829-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260829-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間

![EVT-20260829-host01-002 active_connections の推移](charts/EVT-20260829-host01-002.svg)

# イベントID( EVT-20260829-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 10→9→11→12→…→11→10→11→10
* 開始   : 2026-08-29 05:10:00 (UTC)
* 終了   : 2026-08-29 20:05:00 (UTC)
* 現象   : 14.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.015, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260829-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260829-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260829-host01-003 active_connections の推移](charts/EVT-20260829-host01-003.svg)

# イベントID( EVT-20260829-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 39.91→42.64→31.77→40.45→…→43.4→37.03→48.5→35.87
* 開始   : 2026-08-29 05:15:00 (UTC)
* 終了   : 2026-08-29 18:50:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.138σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.576, 限界=7.23)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260829-host01-004 eu の推移](charts/EVT-20260829-host01-004.svg)

# イベントID( EVT-20260829-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→11→14→11→…→13→11→13→12
* 開始   : 2026-08-29 05:30:00 (UTC)
* 終了   : 2026-08-29 19:10:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.321σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.786, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260829-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260829-host01-005 active_connections の推移](charts/EVT-20260829-host01-005.svg)

# イベントID( EVT-20260829-host01-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 14→13→10→13→…→14→13→14→15
* 開始   : 2026-08-29 05:40:00 (UTC)
* 終了   : 2026-08-29 18:15:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.612, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260829-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→12→10→11→…→12→11→12→14
* 開始   : 2026-08-29 05:45:00 (UTC)
* 終了   : 2026-08-29 18:20:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.739, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260829-host01-007 active_connections の推移](charts/EVT-20260829-host01-007.svg)

# イベントID( EVT-20260829-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→11→12→11→…→13→14→15→14
* 開始   : 2026-08-29 06:00:00 (UTC)
* 終了   : 2026-08-29 19:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.374σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.91, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260829-host01-008 active_connections の推移](charts/EVT-20260829-host01-008.svg)

# イベントID( EVT-20260801-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 37.6→30.23→34.63→36.82→31.13
* 開始   : 2026-08-01 00:00:00 (UTC)
* 終了   : 2026-08-01 00:20:00 (UTC)
* 現象   : 2026-08-01 00:20:00 (UTC)を境に水準が 49.93から40.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=23.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260801-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host01-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 9→7→8→9→…→8→9→8→9
* 開始   : 2026-08-01 20:00:00 (UTC)
* 終了   : 2026-08-01 20:50:00 (UTC)
* 現象   : 50分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.403, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host01-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260801-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260801-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260801-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260801-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host01-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 10→8→7→8→…→7→8→12→10
* 開始   : 2026-08-01 20:20:00 (UTC)
* 終了   : 2026-08-01 20:25:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.789, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260801-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→15→10→12→10→12→10→13→15
* 開始   : 2026-08-02 16:55:00 (UTC)
* 終了   : 2026-08-02 17:05:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7186(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.735σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260802-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 9→8→10→9→9→8→8→10→10
* 開始   : 2026-08-03 00:45:00 (UTC)
* 終了   : 2026-08-03 01:40:00 (UTC)
* 現象   : 2026-08-03 01:40:00 (UTC)を境に水準が 11.9から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.507, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 9→9→10→11→10→9→10→7→11
* 開始   : 2026-08-03 22:25:00 (UTC)
* 終了   : 2026-08-03 23:05:00 (UTC)
* 現象   : 2026-08-03 23:05:00 (UTC)を境に水準が 14.96から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.319, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 7→5→8→11→…→10→5→10→7
* 開始   : 2026-08-03 23:15:00 (UTC)
* 終了   : 2026-08-03 23:35:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260803-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260803-host02-012 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260803-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260803-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260803-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260803-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 47.87→49→54.93→58.12→…→54.93→58.12→51.02→48
* 開始   : 2026-08-04 06:00:00 (UTC)
* 終了   : 2026-08-04 06:05:00 (UTC)
* 現象   : 平常時(46.29)に対し 1.187倍(54.93)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→13→18→19→…→18→19→17→16
* 開始   : 2026-08-04 06:50:00 (UTC)
* 終了   : 2026-08-04 06:55:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 20→24→23→20→24→23→22
* 開始   : 2026-08-04 10:35:00 (UTC)
* 終了   : 2026-08-04 10:40:00 (UTC)
* 現象   : 平常時(20.25)に対し 1.185倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host01-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 23→21→21→20→21→23→20→20→22
* 開始   : 2026-08-04 14:10:00 (UTC)
* 終了   : 2026-08-04 15:15:00 (UTC)
* 現象   : 2026-08-04 15:15:00 (UTC)を境に水準が 14.96から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.758, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 18→16→19→16→19→16→17
* 開始   : 2026-08-04 15:45:00 (UTC)
* 終了   : 2026-08-04 15:55:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.8136(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.548σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260804-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→16→11→10→…→12→9→12→10
* 開始   : 2026-08-04 19:50:00 (UTC)
* 終了   : 2026-08-04 20:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host02-015 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260804-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260804-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 7→6→11→5→…→11→5→8→9
* 開始   : 2026-08-05 00:05:00 (UTC)
* 終了   : 2026-08-05 00:10:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260805-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host01-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 10→9→11→12→9→9→11
* 開始   : 2026-08-05 01:45:00 (UTC)
* 終了   : 2026-08-05 02:15:00 (UTC)
* 現象   : 2026-08-05 02:15:00 (UTC)を境に水準が 14.93から14.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.026, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→10→12→13→10→12→13→10
* 開始   : 2026-08-05 03:05:00 (UTC)
* 終了   : 2026-08-05 03:10:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260805-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→13→16→14→…→14→17→14→13
* 開始   : 2026-08-05 05:25:00 (UTC)
* 終了   : 2026-08-05 05:35:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.297倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260805-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 18→17→20→18→…→18→21→17→19
* 開始   : 2026-08-05 07:40:00 (UTC)
* 終了   : 2026-08-05 08:10:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.212倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.432σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host01-009 (同一ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260805-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260805-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 55.66→52.34→63.79→63.98→…→63.79→63.98→54.65→63.84
* 開始   : 2026-08-05 07:45:00 (UTC)
* 終了   : 2026-08-05 07:50:00 (UTC)
* 現象   : 平常時(55.95)に対し 1.14倍(63.79)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260805-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 62.83→69.16→65.91→73.92→73.59→64.83→61.83→70.77→68.32
* 開始   : 2026-08-05 09:10:00 (UTC)
* 終了   : 2026-08-05 09:55:00 (UTC)
* 現象   : 2026-08-05 09:55:00 (UTC)を境に水準が 49.89から50.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.746σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=24.91, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host01-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 21→21→22→22→23→23
* 開始   : 2026-08-05 09:35:00 (UTC)
* 終了   : 2026-08-05 10:00:00 (UTC)
* 現象   : 2026-08-05 10:00:00 (UTC)を境に水準が 14.99から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.638, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 22→19→25→20→19→25→20→21
* 開始   : 2026-08-05 11:15:00 (UTC)
* 終了   : 2026-08-05 11:20:00 (UTC)
* 現象   : 平常時(21.25)に対し 1.176倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.62σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260805-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 45.96→51.15→42.76→48.78→…→48.78→40.52→47.76→42.48
* 開始   : 2026-08-05 18:40:00 (UTC)
* 終了   : 2026-08-05 18:50:00 (UTC)
* 現象   : 平常時(50.15)に対し 0.8526(42.76)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-053 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260805-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 8→12→10→10→10
* 開始   : 2026-08-06 00:50:00 (UTC)
* 終了   : 2026-08-06 01:10:00 (UTC)
* 現象   : 2026-08-06 01:10:00 (UTC)を境に水準が 14.84から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.733, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→15→16→12→15→16→12→14
* 開始   : 2026-08-06 04:50:00 (UTC)
* 終了   : 2026-08-06 04:55:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→17→14→16→18→17→17→16→19
* 開始   : 2026-08-06 06:05:00 (UTC)
* 終了   : 2026-08-06 06:45:00 (UTC)
* 現象   : 2026-08-06 06:45:00 (UTC)を境に水準が 15.01から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.958, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 47.95→44.82→56.94→48.11→…→58.39→58.44→52.5→55.9
* 開始   : 2026-08-06 06:20:00 (UTC)
* 終了   : 2026-08-06 06:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.228σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 19→18→22→16→…→22→16→21→17
* 開始   : 2026-08-06 09:00:00 (UTC)
* 終了   : 2026-08-06 09:05:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260806-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260806-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 24→23→23→23→22→26→23
* 開始   : 2026-08-06 11:55:00 (UTC)
* 終了   : 2026-08-06 12:25:00 (UTC)
* 現象   : 2026-08-06 12:25:00 (UTC)を境に水準が 14.99から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 20→21→18→20→21→18→20
* 開始   : 2026-08-06 14:35:00 (UTC)
* 終了   : 2026-08-06 14:40:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→19→19→17→19→19
* 開始   : 2026-08-06 16:55:00 (UTC)
* 終了   : 2026-08-06 17:20:00 (UTC)
* 現象   : 2026-08-06 17:20:00 (UTC)を境に水準が 15.08から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.873, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 51.21→46.11→44.31→41.6→…→44.31→41.6→44.8→49.98
* 開始   : 2026-08-06 18:10:00 (UTC)
* 終了   : 2026-08-06 18:15:00 (UTC)
* 現象   : 平常時(52.07)に対し 0.8509(44.31)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→14→12→14→12→14→12→14
* 開始   : 2026-08-06 18:30:00 (UTC)
* 終了   : 2026-08-06 18:40:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host01-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→10→12→13→10→12→11
* 開始   : 2026-08-06 19:35:00 (UTC)
* 終了   : 2026-08-06 19:40:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 47.42→44.37→36.64→38.47→…→38.47→35.31→39.91→36.88
* 開始   : 2026-08-06 19:50:00 (UTC)
* 終了   : 2026-08-06 20:00:00 (UTC)
* 現象   : 平常時(45.64)に対し 0.8028(36.64)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.487σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host01-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 10→11→8→10→10→10
* 開始   : 2026-08-06 22:20:00 (UTC)
* 終了   : 2026-08-06 22:45:00 (UTC)
* 現象   : 2026-08-06 22:45:00 (UTC)を境に水準が 14.96から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.879, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 7→8→11→5→9→8→11→5→9
* 開始   : 2026-08-07 01:25:00 (UTC)
* 終了   : 2026-08-07 01:30:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260807-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260807-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→9→12→9→12
* 開始   : 2026-08-07 02:50:00 (UTC)
* 終了   : 2026-08-07 02:55:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260807-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→15→14→14
* 開始   : 2026-08-07 04:35:00 (UTC)
* 終了   : 2026-08-07 04:55:00 (UTC)
* 現象   : 2026-08-07 04:55:00 (UTC)を境に水準が 15.01から14.71へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.426, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 18→19→23→21→17→23→21→17→18
* 開始   : 2026-08-07 15:30:00 (UTC)
* 終了   : 2026-08-07 15:40:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260807-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→19→14→16→19→14→16
* 開始   : 2026-08-07 17:25:00 (UTC)
* 終了   : 2026-08-07 17:30:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260807-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→13→10→11→…→11→9→14→12
* 開始   : 2026-08-07 19:40:00 (UTC)
* 終了   : 2026-08-07 19:50:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-076 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-077 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→8→6→7→8→6→7→11
* 開始   : 2026-08-07 22:30:00 (UTC)
* 終了   : 2026-08-07 22:35:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-084 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260807-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host01-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 12→8→9→8→…→8→9→11→10
* 開始   : 2026-08-08 04:40:00 (UTC)
* 終了   : 2026-08-08 04:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.529, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host01-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260808-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260808-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host01-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→9→8→10→9→8→10→12
* 開始   : 2026-08-08 04:40:00 (UTC)
* 終了   : 2026-08-08 04:45:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.754, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host01-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260808-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 13→11→12→10
* 開始   : 2026-08-09 04:35:00 (UTC)
* 終了   : 2026-08-09 04:50:00 (UTC)
* 現象   : 2026-08-09 04:50:00 (UTC)を境に水準が 11.94から12.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host01-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→11→14→15→13→13→14→12→14
* 開始   : 2026-08-09 06:15:00 (UTC)
* 終了   : 2026-08-09 06:55:00 (UTC)
* 現象   : 2026-08-09 06:55:00 (UTC)を境に水準が 11.85から12.34へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.708, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→12→17→18→…→17→18→16→15
* 開始   : 2026-08-09 08:30:00 (UTC)
* 終了   : 2026-08-09 08:35:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260809-lsfhost01-023 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260809-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 17→15→13→15→13→15→16
* 開始   : 2026-08-09 12:40:00 (UTC)
* 終了   : 2026-08-09 12:45:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260809-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host01-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 52.42→58.67→52.3→51.74→54.65→52.56→55.19→51.93→55.9
* 開始   : 2026-08-09 12:45:00 (UTC)
* 終了   : 2026-08-09 13:35:00 (UTC)
* 現象   : 2026-08-09 13:35:00 (UTC)を境に水準が 40.77から46.55へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=21.29, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host01-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→14→10→12→10→11→13
* 開始   : 2026-08-09 19:10:00 (UTC)
* 終了   : 2026-08-09 19:40:00 (UTC)
* 現象   : 2026-08-09 19:40:00 (UTC)を境に水準が 11.71から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.927, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host01-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→9→9→11→9
* 開始   : 2026-08-09 23:25:00 (UTC)
* 終了   : 2026-08-09 23:45:00 (UTC)
* 現象   : 2026-08-09 23:45:00 (UTC)を境に水準が 11.9から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.532, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→8→5→8→…→8→11→8→7
* 開始   : 2026-08-11 00:15:00 (UTC)
* 終了   : 2026-08-11 00:25:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260810-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260811-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host01-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→10→11→11→11→12→13→11→13
* 開始   : 2026-08-11 02:15:00 (UTC)
* 終了   : 2026-08-11 03:10:00 (UTC)
* 現象   : 2026-08-11 03:10:00 (UTC)を境に水準が 15から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host01-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→15→15→17→15
* 開始   : 2026-08-11 05:15:00 (UTC)
* 終了   : 2026-08-11 05:35:00 (UTC)
* 現象   : 2026-08-11 05:35:00 (UTC)を境に水準が 15.1から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.532, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host01-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 20→25→22→22→22→24→22→22→24
* 開始   : 2026-08-11 10:50:00 (UTC)
* 終了   : 2026-08-11 11:45:00 (UTC)
* 現象   : 2026-08-11 11:45:00 (UTC)を境に水準が 14.92から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.759, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 21→22→25→23→22→25→23→21
* 開始   : 2026-08-11 11:25:00 (UTC)
* 終了   : 2026-08-11 11:30:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.163倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.432σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 23→23→23→22→25→23→22
* 開始   : 2026-08-11 13:15:00 (UTC)
* 終了   : 2026-08-11 13:45:00 (UTC)
* 現象   : 2026-08-11 13:45:00 (UTC)を境に水準が 14.95から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.88, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 22→21→18→22→18→22→18→22→20
* 開始   : 2026-08-11 13:45:00 (UTC)
* 終了   : 2026-08-11 13:55:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.8372(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 49.5→51.04→43.21→42.64→…→43.21→42.64→43.72→45.66
* 開始   : 2026-08-11 18:45:00 (UTC)
* 終了   : 2026-08-11 18:50:00 (UTC)
* 現象   : 平常時(51.07)に対し 0.8462(43.21)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.171σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→15→11→14→15→11→14→13
* 開始   : 2026-08-11 19:05:00 (UTC)
* 終了   : 2026-08-11 19:10:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.7374(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.736σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260811-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→12→14→15→…→14→15→14→12
* 開始   : 2026-08-12 04:25:00 (UTC)
* 終了   : 2026-08-12 04:30:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→13→15→16→…→15→16→14→15
* 開始   : 2026-08-12 04:40:00 (UTC)
* 終了   : 2026-08-12 04:45:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-013 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260812-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 19→16→20→19→20→19→20→18→19
* 開始   : 2026-08-12 08:05:00 (UTC)
* 終了   : 2026-08-12 08:15:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.212倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.432σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260812-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260812-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 59.01→61.14→66.79→62.05→…→62.05→69.38→61.27→63.41
* 開始   : 2026-08-12 08:30:00 (UTC)
* 終了   : 2026-08-12 08:40:00 (UTC)
* 現象   : 平常時(59.22)に対し 1.128倍(66.79)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260812-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 22→21→24→22→21→24→22
* 開始   : 2026-08-12 11:35:00 (UTC)
* 終了   : 2026-08-12 11:40:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260812-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host01-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 21→20→20→20→23
* 開始   : 2026-08-12 15:15:00 (UTC)
* 終了   : 2026-08-12 15:35:00 (UTC)
* 現象   : 2026-08-12 15:35:00 (UTC)を境に水準が 14.9から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.733, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 61.86→63.41→52.81→51.85→…→54.94→51.52→56.14→61.6
* 開始   : 2026-08-12 16:10:00 (UTC)
* 終了   : 2026-08-12 16:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.355σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260812-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→9→8→9→…→13→7→8→10
* 開始   : 2026-08-12 20:25:00 (UTC)
* 終了   : 2026-08-12 20:45:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260812-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260812-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260812-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→13→16→15→13→16→15→16
* 開始   : 2026-08-13 05:15:00 (UTC)
* 終了   : 2026-08-13 05:20:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.315倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.677σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→20→17→20→17→20→19→18
* 開始   : 2026-08-13 07:15:00 (UTC)
* 終了   : 2026-08-13 07:25:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.27倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.968σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260813-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→18→20→18→20→18→17
* 開始   : 2026-08-13 07:30:00 (UTC)
* 終了   : 2026-08-13 07:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→18→21→19→21→19→21→19→20
* 開始   : 2026-08-13 08:15:00 (UTC)
* 終了   : 2026-08-13 08:25:00 (UTC)
* 現象   : 平常時(17.25)に対し 1.217倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.622σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260813-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host01-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 58.04→58.24→56.11→60.57→55.62→54.33→53.47→47.49→54.46
* 開始   : 2026-08-13 16:50:00 (UTC)
* 終了   : 2026-08-13 18:05:00 (UTC)
* 現象   : 2026-08-13 18:05:00 (UTC)を境に水準が 49.93から49.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=21.87, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→12→8→9→12→8→9→12→10
* 開始   : 2026-08-13 20:10:00 (UTC)
* 終了   : 2026-08-13 20:15:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.6531(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.969σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→13→9→8→…→9→8→10→11
* 開始   : 2026-08-13 20:25:00 (UTC)
* 終了   : 2026-08-13 20:30:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 38.47→41.12→32.04→28.18→…→32.04→28.18→34.9→34.56
* 開始   : 2026-08-13 20:50:00 (UTC)
* 終了   : 2026-08-13 20:55:00 (UTC)
* 現象   : 平常時(39.34)に対し 0.8145(32.04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host04-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260813-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→14→17→16→17→16→17→13→16
* 開始   : 2026-08-14 05:50:00 (UTC)
* 終了   : 2026-08-14 06:00:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.299倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.744σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260814-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 21→19→23→19→23→19→18
* 開始   : 2026-08-14 09:25:00 (UTC)
* 終了   : 2026-08-14 09:30:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.548σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-042 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-041 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260814-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 22→23→19→26→…→19→26→22→23
* 開始   : 2026-08-14 12:40:00 (UTC)
* 終了   : 2026-08-14 12:45:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host01-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 22→20→20→19→21→19→20→20→18
* 開始   : 2026-08-14 14:55:00 (UTC)
* 終了   : 2026-08-14 16:05:00 (UTC)
* 現象   : 2026-08-14 16:05:00 (UTC)を境に水準が 15.02から12.47へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.198, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 10→9→6→11→6→11→6→9→8
* 開始   : 2026-08-15 02:15:00 (UTC)
* 終了   : 2026-08-15 02:25:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260815-lsfhost01-005 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260815-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260815-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 9→9→9→8→7→8→10→9→11
* 開始   : 2026-08-15 22:30:00 (UTC)
* 終了   : 2026-08-15 23:20:00 (UTC)
* 現象   : 2026-08-15 23:20:00 (UTC)を境に水準が 11.9から11.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260815-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 10→8→6→12→8→6→12→11
* 開始   : 2026-08-16 03:30:00 (UTC)
* 終了   : 2026-08-16 03:35:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host01-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 54.93→57.27→50.29→57.45→54.26→50.72→55.57→56.79→52.06
* 開始   : 2026-08-16 13:10:00 (UTC)
* 終了   : 2026-08-16 14:20:00 (UTC)
* 現象   : 2026-08-16 14:20:00 (UTC)を境に水準が 40.86から47.18へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=24.23, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 26.86→34.24→25.26→25.24→…→25.26→25.24→34.54→36.1
* 開始   : 2026-08-16 21:40:00 (UTC)
* 終了   : 2026-08-16 21:45:00 (UTC)
* 現象   : 平常時(33.73)に対し 0.7489(25.26)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260816-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 31.47→23.26→36.12→33.94→…→33.94→20.88→32.28→27.96
* 開始   : 2026-08-17 00:25:00 (UTC)
* 終了   : 2026-08-17 00:35:00 (UTC)
* 現象   : 平常時(28.72)に対し 1.258倍(36.12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260817-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260817-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 10→9→7→10→9→7→10
* 開始   : 2026-08-17 21:25:00 (UTC)
* 終了   : 2026-08-17 21:30:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260817-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 8→9→12→13→10→9→12→13→10
* 開始   : 2026-08-18 02:55:00 (UTC)
* 終了   : 2026-08-18 03:00:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260818-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 9→10→13→9→13→9→13→12→10
* 開始   : 2026-08-18 03:05:00 (UTC)
* 終了   : 2026-08-18 03:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.393倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-007 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260818-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 8→10→13→11→…→11→14→12→11
* 開始   : 2026-08-18 03:45:00 (UTC)
* 終了   : 2026-08-18 03:55:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-lsfhost01-008 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260818-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260818-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 19→20→23→22→20→23→22→20
* 開始   : 2026-08-18 10:15:00 (UTC)
* 終了   : 2026-08-18 10:20:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260818-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 18→17→15→14→…→15→14→15→17
* 開始   : 2026-08-18 17:05:00 (UTC)
* 終了   : 2026-08-18 17:10:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260818-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→16→13→14→…→14→12→14→12
* 開始   : 2026-08-18 18:10:00 (UTC)
* 終了   : 2026-08-18 18:20:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host01-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260818-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→12→13→12→13→12→14→13
* 開始   : 2026-08-18 18:15:00 (UTC)
* 終了   : 2026-08-18 18:25:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.7385(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.978σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260818-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→10→11→8→10→11→8→12
* 開始   : 2026-08-18 19:45:00 (UTC)
* 終了   : 2026-08-18 19:55:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260818-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host01-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→12→11
* 開始   : 2026-08-18 21:20:00 (UTC)
* 終了   : 2026-08-18 21:30:00 (UTC)
* 現象   : 2026-08-18 21:30:00 (UTC)を境に水準が 14.91から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.937, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 10→12→13→11→…→11→7→9→12
* 開始   : 2026-08-19 03:05:00 (UTC)
* 終了   : 2026-08-19 03:15:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260819-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 32.24→35.84→44.09→45.09→…→44.09→45.09→39.07→40.99
* 開始   : 2026-08-19 03:45:00 (UTC)
* 終了   : 2026-08-19 03:50:00 (UTC)
* 現象   : 平常時(36.3)に対し 1.215倍(44.09)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260819-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 42.26→41.53→49.98→44.28→…→44.28→49.02→44.75→44.44
* 開始   : 2026-08-19 05:05:00 (UTC)
* 終了   : 2026-08-19 05:15:00 (UTC)
* 現象   : 平常時(40.82)に対し 1.224倍(49.98)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.532σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 57.62→56.32→62.12→49.78→…→49.78→64.18→60.16→57.6
* 開始   : 2026-08-19 07:20:00 (UTC)
* 終了   : 2026-08-19 07:30:00 (UTC)
* 現象   : 平常時(53.9)に対し 1.152倍(62.12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260819-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 19→18→20→16→20→16→20→17→19
* 開始   : 2026-08-19 07:25:00 (UTC)
* 終了   : 2026-08-19 07:35:00 (UTC)
* 現象   : 平常時(16.75)に対し 1.194倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host01-005 (同一ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260819-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260819-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 18→16→20→19→…→19→21→19→20
* 開始   : 2026-08-19 07:45:00 (UTC)
* 終了   : 2026-08-19 07:55:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260819-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 21→18→22→21→19→18
* 開始   : 2026-08-19 15:50:00 (UTC)
* 終了   : 2026-08-19 16:15:00 (UTC)
* 現象   : 2026-08-19 16:15:00 (UTC)を境に水準が 14.98から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.795, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host01-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 18→15→16→16→16→15→14→14→15
* 開始   : 2026-08-19 17:40:00 (UTC)
* 終了   : 2026-08-19 18:40:00 (UTC)
* 現象   : 2026-08-19 18:40:00 (UTC)を境に水準が 14.99から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.383, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→12→13→11→12→13→11→12
* 開始   : 2026-08-20 03:50:00 (UTC)
* 終了   : 2026-08-20 03:55:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 12→11→13→14→13→14→12→11
* 開始   : 2026-08-20 04:05:00 (UTC)
* 終了   : 2026-08-20 04:15:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 42.79→51.36→39.97→49.02→…→49.02→54.79→51.82→52.82
* 開始   : 2026-08-20 05:55:00 (UTC)
* 終了   : 2026-08-20 06:05:00 (UTC)
* 現象   : 平常時(47.4)に対し 0.8432(39.97)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.053σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host01-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→17→16→17→17→16→19→18→20
* 開始   : 2026-08-20 06:25:00 (UTC)
* 終了   : 2026-08-20 07:25:00 (UTC)
* 現象   : 2026-08-20 07:25:00 (UTC)を境に水準が 15.09から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 19→20→24→21→20→24→21→22
* 開始   : 2026-08-20 10:40:00 (UTC)
* 終了   : 2026-08-20 10:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.176倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host01-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 23→24→23→24
* 開始   : 2026-08-20 13:20:00 (UTC)
* 終了   : 2026-08-20 13:35:00 (UTC)
* 現象   : 2026-08-20 13:35:00 (UTC)を境に水準が 14.89から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 67.66→67.75→76.57→62.1→…→76.57→62.1→66.56→66.85
* 開始   : 2026-08-20 14:05:00 (UTC)
* 終了   : 2026-08-20 14:10:00 (UTC)
* 現象   : 平常時(68.51)に対し 1.118倍(76.57)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.228σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 15→14→12→15→12→15→12→14→13
* 開始   : 2026-08-20 18:10:00 (UTC)
* 終了   : 2026-08-20 18:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.7539(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.735σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260820-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→11→14→12→…→12→15→11→13
* 開始   : 2026-08-21 04:05:00 (UTC)
* 終了   : 2026-08-21 04:15:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260821-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260821-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260821-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→12→16→13→16→13→16→13→15
* 開始   : 2026-08-21 05:05:00 (UTC)
* 終了   : 2026-08-21 05:15:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.297倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.569σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260821-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260821-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→14→16→13→16→13→16→15→13
* 開始   : 2026-08-21 05:30:00 (UTC)
* 終了   : 2026-08-21 05:40:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260821-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260821-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260821-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host01-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 21→20→21→21→22→21→22→19
* 開始   : 2026-08-21 08:20:00 (UTC)
* 終了   : 2026-08-21 08:55:00 (UTC)
* 現象   : 2026-08-21 08:55:00 (UTC)を境に水準が 15.04から14.18へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.852, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 22→21→24→21→24→21→24→23→21
* 開始   : 2026-08-21 10:40:00 (UTC)
* 終了   : 2026-08-21 10:50:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.176倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.511σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260821-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 16→14→12→14→12→14→12→14
* 開始   : 2026-08-21 18:20:00 (UTC)
* 終了   : 2026-08-21 19:30:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host01-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 20 分
  - EVT-20260821-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260821-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260821-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260821-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260821-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 10→11→7→9→11→7→9
* 開始   : 2026-08-21 21:30:00 (UTC)
* 終了   : 2026-08-21 21:35:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host01-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→10→12→11→…→12→11→12→13
* 開始   : 2026-08-22 05:00:00 (UTC)
* 終了   : 2026-08-22 05:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.932, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260822-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 11→8→9→12→11→8→9→12
* 開始   : 2026-08-22 05:20:00 (UTC)
* 終了   : 2026-08-22 05:25:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.562, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host01-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host01-003 (同一ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260822-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260822-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 43.47→37.34→38.04→41.28→35.85→42.41→42.27
* 開始   : 2026-08-23 04:50:00 (UTC)
* 終了   : 2026-08-23 05:20:00 (UTC)
* 現象   : 2026-08-23 05:20:00 (UTC)を境に水準が 40.9から41.5へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=21.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host01-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→13→14→14→14→12→12→15
* 開始   : 2026-08-23 06:05:00 (UTC)
* 終了   : 2026-08-23 06:40:00 (UTC)
* 現象   : 2026-08-23 06:40:00 (UTC)を境に水準が 11.93から12.23へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.059, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 16→14→19→15→…→15→12→16→15
* 開始   : 2026-08-23 10:10:00 (UTC)
* 終了   : 2026-08-23 10:20:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.253倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.686σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260823-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host01-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 16→16→16→16→15→16→18→14→16
* 開始   : 2026-08-23 12:55:00 (UTC)
* 終了   : 2026-08-23 14:20:00 (UTC)
* 現象   : 2026-08-23 14:20:00 (UTC)を境に水準が 11.65から14.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.638, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 11→9→6→8→9→6→8→7
* 開始   : 2026-08-23 21:15:00 (UTC)
* 終了   : 2026-08-23 21:20:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260823-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260823-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host01-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 10→10→12→8→9→8→9→10→10
* 開始   : 2026-08-23 22:55:00 (UTC)
* 終了   : 2026-08-24 01:30:00 (UTC)
* 現象   : 2026-08-24 01:30:00 (UTC)を境に水準が 11.7から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.759, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 6→8→11→7→5→11→7→5→8
* 開始   : 2026-08-23 23:50:00 (UTC)
* 終了   : 2026-08-24 00:45:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260824-lsfhost01-001 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260824-host02-001 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260824-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260823-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host01-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 37.1→29.77→34.44→35.03→36.64
* 開始   : 2026-08-24 22:05:00 (UTC)
* 終了   : 2026-08-24 22:25:00 (UTC)
* 現象   : 2026-08-24 22:25:00 (UTC)を境に水準が 49.77から50.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=27.01, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→12→14→15→12→14→15→12
* 開始   : 2026-08-25 04:40:00 (UTC)
* 終了   : 2026-08-25 04:45:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-014 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260825-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→17→14→15→17→14
* 開始   : 2026-08-25 06:00:00 (UTC)
* 終了   : 2026-08-25 06:05:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host01-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260825-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 16→14→18→16→18→16→18→15
* 開始   : 2026-08-25 06:05:00 (UTC)
* 終了   : 2026-08-25 06:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.278倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.737σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host01-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260825-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 18→17→14→19→…→19→20→18→19
* 開始   : 2026-08-25 07:55:00 (UTC)
* 終了   : 2026-08-25 08:05:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260825-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260825-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260825-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 59.77→63.12→70.38→60.21→…→60.21→68.76→61.47→61.6
* 開始   : 2026-08-25 08:25:00 (UTC)
* 終了   : 2026-08-25 08:35:00 (UTC)
* 現象   : 平常時(60.17)に対し 1.17倍(70.38)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.822σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host01-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260825-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 19→21→16→22→…→16→22→18→19
* 開始   : 2026-08-25 08:30:00 (UTC)
* 終了   : 2026-08-25 08:35:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.8458(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host01-005 (同一ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260825-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 21→20→25→22→…→19→25→22→21
* 開始   : 2026-08-25 12:35:00 (UTC)
* 終了   : 2026-08-25 12:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.447σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260825-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 23→24→19→23→24→19→23→24
* 開始   : 2026-08-25 12:45:00 (UTC)
* 終了   : 2026-08-25 12:50:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8444(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260825-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→14→18→14→18→14→17→16
* 開始   : 2026-08-25 17:20:00 (UTC)
* 終了   : 2026-08-25 17:30:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260825-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260825-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→16→13→16→13→16→13
* 開始   : 2026-08-25 17:55:00 (UTC)
* 終了   : 2026-08-25 18:00:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→10→12→10→12→10→13
* 開始   : 2026-08-25 19:30:00 (UTC)
* 終了   : 2026-08-25 19:40:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 7→10→12→7→…→7→5→6→7
* 開始   : 2026-08-25 22:55:00 (UTC)
* 終了   : 2026-08-25 23:05:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-081 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260825-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 9→11→6→9→…→9→12→11→12
* 開始   : 2026-08-26 03:05:00 (UTC)
* 終了   : 2026-08-26 03:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260826-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→18→19→18→20→19→18→20→19
* 開始   : 2026-08-26 07:25:00 (UTC)
* 終了   : 2026-08-26 07:35:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260826-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 58.08→58.07→56.01→58.51→…→58.51→54.91→62.55→58.6
* 開始   : 2026-08-26 15:45:00 (UTC)
* 終了   : 2026-08-26 15:55:00 (UTC)
* 現象   : 平常時(63.55)に対し 0.8813(56.01)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260826-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 16→13→16→13→16→14
* 開始   : 2026-08-26 18:05:00 (UTC)
* 終了   : 2026-08-26 18:10:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 10→8→11→8→11→8→13→8
* 開始   : 2026-08-26 20:55:00 (UTC)
* 終了   : 2026-08-26 21:05:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→9→8→9→10→10
* 開始   : 2026-08-26 23:40:00 (UTC)
* 終了   : 2026-08-27 00:05:00 (UTC)
* 現象   : 2026-08-27 00:05:00 (UTC)を境に水準が 14.99から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.795, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→14→16→14→16→14→12
* 開始   : 2026-08-27 05:25:00 (UTC)
* 終了   : 2026-08-27 05:30:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260827-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 17→20→15→19→20→15→19→18
* 開始   : 2026-08-27 16:05:00 (UTC)
* 終了   : 2026-08-27 16:10:00 (UTC)
* 現象   : 平常時(19)に対し 0.7895(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.795σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→15→12→15→…→15→11→12→14
* 開始   : 2026-08-27 18:35:00 (UTC)
* 終了   : 2026-08-27 18:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 29.76→29.04→36.86→22.66→…→36.86→22.66→31.54→32.88
* 開始   : 2026-08-28 01:05:00 (UTC)
* 終了   : 2026-08-28 01:10:00 (UTC)
* 現象   : 平常時(29.6)に対し 1.245倍(36.86)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.008σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-lsfhost01-004 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260828-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260828-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→16→18→15→…→15→19→15→16
* 開始   : 2026-08-28 06:25:00 (UTC)
* 終了   : 2026-08-28 06:35:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260828-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260828-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 23→22→19→25→22→19→25→22→23
* 開始   : 2026-08-28 11:25:00 (UTC)
* 終了   : 2026-08-28 11:30:00 (UTC)
* 現象   : 平常時(22)に対し 0.8636(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→15→11→14→…→14→10→14→12
* 開始   : 2026-08-28 18:45:00 (UTC)
* 終了   : 2026-08-28 18:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host03-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 8→9→7→9→7→8
* 開始   : 2026-08-28 21:45:00 (UTC)
* 終了   : 2026-08-28 21:50:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.672(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 7→11→10→11→10→11→9
* 開始   : 2026-08-29 02:25:00 (UTC)
* 終了   : 2026-08-29 02:35:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260829-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260829-host01-001 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
