# host14 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host14 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 318 (SEVERE: 23, FATAL: 132, WARN: 163, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 23 | 132 | 163 | 318 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→18→17→18→…→13→12→14→13
* 開始   : 2026-06-08 02:10:00 (UTC)
* 終了   : 2026-06-08 20:20:00 (UTC)
* 現象   : 2026-06-08 20:20:00 (UTC)を境に水準が 11.81から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 4.047 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.736, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.301, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host14-001 active_connections の推移](charts/EVT-20260608-host14-001.svg)

# イベントID( EVT-20260608-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→13→16→15→…→12→14→13→11
* 開始   : 2026-06-08 02:10:00 (UTC)
* 終了   : 2026-06-08 20:05:00 (UTC)
* 現象   : 2026-06-08 20:05:00 (UTC)を境に水準が 11.87から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.333σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.925, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.45, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host14-002 active_connections の推移](charts/EVT-20260608-host14-002.svg)

# イベントID( EVT-20260608-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→16→17→16→…→13→15→14→13
* 開始   : 2026-06-08 02:35:00 (UTC)
* 終了   : 2026-06-08 20:05:00 (UTC)
* 現象   : 2026-06-08 20:05:00 (UTC)を境に水準が 11.9から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.024σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.072, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.21, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host14-003 active_connections の推移](charts/EVT-20260608-host14-003.svg)

# イベントID( EVT-20260608-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→16→14→13→…→13→12→10→13
* 開始   : 2026-06-08 02:45:00 (UTC)
* 終了   : 2026-06-08 20:45:00 (UTC)
* 現象   : 2026-06-08 20:45:00 (UTC)を境に水準が 11.84から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.794, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host14-004 active_connections の推移](charts/EVT-20260608-host14-004.svg)

# イベントID( EVT-20260608-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→15→16→15→…→15→16→14→13
* 開始   : 2026-06-08 03:00:00 (UTC)
* 終了   : 2026-06-08 20:50:00 (UTC)
* 現象   : 2026-06-08 20:50:00 (UTC)を境に水準が 11.79から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.7, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host14-005 active_connections の推移](charts/EVT-20260608-host14-005.svg)

# イベントID( EVT-20260608-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→15→14→15→…→15→13→15→13
* 開始   : 2026-06-08 04:10:00 (UTC)
* 終了   : 2026-06-08 21:10:00 (UTC)
* 現象   : 2026-06-08 21:10:00 (UTC)を境に水準が 11.86から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.907, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.941, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host14-006 active_connections の推移](charts/EVT-20260608-host14-006.svg)

# イベントID( EVT-20260615-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→15→…→11→14→13→11
* 開始   : 2026-06-15 01:55:00 (UTC)
* 終了   : 2026-06-15 20:55:00 (UTC)
* 現象   : 2026-06-15 20:55:00 (UTC)を境に水準が 11.86から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.487σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.835, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host14-002 active_connections の推移](charts/EVT-20260615-host14-002.svg)

# イベントID( EVT-20260615-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→14→15→14→…→14→13→10→13
* 開始   : 2026-06-15 02:05:00 (UTC)
* 終了   : 2026-06-15 21:20:00 (UTC)
* 現象   : 2026-06-15 21:20:00 (UTC)を境に水準が 11.71から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.028, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.917, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host14-004 active_connections の推移](charts/EVT-20260615-host14-004.svg)

# イベントID( EVT-20260615-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→14→16→18→…→15→16→14→15
* 開始   : 2026-06-15 02:20:00 (UTC)
* 終了   : 2026-06-15 18:30:00 (UTC)
* 現象   : 2026-06-15 18:30:00 (UTC)を境に水準が 11.98から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.7, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host14-005 active_connections の推移](charts/EVT-20260615-host14-005.svg)

# イベントID( EVT-20260615-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 16→13→16→13→…→15→12→15→12
* 開始   : 2026-06-15 03:45:00 (UTC)
* 終了   : 2026-06-15 21:30:00 (UTC)
* 現象   : 2026-06-15 21:30:00 (UTC)を境に水準が 11.83から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.683, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.93, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host14-006 active_connections の推移](charts/EVT-20260615-host14-006.svg)

# イベントID( EVT-20260615-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 16→15→14→17→…→12→14→12→13
* 開始   : 2026-06-15 03:55:00 (UTC)
* 終了   : 2026-06-15 20:25:00 (UTC)
* 現象   : 2026-06-15 20:25:00 (UTC)を境に水準が 11.84から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.668, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host14-007 active_connections の推移](charts/EVT-20260615-host14-007.svg)

# イベントID( EVT-20260622-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→15→14→15→…→14→15→11→14
* 開始   : 2026-06-22 03:00:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 11.75から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 4.721 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.72, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.648, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host14-003 active_connections の推移](charts/EVT-20260622-host14-003.svg)

# イベントID( EVT-20260622-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→16→19→16→…→15→14→11→13
* 開始   : 2026-06-22 03:05:00 (UTC)
* 終了   : 2026-06-22 21:45:00 (UTC)
* 現象   : 2026-06-22 21:45:00 (UTC)を境に水準が 11.99から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.295σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.208, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.459, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host14-004 active_connections の推移](charts/EVT-20260622-host14-004.svg)

# イベントID( EVT-20260622-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→17→…→15→14→13→16
* 開始   : 2026-06-22 03:20:00 (UTC)
* 終了   : 2026-06-22 20:15:00 (UTC)
* 現象   : 2026-06-22 20:15:00 (UTC)を境に水準が 11.83から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.007σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.944, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host14-005 active_connections の推移](charts/EVT-20260622-host14-005.svg)

# イベントID( EVT-20260622-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→13→14→17→…→13→15→14→16
* 開始   : 2026-06-22 03:30:00 (UTC)
* 終了   : 2026-06-22 20:15:00 (UTC)
* 現象   : 2026-06-22 20:15:00 (UTC)を境に水準が 11.86から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.842, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.971, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host14-006 active_connections の推移](charts/EVT-20260622-host14-006.svg)

# イベントID( EVT-20260622-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→18→15→18→…→12→14→13→12
* 開始   : 2026-06-22 03:55:00 (UTC)
* 終了   : 2026-06-22 21:55:00 (UTC)
* 現象   : 2026-06-22 21:55:00 (UTC)を境に水準が 11.88から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.7, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host14-007 active_connections の推移](charts/EVT-20260622-host14-007.svg)

# イベントID( EVT-20260622-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→16→14→16→…→13→14→13→12
* 開始   : 2026-06-22 04:10:00 (UTC)
* 終了   : 2026-06-22 20:05:00 (UTC)
* 現象   : 2026-06-22 20:05:00 (UTC)を境に水準が 12.08から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.37σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.789, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host14-008 active_connections の推移](charts/EVT-20260622-host14-008.svg)

# イベントID( EVT-20260629-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→17→18→17→…→13→15→11→14
* 開始   : 2026-06-29 01:35:00 (UTC)
* 終了   : 2026-06-29 20:00:00 (UTC)
* 現象   : 2026-06-29 20:00:00 (UTC)を境に水準が 11.8から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.105, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.85, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-001 active_connections の推移](charts/EVT-20260629-host14-001.svg)

# イベントID( EVT-20260629-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→15→16→15→…→12→13→12→10
* 開始   : 2026-06-29 02:15:00 (UTC)
* 終了   : 2026-06-29 20:45:00 (UTC)
* 現象   : 2026-06-29 20:45:00 (UTC)を境に水準が 11.87から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.665, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.149, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-002 active_connections の推移](charts/EVT-20260629-host14-002.svg)

# イベントID( EVT-20260629-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→13→14→15→…→15→13→14→13
* 開始   : 2026-06-29 02:25:00 (UTC)
* 終了   : 2026-06-29 18:50:00 (UTC)
* 現象   : 2026-06-29 18:50:00 (UTC)を境に水準が 11.85から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.024, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-003 active_connections の推移](charts/EVT-20260629-host14-003.svg)

# イベントID( EVT-20260629-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→15→14→13→…→14→12→15→12
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 20:30:00 (UTC)
* 現象   : 2026-06-29 20:30:00 (UTC)を境に水準が 11.79から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.685σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.065, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.834, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-005 active_connections の推移](charts/EVT-20260629-host14-005.svg)

# イベントID( EVT-20260629-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→16→15→16→…→15→14→15→13
* 開始   : 2026-06-29 03:20:00 (UTC)
* 終了   : 2026-06-29 21:00:00 (UTC)
* 現象   : 2026-06-29 21:00:00 (UTC)を境に水準が 11.88から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.681, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.699, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-006 active_connections の推移](charts/EVT-20260629-host14-006.svg)

# イベントID( EVT-20260629-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 16→14→16→14→…→14→15→13→15
* 開始   : 2026-06-29 04:25:00 (UTC)
* 終了   : 2026-06-29 20:20:00 (UTC)
* 現象   : 2026-06-29 20:20:00 (UTC)を境に水準が 12.05から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.255σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.737, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-007 active_connections の推移](charts/EVT-20260629-host14-007.svg)

# イベントID( EVT-20260601-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 10→8→4→8→6
* 開始   : 2026-06-01 00:30:00 (UTC)
* 終了   : 2026-06-01 00:30:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 10→11→12→11→…→11→14→8→10
* 開始   : 2026-06-01 03:10:00 (UTC)
* 終了   : 2026-06-01 03:20:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 16→17→21→18→…→18→20→17→19
* 開始   : 2026-06-01 07:15:00 (UTC)
* 終了   : 2026-06-01 07:25:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 21→23→18→20→23
* 開始   : 2026-06-01 13:20:00 (UTC)
* 終了   : 2026-06-01 13:20:00 (UTC)
* 現象   : 平常時(22.58)に対し 0.797(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 16→17→19→14→15
* 開始   : 2026-06-02 06:40:00 (UTC)
* 終了   : 2026-06-02 06:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→16→19→18→21→19→18→21→16
* 開始   : 2026-06-02 06:45:00 (UTC)
* 終了   : 2026-06-02 07:15:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host14-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260602-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260602-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 16→17→20→18→20→18→20→17→18
* 開始   : 2026-06-02 07:05:00 (UTC)
* 終了   : 2026-06-02 07:15:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.065σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-033 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260602-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→12→8→11→13
* 開始   : 2026-06-02 19:30:00 (UTC)
* 終了   : 2026-06-02 19:30:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.6194(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.428σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host14-008 active_connections の推移](charts/EVT-20260602-host14-008.svg)

# イベントID( EVT-20260603-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 19→18→23→20→21
* 開始   : 2026-06-03 08:50:00 (UTC)
* 終了   : 2026-06-03 08:50:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.179σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 20→18→23→19→…→19→22→20→19
* 開始   : 2026-06-03 08:55:00 (UTC)
* 終了   : 2026-06-03 09:05:00 (UTC)
* 現象   : 平常時(18.17)に対し 1.266倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→10→9→12→…→9→11→7→11
* 開始   : 2026-06-03 20:10:00 (UTC)
* 終了   : 2026-06-03 20:30:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-071 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260603-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 7→9→13→7→10
* 開始   : 2026-06-04 01:20:00 (UTC)
* 終了   : 2026-06-04 01:20:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 19→19→17→17→18→19→17→19
* 開始   : 2026-06-04 16:55:00 (UTC)
* 終了   : 2026-06-04 19:05:00 (UTC)
* 現象   : 2026-06-04 19:05:00 (UTC)を境に水準が 15.03から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.543σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.074, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→12→7→10→9
* 開始   : 2026-06-04 20:15:00 (UTC)
* 終了   : 2026-06-04 20:15:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.5793(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.526σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host14-013 active_connections の推移](charts/EVT-20260604-host14-013.svg)

# イベントID( EVT-20260605-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→17→20→21→20→17→20→21→20
* 開始   : 2026-06-05 07:00:00 (UTC)
* 終了   : 2026-06-05 08:05:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260605-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260605-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 18→20→23→20→23→20→21
* 開始   : 2026-06-05 09:10:00 (UTC)
* 終了   : 2026-06-05 09:15:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 22→19→22→26→19→22→26→23
* 開始   : 2026-06-05 12:10:00 (UTC)
* 終了   : 2026-06-05 12:20:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 20→19→15→17→18
* 開始   : 2026-06-05 16:30:00 (UTC)
* 終了   : 2026-06-05 16:30:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260605-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→15→10→13→13
* 開始   : 2026-06-05 18:45:00 (UTC)
* 終了   : 2026-06-05 18:45:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host14-013 active_connections の推移](charts/EVT-20260605-host14-013.svg)

# イベントID( EVT-20260606-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 8→11→13→10→…→10→6→8→11
* 開始   : 2026-06-06 02:40:00 (UTC)
* 終了   : 2026-06-06 02:50:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260606-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260606-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260606-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→12→13→12→…→11→12→13→10
* 開始   : 2026-06-06 05:00:00 (UTC)
* 終了   : 2026-06-06 19:40:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.179σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.052, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260606-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260606-host14-002 active_connections の推移](charts/EVT-20260606-host14-002.svg)

# イベントID( EVT-20260606-host14-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→11→9→11→…→11→13→14→11
* 開始   : 2026-06-06 05:05:00 (UTC)
* 終了   : 2026-06-06 18:40:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.845, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260606-host14-003 active_connections の推移](charts/EVT-20260606-host14-003.svg)

# イベントID( EVT-20260606-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→10→11→12→…→12→13→12→13
* 開始   : 2026-06-06 05:10:00 (UTC)
* 終了   : 2026-06-06 19:10:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.196σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.985, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260606-host14-004 active_connections の推移](charts/EVT-20260606-host14-004.svg)

# イベントID( EVT-20260606-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→11→10→14→…→10→8→12→11
* 開始   : 2026-06-06 05:30:00 (UTC)
* 終了   : 2026-06-06 19:25:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.321, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host14-005 active_connections の推移](charts/EVT-20260606-host14-005.svg)

# イベントID( EVT-20260606-host14-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 13→11→10→11→…→11→14→10→11
* 開始   : 2026-06-06 05:45:00 (UTC)
* 終了   : 2026-06-06 18:40:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.754, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260606-host14-006 active_connections の推移](charts/EVT-20260606-host14-006.svg)

# イベントID( EVT-20260606-host14-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→12→9→12→…→13→12→13→12
* 開始   : 2026-06-06 05:55:00 (UTC)
* 終了   : 2026-06-06 20:00:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.963, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.0 時間

![EVT-20260606-host14-007 active_connections の推移](charts/EVT-20260606-host14-007.svg)

# イベントID( EVT-20260607-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 8→6→12→10→11
* 開始   : 2026-06-07 03:05:00 (UTC)
* 終了   : 2026-06-07 03:05:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→16→12→15→16→12→15→14→12
* 開始   : 2026-06-07 06:45:00 (UTC)
* 終了   : 2026-06-07 06:55:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260607-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260607-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→16→13→13→14→15→14
* 開始   : 2026-06-07 16:20:00 (UTC)
* 終了   : 2026-06-07 17:10:00 (UTC)
* 現象   : 2026-06-07 17:10:00 (UTC)を境に水準が 11.82から14.52へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.468σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 11→11→5→12→8
* 開始   : 2026-06-07 21:00:00 (UTC)
* 終了   : 2026-06-07 21:00:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260607-host14-006 active_connections の推移](charts/EVT-20260607-host14-006.svg)

# イベントID( EVT-20260608-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 9→9→3→10→6
* 開始   : 2026-06-08 23:40:00 (UTC)
* 終了   : 2026-06-08 23:40:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.3529(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.816σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260608-host14-007 active_connections の推移](charts/EVT-20260608-host14-007.svg)

# イベントID( EVT-20260609-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 8→9→13→12→…→13→12→8→9
* 開始   : 2026-06-09 02:15:00 (UTC)
* 終了   : 2026-06-09 02:20:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.007σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 21→21→24→20→20
* 開始   : 2026-06-09 09:15:00 (UTC)
* 終了   : 2026-06-09 09:15:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host14-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 15→14→11→12→…→11→12→17→14
* 開始   : 2026-06-09 18:40:00 (UTC)
* 終了   : 2026-06-09 18:45:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.6984(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.296σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→11→7→13→10
* 開始   : 2026-06-09 20:10:00 (UTC)
* 終了   : 2026-06-09 20:10:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.5793(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.551σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host14-013 active_connections の推移](charts/EVT-20260609-host14-013.svg)

# イベントID( EVT-20260610-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→9→13→9→10
* 開始   : 2026-06-10 02:00:00 (UTC)
* 終了   : 2026-06-10 02:00:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.295σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 16→17→19→16→15
* 開始   : 2026-06-10 06:30:00 (UTC)
* 終了   : 2026-06-10 06:30:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 18→20→22→18→18
* 開始   : 2026-06-10 08:00:00 (UTC)
* 終了   : 2026-06-10 08:00:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 19→19→24→20→20
* 開始   : 2026-06-10 09:05:00 (UTC)
* 終了   : 2026-06-10 09:05:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.303倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.911σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host14-006 active_connections の推移](charts/EVT-20260610-host14-006.svg)

# イベントID( EVT-20260610-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 20→18→15→17→16→16→17→15→18
* 開始   : 2026-06-10 17:00:00 (UTC)
* 終了   : 2026-06-10 19:55:00 (UTC)
* 現象   : 2026-06-10 19:55:00 (UTC)を境に水準が 14.99から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.179σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.917, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 17→16→15→17→16→16→18→18→18
* 開始   : 2026-06-11 06:05:00 (UTC)
* 終了   : 2026-06-11 07:20:00 (UTC)
* 現象   : 2026-06-11 07:20:00 (UTC)を境に水準が 14.94から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.468σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.149, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 19→19→14→17→18
* 開始   : 2026-06-11 16:30:00 (UTC)
* 終了   : 2026-06-11 16:30:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 13→14→11→12→15→14→11→12→15
* 開始   : 2026-06-11 18:30:00 (UTC)
* 終了   : 2026-06-11 18:35:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260611-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→12→8→12→10
* 開始   : 2026-06-11 20:05:00 (UTC)
* 終了   : 2026-06-11 20:05:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260611-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 20→19→22→20→…→19→25→19→20
* 開始   : 2026-06-12 09:05:00 (UTC)
* 終了   : 2026-06-12 09:25:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.198σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260612-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host14-006 active_connections の推移](charts/EVT-20260612-host14-006.svg)

# イベントID( EVT-20260612-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 23→21→26→24→21
* 開始   : 2026-06-12 11:55:00 (UTC)
* 終了   : 2026-06-12 11:55:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 22→21→17→22→22
* 開始   : 2026-06-12 14:25:00 (UTC)
* 終了   : 2026-06-12 14:25:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 20→19→16→19→16→19→18
* 開始   : 2026-06-12 15:35:00 (UTC)
* 終了   : 2026-06-12 15:40:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.122σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→15→14→14→15→14→13→13→15
* 開始   : 2026-06-12 18:35:00 (UTC)
* 終了   : 2026-06-12 22:05:00 (UTC)
* 現象   : 2026-06-12 22:05:00 (UTC)を境に水準が 14.96から12.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→14→12→10→…→12→10→13→14
* 開始   : 2026-06-12 18:55:00 (UTC)
* 終了   : 2026-06-12 19:00:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host14-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-082 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→13→8→12→12
* 開始   : 2026-06-12 20:05:00 (UTC)
* 終了   : 2026-06-12 20:05:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.18σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260612-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 7→10→4→9→7
* 開始   : 2026-06-12 23:15:00 (UTC)
* 終了   : 2026-06-12 23:15:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host14-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→9→14→11→8
* 開始   : 2026-06-13 04:25:00 (UTC)
* 終了   : 2026-06-13 04:25:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260613-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260613-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260613-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260613-host14-001 active_connections の推移](charts/EVT-20260613-host14-001.svg)

# イベントID( EVT-20260613-host14-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→11→10→12→…→13→11→14→12
* 開始   : 2026-06-13 04:30:00 (UTC)
* 終了   : 2026-06-13 19:25:00 (UTC)
* 現象   : 14.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.094, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260613-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間

![EVT-20260613-host14-002 active_connections の推移](charts/EVT-20260613-host14-002.svg)

# イベントID( EVT-20260613-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→10→12→10→…→13→10→13→12
* 開始   : 2026-06-13 05:05:00 (UTC)
* 終了   : 2026-06-13 18:10:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.313σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.778, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260613-host14-003 active_connections の推移](charts/EVT-20260613-host14-003.svg)

# イベントID( EVT-20260613-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→13→…→13→11→13→12
* 開始   : 2026-06-13 05:15:00 (UTC)
* 終了   : 2026-06-13 18:40:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.021σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.807, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260613-host14-004 active_connections の推移](charts/EVT-20260613-host14-004.svg)

# イベントID( EVT-20260613-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→14→11→12→…→14→10→11→10
* 開始   : 2026-06-13 05:50:00 (UTC)
* 終了   : 2026-06-13 18:55:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.727, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260613-host14-005 active_connections の推移](charts/EVT-20260613-host14-005.svg)

# イベントID( EVT-20260613-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→14→12→14→…→9→11→12→10
* 開始   : 2026-06-13 06:20:00 (UTC)
* 終了   : 2026-06-13 19:50:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.01, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260613-host14-006 active_connections の推移](charts/EVT-20260613-host14-006.svg)

# イベントID( EVT-20260613-host14-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→12→13→12→…→10→9→11→10
* 開始   : 2026-06-13 06:30:00 (UTC)
* 終了   : 2026-06-13 19:25:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.746, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260613-host14-007 active_connections の推移](charts/EVT-20260613-host14-007.svg)

# イベントID( EVT-20260614-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→12→17→13→13
* 開始   : 2026-06-14 06:55:00 (UTC)
* 終了   : 2026-06-14 06:55:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.447倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.643σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-lsfhost01-014 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260614-host14-005 active_connections の推移](charts/EVT-20260614-host14-005.svg)

# イベントID( EVT-20260615-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 7→9→12→9→8
* 開始   : 2026-06-15 01:25:00 (UTC)
* 終了   : 2026-06-15 01:25:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260615-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host14-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→15→18→14→…→14→15→14→15
* 開始   : 2026-06-15 01:55:00 (UTC)
* 終了   : 2026-06-15 21:20:00 (UTC)
* 現象   : 2026-06-15 21:20:00 (UTC)を境に水準が 11.83から14.9へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.793, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.925, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→11→17→12→11→17→12→15
* 開始   : 2026-06-16 05:40:00 (UTC)
* 終了   : 2026-06-16 07:05:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.333倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.968σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 1.1 時間
  - EVT-20260616-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260616-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分

![EVT-20260616-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 19→20→24→22→22
* 開始   : 2026-06-16 09:15:00 (UTC)
* 終了   : 2026-06-16 09:15:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.258倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.428σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host14-006 active_connections の推移](charts/EVT-20260616-host14-006.svg)

# イベントID( EVT-20260616-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 21→22→15→19→20
* 開始   : 2026-06-16 15:30:00 (UTC)
* 終了   : 2026-06-16 15:30:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7377(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.736σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host14-009 active_connections の推移](charts/EVT-20260616-host14-009.svg)

# イベントID( EVT-20260616-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→13→10→12→14
* 開始   : 2026-06-16 18:40:00 (UTC)
* 終了   : 2026-06-16 18:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260616-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 10→11→14→11→10
* 開始   : 2026-06-17 03:10:00 (UTC)
* 終了   : 2026-06-17 03:10:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→14→18→15→15
* 開始   : 2026-06-17 06:00:00 (UTC)
* 終了   : 2026-06-17 06:00:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→14→19→15→14
* 開始   : 2026-06-17 06:20:00 (UTC)
* 終了   : 2026-06-17 06:20:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.181σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 16→16→20→16→16
* 開始   : 2026-06-17 07:00:00 (UTC)
* 終了   : 2026-06-17 07:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 17→15→21→19→17
* 開始   : 2026-06-17 07:25:00 (UTC)
* 終了   : 2026-06-17 07:25:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.279倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 17→16→22→20→19
* 開始   : 2026-06-17 08:15:00 (UTC)
* 終了   : 2026-06-17 08:15:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.269倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.237σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260617-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 20→21→25→18→21→25→18→21→23
* 開始   : 2026-06-17 10:15:00 (UTC)
* 終了   : 2026-06-17 10:20:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 21→18→16→20→22
* 開始   : 2026-06-17 15:15:00 (UTC)
* 終了   : 2026-06-17 15:15:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260617-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 17→18→21→20→18→21→20→18
* 開始   : 2026-06-18 07:50:00 (UTC)
* 終了   : 2026-06-18 07:55:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 19→19→24→19→20
* 開始   : 2026-06-18 09:05:00 (UTC)
* 終了   : 2026-06-18 09:05:00 (UTC)
* 現象   : 平常時(19.17)に対し 1.252倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 22→24→18→20→18→20→18→21
* 開始   : 2026-06-18 13:50:00 (UTC)
* 終了   : 2026-06-18 14:00:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260618-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→12→9→12→12
* 開始   : 2026-06-18 19:25:00 (UTC)
* 終了   : 2026-06-18 20:20:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host05-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host05-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-055 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260618-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260618-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 18→20→23→18→21
* 開始   : 2026-06-19 08:50:00 (UTC)
* 終了   : 2026-06-19 08:50:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→15→9→12→13
* 開始   : 2026-06-19 18:50:00 (UTC)
* 終了   : 2026-06-19 18:50:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.6316(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.667σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host14-009 active_connections の推移](charts/EVT-20260619-host14-009.svg)

# イベントID( EVT-20260619-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 8→10→4→10→8
* 開始   : 2026-06-19 23:05:00 (UTC)
* 終了   : 2026-06-19 23:05:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-078 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 8→8→13→10→7
* 開始   : 2026-06-20 02:35:00 (UTC)
* 終了   : 2026-06-20 02:35:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.237σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→15→12→13→…→12→13→14→11
* 開始   : 2026-06-20 04:35:00 (UTC)
* 終了   : 2026-06-20 18:00:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.024σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.842, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260620-host14-002 active_connections の推移](charts/EVT-20260620-host14-002.svg)

# イベントID( EVT-20260620-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→10→8→12→…→11→10→13→14
* 開始   : 2026-06-20 05:20:00 (UTC)
* 終了   : 2026-06-20 20:35:00 (UTC)
* 現象   : 15.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.263, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host14-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260620-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260620-host14-003 active_connections の推移](charts/EVT-20260620-host14-003.svg)

# イベントID( EVT-20260620-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→11→10→11→…→13→10→12→11
* 開始   : 2026-06-20 05:20:00 (UTC)
* 終了   : 2026-06-20 18:25:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.772, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260620-host14-004 active_connections の推移](charts/EVT-20260620-host14-004.svg)

# イベントID( EVT-20260620-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→11→9→10→…→13→12→11→12
* 開始   : 2026-06-20 05:35:00 (UTC)
* 終了   : 2026-06-20 18:20:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.971, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260620-host14-005 active_connections の推移](charts/EVT-20260620-host14-005.svg)

# イベントID( EVT-20260620-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→11→10→13→…→12→13→12→13
* 開始   : 2026-06-20 05:40:00 (UTC)
* 終了   : 2026-06-20 18:20:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.9, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260620-host14-006 active_connections の推移](charts/EVT-20260620-host14-006.svg)

# イベントID( EVT-20260620-host14-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→9→10→12→…→12→11→13→12
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 19:40:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.022, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host14-007 active_connections の推移](charts/EVT-20260620-host14-007.svg)

# イベントID( EVT-20260621-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 7→10→4→9→6
* 開始   : 2026-06-21 00:30:00 (UTC)
* 終了   : 2026-06-21 00:30:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→12→16→15→12→16→15→12→13
* 開始   : 2026-06-21 07:10:00 (UTC)
* 終了   : 2026-06-21 07:15:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分

![EVT-20260621-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→15→9→13→14
* 開始   : 2026-06-21 17:30:00 (UTC)
* 終了   : 2026-06-21 17:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.064σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host11-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→7→4→8→9
* 開始   : 2026-06-21 23:00:00 (UTC)
* 終了   : 2026-06-21 23:00:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260621-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 10→7→13→9→9
* 開始   : 2026-06-23 01:40:00 (UTC)
* 終了   : 2026-06-23 01:40:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.642倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.545σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host14-001 active_connections の推移](charts/EVT-20260623-host14-001.svg)

# イベントID( EVT-20260623-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 8→10→16→12→12
* 開始   : 2026-06-23 03:50:00 (UTC)
* 終了   : 2026-06-23 03:50:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.587倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.132σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host14-003 active_connections の推移](charts/EVT-20260623-host14-003.svg)

# イベントID( EVT-20260623-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→15→20→15→15
* 開始   : 2026-06-23 06:25:00 (UTC)
* 終了   : 2026-06-23 06:25:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.387倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.873σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host14-004 active_connections の推移](charts/EVT-20260623-host14-004.svg)

# イベントID( EVT-20260623-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 21→20→16→20→20
* 開始   : 2026-06-23 14:50:00 (UTC)
* 終了   : 2026-06-23 14:50:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.7742(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.238σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 21→18→16→17→20
* 開始   : 2026-06-23 15:30:00 (UTC)
* 終了   : 2026-06-23 15:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→16→13→14→…→14→12→16→15
* 開始   : 2026-06-23 18:15:00 (UTC)
* 終了   : 2026-06-23 19:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host14-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260623-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260623-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 45 分
  - EVT-20260623-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分

![EVT-20260623-host14-011 active_connections の推移](charts/EVT-20260623-host14-011.svg)

# イベントID( EVT-20260623-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→13→9→11→12
* 開始   : 2026-06-23 19:35:00 (UTC)
* 終了   : 2026-06-23 19:35:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.6391(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.551σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host14-013 active_connections の推移](charts/EVT-20260623-host14-013.svg)

# イベントID( EVT-20260623-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 9→10→4→8→9
* 開始   : 2026-06-23 22:00:00 (UTC)
* 終了   : 2026-06-23 22:00:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.4211(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.853σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host14-014 active_connections の推移](charts/EVT-20260623-host14-014.svg)

# イベントID( EVT-20260624-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 10→14→9→13→14→9→13→11→10
* 開始   : 2026-06-24 02:45:00 (UTC)
* 終了   : 2026-06-24 02:55:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260624-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→14→19→16→18
* 開始   : 2026-06-24 06:25:00 (UTC)
* 終了   : 2026-06-24 06:25:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→15→19→15→15
* 開始   : 2026-06-24 06:25:00 (UTC)
* 終了   : 2026-06-24 06:25:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 20→24→17→22→20
* 開始   : 2026-06-24 14:35:00 (UTC)
* 終了   : 2026-06-24 14:35:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.7698(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.526σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host14-010 active_connections の推移](charts/EVT-20260624-host14-010.svg)

# イベントID( EVT-20260624-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 18→17→14→18→…→14→12→17→16
* 開始   : 2026-06-24 17:25:00 (UTC)
* 終了   : 2026-06-24 17:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260624-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→12→16→12→14
* 開始   : 2026-06-25 04:35:00 (UTC)
* 終了   : 2026-06-25 04:35:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.181σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260625-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→14→15→12→…→18→15→17→15
* 開始   : 2026-06-25 05:25:00 (UTC)
* 終了   : 2026-06-25 05:45:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260625-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260625-host14-004 active_connections の推移](charts/EVT-20260625-host14-004.svg)

# イベントID( EVT-20260625-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→20→23→21→20
* 開始   : 2026-06-25 09:00:00 (UTC)
* 終了   : 2026-06-25 09:00:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 18→19→15→21→20
* 開始   : 2026-06-25 15:30:00 (UTC)
* 終了   : 2026-06-25 15:30:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 18→15→18→13→15→18→13→16→17
* 開始   : 2026-06-25 16:40:00 (UTC)
* 終了   : 2026-06-25 16:50:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-062 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260625-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host14-011 active_connections の推移](charts/EVT-20260625-host14-011.svg)

# イベントID( EVT-20260625-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→13→11→8→…→11→8→11→13
* 開始   : 2026-06-25 19:05:00 (UTC)
* 終了   : 2026-06-25 19:15:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host14-013 active_connections の推移](charts/EVT-20260625-host14-013.svg)

# イベントID( EVT-20260625-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→15→11→10→…→12→8→10→13
* 開始   : 2026-06-25 19:25:00 (UTC)
* 終了   : 2026-06-25 19:50:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host14-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-077 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-079 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-078 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host14-014 active_connections の推移](charts/EVT-20260625-host14-014.svg)

# イベントID( EVT-20260625-host14-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→12→6→9→9
* 開始   : 2026-06-25 21:25:00 (UTC)
* 終了   : 2026-06-25 21:25:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.18σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host14-016 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host14-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 18→17→21→18→21→18→21→18→20
* 開始   : 2026-06-26 07:45:00 (UTC)
* 終了   : 2026-06-26 07:55:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260626-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260626-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 19→22→17→21→21
* 開始   : 2026-06-26 13:55:00 (UTC)
* 終了   : 2026-06-26 13:55:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 7→10→5→9→8
* 開始   : 2026-06-26 22:30:00 (UTC)
* 終了   : 2026-06-26 22:30:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-079 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host14-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→11→12→11→…→14→13→14→12
* 開始   : 2026-06-27 04:50:00 (UTC)
* 終了   : 2026-06-27 18:05:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.965, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 13.2 時間
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 13.2 時間

![EVT-20260627-host14-002 active_connections の推移](charts/EVT-20260627-host14-002.svg)

# イベントID( EVT-20260627-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→13→11→12→…→9→11→12→13
* 開始   : 2026-06-27 05:15:00 (UTC)
* 終了   : 2026-06-27 19:35:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.795, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260627-host14-003 active_connections の推移](charts/EVT-20260627-host14-003.svg)

# イベントID( EVT-20260627-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→11→14→11→…→11→12→11→12
* 開始   : 2026-06-27 05:40:00 (UTC)
* 終了   : 2026-06-27 18:25:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.96, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host14-004 active_connections の推移](charts/EVT-20260627-host14-004.svg)

# イベントID( EVT-20260627-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→14→…→14→12→14→12
* 開始   : 2026-06-27 06:00:00 (UTC)
* 終了   : 2026-06-27 19:35:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.795, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260627-host14-005 active_connections の推移](charts/EVT-20260627-host14-005.svg)

# イベントID( EVT-20260627-host14-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 12→10→12→10→…→13→12→13→12
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 17:55:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.135, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間

![EVT-20260627-host14-006 active_connections の推移](charts/EVT-20260627-host14-006.svg)

# イベントID( EVT-20260627-host14-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→13→9→12→…→11→9→11→9
* 開始   : 2026-06-27 06:15:00 (UTC)
* 終了   : 2026-06-27 19:25:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.812, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host14-007 active_connections の推移](charts/EVT-20260627-host14-007.svg)

# イベントID( EVT-20260628-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→15→11→16→15
* 開始   : 2026-06-28 12:55:00 (UTC)
* 終了   : 2026-06-28 12:55:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→14→9→12→13
* 開始   : 2026-06-28 17:10:00 (UTC)
* 終了   : 2026-06-28 17:10:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→6→13→8→8
* 開始   : 2026-06-29 23:00:00 (UTC)
* 終了   : 2026-06-29 23:00:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.608倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260629-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260629-host14-009 active_connections の推移](charts/EVT-20260629-host14-009.svg)

# イベントID( EVT-20260630-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→11→16→13→13
* 開始   : 2026-06-30 04:45:00 (UTC)
* 終了   : 2026-06-30 04:45:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.444倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.412σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→15→19→17→17
* 開始   : 2026-06-30 06:25:00 (UTC)
* 終了   : 2026-06-30 06:25:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 17→18→21→19→…→16→23→18→20
* 開始   : 2026-06-30 08:10:00 (UTC)
* 終了   : 2026-06-30 08:35:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260630-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 22→20→16→20→21
* 開始   : 2026-06-30 15:05:00 (UTC)
* 終了   : 2026-06-30 15:05:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→14→11→14→15
* 開始   : 2026-06-30 18:30:00 (UTC)
* 終了   : 2026-06-30 18:30:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→14→10→14→14
* 開始   : 2026-06-30 18:50:00 (UTC)
* 終了   : 2026-06-30 18:50:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.021σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 9→8→4→7→8
* 開始   : 2026-06-30 22:30:00 (UTC)
* 終了   : 2026-06-30 22:30:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.4364(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.603σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host14-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→7→10→14→7→10→14→10→11
* 開始   : 2026-06-01 03:55:00 (UTC)
* 終了   : 2026-06-01 04:05:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-005 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260601-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-013 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260601-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→18→17→14→18→17→16
* 開始   : 2026-06-01 06:20:00 (UTC)
* 終了   : 2026-06-01 06:25:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 23→22→18→20→…→20→25→24→23
* 開始   : 2026-06-01 12:15:00 (UTC)
* 終了   : 2026-06-01 12:25:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.812(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.905σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 19→20→17→19→17→19→17→20
* 開始   : 2026-06-01 15:20:00 (UTC)
* 終了   : 2026-06-01 15:30:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 18→16→18→16
* 開始   : 2026-06-01 16:00:00 (UTC)
* 終了   : 2026-06-01 16:05:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 19→21→16→18→16→18→16→18→16
* 開始   : 2026-06-01 16:10:00 (UTC)
* 終了   : 2026-06-01 16:20:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.8101(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.631σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→15→10→12→15→10→12→13
* 開始   : 2026-06-01 19:35:00 (UTC)
* 終了   : 2026-06-01 19:40:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260601-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260601-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 8→9→7→10→…→7→10→6→7
* 開始   : 2026-06-01 22:55:00 (UTC)
* 終了   : 2026-06-01 23:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 7→5→9→11→5→9→11→9
* 開始   : 2026-06-02 01:30:00 (UTC)
* 終了   : 2026-06-02 01:40:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-004 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260602-host01-001 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260602-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 9→8→12→9→12→9→12→10→8
* 開始   : 2026-06-02 02:25:00 (UTC)
* 終了   : 2026-06-02 02:35:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 17→14→18→19→18→14→18→19→18
* 開始   : 2026-06-02 06:55:00 (UTC)
* 終了   : 2026-06-02 07:00:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 22→21→18→19→18→19→18→21→20
* 開始   : 2026-06-02 14:05:00 (UTC)
* 終了   : 2026-06-02 14:15:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→12→8→10→8→10→8→9→11
* 開始   : 2026-06-02 20:30:00 (UTC)
* 終了   : 2026-06-02 20:40:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.6761(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.659σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-017 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-076 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260602-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 9→8→11→8→11→8→11→9
* 開始   : 2026-06-02 20:45:00 (UTC)
* 終了   : 2026-06-02 20:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.313σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host05-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260602-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260602-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→8→6→5→7→8→6→5→7
* 開始   : 2026-06-02 23:15:00 (UTC)
* 終了   : 2026-06-02 23:20:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→13→10→14→13→10→14→12→10
* 開始   : 2026-06-03 03:50:00 (UTC)
* 終了   : 2026-06-03 04:00:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-014 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260603-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→12→14→12→14→12→14
* 開始   : 2026-06-03 04:15:00 (UTC)
* 終了   : 2026-06-03 04:25:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 22→21→18→21→18→21→18→20→18
* 開始   : 2026-06-03 14:40:00 (UTC)
* 終了   : 2026-06-03 14:50:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-046 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→13→10→15→13→10→15→13
* 開始   : 2026-06-03 19:00:00 (UTC)
* 終了   : 2026-06-03 19:05:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.7273(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.601σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260603-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 8→5→10→8→5→10→9
* 開始   : 2026-06-04 00:05:00 (UTC)
* 終了   : 2026-06-04 00:10:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-085 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260604-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 9→7→11→5→…→11→5→8→6
* 開始   : 2026-06-04 00:35:00 (UTC)
* 終了   : 2026-06-04 00:40:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-085 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-002 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260604-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→12→11→11
* 開始   : 2026-06-04 03:00:00 (UTC)
* 終了   : 2026-06-04 03:15:00 (UTC)
* 現象   : 2026-06-04 03:15:00 (UTC)を境に水準が 14.94から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.152, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 8→10→12→10→…→10→13→12→9
* 開始   : 2026-06-04 03:10:00 (UTC)
* 終了   : 2026-06-04 03:20:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260604-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→16→17→15→13→16→17→15→16
* 開始   : 2026-06-04 05:30:00 (UTC)
* 終了   : 2026-06-04 05:35:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260604-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→15→18→17→19→18→17→19→16
* 開始   : 2026-06-04 06:45:00 (UTC)
* 終了   : 2026-06-04 06:55:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 24→23→22→22→22→22→22→23
* 開始   : 2026-06-04 10:35:00 (UTC)
* 終了   : 2026-06-04 11:55:00 (UTC)
* 現象   : 2026-06-04 11:55:00 (UTC)を境に水準が 14.99から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.948σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.074, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 21→18→16→21→18→16→21→18
* 開始   : 2026-06-04 15:50:00 (UTC)
* 終了   : 2026-06-04 15:55:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.8067(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.685σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 17→16→15→17→14→15→17→14→16
* 開始   : 2026-06-04 16:40:00 (UTC)
* 終了   : 2026-06-04 16:50:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-047 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→15→11→12→15→11→12
* 開始   : 2026-06-04 19:10:00 (UTC)
* 終了   : 2026-06-04 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.313σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→10→8→9→10→8→9→11
* 開始   : 2026-06-04 20:40:00 (UTC)
* 終了   : 2026-06-04 20:45:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 10→13→14→15→…→14→15→10→12
* 開始   : 2026-06-05 04:20:00 (UTC)
* 終了   : 2026-06-05 04:25:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260605-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 15→14→18→15→14→18→15
* 開始   : 2026-06-05 06:10:00 (UTC)
* 終了   : 2026-06-05 06:15:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.293倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.834σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→18→19→18→19→18→19→16→17
* 開始   : 2026-06-05 06:55:00 (UTC)
* 終了   : 2026-06-05 07:05:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 21→21→22→21→19→22→20→21
* 開始   : 2026-06-05 08:40:00 (UTC)
* 終了   : 2026-06-05 09:15:00 (UTC)
* 現象   : 2026-06-05 09:15:00 (UTC)を境に水準が 14.93から14.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.922, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 23→23→22→22→23→23→22→23→22
* 開始   : 2026-06-05 12:25:00 (UTC)
* 終了   : 2026-06-05 13:10:00 (UTC)
* 現象   : 2026-06-05 13:10:00 (UTC)を境に水準が 14.9から13.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.771, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 21→20→21→21→21→19
* 開始   : 2026-06-05 15:20:00 (UTC)
* 終了   : 2026-06-05 15:45:00 (UTC)
* 現象   : 2026-06-05 15:45:00 (UTC)を境に水準が 15.09から12.49へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 17→14→15→13→14→15→13→15
* 開始   : 2026-06-05 17:35:00 (UTC)
* 終了   : 2026-06-05 17:45:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260605-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→14→12→15→…→15→11→12→14
* 開始   : 2026-06-05 18:15:00 (UTC)
* 終了   : 2026-06-05 18:25:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host14-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→13→12
* 開始   : 2026-06-05 20:15:00 (UTC)
* 終了   : 2026-06-05 20:25:00 (UTC)
* 現象   : 2026-06-05 20:25:00 (UTC)を境に水準が 15.02から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.153, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 8→7→11→5→…→11→5→9→8
* 開始   : 2026-06-06 23:05:00 (UTC)
* 終了   : 2026-06-06 23:10:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260606-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260606-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host14-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→10→7→10→11→11→8
* 開始   : 2026-06-07 01:00:00 (UTC)
* 終了   : 2026-06-07 01:30:00 (UTC)
* 現象   : 2026-06-07 01:30:00 (UTC)を境に水準が 11.72から11.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→16→19→15→19→15→19→16→17
* 開始   : 2026-06-07 10:50:00 (UTC)
* 終了   : 2026-06-07 11:00:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.26倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.748σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260607-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 18→17→20→16→20→16→20→18→17
* 開始   : 2026-06-09 07:30:00 (UTC)
* 終了   : 2026-06-09 07:40:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.257倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.865σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260609-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 19→17→21→18→19→21→19
* 開始   : 2026-06-09 07:35:00 (UTC)
* 終了   : 2026-06-09 08:05:00 (UTC)
* 現象   : 2026-06-09 08:05:00 (UTC)を境に水準が 15.09から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 20→21→22→21→…→21→23→20→22
* 開始   : 2026-06-09 09:05:00 (UTC)
* 終了   : 2026-06-09 09:15:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 19→20→23→22→20→23→22→21
* 開始   : 2026-06-09 09:40:00 (UTC)
* 終了   : 2026-06-09 09:45:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260609-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 24→23→21→21→23→24→24→23→22
* 開始   : 2026-06-09 12:20:00 (UTC)
* 終了   : 2026-06-09 13:20:00 (UTC)
* 現象   : 2026-06-09 13:20:00 (UTC)を境に水準が 15.1から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.996, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 22→19→20→22→19→20→21
* 開始   : 2026-06-09 14:40:00 (UTC)
* 終了   : 2026-06-09 14:45:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-044 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260609-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 19→20→17→16→19→17→17→16→19
* 開始   : 2026-06-09 15:45:00 (UTC)
* 終了   : 2026-06-09 17:55:00 (UTC)
* 現象   : 2026-06-09 17:55:00 (UTC)を境に水準が 15.13から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.185, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 19→18→16→20→18→16→20→18
* 開始   : 2026-06-09 16:05:00 (UTC)
* 終了   : 2026-06-09 16:10:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→17→13→16→13→16→13→14→16
* 開始   : 2026-06-09 18:00:00 (UTC)
* 終了   : 2026-06-09 18:10:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.78(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.573σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260609-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→10→12→10→10→8→9
* 開始   : 2026-06-09 21:20:00 (UTC)
* 終了   : 2026-06-09 21:50:00 (UTC)
* 現象   : 2026-06-09 21:50:00 (UTC)を境に水準が 15.03から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host14-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→9→11→10→9→10→9→10
* 開始   : 2026-06-09 22:40:00 (UTC)
* 終了   : 2026-06-09 23:15:00 (UTC)
* 現象   : 2026-06-09 23:15:00 (UTC)を境に水準が 15.05から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.598, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host14-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 10→10→9→8→9→10→10→10→10
* 開始   : 2026-06-10 00:45:00 (UTC)
* 終了   : 2026-06-10 01:35:00 (UTC)
* 現象   : 2026-06-10 01:35:00 (UTC)を境に水準が 15.09から14.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→17→13→11→17→13→11→15→16
* 開始   : 2026-06-10 05:50:00 (UTC)
* 終了   : 2026-06-10 06:00:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 22→20→23→21→23→21→23→22→21
* 開始   : 2026-06-10 09:50:00 (UTC)
* 終了   : 2026-06-10 10:00:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.185倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 21→23→24→23→24→22
* 開始   : 2026-06-10 10:05:00 (UTC)
* 終了   : 2026-06-10 10:15:00 (UTC)
* 現象   : 平常時(20)に対し 1.15倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 22→23→21→25→24→22→24
* 開始   : 2026-06-10 10:55:00 (UTC)
* 終了   : 2026-06-10 11:25:00 (UTC)
* 現象   : 2026-06-10 11:25:00 (UTC)を境に水準が 15.02から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→13→9→12→13→9→12→13
* 開始   : 2026-06-10 19:50:00 (UTC)
* 終了   : 2026-06-10 19:55:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.7013(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.685σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→12→9→11→9→11→9→11→12
* 開始   : 2026-06-10 20:25:00 (UTC)
* 終了   : 2026-06-10 20:35:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.486σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260610-host04-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 9→8→7→9→6→7→9→6→9
* 開始   : 2026-06-10 21:45:00 (UTC)
* 終了   : 2026-06-10 21:55:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→16→18→17→…→17→19→17→19
* 開始   : 2026-06-11 06:45:00 (UTC)
* 終了   : 2026-06-11 07:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260611-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260611-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 22→24→23→22→25
* 開始   : 2026-06-11 11:50:00 (UTC)
* 終了   : 2026-06-11 12:10:00 (UTC)
* 現象   : 2026-06-11 12:10:00 (UTC)を境に水準が 14.99から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.921, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 19→16→18→19→16→18
* 開始   : 2026-06-11 16:10:00 (UTC)
* 終了   : 2026-06-11 16:15:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→14→13→14→13→14
* 開始   : 2026-06-11 17:55:00 (UTC)
* 終了   : 2026-06-11 18:00:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 15→13→11→15→13→11→15→14
* 開始   : 2026-06-11 19:10:00 (UTC)
* 終了   : 2026-06-11 19:15:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host13-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→9→12→6→…→12→6→11→9
* 開始   : 2026-06-12 02:50:00 (UTC)
* 終了   : 2026-06-12 02:55:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260612-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→11→11→13→12→13→12→13→15
* 開始   : 2026-06-12 03:25:00 (UTC)
* 終了   : 2026-06-12 04:30:00 (UTC)
* 現象   : 2026-06-12 04:30:00 (UTC)を境に水準が 14.99から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 9→12→13→14→12→13→14→12→11
* 開始   : 2026-06-12 04:00:00 (UTC)
* 終了   : 2026-06-12 04:05:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→12→15→13→15→13→15→14
* 開始   : 2026-06-12 05:10:00 (UTC)
* 終了   : 2026-06-12 05:20:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 20→19→15→20→…→20→22→19→18
* 開始   : 2026-06-12 08:30:00 (UTC)
* 終了   : 2026-06-12 08:40:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 21→20→24→20→…→20→17→18→20
* 開始   : 2026-06-12 14:45:00 (UTC)
* 終了   : 2026-06-12 14:55:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→14→13→11→14→13
* 開始   : 2026-06-12 19:00:00 (UTC)
* 終了   : 2026-06-12 19:05:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host14-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 8→6→5→9→8→6→5→9→8
* 開始   : 2026-06-13 21:45:00 (UTC)
* 終了   : 2026-06-13 21:50:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260613-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 8→6→11→8→11→8→11→7→8
* 開始   : 2026-06-14 00:40:00 (UTC)
* 終了   : 2026-06-14 00:50:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260614-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→12→9→10→12→9→10
* 開始   : 2026-06-14 03:20:00 (UTC)
* 終了   : 2026-06-14 03:25:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260614-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host14-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→11→9→11→8→13→10→11→11
* 開始   : 2026-06-14 03:55:00 (UTC)
* 終了   : 2026-06-14 04:50:00 (UTC)
* 現象   : 2026-06-14 04:50:00 (UTC)を境に水準が 11.78から11.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.611, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 11→14→10→11→14→10→13
* 開始   : 2026-06-14 05:35:00 (UTC)
* 終了   : 2026-06-14 05:40:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 16→14→18→12→…→12→11→17→14
* 開始   : 2026-06-14 15:20:00 (UTC)
* 終了   : 2026-06-14 15:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.602σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260614-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260614-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260614-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 16→12→11→12→16→12→11→12→11
* 開始   : 2026-06-14 15:55:00 (UTC)
* 終了   : 2026-06-14 16:00:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→10→15→13→…→13→16→13→14
* 開始   : 2026-06-16 05:00:00 (UTC)
* 終了   : 2026-06-16 05:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260616-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260616-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→12→15→13→12→15→13→12
* 開始   : 2026-06-16 05:00:00 (UTC)
* 終了   : 2026-06-16 05:05:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260616-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→13→16→13→16→15→13
* 開始   : 2026-06-16 05:15:00 (UTC)
* 終了   : 2026-06-16 05:25:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.487σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-023 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260616-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 18→19→22→19→22→19→22→19→20
* 開始   : 2026-06-16 08:55:00 (UTC)
* 終了   : 2026-06-16 09:05:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.205倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 22→23→22→22→22→23→21→23→23
* 開始   : 2026-06-16 12:35:00 (UTC)
* 終了   : 2026-06-16 13:25:00 (UTC)
* 現象   : 2026-06-16 13:25:00 (UTC)を境に水準が 14.94から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.23, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 19→21→18→21→18→21→18→19
* 開始   : 2026-06-16 14:55:00 (UTC)
* 終了   : 2026-06-16 15:05:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260616-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→13→11→12→11→12→11→14→13
* 開始   : 2026-06-16 19:10:00 (UTC)
* 終了   : 2026-06-16 19:20:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260616-host01-010 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260616-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 21→25→18→22→21→25→18→22→23
* 開始   : 2026-06-17 11:40:00 (UTC)
* 終了   : 2026-06-17 11:45:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.167倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→12→10→12→…→12→9→11→10
* 開始   : 2026-06-17 19:30:00 (UTC)
* 終了   : 2026-06-17 19:40:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-lsfhost01-071 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260617-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-018 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260617-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→11→7→9→11→7→9→11
* 開始   : 2026-06-17 21:30:00 (UTC)
* 終了   : 2026-06-17 21:35:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260617-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 18→17→20→19→…→19→21→18→19
* 開始   : 2026-06-18 07:50:00 (UTC)
* 終了   : 2026-06-18 08:00:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→20→18→20→18→20→16→19
* 開始   : 2026-06-18 07:55:00 (UTC)
* 終了   : 2026-06-18 08:05:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host14-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 23→20→21→24→23→23
* 開始   : 2026-06-18 09:30:00 (UTC)
* 終了   : 2026-06-18 10:00:00 (UTC)
* 現象   : 2026-06-18 10:00:00 (UTC)を境に水準が 14.93から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.306, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 22→23→22→21→22→23→23→23→22
* 開始   : 2026-06-18 12:45:00 (UTC)
* 終了   : 2026-06-18 13:25:00 (UTC)
* 現象   : 2026-06-18 13:25:00 (UTC)を境に水準が 15.04から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.593, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 20→21→18→17→…→18→17→20→21
* 開始   : 2026-06-18 14:30:00 (UTC)
* 終了   : 2026-06-18 14:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260618-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→13→12→16→15→13→12→16→14
* 開始   : 2026-06-18 17:35:00 (UTC)
* 終了   : 2026-06-18 17:40:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7879(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 17→14→15→17→14→15→16
* 開始   : 2026-06-18 17:35:00 (UTC)
* 終了   : 2026-06-18 17:40:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 17→16→16→13→15→13→14→13→13
* 開始   : 2026-06-18 17:55:00 (UTC)
* 終了   : 2026-06-18 19:20:00 (UTC)
* 現象   : 2026-06-18 19:20:00 (UTC)を境に水準が 15.01から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.824, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 7→6→11→5→10→6→11→5→10
* 開始   : 2026-06-18 23:15:00 (UTC)
* 終了   : 2026-06-18 23:20:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→14→18→14→18→14→16
* 開始   : 2026-06-19 06:30:00 (UTC)
* 終了   : 2026-06-19 06:35:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→15→19→17→…→17→19→18→14
* 開始   : 2026-06-19 06:50:00 (UTC)
* 終了   : 2026-06-19 07:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260619-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 19→17→20→16→20→16→20→18→20
* 開始   : 2026-06-19 07:30:00 (UTC)
* 終了   : 2026-06-19 07:40:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 19→19→21→22→19→22→21→20→21
* 開始   : 2026-06-19 08:20:00 (UTC)
* 終了   : 2026-06-19 09:00:00 (UTC)
* 現象   : 2026-06-19 09:00:00 (UTC)を境に水準が 14.88から14.23へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 22→23→22→23
* 開始   : 2026-06-19 13:30:00 (UTC)
* 終了   : 2026-06-19 14:05:00 (UTC)
* 現象   : 2026-06-19 14:05:00 (UTC)を境に水準が 15.06から12.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.919σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.961, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 21→20→16→21→18→19→20→19→18
* 開始   : 2026-06-19 16:00:00 (UTC)
* 終了   : 2026-06-19 16:55:00 (UTC)
* 現象   : 2026-06-19 16:55:00 (UTC)を境に水準が 15.03から12.28へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→12→14→15→12
* 開始   : 2026-06-19 18:15:00 (UTC)
* 終了   : 2026-06-19 20:35:00 (UTC)
* 現象   : 2026-06-19 20:35:00 (UTC)を境に水準が 14.94から12.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.921, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→13→10→9→13→10→9→13→12
* 開始   : 2026-06-19 19:30:00 (UTC)
* 終了   : 2026-06-19 19:35:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→9→8→14→…→8→14→10→11
* 開始   : 2026-06-19 20:35:00 (UTC)
* 終了   : 2026-06-19 20:40:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host14-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 9→10→9→8→8→8→8→8→11
* 開始   : 2026-06-19 23:50:00 (UTC)
* 終了   : 2026-06-20 00:40:00 (UTC)
* 現象   : 2026-06-20 00:40:00 (UTC)を境に水準が 14.93から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.169, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host14-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→8→7→10→7→10→7→10→11
* 開始   : 2026-06-20 20:25:00 (UTC)
* 終了   : 2026-06-20 20:35:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.815, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260620-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260620-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host14-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→10→10→9→9→8→9→12→10
* 開始   : 2026-06-21 00:10:00 (UTC)
* 終了   : 2026-06-21 01:00:00 (UTC)
* 現象   : 2026-06-21 01:00:00 (UTC)を境に水準が 11.87から11.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.23, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→12→8→12→8→12→7→9
* 開始   : 2026-06-21 02:50:00 (UTC)
* 終了   : 2026-06-21 03:00:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→7→12→13→7→12→13→11
* 開始   : 2026-06-21 04:45:00 (UTC)
* 終了   : 2026-06-21 04:55:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 19→17→17→15→13→16→19→19→17
* 開始   : 2026-06-21 10:25:00 (UTC)
* 終了   : 2026-06-21 11:20:00 (UTC)
* 現象   : 2026-06-21 11:20:00 (UTC)を境に水準が 11.88から13.31へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.925, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 16→15→13→12→…→13→12→14→17
* 開始   : 2026-06-21 10:55:00 (UTC)
* 終了   : 2026-06-21 11:00:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-024 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260621-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host14-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→18→16→16→17→16→18→16→18
* 開始   : 2026-06-21 13:05:00 (UTC)
* 終了   : 2026-06-21 13:50:00 (UTC)
* 現象   : 2026-06-21 13:50:00 (UTC)を境に水準が 11.96から13.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.843, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host14-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 16→16→18→16
* 開始   : 2026-06-21 14:40:00 (UTC)
* 終了   : 2026-06-21 14:55:00 (UTC)
* 現象   : 2026-06-21 14:55:00 (UTC)を境に水準が 11.78から14.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.799, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 8→9→5→10→…→10→11→8→9
* 開始   : 2026-06-22 01:45:00 (UTC)
* 終了   : 2026-06-22 01:55:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260622-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260622-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host14-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 9→10→12→10→8→8→13→10→10
* 開始   : 2026-06-22 02:00:00 (UTC)
* 終了   : 2026-06-22 02:40:00 (UTC)
* 現象   : 2026-06-22 02:40:00 (UTC)を境に水準が 11.97から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.694, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→9→13→10→9→13→10→11
* 開始   : 2026-06-23 03:05:00 (UTC)
* 終了   : 2026-06-23 03:10:00 (UTC)
* 現象   : 平常時(9)に対し 1.444倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.807σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 16→17→18→19→18→19→18→17
* 開始   : 2026-06-23 06:55:00 (UTC)
* 終了   : 2026-06-23 07:05:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 20→18→21→17→18→21→17→19
* 開始   : 2026-06-23 08:05:00 (UTC)
* 終了   : 2026-06-23 08:10:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260623-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 23→19→21→19→21→19→23→20
* 開始   : 2026-06-23 13:15:00 (UTC)
* 終了   : 2026-06-23 13:25:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.8476(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-039 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260623-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 18→19→17→18→19→17→18→17
* 開始   : 2026-06-23 15:40:00 (UTC)
* 終了   : 2026-06-23 15:45:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→15→11→13→15→11→13→12
* 開始   : 2026-06-23 19:10:00 (UTC)
* 終了   : 2026-06-23 19:15:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host14-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host14-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 8→8→10→7→10→10→10→8
* 開始   : 2026-06-23 23:45:00 (UTC)
* 終了   : 2026-06-24 00:20:00 (UTC)
* 現象   : 2026-06-24 00:20:00 (UTC)を境に水準が 14.91から14.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.074, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host14-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→14→15→12→15→12→15→13→14
* 開始   : 2026-06-24 04:55:00 (UTC)
* 終了   : 2026-06-24 05:05:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 16→19→18→16→19→18→17
* 開始   : 2026-06-24 06:50:00 (UTC)
* 終了   : 2026-06-24 06:55:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260624-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 20→19→22→20→…→20→23→21→20
* 開始   : 2026-06-24 09:00:00 (UTC)
* 終了   : 2026-06-24 09:10:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 21→19→21→20→23→20→23→20→22
* 開始   : 2026-06-24 09:05:00 (UTC)
* 終了   : 2026-06-24 09:45:00 (UTC)
* 現象   : 2026-06-24 09:45:00 (UTC)を境に水準が 15.1から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.593, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 20→19→23→21→…→21→24→22→20
* 開始   : 2026-06-24 09:45:00 (UTC)
* 終了   : 2026-06-24 09:55:00 (UTC)
* 現象   : 平常時(20)に対し 1.15倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-038 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-040 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 22→23→19→21→19→21→19→21→24
* 開始   : 2026-06-24 12:35:00 (UTC)
* 終了   : 2026-06-24 12:45:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-041 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260624-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260624-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→8→11→10→8→11→9
* 開始   : 2026-06-24 20:55:00 (UTC)
* 終了   : 2026-06-24 21:00:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 12→10→14→10→14→10→9
* 開始   : 2026-06-25 03:35:00 (UTC)
* 終了   : 2026-06-25 03:40:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 13→15→12→13→15→12→13
* 開始   : 2026-06-25 04:55:00 (UTC)
* 終了   : 2026-06-25 05:00:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 20→23→24→21→…→21→25→21→20
* 開始   : 2026-06-25 10:00:00 (UTC)
* 終了   : 2026-06-25 10:10:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.171倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260625-lsfhost01-039 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 21→18→22→21→18→22→20
* 開始   : 2026-06-25 11:25:00 (UTC)
* 終了   : 2026-06-25 11:30:00 (UTC)
* 現象   : 平常時(21.75)に対し 0.8276(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.602σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 22→21→19→23→25→19→23→25→23
* 開始   : 2026-06-25 12:20:00 (UTC)
* 終了   : 2026-06-25 12:30:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260625-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 22→21→18→19→21→18→19→18
* 開始   : 2026-06-25 15:00:00 (UTC)
* 終了   : 2026-06-25 15:05:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 17→13→14→12→13→14→12→16→15
* 開始   : 2026-06-25 18:10:00 (UTC)
* 終了   : 2026-06-25 18:20:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260625-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260625-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260625-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 15→13→11→13→…→13→10→12→11
* 開始   : 2026-06-25 19:30:00 (UTC)
* 終了   : 2026-06-25 19:40:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host14-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host14-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host14-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 8→11→7→10→6→7→10→6→9
* 開始   : 2026-06-25 21:15:00 (UTC)
* 終了   : 2026-06-25 21:25:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.6667(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.427σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host14-017 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260625-host07-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host14-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 8→9→6→8→…→8→12→9→7
* 開始   : 2026-06-26 02:15:00 (UTC)
* 終了   : 2026-06-26 02:25:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260626-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 19→23→21→19→23→21→22
* 開始   : 2026-06-26 09:20:00 (UTC)
* 終了   : 2026-06-26 09:25:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host14-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 22→20→21→19→23→20→21→20→19
* 開始   : 2026-06-26 13:55:00 (UTC)
* 終了   : 2026-06-26 15:30:00 (UTC)
* 現象   : 2026-06-26 15:30:00 (UTC)を境に水準が 14.95から12.53へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 18→20→16→20→16→18→16→18
* 開始   : 2026-06-26 16:40:00 (UTC)
* 終了   : 2026-06-26 16:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 9→5→9→5→9→5→7→9
* 開始   : 2026-06-27 00:55:00 (UTC)
* 終了   : 2026-06-27 01:05:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.313σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-lsfhost01-005 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260627-lsfhost01-004 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260627-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 7→9→6→12→9→6→12→9→10
* 開始   : 2026-06-27 22:50:00 (UTC)
* 終了   : 2026-06-27 22:55:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260627-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 6→9→11→12→8→9→11→12→8
* 開始   : 2026-06-28 03:05:00 (UTC)
* 終了   : 2026-06-28 03:10:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host14-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→15→16→17→17→16→16→18→18
* 開始   : 2026-06-28 10:00:00 (UTC)
* 終了   : 2026-06-28 11:15:00 (UTC)
* 現象   : 2026-06-28 11:15:00 (UTC)を境に水準が 11.85から13.22へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.149, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 12→15→11→10→15→11→10→15→12
* 開始   : 2026-06-28 16:25:00 (UTC)
* 終了   : 2026-06-28 16:30:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260628-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→10→8→9→10→8→9→10
* 開始   : 2026-06-28 19:40:00 (UTC)
* 終了   : 2026-06-28 19:45:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-036 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260628-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host14-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→10→8→10→10→9→11→12→10
* 開始   : 2026-06-28 20:55:00 (UTC)
* 終了   : 2026-06-28 21:35:00 (UTC)
* 現象   : 2026-06-28 21:35:00 (UTC)を境に水準が 11.85から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host14-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→9→12→12→10
* 開始   : 2026-06-29 02:45:00 (UTC)
* 終了   : 2026-06-29 03:05:00 (UTC)
* 現象   : 2026-06-29 03:05:00 (UTC)を境に水準が 11.96から14.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host14-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 10→10→10→9→11→7→9→9
* 開始   : 2026-06-29 22:40:00 (UTC)
* 終了   : 2026-06-29 23:15:00 (UTC)
* 現象   : 2026-06-29 23:15:00 (UTC)を境に水準が 14.96から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.62, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 9→6→11→9→…→12→5→8→7
* 開始   : 2026-06-30 00:55:00 (UTC)
* 終了   : 2026-06-30 01:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-001 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260630-lsfhost01-002 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260630-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→10→13→7→…→11→14→10→11
* 開始   : 2026-06-30 03:10:00 (UTC)
* 終了   : 2026-06-30 03:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 20→20→20→20→21→19→20→20→20
* 開始   : 2026-06-30 15:05:00 (UTC)
* 終了   : 2026-06-30 16:05:00 (UTC)
* 現象   : 2026-06-30 16:05:00 (UTC)を境に水準が 14.97から15.17へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→17→13→16→17→13→16→13
* 開始   : 2026-06-30 17:40:00 (UTC)
* 終了   : 2026-06-30 17:45:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7879(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260630-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→7→11→7→11
* 開始   : 2026-06-30 20:50:00 (UTC)
* 終了   : 2026-06-30 20:55:00 (UTC)
* 現象   : 火曜20時台の平常値(10.86)に対し 7であった
* 説明   : ALG-A1: 移動平均からの残差が 2.977σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.151σ 外れた (平常値=10.86)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→9→7→10→7→10→7→9
* 開始   : 2026-06-30 21:15:00 (UTC)
* 終了   : 2026-06-30 21:25:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.672(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 9→10→6→12→…→6→12→8→10
* 開始   : 2026-06-30 21:35:00 (UTC)
* 終了   : 2026-06-30 21:40:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→9→13→11→…→10→6→9→10
* 開始   : 2026-06-30 21:50:00 (UTC)
* 終了   : 2026-06-30 22:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260630-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260630-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host14-014 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
