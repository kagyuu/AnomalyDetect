# host11 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host11 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 333 (SEVERE: 28, FATAL: 128, WARN: 177, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 28 | 128 | 177 | 333 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260702-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 20→19→20
* 開始   : 2026-07-02 08:05:00 (UTC)
* 終了   : 2026-07-02 09:10:00 (UTC)
* 現象   : 2026-07-02 09:10:00 (UTC)を境に水準が 14.96から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.412, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host11-006 active_connections の推移](charts/EVT-20260702-host11-006.svg)

# イベントID( EVT-20260702-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 23→23→22→22→20→22→22→24→24
* 開始   : 2026-07-02 11:30:00 (UTC)
* 終了   : 2026-07-02 12:25:00 (UTC)
* 現象   : 2026-07-02 12:25:00 (UTC)を境に水準が 14.98から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.649, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host11-009 active_connections の推移](charts/EVT-20260702-host11-009.svg)

# イベントID( EVT-20260705-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→11→16→14→14
* 開始   : 2026-07-05 07:20:00 (UTC)
* 終了   : 2026-07-05 07:40:00 (UTC)
* 現象   : 2026-07-05 07:40:00 (UTC)を境に水準が 11.83から12.3へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host11-003 active_connections の推移](charts/EVT-20260705-host11-003.svg)

# イベントID( EVT-20260706-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→16→14→16→…→14→16→12→13
* 開始   : 2026-07-06 01:50:00 (UTC)
* 終了   : 2026-07-06 19:50:00 (UTC)
* 現象   : 2026-07-06 19:50:00 (UTC)を境に水準が 11.76から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.121, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.649, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host11-002 active_connections の推移](charts/EVT-20260706-host11-002.svg)

# イベントID( EVT-20260706-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→16→18→16→…→11→15→12→15
* 開始   : 2026-07-06 03:05:00 (UTC)
* 終了   : 2026-07-06 21:35:00 (UTC)
* 現象   : 2026-07-06 21:35:00 (UTC)を境に水準が 11.87から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.683σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.112, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host11-003 active_connections の推移](charts/EVT-20260706-host11-003.svg)

# イベントID( EVT-20260706-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→19→…→13→15→14→13
* 開始   : 2026-07-06 03:05:00 (UTC)
* 終了   : 2026-07-06 21:40:00 (UTC)
* 現象   : 2026-07-06 21:40:00 (UTC)を境に水準が 11.88から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.006, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.402, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host11-005 active_connections の推移](charts/EVT-20260706-host11-005.svg)

# イベントID( EVT-20260708-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 21→19→19→17→20→18→21→18→18
* 開始   : 2026-07-08 16:00:00 (UTC)
* 終了   : 2026-07-08 18:25:00 (UTC)
* 現象   : 2026-07-08 18:25:00 (UTC)を境に水準が 15.03から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host11-008 active_connections の推移](charts/EVT-20260708-host11-008.svg)

# イベントID( EVT-20260713-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→13→16→13→…→15→14→13→12
* 開始   : 2026-07-13 01:55:00 (UTC)
* 終了   : 2026-07-13 21:00:00 (UTC)
* 現象   : 2026-07-13 21:00:00 (UTC)を境に水準が 11.72から15.21へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.713, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.048, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host11-001 active_connections の推移](charts/EVT-20260713-host11-001.svg)

# イベントID( EVT-20260713-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→17→16→18→…→14→12→10→12
* 開始   : 2026-07-13 02:15:00 (UTC)
* 終了   : 2026-07-13 21:15:00 (UTC)
* 現象   : 2026-07-13 21:15:00 (UTC)を境に水準が 11.92から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.698σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.902, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host11-003 active_connections の推移](charts/EVT-20260713-host11-003.svg)

# イベントID( EVT-20260713-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→16→…→12→15→13→11
* 開始   : 2026-07-13 02:35:00 (UTC)
* 終了   : 2026-07-13 20:15:00 (UTC)
* 現象   : 2026-07-13 20:15:00 (UTC)を境に水準が 12.02から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.556σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.779, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host11-004 active_connections の推移](charts/EVT-20260713-host11-004.svg)

# イベントID( EVT-20260713-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→15→18→15→…→17→16→15→16
* 開始   : 2026-07-13 02:50:00 (UTC)
* 終了   : 2026-07-13 20:40:00 (UTC)
* 現象   : 2026-07-13 20:40:00 (UTC)を境に水準が 11.83から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.665, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host11-005 active_connections の推移](charts/EVT-20260713-host11-005.svg)

# イベントID( EVT-20260714-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→13→16→15→15→15→15→15
* 開始   : 2026-07-14 05:05:00 (UTC)
* 終了   : 2026-07-14 05:40:00 (UTC)
* 現象   : 2026-07-14 05:40:00 (UTC)を境に水準が 15から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host11-004 active_connections の推移](charts/EVT-20260714-host11-004.svg)

# イベントID( EVT-20260716-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→13→13→10→13
* 開始   : 2026-07-16 20:15:00 (UTC)
* 終了   : 2026-07-16 20:35:00 (UTC)
* 現象   : 2026-07-16 20:35:00 (UTC)を境に水準が 14.91から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host11-009 active_connections の推移](charts/EVT-20260716-host11-009.svg)

# イベントID( EVT-20260719-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→8→9→9→8→11→10
* 開始   : 2026-07-19 00:30:00 (UTC)
* 終了   : 2026-07-19 01:00:00 (UTC)
* 現象   : 2026-07-19 01:00:00 (UTC)を境に水準が 11.99から11.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.962, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host11-001 active_connections の推移](charts/EVT-20260719-host11-001.svg)

# イベントID( EVT-20260720-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→16→18→20→…→15→12→11→14
* 開始   : 2026-07-20 03:05:00 (UTC)
* 終了   : 2026-07-20 21:30:00 (UTC)
* 現象   : 2026-07-20 21:30:00 (UTC)を境に水準が 11.98から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.762, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.88, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host11-002 active_connections の推移](charts/EVT-20260720-host11-002.svg)

# イベントID( EVT-20260720-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→15→13→12→…→14→13→16→13
* 開始   : 2026-07-20 03:15:00 (UTC)
* 終了   : 2026-07-20 19:35:00 (UTC)
* 現象   : 2026-07-20 19:35:00 (UTC)を境に水準が 11.9から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.747σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.919, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.242, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host11-004 active_connections の推移](charts/EVT-20260720-host11-004.svg)

# イベントID( EVT-20260720-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→14→16→13→…→14→13→12→13
* 開始   : 2026-07-20 03:30:00 (UTC)
* 終了   : 2026-07-20 20:30:00 (UTC)
* 現象   : 2026-07-20 20:30:00 (UTC)を境に水準が 11.82から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.139σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.744, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.199, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host11-005 active_connections の推移](charts/EVT-20260720-host11-005.svg)

# イベントID( EVT-20260720-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→13→16→14→…→14→15→13→15
* 開始   : 2026-07-20 04:05:00 (UTC)
* 終了   : 2026-07-20 20:35:00 (UTC)
* 現象   : 2026-07-20 20:35:00 (UTC)を境に水準が 12.06から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.56σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.996, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.939, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host11-007 active_connections の推移](charts/EVT-20260720-host11-007.svg)

# イベントID( EVT-20260727-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→16→14→15→…→14→15→11→13
* 開始   : 2026-07-27 02:35:00 (UTC)
* 終了   : 2026-07-27 21:05:00 (UTC)
* 現象   : 2026-07-27 21:05:00 (UTC)を境に水準が 11.94から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.841, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host11-003 active_connections の推移](charts/EVT-20260727-host11-003.svg)

# イベントID( EVT-20260727-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→15→18→15→…→10→12→13→12
* 開始   : 2026-07-27 02:55:00 (UTC)
* 終了   : 2026-07-27 20:30:00 (UTC)
* 現象   : 2026-07-27 20:30:00 (UTC)を境に水準が 11.88から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.346σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.028, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.403, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host11-005 active_connections の推移](charts/EVT-20260727-host11-005.svg)

# イベントID( EVT-20260727-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→16→18→15→…→17→14→13→14
* 開始   : 2026-07-27 03:10:00 (UTC)
* 終了   : 2026-07-27 20:45:00 (UTC)
* 現象   : 2026-07-27 20:45:00 (UTC)を境に水準が 11.91から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.971, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.257, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host11-006 active_connections の推移](charts/EVT-20260727-host11-006.svg)

# イベントID( EVT-20260727-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→16→14→17→…→12→13→12→13
* 開始   : 2026-07-27 03:50:00 (UTC)
* 終了   : 2026-07-27 19:30:00 (UTC)
* 現象   : 2026-07-27 19:30:00 (UTC)を境に水準が 11.89から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.91, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host11-007 active_connections の推移](charts/EVT-20260727-host11-007.svg)

# イベントID( EVT-20260727-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 14→15→16→17→…→14→13→17→14
* 開始   : 2026-07-27 03:50:00 (UTC)
* 終了   : 2026-07-27 22:10:00 (UTC)
* 現象   : 2026-07-27 22:10:00 (UTC)を境に水準が 11.93から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.832, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host11-008 active_connections の推移](charts/EVT-20260727-host11-008.svg)

# イベントID( EVT-20260727-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→16→17→18→…→14→13→12→13
* 開始   : 2026-07-27 04:00:00 (UTC)
* 終了   : 2026-07-27 21:05:00 (UTC)
* 現象   : 2026-07-27 21:05:00 (UTC)を境に水準が 12.05から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.684σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.712, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host11-009 active_connections の推移](charts/EVT-20260727-host11-009.svg)

# イベントID( EVT-20260727-host11-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→8→8→12→9
* 開始   : 2026-07-27 23:35:00 (UTC)
* 終了   : 2026-07-27 23:55:00 (UTC)
* 現象   : 2026-07-27 23:55:00 (UTC)を境に水準が 14.98から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host11-011 active_connections の推移](charts/EVT-20260727-host11-011.svg)

# イベントID( EVT-20260728-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 25→23→24
* 開始   : 2026-07-28 12:35:00 (UTC)
* 終了   : 2026-07-28 12:45:00 (UTC)
* 現象   : 2026-07-28 12:45:00 (UTC)を境に水準が 14.96から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.412, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host11-009 active_connections の推移](charts/EVT-20260728-host11-009.svg)

# イベントID( EVT-20260728-host11-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 18→18→16→16→16→16→13→17
* 開始   : 2026-07-28 17:20:00 (UTC)
* 終了   : 2026-07-28 17:55:00 (UTC)
* 現象   : 2026-07-28 17:55:00 (UTC)を境に水準が 14.98から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host11-011 active_connections の推移](charts/EVT-20260728-host11-011.svg)

# イベントID( EVT-20260731-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 17→16→14→17→16→14→16→17→18
* 開始   : 2026-07-31 05:45:00 (UTC)
* 終了   : 2026-07-31 06:35:00 (UTC)
* 現象   : 2026-07-31 06:35:00 (UTC)を境に水準が 15から14.64へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.512, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host11-003 active_connections の推移](charts/EVT-20260731-host11-003.svg)

# イベントID( EVT-20260701-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→17→20→17→16
* 開始   : 2026-07-01 06:45:00 (UTC)
* 終了   : 2026-07-01 06:45:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→16→12→16→17
* 開始   : 2026-07-01 17:20:00 (UTC)
* 終了   : 2026-07-01 17:20:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.6825(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.906σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260701-host11-006 active_connections の推移](charts/EVT-20260701-host11-006.svg)

# イベントID( EVT-20260701-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→15→12→17→14
* 開始   : 2026-07-01 17:40:00 (UTC)
* 終了   : 2026-07-01 17:40:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.167σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→13→11→15→13→11→15
* 開始   : 2026-07-01 18:35:00 (UTC)
* 終了   : 2026-07-01 19:00:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260701-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260701-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260701-host11-009 active_connections の推移](charts/EVT-20260701-host11-009.svg)

# イベントID( EVT-20260702-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→11→16→14→12
* 開始   : 2026-07-02 04:25:00 (UTC)
* 終了   : 2026-07-02 04:25:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→9→16→13→14
* 開始   : 2026-07-02 04:50:00 (UTC)
* 終了   : 2026-07-02 04:50:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→17→20→18→17
* 開始   : 2026-07-02 07:05:00 (UTC)
* 終了   : 2026-07-02 07:05:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260702-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 20→20→24→19→21
* 開始   : 2026-07-02 09:00:00 (UTC)
* 終了   : 2026-07-02 09:00:00 (UTC)
* 現象   : 平常時(19)に対し 1.263倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.498σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→15→19→15→16
* 開始   : 2026-07-03 06:20:00 (UTC)
* 終了   : 2026-07-03 06:20:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 24→23→21→22→21→21→19→20→23
* 開始   : 2026-07-03 12:30:00 (UTC)
* 終了   : 2026-07-03 14:45:00 (UTC)
* 現象   : 2026-07-03 14:45:00 (UTC)を境に水準が 14.93から13.33へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.672σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.086, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 17→15→12→16→15
* 開始   : 2026-07-03 17:35:00 (UTC)
* 終了   : 2026-07-03 17:35:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host11-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host03-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host08-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host11-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 11→9→11→12→…→12→9→10→11
* 開始   : 2026-07-04 05:05:00 (UTC)
* 終了   : 2026-07-04 19:10:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.752, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260704-host11-001 active_connections の推移](charts/EVT-20260704-host11-001.svg)

# イベントID( EVT-20260704-host11-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→14→11→13→…→11→12→13→11
* 開始   : 2026-07-04 05:35:00 (UTC)
* 終了   : 2026-07-04 18:50:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.111, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260704-host11-002 active_connections の推移](charts/EVT-20260704-host11-002.svg)

# イベントID( EVT-20260704-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→14→12→14→…→12→11→12→13
* 開始   : 2026-07-04 05:35:00 (UTC)
* 終了   : 2026-07-04 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.735σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.155, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260704-host11-003 active_connections の推移](charts/EVT-20260704-host11-003.svg)

# イベントID( EVT-20260704-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→11→13→12→…→10→11→12→11
* 開始   : 2026-07-04 05:35:00 (UTC)
* 終了   : 2026-07-04 19:00:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.997, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260704-host11-004 active_connections の推移](charts/EVT-20260704-host11-004.svg)

# イベントID( EVT-20260704-host11-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→12→…→11→13→12→10
* 開始   : 2026-07-04 05:45:00 (UTC)
* 終了   : 2026-07-04 18:45:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.784, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260704-host11-005 active_connections の推移](charts/EVT-20260704-host11-005.svg)

# イベントID( EVT-20260704-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→11→12→11→…→10→12→13→12
* 開始   : 2026-07-04 06:20:00 (UTC)
* 終了   : 2026-07-04 19:40:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.463, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260704-host11-006 active_connections の推移](charts/EVT-20260704-host11-006.svg)

# イベントID( EVT-20260705-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→15→16→13→12→15→16→13→15
* 開始   : 2026-07-05 07:15:00 (UTC)
* 終了   : 2026-07-05 07:35:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260705-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260705-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260705-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→15→11→17→16
* 開始   : 2026-07-05 14:30:00 (UTC)
* 終了   : 2026-07-05 14:30:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host11-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→17→18→16→…→13→15→12→14
* 開始   : 2026-07-06 01:35:00 (UTC)
* 終了   : 2026-07-06 20:00:00 (UTC)
* 現象   : 2026-07-06 20:00:00 (UTC)を境に水準が 11.89から14.89へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.827, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.343, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host11-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→16→14→16→…→14→13→11→12
* 開始   : 2026-07-06 03:05:00 (UTC)
* 終了   : 2026-07-06 21:10:00 (UTC)
* 現象   : 2026-07-06 21:10:00 (UTC)を境に水準が 11.86から14.98へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.688, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.324, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→15→16→15→…→15→13→15→13
* 開始   : 2026-07-06 04:10:00 (UTC)
* 終了   : 2026-07-06 20:00:00 (UTC)
* 現象   : 2026-07-06 20:00:00 (UTC)を境に水準が 11.85から14.9へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.959, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 9→10→10→7→10→8→6→11→9
* 開始   : 2026-07-06 23:40:00 (UTC)
* 終了   : 2026-07-07 01:15:00 (UTC)
* 現象   : 2026-07-07 01:15:00 (UTC)を境に水準が 14.9から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.724, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→10→4→7→7
* 開始   : 2026-07-07 00:35:00 (UTC)
* 終了   : 2026-07-07 00:35:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.4486(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→12→17→12→15
* 開始   : 2026-07-07 04:40:00 (UTC)
* 終了   : 2026-07-07 04:40:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.447倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host11-002 active_connections の推移](charts/EVT-20260707-host11-002.svg)

# イベントID( EVT-20260707-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→16→23→20→19
* 開始   : 2026-07-07 08:00:00 (UTC)
* 終了   : 2026-07-07 08:00:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.346倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260707-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host11-005 active_connections の推移](charts/EVT-20260707-host11-005.svg)

# イベントID( EVT-20260707-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 18→19→23→19→17
* 開始   : 2026-07-07 08:25:00 (UTC)
* 終了   : 2026-07-07 08:25:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.26倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260707-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 18→20→24→20→20
* 開始   : 2026-07-07 09:10:00 (UTC)
* 終了   : 2026-07-07 09:10:00 (UTC)
* 現象   : 平常時(19.25)に対し 1.247倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260707-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→15→13→16→…→16→11→16→13
* 開始   : 2026-07-07 18:05:00 (UTC)
* 終了   : 2026-07-07 19:50:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host11-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 30 分
  - EVT-20260707-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260707-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→14→11→12→14
* 開始   : 2026-07-07 18:45:00 (UTC)
* 終了   : 2026-07-07 18:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260707-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→13→…→11→8→12→10
* 開始   : 2026-07-07 19:40:00 (UTC)
* 終了   : 2026-07-07 20:10:00 (UTC)
* 現象   : 30分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host12-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→14→19→17→…→18→19→16→17
* 開始   : 2026-07-08 06:45:00 (UTC)
* 終了   : 2026-07-08 07:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260708-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host01-006 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260708-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260708-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 20→18→23→20→21
* 開始   : 2026-07-08 08:25:00 (UTC)
* 終了   : 2026-07-08 08:25:00 (UTC)
* 現象   : 平常時(18.17)に対し 1.266倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 22→21→22→23→23→24→22
* 開始   : 2026-07-08 13:55:00 (UTC)
* 終了   : 2026-07-08 14:55:00 (UTC)
* 現象   : 2026-07-08 14:55:00 (UTC)を境に水準が 15.02から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.63σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.046, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→15→12→16→16
* 開始   : 2026-07-08 17:55:00 (UTC)
* 終了   : 2026-07-08 17:55:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 12→12→8→12→12
* 開始   : 2026-07-08 19:15:00 (UTC)
* 終了   : 2026-07-08 19:15:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.6(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.741σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host11-011 active_connections の推移](charts/EVT-20260708-host11-011.svg)

# イベントID( EVT-20260708-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→13→8→10→10
* 開始   : 2026-07-08 20:05:00 (UTC)
* 終了   : 2026-07-08 20:05:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.6316(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host11-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260708-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→13→15→10→12
* 開始   : 2026-07-09 04:10:00 (UTC)
* 終了   : 2026-07-09 04:10:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260709-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→16→12→16→15
* 開始   : 2026-07-09 17:55:00 (UTC)
* 終了   : 2026-07-09 17:55:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→13→9→11→12
* 開始   : 2026-07-09 19:15:00 (UTC)
* 終了   : 2026-07-09 19:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.6391(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host11-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260709-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host11-012 active_connections の推移](charts/EVT-20260709-host11-012.svg)

# イベントID( EVT-20260710-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→17→19→18→17→19→17
* 開始   : 2026-07-10 06:05:00 (UTC)
* 終了   : 2026-07-10 07:00:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260710-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 15 分
  - EVT-20260710-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260710-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→20→20→18→21→21
* 開始   : 2026-07-10 07:05:00 (UTC)
* 終了   : 2026-07-10 07:55:00 (UTC)
* 現象   : 2026-07-10 07:55:00 (UTC)を境に水準が 14.93から14.48へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 22→23→18→22→22
* 開始   : 2026-07-10 12:05:00 (UTC)
* 終了   : 2026-07-10 12:05:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.803(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 19→22→26→21→22
* 開始   : 2026-07-10 13:10:00 (UTC)
* 終了   : 2026-07-10 13:10:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.214倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 21→18→14→19→15→14→19→15→18
* 開始   : 2026-07-10 16:30:00 (UTC)
* 終了   : 2026-07-10 17:05:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260710-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260710-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260710-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-lsfhost01-057 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260710-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→14→11→16→14
* 開始   : 2026-07-10 18:35:00 (UTC)
* 終了   : 2026-07-10 18:35:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 9→9→4→8→9
* 開始   : 2026-07-10 23:15:00 (UTC)
* 終了   : 2026-07-10 23:15:00 (UTC)
* 現象   : 平常時(8.833)に対し 0.4528(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host11-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→14→12→13→…→11→10→11→12
* 開始   : 2026-07-11 04:20:00 (UTC)
* 終了   : 2026-07-11 18:55:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.855, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host11-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host11-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260711-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260711-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260711-host11-004 active_connections の推移](charts/EVT-20260711-host11-004.svg)

# イベントID( EVT-20260711-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→10→11→12→…→12→13→12→14
* 開始   : 2026-07-11 05:15:00 (UTC)
* 終了   : 2026-07-11 19:00:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.808, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host11-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260711-host11-006 active_connections の推移](charts/EVT-20260711-host11-006.svg)

# イベントID( EVT-20260711-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→13→11→13→…→13→12→13→15
* 開始   : 2026-07-11 05:35:00 (UTC)
* 終了   : 2026-07-11 19:15:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.121, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260711-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host11-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260711-host11-007 active_connections の推移](charts/EVT-20260711-host11-007.svg)

# イベントID( EVT-20260711-host11-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→13→11→12→…→11→12→13→12
* 開始   : 2026-07-11 06:00:00 (UTC)
* 終了   : 2026-07-11 18:50:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.754, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host11-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260711-host11-008 active_connections の推移](charts/EVT-20260711-host11-008.svg)

# イベントID( EVT-20260711-host11-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→11→13→10→…→10→9→11→10
* 開始   : 2026-07-11 06:05:00 (UTC)
* 終了   : 2026-07-11 19:50:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.923, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host11-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260711-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 13.8 時間
  - EVT-20260711-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260711-host11-009 active_connections の推移](charts/EVT-20260711-host11-009.svg)

# イベントID( EVT-20260711-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→12→13→14→…→11→12→13→11
* 開始   : 2026-07-11 06:40:00 (UTC)
* 終了   : 2026-07-11 19:05:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.805, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260711-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260711-host11-010 active_connections の推移](charts/EVT-20260711-host11-010.svg)

# イベントID( EVT-20260711-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→7→5→10→8
* 開始   : 2026-07-11 21:15:00 (UTC)
* 終了   : 2026-07-11 21:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260711-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host11-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→14→16→14→…→15→13→14→16
* 開始   : 2026-07-13 02:15:00 (UTC)
* 終了   : 2026-07-13 20:20:00 (UTC)
* 現象   : 2026-07-13 20:20:00 (UTC)を境に水準が 11.85から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.65, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.493, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→16→18→16→…→15→12→15→13
* 開始   : 2026-07-13 03:00:00 (UTC)
* 終了   : 2026-07-13 20:40:00 (UTC)
* 現象   : 2026-07-13 20:40:00 (UTC)を境に水準が 11.96から15へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.029, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.196, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→12→16→10→14
* 開始   : 2026-07-14 04:30:00 (UTC)
* 終了   : 2026-07-14 04:30:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260714-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→15→20→18→17
* 開始   : 2026-07-14 07:05:00 (UTC)
* 終了   : 2026-07-14 07:05:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 21→19→24→21→18
* 開始   : 2026-07-14 09:45:00 (UTC)
* 終了   : 2026-07-14 09:45:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260714-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host11-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→12→9→11→12
* 開始   : 2026-07-14 19:15:00 (UTC)
* 終了   : 2026-07-14 19:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.6391(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.556σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260714-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 8→9→13→9→11
* 開始   : 2026-07-15 02:30:00 (UTC)
* 終了   : 2026-07-15 02:30:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260715-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→11→14→16→…→14→16→13→12
* 開始   : 2026-07-15 04:15:00 (UTC)
* 終了   : 2026-07-15 04:20:00 (UTC)
* 現象   : 平常時(11)に対し 1.273倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260715-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→13→15→12→15→13→14→17→15
* 開始   : 2026-07-15 04:35:00 (UTC)
* 終了   : 2026-07-15 06:20:00 (UTC)
* 現象   : 2026-07-15 06:20:00 (UTC)を境に水準が 15.04から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 17→16→21→17→18
* 開始   : 2026-07-15 07:30:00 (UTC)
* 終了   : 2026-07-15 07:30:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260715-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→11→15→14→12
* 開始   : 2026-07-16 04:25:00 (UTC)
* 終了   : 2026-07-16 04:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 18→17→22→18→17
* 開始   : 2026-07-16 07:50:00 (UTC)
* 終了   : 2026-07-16 07:50:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.288倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→18→20→19→18→18→17→19→18
* 開始   : 2026-07-16 16:10:00 (UTC)
* 終了   : 2026-07-16 17:05:00 (UTC)
* 現象   : 2026-07-16 17:05:00 (UTC)を境に水準が 15.08から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.257, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 10→14→13→16→14→13→16→12→13
* 開始   : 2026-07-17 04:30:00 (UTC)
* 終了   : 2026-07-17 04:40:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260717-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260717-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→11→16→12→14
* 開始   : 2026-07-17 04:40:00 (UTC)
* 終了   : 2026-07-17 04:40:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.444倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 21→18→16→14→…→16→14→21→17
* 開始   : 2026-07-17 16:20:00 (UTC)
* 終了   : 2026-07-17 16:25:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260717-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 18→17→14→17→19
* 開始   : 2026-07-17 16:40:00 (UTC)
* 終了   : 2026-07-17 16:40:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host11-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→12→8→11→…→11→12→13→12
* 開始   : 2026-07-18 04:55:00 (UTC)
* 終了   : 2026-07-18 19:30:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.156, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260718-host11-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260718-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260718-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260718-host11-001 active_connections の推移](charts/EVT-20260718-host11-001.svg)

# イベントID( EVT-20260718-host11-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→13→…→10→11→12→10
* 開始   : 2026-07-18 05:40:00 (UTC)
* 終了   : 2026-07-18 19:10:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.954, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260718-host11-002 active_connections の推移](charts/EVT-20260718-host11-002.svg)

# イベントID( EVT-20260718-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→9→11→12→…→12→13→12→14
* 開始   : 2026-07-18 05:50:00 (UTC)
* 終了   : 2026-07-18 19:00:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.405σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.123, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260718-host11-003 active_connections の推移](charts/EVT-20260718-host11-003.svg)

# イベントID( EVT-20260718-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→11→…→12→11→13→9
* 開始   : 2026-07-18 05:55:00 (UTC)
* 終了   : 2026-07-18 19:20:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.906, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260718-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260718-host11-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260718-host11-004 active_connections の推移](charts/EVT-20260718-host11-004.svg)

# イベントID( EVT-20260718-host11-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→12→14→12→…→11→9→11→10
* 開始   : 2026-07-18 06:10:00 (UTC)
* 終了   : 2026-07-18 18:55:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.719, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260718-host11-005 active_connections の推移](charts/EVT-20260718-host11-005.svg)

# イベントID( EVT-20260718-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→13→12→13→…→11→13→12→13
* 開始   : 2026-07-18 06:35:00 (UTC)
* 終了   : 2026-07-18 18:15:00 (UTC)
* 現象   : 11.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.993, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260718-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260718-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260718-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260718-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.7 時間
  - EVT-20260718-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間

![EVT-20260718-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→11→6→10→12
* 開始   : 2026-07-18 20:15:00 (UTC)
* 終了   : 2026-07-18 20:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260718-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→8→14→11→11
* 開始   : 2026-07-19 04:15:00 (UTC)
* 終了   : 2026-07-19 04:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→13→15→16→13→14
* 開始   : 2026-07-19 15:45:00 (UTC)
* 終了   : 2026-07-19 16:45:00 (UTC)
* 現象   : 2026-07-19 16:45:00 (UTC)を境に水準が 11.77から14.6へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host11-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→15→17→15→…→13→11→12→11
* 開始   : 2026-07-20 03:10:00 (UTC)
* 終了   : 2026-07-20 19:00:00 (UTC)
* 現象   : 2026-07-20 19:00:00 (UTC)を境に水準が 11.77から15.16へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.685, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.74, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→14→17→16→…→14→13→12→14
* 開始   : 2026-07-20 03:45:00 (UTC)
* 終了   : 2026-07-20 20:35:00 (UTC)
* 現象   : 2026-07-20 20:35:00 (UTC)を境に水準が 11.89から15.06へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.912, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.802, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→11→6→10→10
* 開始   : 2026-07-20 21:25:00 (UTC)
* 終了   : 2026-07-20 21:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.5625(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260720-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→8→4→7→11
* 開始   : 2026-07-20 23:05:00 (UTC)
* 終了   : 2026-07-20 23:05:00 (UTC)
* 現象   : 平常時(9)に対し 0.4444(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260720-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260720-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260720-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→15→20→17→15
* 開始   : 2026-07-21 06:50:00 (UTC)
* 終了   : 2026-07-21 06:50:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260721-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 21→20→26→22→23
* 開始   : 2026-07-21 12:25:00 (UTC)
* 終了   : 2026-07-21 12:25:00 (UTC)
* 現象   : 平常時(21.25)に対し 1.224倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260721-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→16→15→16→15→16→16
* 開始   : 2026-07-21 17:55:00 (UTC)
* 終了   : 2026-07-21 19:00:00 (UTC)
* 現象   : 2026-07-21 19:00:00 (UTC)を境に水準が 14.93から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.939, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 8→10→12→8→…→8→14→10→12
* 開始   : 2026-07-22 02:55:00 (UTC)
* 終了   : 2026-07-22 03:05:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-006 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-007 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260722-host11-001 active_connections の推移](charts/EVT-20260722-host11-001.svg)

# イベントID( EVT-20260722-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→12→17→13→15
* 開始   : 2026-07-22 05:20:00 (UTC)
* 終了   : 2026-07-22 05:20:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 17→16→18→12→…→17→19→14→16
* 開始   : 2026-07-22 06:25:00 (UTC)
* 終了   : 2026-07-22 07:30:00 (UTC)
* 現象   : 1.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host11-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260722-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-019 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260722-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→18→11→13→13
* 開始   : 2026-07-22 18:35:00 (UTC)
* 終了   : 2026-07-22 18:35:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 14→13→10→13→…→13→11→14→12
* 開始   : 2026-07-22 18:55:00 (UTC)
* 終了   : 2026-07-22 19:05:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→8→5→11→7
* 開始   : 2026-07-22 21:50:00 (UTC)
* 終了   : 2026-07-22 21:50:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host06-019 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-080 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→12→16→17→…→16→17→13→15
* 開始   : 2026-07-23 05:10:00 (UTC)
* 終了   : 2026-07-23 05:15:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.315倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.691σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260723-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→15→18→15→15
* 開始   : 2026-07-23 05:30:00 (UTC)
* 終了   : 2026-07-23 05:30:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.394倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host11-006 active_connections の推移](charts/EVT-20260723-host11-006.svg)

# イベントID( EVT-20260723-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 18→17→22→21→…→22→21→18→19
* 開始   : 2026-07-23 08:00:00 (UTC)
* 終了   : 2026-07-23 08:05:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 19→18→16→14→19→18→16→14→19
* 開始   : 2026-07-23 16:05:00 (UTC)
* 終了   : 2026-07-23 16:40:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260723-lsfhost01-051 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→13→12→13→…→13→10→13→12
* 開始   : 2026-07-23 18:35:00 (UTC)
* 終了   : 2026-07-23 19:05:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 15 分
  - EVT-20260723-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260723-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260723-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260723-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 7→8→3→7→9
* 開始   : 2026-07-23 23:55:00 (UTC)
* 終了   : 2026-07-23 23:55:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.3636(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.685σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-086 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260723-host11-016 active_connections の推移](charts/EVT-20260723-host11-016.svg)

# イベントID( EVT-20260724-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 20→23→25→23→23
* 開始   : 2026-07-24 10:20:00 (UTC)
* 終了   : 2026-07-24 10:20:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260724-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host11-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→14→11→13→…→9→11→10→12
* 開始   : 2026-07-25 05:05:00 (UTC)
* 終了   : 2026-07-25 19:45:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.127, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.7 時間
  - EVT-20260725-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260725-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 14.6 時間

![EVT-20260725-host11-002 active_connections の推移](charts/EVT-20260725-host11-002.svg)

# イベントID( EVT-20260725-host11-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→10→12→11→…→13→10→12→10
* 開始   : 2026-07-25 05:35:00 (UTC)
* 終了   : 2026-07-25 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.136, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260725-host11-003 active_connections の推移](charts/EVT-20260725-host11-003.svg)

# イベントID( EVT-20260725-host11-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→10→9→10→…→14→12→13→12
* 開始   : 2026-07-25 05:35:00 (UTC)
* 終了   : 2026-07-25 18:25:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.182, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260725-host11-004 active_connections の推移](charts/EVT-20260725-host11-004.svg)

# イベントID( EVT-20260725-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→10→…→10→13→11→16
* 開始   : 2026-07-25 05:45:00 (UTC)
* 終了   : 2026-07-25 19:00:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.765, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260725-host11-005 active_connections の推移](charts/EVT-20260725-host11-005.svg)

# イベントID( EVT-20260725-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→11→13→11→…→14→10→13→11
* 開始   : 2026-07-25 05:50:00 (UTC)
* 終了   : 2026-07-25 18:50:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.79, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260725-host11-006 active_connections の推移](charts/EVT-20260725-host11-006.svg)

# イベントID( EVT-20260725-host11-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→12→10→15→…→13→12→13→12
* 開始   : 2026-07-25 06:20:00 (UTC)
* 終了   : 2026-07-25 20:15:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.82, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260725-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260725-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 13.9 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間

![EVT-20260725-host11-007 active_connections の推移](charts/EVT-20260725-host11-007.svg)

# イベントID( EVT-20260726-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 8→10→9→8→9→8→10→9→8
* 開始   : 2026-07-26 00:15:00 (UTC)
* 終了   : 2026-07-26 01:40:00 (UTC)
* 現象   : 2026-07-26 01:40:00 (UTC)を境に水準が 12から11.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.981, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→13→10→15→16
* 開始   : 2026-07-26 09:10:00 (UTC)
* 終了   : 2026-07-26 09:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→9→13→9→10
* 開始   : 2026-07-27 02:15:00 (UTC)
* 終了   : 2026-07-27 02:15:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260727-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260727-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 9→9→14→11→10
* 開始   : 2026-07-27 02:55:00 (UTC)
* 終了   : 2026-07-27 02:55:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.6倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.676σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260727-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260727-host11-004 active_connections の推移](charts/EVT-20260727-host11-004.svg)

# イベントID( EVT-20260728-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→16→19→17→16
* 開始   : 2026-07-28 06:25:00 (UTC)
* 終了   : 2026-07-28 06:25:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.333倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→15→21→18→17
* 開始   : 2026-07-28 07:20:00 (UTC)
* 終了   : 2026-07-28 07:20:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 17→17→17→18→19
* 開始   : 2026-07-28 17:25:00 (UTC)
* 終了   : 2026-07-28 18:35:00 (UTC)
* 現象   : 2026-07-28 18:35:00 (UTC)を境に水準が 15.1から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.87, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 10→10→14→10→12
* 開始   : 2026-07-29 03:15:00 (UTC)
* 終了   : 2026-07-29 03:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 20→20→23→20→20
* 開始   : 2026-07-29 08:40:00 (UTC)
* 終了   : 2026-07-29 08:40:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 20→19→25→22→22
* 開始   : 2026-07-29 10:30:00 (UTC)
* 終了   : 2026-07-29 10:30:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 20→21→22→21→19
* 開始   : 2026-07-29 15:20:00 (UTC)
* 終了   : 2026-07-29 16:25:00 (UTC)
* 現象   : 2026-07-29 16:25:00 (UTC)を境に水準が 14.87から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.81, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→15→19→18→15→19→18→16
* 開始   : 2026-07-30 06:40:00 (UTC)
* 終了   : 2026-07-30 06:45:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→20→18→16→20→18
* 開始   : 2026-07-30 07:05:00 (UTC)
* 終了   : 2026-07-30 08:10:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 21→22→17→20→20
* 開始   : 2026-07-30 14:15:00 (UTC)
* 終了   : 2026-07-30 14:15:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260730-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 8→10→6→9→…→9→4→9→8
* 開始   : 2026-07-30 23:00:00 (UTC)
* 終了   : 2026-07-30 23:10:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→7→12→8→8
* 開始   : 2026-07-31 01:10:00 (UTC)
* 終了   : 2026-07-31 01:10:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260731-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 21→19→24→18→21
* 開始   : 2026-07-31 09:05:00 (UTC)
* 終了   : 2026-07-31 09:05:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 21→21→17→20→22
* 開始   : 2026-07-31 15:00:00 (UTC)
* 終了   : 2026-07-31 16:00:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260731-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260731-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→17→15→14→…→15→14→18→15
* 開始   : 2026-07-31 17:05:00 (UTC)
* 終了   : 2026-07-31 17:45:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260731-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260731-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 35 分
  - EVT-20260731-host02-015 (他ホスト) jvm_gc / ou : WARN / 重なり 15 分
  - EVT-20260731-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260731-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→17→13→17→15
* 開始   : 2026-07-31 17:35:00 (UTC)
* 終了   : 2026-07-31 17:35:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260731-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host02-015 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→15→10→12→13
* 開始   : 2026-07-31 18:20:00 (UTC)
* 終了   : 2026-07-31 18:20:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.6486(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.789σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host11-010 active_connections の推移](charts/EVT-20260731-host11-010.svg)

# イベントID( EVT-20260731-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→10→8→11→11→8→10
* 開始   : 2026-07-31 20:35:00 (UTC)
* 終了   : 2026-07-31 22:05:00 (UTC)
* 現象   : 2026-07-31 22:05:00 (UTC)を境に水準が 15.06から11.83へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.534, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→8→12→13→…→12→13→9→10
* 開始   : 2026-07-01 02:55:00 (UTC)
* 終了   : 2026-07-01 03:05:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-008 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260701-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 19→15→17→15→17→15→19→20
* 開始   : 2026-07-01 08:05:00 (UTC)
* 終了   : 2026-07-01 09:15:00 (UTC)
* 現象   : 水曜8時台の平常値(19.06)に対し 15であった
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.097σ 外れた (平常値=19.06)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260701-host11-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260701-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260701-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 18→19→21→22→19→21→22→19→21
* 開始   : 2026-07-01 08:15:00 (UTC)
* 終了   : 2026-07-01 08:20:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host11-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260701-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 16→17→15→14→17→15→14→17→18
* 開始   : 2026-07-01 17:00:00 (UTC)
* 終了   : 2026-07-01 17:05:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-052 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-054 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→17→14→18→17→14→18→16
* 開始   : 2026-07-01 17:25:00 (UTC)
* 終了   : 2026-07-01 17:30:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.8(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260701-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→11→12→10→11→10→12→11→12
* 開始   : 2026-07-01 20:25:00 (UTC)
* 終了   : 2026-07-01 21:10:00 (UTC)
* 現象   : 2026-07-01 21:10:00 (UTC)を境に水準が 15.01から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 8→9→7→6→7→6→9→8
* 開始   : 2026-07-01 21:55:00 (UTC)
* 終了   : 2026-07-01 22:05:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 8→9→5→6→…→6→11→8→9
* 開始   : 2026-07-02 00:05:00 (UTC)
* 終了   : 2026-07-02 00:15:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260702-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→10→14→16→10→14
* 開始   : 2026-07-02 05:30:00 (UTC)
* 終了   : 2026-07-02 05:35:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 23→22→22→21→21→22→22→24→24
* 開始   : 2026-07-02 09:55:00 (UTC)
* 終了   : 2026-07-02 10:45:00 (UTC)
* 現象   : 2026-07-02 10:45:00 (UTC)を境に水準が 15から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.047, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 23→20→18→22→18→22→18→21→19
* 開始   : 2026-07-02 14:35:00 (UTC)
* 終了   : 2026-07-02 14:45:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 17→18→15→16→15→16→15→16
* 開始   : 2026-07-02 17:00:00 (UTC)
* 終了   : 2026-07-02 17:10:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.8036(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.574σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260702-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→14→12→15→11→12→15→11→13
* 開始   : 2026-07-02 18:20:00 (UTC)
* 終了   : 2026-07-02 18:30:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260702-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260702-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 14→13→12→15→12→15→12→13→14
* 開始   : 2026-07-02 18:35:00 (UTC)
* 終了   : 2026-07-02 18:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260702-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260702-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→12→13→10→12→11
* 開始   : 2026-07-02 19:25:00 (UTC)
* 終了   : 2026-07-02 19:30:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.7362(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→10→9→9→8→7→9→8→11
* 開始   : 2026-07-03 00:05:00 (UTC)
* 終了   : 2026-07-03 00:45:00 (UTC)
* 現象   : 2026-07-03 00:45:00 (UTC)を境に水準が 14.92から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.257, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 16→15→19→18→15→19→18→14
* 開始   : 2026-07-03 06:35:00 (UTC)
* 終了   : 2026-07-03 06:40:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.253倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.691σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260703-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→17→19→17→19→17→19→18
* 開始   : 2026-07-03 07:00:00 (UTC)
* 終了   : 2026-07-03 07:10:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.26倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.743σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260703-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 20→19→22→21→19→22→21→19
* 開始   : 2026-07-03 08:50:00 (UTC)
* 終了   : 2026-07-03 08:55:00 (UTC)
* 現象   : 平常時(18.17)に対し 1.211倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host11-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 21→22→22→22→21→23→24→24→24
* 開始   : 2026-07-03 11:15:00 (UTC)
* 終了   : 2026-07-03 11:55:00 (UTC)
* 現象   : 2026-07-03 11:55:00 (UTC)を境に水準が 15.05から13.46へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 18→16→17→22→16→17→22→16→18
* 開始   : 2026-07-03 16:20:00 (UTC)
* 終了   : 2026-07-03 16:30:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.8458(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260703-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260703-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→18→14→15→18→14→15
* 開始   : 2026-07-03 17:35:00 (UTC)
* 終了   : 2026-07-03 17:40:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host11-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host08-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 17→16→13→17→13→17→13→15
* 開始   : 2026-07-03 17:45:00 (UTC)
* 終了   : 2026-07-03 17:55:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 9→8→7→9→8→7→9
* 開始   : 2026-07-03 21:30:00 (UTC)
* 終了   : 2026-07-03 21:35:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-081 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260703-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 10→11→14→15→11→14→15→11→13
* 開始   : 2026-07-05 05:55:00 (UTC)
* 終了   : 2026-07-05 06:00:00 (UTC)
* 現象   : 平常時(11)に対し 1.273倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260705-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→15→10→12→…→12→9→12→11
* 開始   : 2026-07-05 18:05:00 (UTC)
* 終了   : 2026-07-05 18:15:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260705-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260705-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260705-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260705-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→8→7→9→13→7→9→13→10
* 開始   : 2026-07-05 20:45:00 (UTC)
* 終了   : 2026-07-05 20:55:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-040 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260705-lsfhost01-041 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260705-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260705-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→11→9→10→10→9→7→10→12
* 開始   : 2026-07-06 21:10:00 (UTC)
* 終了   : 2026-07-06 22:00:00 (UTC)
* 現象   : 2026-07-06 22:00:00 (UTC)を境に水準が 14.83から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.981, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→13→15→12→15→12→15→14→13
* 開始   : 2026-07-07 04:45:00 (UTC)
* 終了   : 2026-07-07 04:55:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260707-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260707-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260707-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 17→16→20→17→16→20→17
* 開始   : 2026-07-07 07:45:00 (UTC)
* 終了   : 2026-07-07 07:50:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.206倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.405σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260707-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260707-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 23→21→21→21→20→24→23
* 開始   : 2026-07-07 13:25:00 (UTC)
* 終了   : 2026-07-07 13:55:00 (UTC)
* 現象   : 2026-07-07 13:55:00 (UTC)を境に水準が 14.92から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.534, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 19→21→17→20→21→17→20
* 開始   : 2026-07-07 15:05:00 (UTC)
* 終了   : 2026-07-07 15:10:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8031(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.915σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 18→16→15→17→16→15→17→16
* 開始   : 2026-07-07 16:25:00 (UTC)
* 終了   : 2026-07-07 16:30:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host11-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 10→14→10→9→10→10→10→10→10
* 開始   : 2026-07-07 21:15:00 (UTC)
* 終了   : 2026-07-07 22:20:00 (UTC)
* 現象   : 2026-07-07 22:20:00 (UTC)を境に水準が 14.97から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.878, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host11-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 9→10→10→9→10→10
* 開始   : 2026-07-07 23:05:00 (UTC)
* 終了   : 2026-07-07 23:30:00 (UTC)
* 現象   : 2026-07-07 23:30:00 (UTC)を境に水準が 14.94から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→11→15→14→15→14→15→14→13
* 開始   : 2026-07-08 04:25:00 (UTC)
* 終了   : 2026-07-08 04:35:00 (UTC)
* 現象   : 平常時(11)に対し 1.364倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.801σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260708-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260708-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→13→18→15→13→18→15→17
* 開始   : 2026-07-08 06:20:00 (UTC)
* 終了   : 2026-07-08 06:25:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.271倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.684σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260708-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 17→16→16→17→16→18→18→19→20
* 開始   : 2026-07-08 06:20:00 (UTC)
* 終了   : 2026-07-08 08:00:00 (UTC)
* 現象   : 2026-07-08 08:00:00 (UTC)を境に水準が 14.82から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.206, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 22→20→25→20→25→20→22
* 開始   : 2026-07-08 12:10:00 (UTC)
* 終了   : 2026-07-08 12:15:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 19→21→20→17→17
* 開始   : 2026-07-08 16:10:00 (UTC)
* 終了   : 2026-07-08 16:30:00 (UTC)
* 現象   : 2026-07-08 16:30:00 (UTC)を境に水準が 15.07から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.385, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→10→9→11→9→11→9→11→10
* 開始   : 2026-07-08 20:00:00 (UTC)
* 終了   : 2026-07-08 20:10:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host11-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260708-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 8→9→5→8→9→5→8→5
* 開始   : 2026-07-08 23:30:00 (UTC)
* 終了   : 2026-07-08 23:35:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.346σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-083 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260708-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→10→14→15→…→14→15→12→13
* 開始   : 2026-07-09 04:40:00 (UTC)
* 終了   : 2026-07-09 04:45:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 19→18→21→22→…→21→22→19→18
* 開始   : 2026-07-09 08:25:00 (UTC)
* 終了   : 2026-07-09 08:30:00 (UTC)
* 現象   : 平常時(18)に対し 1.167倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260709-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 20→20→21→21→22→22→22→22→22
* 開始   : 2026-07-09 08:45:00 (UTC)
* 終了   : 2026-07-09 09:40:00 (UTC)
* 現象   : 2026-07-09 09:40:00 (UTC)を境に水準が 15.04から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.324, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 21→19→22→25→…→25→19→20→22
* 開始   : 2026-07-09 13:20:00 (UTC)
* 終了   : 2026-07-09 13:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260709-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 23→21→19→21→19→21
* 開始   : 2026-07-09 13:45:00 (UTC)
* 終了   : 2026-07-09 13:50:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 22→23→22→22→21→22→22→23→21
* 開始   : 2026-07-09 14:00:00 (UTC)
* 終了   : 2026-07-09 14:40:00 (UTC)
* 現象   : 2026-07-09 14:40:00 (UTC)を境に水準が 14.93から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.257, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 17→15→14→15→14→16
* 開始   : 2026-07-09 17:25:00 (UTC)
* 終了   : 2026-07-09 17:35:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host11-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260709-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260709-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260709-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 18→15→14→16→15→14→16→17
* 開始   : 2026-07-09 17:35:00 (UTC)
* 終了   : 2026-07-09 17:40:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host11-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260709-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→14→11→12→11→12→11→13→16
* 開始   : 2026-07-09 19:05:00 (UTC)
* 終了   : 2026-07-09 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host11-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260709-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260709-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260709-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→12→10→11→12→10→11
* 開始   : 2026-07-09 19:35:00 (UTC)
* 終了   : 2026-07-09 19:40:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260709-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260709-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→9→8→13→12→9→8→13→10
* 開始   : 2026-07-09 20:30:00 (UTC)
* 終了   : 2026-07-09 20:35:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260709-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→11→11→11→11→10→9→10→11
* 開始   : 2026-07-09 20:45:00 (UTC)
* 終了   : 2026-07-09 21:25:00 (UTC)
* 現象   : 2026-07-09 21:25:00 (UTC)を境に水準が 14.92から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.345, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host11-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 8→6→5→9→8→6→5→9→7
* 開始   : 2026-07-09 22:35:00 (UTC)
* 終了   : 2026-07-09 22:40:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260709-host11-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 9→8→5→11→…→5→11→9→8
* 開始   : 2026-07-10 00:20:00 (UTC)
* 終了   : 2026-07-10 00:25:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 6→10→12→9→13→12→9→13→10
* 開始   : 2026-07-10 02:20:00 (UTC)
* 終了   : 2026-07-10 02:30:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-005 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 17→19→21→19→21→19
* 開始   : 2026-07-10 08:30:00 (UTC)
* 終了   : 2026-07-10 08:35:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260710-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→11→10→11→13→11→10→11→12
* 開始   : 2026-07-10 19:25:00 (UTC)
* 終了   : 2026-07-10 19:30:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→12→10→6→12→10→6→9→8
* 開始   : 2026-07-10 23:00:00 (UTC)
* 終了   : 2026-07-10 23:10:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-088 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260710-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 6→7→11→8→11→8→11→8
* 開始   : 2026-07-11 01:30:00 (UTC)
* 終了   : 2026-07-11 01:40:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260711-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 10→8→6→11→…→11→12→9→8
* 開始   : 2026-07-11 02:35:00 (UTC)
* 終了   : 2026-07-11 02:45:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host11-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260711-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260711-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 10→7→11→7→12→11→7→12→9
* 開始   : 2026-07-11 02:35:00 (UTC)
* 終了   : 2026-07-11 02:45:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.053σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host11-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260711-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260711-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host11-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 11→9→8→11→…→8→11→10→11
* 開始   : 2026-07-11 04:35:00 (UTC)
* 終了   : 2026-07-11 04:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.97, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260711-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260711-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260711-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260711-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→14→15→14→…→14→16→12→13
* 開始   : 2026-07-12 07:10:00 (UTC)
* 終了   : 2026-07-12 07:20:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260712-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→14→18→15→12→18→15→12→14
* 開始   : 2026-07-12 09:50:00 (UTC)
* 終了   : 2026-07-12 10:00:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260712-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→17→16→15→15→16→17→17→18
* 開始   : 2026-07-12 10:45:00 (UTC)
* 終了   : 2026-07-12 11:40:00 (UTC)
* 現象   : 2026-07-12 11:40:00 (UTC)を境に水準が 11.82から13.46へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.79, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→10→7→6→…→10→7→6→10
* 開始   : 2026-07-12 20:05:00 (UTC)
* 終了   : 2026-07-12 20:15:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260712-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 9→10→13→8→…→8→7→9→10
* 開始   : 2026-07-12 20:25:00 (UTC)
* 終了   : 2026-07-12 20:35:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.053σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host11-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→10→10→9→10→10→8→11
* 開始   : 2026-07-12 20:45:00 (UTC)
* 終了   : 2026-07-12 21:20:00 (UTC)
* 現象   : 2026-07-12 21:20:00 (UTC)を境に水準が 11.93から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.196, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 9→11→11→10
* 開始   : 2026-07-13 21:25:00 (UTC)
* 終了   : 2026-07-13 21:40:00 (UTC)
* 現象   : 2026-07-13 21:40:00 (UTC)を境に水準が 15から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.108, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→13→8→13→8→13→12→10
* 開始   : 2026-07-14 02:55:00 (UTC)
* 終了   : 2026-07-14 03:05:00 (UTC)
* 現象   : 平常時(9)に対し 1.444倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.798σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260714-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host11-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→12→13→13→11→12→13→14→14
* 開始   : 2026-07-14 03:50:00 (UTC)
* 終了   : 2026-07-14 05:05:00 (UTC)
* 現象   : 2026-07-14 05:05:00 (UTC)を境に水準が 14.88から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.204, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→18→12→14→15→18→12→14→15
* 開始   : 2026-07-14 06:15:00 (UTC)
* 終了   : 2026-07-14 06:20:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260714-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→18→16→18→16→15
* 開始   : 2026-07-14 06:35:00 (UTC)
* 終了   : 2026-07-14 06:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 19→17→21→22→…→21→22→20→21
* 開始   : 2026-07-14 08:20:00 (UTC)
* 終了   : 2026-07-14 08:25:00 (UTC)
* 現象   : 平常時(18)に対し 1.167倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 21→20→24→21→24→21→24→21→22
* 開始   : 2026-07-14 11:00:00 (UTC)
* 終了   : 2026-07-14 11:10:00 (UTC)
* 現象   : 平常時(20.75)に対し 1.157倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260714-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host11-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 23→23→23→22→23→24
* 開始   : 2026-07-14 13:30:00 (UTC)
* 終了   : 2026-07-14 13:55:00 (UTC)
* 現象   : 2026-07-14 13:55:00 (UTC)を境に水準が 15.01から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 20→19→17→16→…→17→16→18→17
* 開始   : 2026-07-14 15:45:00 (UTC)
* 終了   : 2026-07-14 15:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260714-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260714-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host11-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→20→18→20→19→20
* 開始   : 2026-07-14 15:55:00 (UTC)
* 終了   : 2026-07-14 16:20:00 (UTC)
* 現象   : 2026-07-14 16:20:00 (UTC)を境に水準が 14.91から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.845, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→14→12→15→14→12→15
* 開始   : 2026-07-14 18:15:00 (UTC)
* 終了   : 2026-07-14 18:20:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.7579(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.691σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260714-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→14→16→15→14→16→15→11
* 開始   : 2026-07-15 05:30:00 (UTC)
* 終了   : 2026-07-15 05:35:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host11-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 19→19→20→18→18→19→17→18→19
* 開始   : 2026-07-15 15:45:00 (UTC)
* 終了   : 2026-07-15 16:30:00 (UTC)
* 現象   : 2026-07-15 16:30:00 (UTC)を境に水準が 14.9から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.003, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 19→19→17→17→19→19
* 開始   : 2026-07-15 16:30:00 (UTC)
* 終了   : 2026-07-15 16:55:00 (UTC)
* 現象   : 2026-07-15 16:55:00 (UTC)を境に水準が 15.02から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 16→14→15→13→14→15→13→15→14
* 開始   : 2026-07-15 17:25:00 (UTC)
* 終了   : 2026-07-15 17:35:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host01-007 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260715-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260715-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260715-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 10→10→10→9→8→9→10
* 開始   : 2026-07-15 22:50:00 (UTC)
* 終了   : 2026-07-15 23:20:00 (UTC)
* 現象   : 2026-07-15 23:20:00 (UTC)を境に水準が 14.96から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.402, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→7→13→11→7→13→11
* 開始   : 2026-07-16 03:35:00 (UTC)
* 終了   : 2026-07-16 03:40:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.672(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-013 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260716-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 22→24→25→22→22→21
* 開始   : 2026-07-16 10:00:00 (UTC)
* 終了   : 2026-07-16 10:25:00 (UTC)
* 現象   : 2026-07-16 10:25:00 (UTC)を境に水準が 14.92から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 19→16→15→18→19→16→15→18→20
* 開始   : 2026-07-16 15:50:00 (UTC)
* 終了   : 2026-07-16 15:55:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260716-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→11→12→10→11→12→10→13→11
* 開始   : 2026-07-16 18:55:00 (UTC)
* 終了   : 2026-07-16 19:05:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→14→10→9→…→10→9→13→12
* 開始   : 2026-07-16 19:40:00 (UTC)
* 終了   : 2026-07-16 19:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→9→7→8→9→7→8→7
* 開始   : 2026-07-16 21:55:00 (UTC)
* 終了   : 2026-07-16 22:00:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.672(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-087 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260716-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 11→10→10→12→8→10
* 開始   : 2026-07-17 01:15:00 (UTC)
* 終了   : 2026-07-17 01:40:00 (UTC)
* 現象   : 2026-07-17 01:40:00 (UTC)を境に水準が 14.91から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.202, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 7→8→11→8→11→8→11→7
* 開始   : 2026-07-17 01:25:00 (UTC)
* 終了   : 2026-07-17 01:35:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260717-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 9→10→11
* 開始   : 2026-07-17 01:35:00 (UTC)
* 終了   : 2026-07-17 01:45:00 (UTC)
* 現象   : 2026-07-17 01:45:00 (UTC)を境に水準が 14.93から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.923, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→14→16→17→…→16→17→14→15
* 開始   : 2026-07-17 05:50:00 (UTC)
* 終了   : 2026-07-17 06:00:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.053σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 17→16→19→20→17→16→19→20→17
* 開始   : 2026-07-17 07:10:00 (UTC)
* 終了   : 2026-07-17 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→16→20→21→…→20→21→19→17
* 開始   : 2026-07-17 07:45:00 (UTC)
* 終了   : 2026-07-17 07:50:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-040 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260717-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→17→13→15→…→15→12→17→14
* 開始   : 2026-07-17 17:50:00 (UTC)
* 終了   : 2026-07-17 18:00:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260717-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260717-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host11-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→10→8→10→10→9→9
* 開始   : 2026-07-17 22:25:00 (UTC)
* 終了   : 2026-07-17 22:55:00 (UTC)
* 現象   : 2026-07-17 22:55:00 (UTC)を境に水準が 15から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→13→9→6→13→9→6→10→8
* 開始   : 2026-07-17 22:35:00 (UTC)
* 終了   : 2026-07-17 22:45:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.393倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260717-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→13→9→12→13→9→12→11
* 開始   : 2026-07-18 19:20:00 (UTC)
* 終了   : 2026-07-18 19:25:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260718-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 8→10→11→10→9→8→9→9→9
* 開始   : 2026-07-18 23:10:00 (UTC)
* 終了   : 2026-07-19 00:00:00 (UTC)
* 現象   : 2026-07-19 00:00:00 (UTC)を境に水準が 11.75から11.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.981, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260718-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 8→11→12→13→10→11→12→13→10
* 開始   : 2026-07-19 03:30:00 (UTC)
* 終了   : 2026-07-19 03:35:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host02-003 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260719-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→15→17→15→17→15→17→16→15
* 開始   : 2026-07-19 09:50:00 (UTC)
* 終了   : 2026-07-19 10:00:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host11-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260719-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→18→12→15→18→12→15→17
* 開始   : 2026-07-19 09:55:00 (UTC)
* 終了   : 2026-07-19 10:00:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host11-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260719-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→15→15→15→16→15→14→17→15
* 開始   : 2026-07-19 13:50:00 (UTC)
* 終了   : 2026-07-19 15:20:00 (UTC)
* 現象   : 2026-07-19 15:20:00 (UTC)を境に水準が 11.89から14.16へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.981, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→14→14→15→13→15→14→15→14
* 開始   : 2026-07-19 14:50:00 (UTC)
* 終了   : 2026-07-19 16:45:00 (UTC)
* 現象   : 2026-07-19 16:45:00 (UTC)を境に水準が 11.82から14.38へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 9→10→10→10→10→9→10→10→12
* 開始   : 2026-07-20 01:50:00 (UTC)
* 終了   : 2026-07-20 02:35:00 (UTC)
* 現象   : 2026-07-20 02:35:00 (UTC)を境に水準が 11.95から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 9→9→11→12→10→9→12
* 開始   : 2026-07-21 02:10:00 (UTC)
* 終了   : 2026-07-21 02:40:00 (UTC)
* 現象   : 2026-07-21 02:40:00 (UTC)を境に水準が 14.95から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.534, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→12→16→13→17→16→13→17→15
* 開始   : 2026-07-21 05:30:00 (UTC)
* 終了   : 2026-07-21 05:40:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→17→16→16→16→18→17→18→16
* 開始   : 2026-07-21 06:05:00 (UTC)
* 終了   : 2026-07-21 06:55:00 (UTC)
* 現象   : 2026-07-21 06:55:00 (UTC)を境に水準が 15.03から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.981, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 18→16→20→21→19→16→20→21→19
* 開始   : 2026-07-21 08:10:00 (UTC)
* 終了   : 2026-07-21 08:15:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.053σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 21→24→20→19→…→20→19→21→22
* 開始   : 2026-07-21 12:40:00 (UTC)
* 終了   : 2026-07-21 12:45:00 (UTC)
* 現象   : 平常時(22.92)に対し 0.8727(20)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260721-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 22→19→23→19→23→19→24→22
* 開始   : 2026-07-21 13:40:00 (UTC)
* 終了   : 2026-07-21 13:50:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260721-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260721-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 21→18→19→19→17→18→18→15→17
* 開始   : 2026-07-21 14:55:00 (UTC)
* 終了   : 2026-07-21 17:20:00 (UTC)
* 現象   : 2026-07-21 17:20:00 (UTC)を境に水準が 15.05から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.086, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→14→12→13→…→13→11→13→16
* 開始   : 2026-07-21 18:55:00 (UTC)
* 終了   : 2026-07-21 19:05:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260721-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→9→12→9→12→9→11→12
* 開始   : 2026-07-21 20:40:00 (UTC)
* 終了   : 2026-07-21 21:45:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.7297(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260721-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host09-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-073 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-074 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260721-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→9→13→12→…→12→14→11→10
* 開始   : 2026-07-22 04:00:00 (UTC)
* 終了   : 2026-07-22 04:10:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260722-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→12→12→14→13→14→14→14→17
* 開始   : 2026-07-22 04:25:00 (UTC)
* 終了   : 2026-07-22 06:15:00 (UTC)
* 現象   : 2026-07-22 06:15:00 (UTC)を境に水準が 14.91から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.437, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→17→20→17→20→17→20→18
* 開始   : 2026-07-22 07:25:00 (UTC)
* 終了   : 2026-07-22 07:35:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.574σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260722-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→17→20→18→…→17→21→17→19
* 開始   : 2026-07-22 07:40:00 (UTC)
* 終了   : 2026-07-22 08:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260722-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 20 分
  - EVT-20260722-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 20→21→19→21→21→21→21→20→22
* 開始   : 2026-07-22 08:30:00 (UTC)
* 終了   : 2026-07-22 09:30:00 (UTC)
* 現象   : 2026-07-22 09:30:00 (UTC)を境に水準が 15.04から15.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.705, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 21→22→18→24→21→22→18→24→21
* 開始   : 2026-07-22 10:40:00 (UTC)
* 終了   : 2026-07-22 10:45:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-037 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 25→22→21→25→23→23
* 開始   : 2026-07-22 11:20:00 (UTC)
* 終了   : 2026-07-22 11:45:00 (UTC)
* 現象   : 2026-07-22 11:45:00 (UTC)を境に水準が 15.03から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 10→13→9→6→13→9→6→10
* 開始   : 2026-07-23 02:40:00 (UTC)
* 終了   : 2026-07-23 02:50:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.405倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.631σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→12→12→12→13→12→12→12
* 開始   : 2026-07-23 03:20:00 (UTC)
* 終了   : 2026-07-23 03:55:00 (UTC)
* 現象   : 2026-07-23 03:55:00 (UTC)を境に水準が 14.94から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.794, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→13→14→15→14→15
* 開始   : 2026-07-23 03:25:00 (UTC)
* 終了   : 2026-07-23 04:55:00 (UTC)
* 現象   : 2026-07-23 04:55:00 (UTC)を境に水準が 14.9から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.202, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→13→13→12→13
* 開始   : 2026-07-23 03:40:00 (UTC)
* 終了   : 2026-07-23 04:00:00 (UTC)
* 現象   : 2026-07-23 04:00:00 (UTC)を境に水準が 15.11から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.81, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→19→20→17→19→20→17→15
* 開始   : 2026-07-23 06:50:00 (UTC)
* 終了   : 2026-07-23 06:55:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 19→18→22→19→18→22→19→21
* 開始   : 2026-07-23 09:05:00 (UTC)
* 終了   : 2026-07-23 09:10:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.398σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 21→25→22→21→25→22
* 開始   : 2026-07-23 12:20:00 (UTC)
* 終了   : 2026-07-23 12:25:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.163倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260723-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 21→23→19→18→19→18→21
* 開始   : 2026-07-23 14:15:00 (UTC)
* 終了   : 2026-07-23 14:25:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-046 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260723-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→10→9→11→12→10→9→11
* 開始   : 2026-07-23 19:45:00 (UTC)
* 終了   : 2026-07-23 19:50:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260723-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host11-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→11→9→12→10→10
* 開始   : 2026-07-23 21:15:00 (UTC)
* 終了   : 2026-07-23 21:40:00 (UTC)
* 現象   : 2026-07-23 21:40:00 (UTC)を境に水準が 15.02から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 10→9→6→12→10→9→6→12→10
* 開始   : 2026-07-24 02:25:00 (UTC)
* 終了   : 2026-07-24 02:30:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-lsfhost01-006 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260724-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host11-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→10→11→12→13
* 開始   : 2026-07-24 03:05:00 (UTC)
* 終了   : 2026-07-24 03:35:00 (UTC)
* 現象   : 2026-07-24 03:35:00 (UTC)を境に水準が 15.04から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.534, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→13→11→10→9→12→13→13→10
* 開始   : 2026-07-24 03:15:00 (UTC)
* 終了   : 2026-07-24 03:55:00 (UTC)
* 現象   : 2026-07-24 03:55:00 (UTC)を境に水準が 14.91から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→10→14→12→14→12→14→13→11
* 開始   : 2026-07-24 03:55:00 (UTC)
* 終了   : 2026-07-24 04:05:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.366倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260724-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host11-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 24→22→24→22→22→23
* 開始   : 2026-07-24 13:30:00 (UTC)
* 終了   : 2026-07-24 13:55:00 (UTC)
* 現象   : 2026-07-24 13:55:00 (UTC)を境に水準が 15.01から12.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 18→22→16→17→18→22→16→17→16
* 開始   : 2026-07-24 15:50:00 (UTC)
* 終了   : 2026-07-24 15:55:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260724-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 18→15→19→15→19→15→16→18
* 開始   : 2026-07-24 16:50:00 (UTC)
* 終了   : 2026-07-24 17:00:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→11→14→10→11→14→10→13
* 開始   : 2026-07-24 19:00:00 (UTC)
* 終了   : 2026-07-24 19:10:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260724-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→11→10→11→9→11→10
* 開始   : 2026-07-24 21:20:00 (UTC)
* 終了   : 2026-07-24 21:50:00 (UTC)
* 現象   : 2026-07-24 21:50:00 (UTC)を境に水準が 15から11.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.939, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 9→12→9→12→9→12→11
* 開始   : 2026-07-25 03:55:00 (UTC)
* 終了   : 2026-07-25 04:05:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.464σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260725-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260725-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260725-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260725-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260725-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host11-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 10→11→9→9→8→10→7→9→9
* 開始   : 2026-07-26 00:20:00 (UTC)
* 終了   : 2026-07-26 01:05:00 (UTC)
* 現象   : 2026-07-26 01:05:00 (UTC)を境に水準が 11.82から11.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 8→9→11→12→…→11→12→10→8
* 開始   : 2026-07-26 02:25:00 (UTC)
* 終了   : 2026-07-26 02:30:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260726-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 9→8→12→9→…→9→13→10→8
* 開始   : 2026-07-26 03:15:00 (UTC)
* 終了   : 2026-07-26 03:25:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260726-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260726-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host11-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→12→12→12→14→11
* 開始   : 2026-07-26 05:20:00 (UTC)
* 終了   : 2026-07-26 06:35:00 (UTC)
* 現象   : 2026-07-26 06:35:00 (UTC)を境に水準が 12.09から12.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→11→13→14→12
* 開始   : 2026-07-26 18:15:00 (UTC)
* 終了   : 2026-07-26 18:35:00 (UTC)
* 現象   : 2026-07-26 18:35:00 (UTC)を境に水準が 12.01から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.81, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 10→10→10→8→11→8→12
* 開始   : 2026-07-27 01:50:00 (UTC)
* 終了   : 2026-07-27 02:20:00 (UTC)
* 現象   : 2026-07-27 02:20:00 (UTC)を境に水準が 11.86から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.819, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 9→10→9→10→10→9→9
* 開始   : 2026-07-27 22:15:00 (UTC)
* 終了   : 2026-07-27 22:45:00 (UTC)
* 現象   : 2026-07-27 22:45:00 (UTC)を境に水準が 15.1から14.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.534, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→8→9→10→8→9→10→10→8
* 開始   : 2026-07-28 00:20:00 (UTC)
* 終了   : 2026-07-28 01:40:00 (UTC)
* 現象   : 2026-07-28 01:40:00 (UTC)を境に水準が 14.89から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.541, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→11→13→12→11→13→12→11
* 開始   : 2026-07-28 04:00:00 (UTC)
* 終了   : 2026-07-28 04:05:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260728-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→15→15→16→17
* 開始   : 2026-07-28 04:35:00 (UTC)
* 終了   : 2026-07-28 05:45:00 (UTC)
* 現象   : 2026-07-28 05:45:00 (UTC)を境に水準が 15.06から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.001, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→12→16→15→…→15→17→16→12
* 開始   : 2026-07-28 04:45:00 (UTC)
* 終了   : 2026-07-28 05:40:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260728-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 25 分
  - EVT-20260728-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260728-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→17→19→18→19→18→19→17→16
* 開始   : 2026-07-28 06:55:00 (UTC)
* 終了   : 2026-07-28 07:05:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.239倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260728-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 21→22→24→22→…→22→25→22→21
* 開始   : 2026-07-28 11:05:00 (UTC)
* 終了   : 2026-07-28 11:15:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 18→19→23→17→…→17→16→20→21
* 開始   : 2026-07-28 16:00:00 (UTC)
* 終了   : 2026-07-28 16:10:00 (UTC)
* 現象   : 平常時(19.17)に対し 1.2倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.689σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-049 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260728-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 12→13→9→8→…→9→8→10→11
* 開始   : 2026-07-28 20:05:00 (UTC)
* 終了   : 2026-07-28 20:15:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260728-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→15→16→12→15→16→12→14
* 開始   : 2026-07-29 05:00:00 (UTC)
* 終了   : 2026-07-29 05:05:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260729-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 19→22→23→19→…→19→23→21→20
* 開始   : 2026-07-29 09:10:00 (UTC)
* 終了   : 2026-07-29 09:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260729-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260729-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 20→19→16→19→16→17
* 開始   : 2026-07-29 16:20:00 (UTC)
* 終了   : 2026-07-29 16:25:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→12→11→10→11→10→12→11
* 開始   : 2026-07-29 19:25:00 (UTC)
* 終了   : 2026-07-29 19:35:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260729-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260729-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→14→9→10→9→10→9→12→10
* 開始   : 2026-07-29 19:45:00 (UTC)
* 終了   : 2026-07-29 19:55:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.7013(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260729-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260729-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260729-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 21→22→24→18→…→24→18→23→22
* 開始   : 2026-07-30 10:45:00 (UTC)
* 終了   : 2026-07-30 10:50:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 24→21→23→23
* 開始   : 2026-07-30 13:50:00 (UTC)
* 終了   : 2026-07-30 14:10:00 (UTC)
* 現象   : 2026-07-30 14:10:00 (UTC)を境に水準が 14.91から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.108, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 21→20→17→16→17→16→18→19
* 開始   : 2026-07-30 15:50:00 (UTC)
* 終了   : 2026-07-30 16:00:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-062 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260730-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 21→18→16→15→19→18→16→15→19
* 開始   : 2026-07-30 16:35:00 (UTC)
* 終了   : 2026-07-30 16:40:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.457σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260730-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 16→19→17→18→17→17→17→14→15
* 開始   : 2026-07-30 17:10:00 (UTC)
* 終了   : 2026-07-30 18:00:00 (UTC)
* 現象   : 2026-07-30 18:00:00 (UTC)を境に水準が 14.95から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.981, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→17→14→13→…→13→14→13→14
* 開始   : 2026-07-30 17:50:00 (UTC)
* 終了   : 2026-07-30 18:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260730-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260730-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→14→11→14→…→11→13→11→13
* 開始   : 2026-07-30 18:45:00 (UTC)
* 終了   : 2026-07-30 19:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.815σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260730-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-078 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-080 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260730-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260730-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260730-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 12→11→9→12→…→12→8→11→12
* 開始   : 2026-07-30 19:55:00 (UTC)
* 終了   : 2026-07-30 20:05:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 11→10→8→10→…→10→7→11→10
* 開始   : 2026-07-30 21:05:00 (UTC)
* 終了   : 2026-07-30 21:15:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-083 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-085 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260730-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→15→17→16→15→17→16→15→16
* 開始   : 2026-07-31 05:20:00 (UTC)
* 終了   : 2026-07-31 05:25:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.325倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.915σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260731-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 16→19→15→20→19→15→20→16→17
* 開始   : 2026-07-31 06:55:00 (UTC)
* 終了   : 2026-07-31 07:05:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260731-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260731-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 20→23→17→21→20→23→17→21→18
* 開始   : 2026-07-31 15:10:00 (UTC)
* 終了   : 2026-07-31 15:15:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host11-007 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
