# host07 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host07 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 305 (SEVERE: 21, FATAL: 124, WARN: 160, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 21 | 124 | 160 | 305 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260803-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→14→15→13→…→14→13→14→13
* 開始   : 2026-08-03 02:15:00 (UTC)
* 終了   : 2026-08-03 20:20:00 (UTC)
* 現象   : 2026-08-03 20:20:00 (UTC)を境に水準が 11.85から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.371, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host07-002 active_connections の推移](charts/EVT-20260803-host07-002.svg)

# イベントID( EVT-20260803-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→16→17→14→…→15→14→15→14
* 開始   : 2026-08-03 03:20:00 (UTC)
* 終了   : 2026-08-03 19:45:00 (UTC)
* 現象   : 2026-08-03 19:45:00 (UTC)を境に水準が 11.89から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.49σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.472, 限界=2.701)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.468, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host07-004 active_connections の推移](charts/EVT-20260803-host07-004.svg)

# イベントID( EVT-20260803-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→17→16→17→…→15→13→12→13
* 開始   : 2026-08-03 03:25:00 (UTC)
* 終了   : 2026-08-03 18:50:00 (UTC)
* 現象   : 2026-08-03 18:50:00 (UTC)を境に水準が 11.84から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.058, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.213, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host07-005 active_connections の推移](charts/EVT-20260803-host07-005.svg)

# イベントID( EVT-20260803-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→17→…→12→13→14→12
* 開始   : 2026-08-03 03:35:00 (UTC)
* 終了   : 2026-08-03 21:25:00 (UTC)
* 現象   : 2026-08-03 21:25:00 (UTC)を境に水準が 11.87から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.012, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.248, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host07-006 active_connections の推移](charts/EVT-20260803-host07-006.svg)

# イベントID( EVT-20260803-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→13→14→13→…→14→15→16→10
* 開始   : 2026-08-03 03:40:00 (UTC)
* 終了   : 2026-08-03 20:20:00 (UTC)
* 現象   : 2026-08-03 20:20:00 (UTC)を境に水準が 11.93から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.718, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.539, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host07-007 active_connections の推移](charts/EVT-20260803-host07-007.svg)

# イベントID( EVT-20260810-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 17→14→17→14→…→13→14→10→14
* 開始   : 2026-08-10 01:30:00 (UTC)
* 終了   : 2026-08-10 20:00:00 (UTC)
* 現象   : 2026-08-10 20:00:00 (UTC)を境に水準が 11.79から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.2σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.162, 限界=2.701)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.561, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host07-001 active_connections の推移](charts/EVT-20260810-host07-001.svg)

# イベントID( EVT-20260810-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→14→18→17→…→15→16→12→13
* 開始   : 2026-08-10 01:55:00 (UTC)
* 終了   : 2026-08-10 19:20:00 (UTC)
* 現象   : 2026-08-10 19:20:00 (UTC)を境に水準が 11.86から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.704, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host07-002 active_connections の推移](charts/EVT-20260810-host07-002.svg)

# イベントID( EVT-20260810-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→16→17→16→…→15→13→14→12
* 開始   : 2026-08-10 02:10:00 (UTC)
* 終了   : 2026-08-10 22:10:00 (UTC)
* 現象   : 2026-08-10 22:10:00 (UTC)を境に水準が 11.83から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.218σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.119, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.592, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host07-003 active_connections の推移](charts/EVT-20260810-host07-003.svg)

# イベントID( EVT-20260810-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→14→15→14→…→14→16→14→13
* 開始   : 2026-08-10 02:35:00 (UTC)
* 終了   : 2026-08-10 22:00:00 (UTC)
* 現象   : 2026-08-10 22:00:00 (UTC)を境に水準が 11.94から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.794, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.16, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host07-004 active_connections の推移](charts/EVT-20260810-host07-004.svg)

# イベントID( EVT-20260810-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 12→13→16→12→…→12→14→11→12
* 開始   : 2026-08-10 03:05:00 (UTC)
* 終了   : 2026-08-10 19:30:00 (UTC)
* 現象   : 2026-08-10 19:30:00 (UTC)を境に水準が 11.7から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.941, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.674, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host07-005 active_connections の推移](charts/EVT-20260810-host07-005.svg)

# イベントID( EVT-20260810-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 16→15→16→15→…→11→15→12→11
* 開始   : 2026-08-10 04:25:00 (UTC)
* 終了   : 2026-08-10 20:25:00 (UTC)
* 現象   : 2026-08-10 20:25:00 (UTC)を境に水準が 11.73から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.138σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.931, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host07-006 active_connections の推移](charts/EVT-20260810-host07-006.svg)

# イベントID( EVT-20260817-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→18→14→16→…→16→14→12→15
* 開始   : 2026-08-17 02:35:00 (UTC)
* 終了   : 2026-08-17 20:00:00 (UTC)
* 現象   : 2026-08-17 20:00:00 (UTC)を境に水準が 11.85から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.068, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.705, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host07-002 active_connections の推移](charts/EVT-20260817-host07-002.svg)

# イベントID( EVT-20260817-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→15→16→17→…→17→15→14→13
* 開始   : 2026-08-17 02:45:00 (UTC)
* 終了   : 2026-08-17 21:35:00 (UTC)
* 現象   : 2026-08-17 21:35:00 (UTC)を境に水準が 11.74から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.173, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.559, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host07-003 active_connections の推移](charts/EVT-20260817-host07-003.svg)

# イベントID( EVT-20260817-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 16→15→14→15→…→13→12→13→12
* 開始   : 2026-08-17 03:15:00 (UTC)
* 終了   : 2026-08-17 20:45:00 (UTC)
* 現象   : 2026-08-17 20:45:00 (UTC)を境に水準が 11.9から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.962, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host07-005 active_connections の推移](charts/EVT-20260817-host07-005.svg)

# イベントID( EVT-20260817-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 15→16→17→15→…→11→14→13→11
* 開始   : 2026-08-17 03:35:00 (UTC)
* 終了   : 2026-08-17 20:15:00 (UTC)
* 現象   : 2026-08-17 20:15:00 (UTC)を境に水準が 11.8から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.857, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.091, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host07-006 active_connections の推移](charts/EVT-20260817-host07-006.svg)

# イベントID( EVT-20260817-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→16→17→16→…→12→15→13→14
* 開始   : 2026-08-17 04:00:00 (UTC)
* 終了   : 2026-08-17 20:30:00 (UTC)
* 現象   : 2026-08-17 20:30:00 (UTC)を境に水準が 11.89から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.432σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.852, 限界=2.701)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.78, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host07-007 active_connections の推移](charts/EVT-20260817-host07-007.svg)

# イベントID( EVT-20260824-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→15→…→16→14→10→13
* 開始   : 2026-08-24 01:55:00 (UTC)
* 終了   : 2026-08-24 19:45:00 (UTC)
* 現象   : 2026-08-24 19:45:00 (UTC)を境に水準が 11.95から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.618σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.649, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.658, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host07-001 active_connections の推移](charts/EVT-20260824-host07-001.svg)

# イベントID( EVT-20260824-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 15→16→17→14→…→12→13→12→13
* 開始   : 2026-08-24 02:50:00 (UTC)
* 終了   : 2026-08-24 20:50:00 (UTC)
* 現象   : 2026-08-24 20:50:00 (UTC)を境に水準が 11.99から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.949, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host07-002 active_connections の推移](charts/EVT-20260824-host07-002.svg)

# イベントID( EVT-20260824-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→12→16→15→…→14→12→11→12
* 開始   : 2026-08-24 03:10:00 (UTC)
* 終了   : 2026-08-24 19:45:00 (UTC)
* 現象   : 2026-08-24 19:45:00 (UTC)を境に水準が 11.88から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.718, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.079, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host07-003 active_connections の推移](charts/EVT-20260824-host07-003.svg)

# イベントID( EVT-20260824-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 16→17→18→16→…→12→15→11→12
* 開始   : 2026-08-24 03:20:00 (UTC)
* 終了   : 2026-08-24 19:25:00 (UTC)
* 現象   : 2026-08-24 19:25:00 (UTC)を境に水準が 11.96から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.277σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.891, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.592, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host07-004 active_connections の推移](charts/EVT-20260824-host07-004.svg)

# イベントID( EVT-20260824-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→18→17→13→…→14→13→14→13
* 開始   : 2026-08-24 03:35:00 (UTC)
* 終了   : 2026-08-24 21:35:00 (UTC)
* 現象   : 2026-08-24 21:35:00 (UTC)を境に水準が 11.83から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.991, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host07-005 active_connections の推移](charts/EVT-20260824-host07-005.svg)

# イベントID( EVT-20260801-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→12→14→13→…→14→13→15→13
* 開始   : 2026-08-01 05:00:00 (UTC)
* 終了   : 2026-08-01 19:25:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.284, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260801-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260801-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 14.4 時間

![EVT-20260801-host07-001 active_connections の推移](charts/EVT-20260801-host07-001.svg)

# イベントID( EVT-20260801-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→13→11→13→…→12→14→11→13
* 開始   : 2026-08-01 05:00:00 (UTC)
* 終了   : 2026-08-01 19:05:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.887, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260801-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260801-host07-002 active_connections の推移](charts/EVT-20260801-host07-002.svg)

# イベントID( EVT-20260801-host07-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→11→13→12→…→10→13→12→11
* 開始   : 2026-08-01 05:55:00 (UTC)
* 終了   : 2026-08-01 18:35:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.204, 限界=2.701)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260801-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260801-host07-003 active_connections の推移](charts/EVT-20260801-host07-003.svg)

# イベントID( EVT-20260801-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→12→10→11→…→11→12→13→10
* 開始   : 2026-08-01 06:05:00 (UTC)
* 終了   : 2026-08-01 18:45:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.367σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.086, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260801-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260801-host07-004 active_connections の推移](charts/EVT-20260801-host07-004.svg)

# イベントID( EVT-20260801-host07-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→12→11→12→…→13→9→12→13
* 開始   : 2026-08-01 06:30:00 (UTC)
* 終了   : 2026-08-01 18:50:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.04, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260801-host07-005 active_connections の推移](charts/EVT-20260801-host07-005.svg)

# イベントID( EVT-20260801-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→13→12→11→…→11→10→11→12
* 開始   : 2026-08-01 06:30:00 (UTC)
* 終了   : 2026-08-01 20:05:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.92, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260801-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260801-host07-006 active_connections の推移](charts/EVT-20260801-host07-006.svg)

# イベントID( EVT-20260801-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→8→5→8→10
* 開始   : 2026-08-01 21:50:00 (UTC)
* 終了   : 2026-08-01 21:50:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.5128(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260801-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→12→17→13→15
* 開始   : 2026-08-02 08:00:00 (UTC)
* 終了   : 2026-08-02 08:00:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260802-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host07-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→13→17→15→…→13→15→13→14
* 開始   : 2026-08-03 02:45:00 (UTC)
* 終了   : 2026-08-03 18:45:00 (UTC)
* 現象   : 2026-08-03 18:45:00 (UTC)を境に水準が 11.87から14.9へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.209, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.837, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 7→8→12→10→7
* 開始   : 2026-08-04 01:55:00 (UTC)
* 終了   : 2026-08-04 01:55:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→13→16→13→12
* 開始   : 2026-08-04 04:30:00 (UTC)
* 終了   : 2026-08-04 04:30:00 (UTC)
* 現象   : 平常時(11)に対し 1.455倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.511σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host07-004 active_connections の推移](charts/EVT-20260804-host07-004.svg)

# イベントID( EVT-20260804-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 17→19→23→18→18
* 開始   : 2026-08-04 08:15:00 (UTC)
* 終了   : 2026-08-04 08:15:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.302倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.73σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host07-008 active_connections の推移](charts/EVT-20260804-host07-008.svg)

# イベントID( EVT-20260804-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 20→21→24→20→20
* 開始   : 2026-08-04 09:35:00 (UTC)
* 終了   : 2026-08-04 09:35:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.22倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 22→20→25→23→21
* 開始   : 2026-08-04 10:55:00 (UTC)
* 終了   : 2026-08-04 10:55:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 18→19→14→20→17
* 開始   : 2026-08-04 16:35:00 (UTC)
* 終了   : 2026-08-04 16:35:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→13→10→14→15
* 開始   : 2026-08-04 19:05:00 (UTC)
* 終了   : 2026-08-04 19:05:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260804-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260804-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→13→9→11→12
* 開始   : 2026-08-04 19:25:00 (UTC)
* 終了   : 2026-08-04 19:25:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host04-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 8→9→13→6→6
* 開始   : 2026-08-05 01:05:00 (UTC)
* 終了   : 2026-08-05 01:05:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.608倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.416σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260805-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 19→21→24→19→20
* 開始   : 2026-08-05 09:00:00 (UTC)
* 終了   : 2026-08-05 09:00:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.291倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.773σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host07-005 active_connections の推移](charts/EVT-20260805-host07-005.svg)

# イベントID( EVT-20260805-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 21→22→25→20→21
* 開始   : 2026-08-05 10:00:00 (UTC)
* 終了   : 2026-08-05 10:00:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.245倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.432σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host07-006 active_connections の推移](charts/EVT-20260805-host07-006.svg)

# イベントID( EVT-20260805-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 18→21→16→18→18
* 開始   : 2026-08-05 15:05:00 (UTC)
* 終了   : 2026-08-05 15:05:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.7742(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260805-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 20→16→12→15→14
* 開始   : 2026-08-05 17:20:00 (UTC)
* 終了   : 2026-08-05 17:20:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.6923(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.706σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host07-010 active_connections の推移](charts/EVT-20260805-host07-010.svg)

# イベントID( EVT-20260805-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→16→10→14→14
* 開始   : 2026-08-05 19:05:00 (UTC)
* 終了   : 2026-08-05 19:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 6→8→12→7→9
* 開始   : 2026-08-06 01:05:00 (UTC)
* 終了   : 2026-08-06 01:05:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260806-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→17→21→17→17
* 開始   : 2026-08-06 07:10:00 (UTC)
* 終了   : 2026-08-06 07:10:00 (UTC)
* 現象   : 平常時(16)に対し 1.312倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.511σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host07-003 active_connections の推移](charts/EVT-20260806-host07-003.svg)

# イベントID( EVT-20260806-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→18→12→16→14
* 開始   : 2026-08-06 17:30:00 (UTC)
* 終了   : 2026-08-06 17:30:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.689(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.764σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260806-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→10→9→10→13→10→9→10→11
* 開始   : 2026-08-06 19:55:00 (UTC)
* 終了   : 2026-08-06 20:20:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260806-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260806-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260806-host01-015 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260806-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260806-host07-011 active_connections の推移](charts/EVT-20260806-host07-011.svg)

# イベントID( EVT-20260806-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→9→6→9→10
* 開始   : 2026-08-06 20:55:00 (UTC)
* 終了   : 2026-08-06 20:55:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.011σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host07-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host02-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 9→9→13→8→9
* 開始   : 2026-08-07 02:20:00 (UTC)
* 終了   : 2026-08-07 02:20:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-007 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260807-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 16→16→20→15→17
* 開始   : 2026-08-07 06:25:00 (UTC)
* 終了   : 2026-08-07 06:25:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.341倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.532σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260807-host07-005 active_connections の推移](charts/EVT-20260807-host07-005.svg)

# イベントID( EVT-20260808-host07-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→12→11→10→…→12→9→13→11
* 開始   : 2026-08-08 04:45:00 (UTC)
* 終了   : 2026-08-08 19:25:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.168, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260808-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260808-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間

![EVT-20260808-host07-001 active_connections の推移](charts/EVT-20260808-host07-001.svg)

# イベントID( EVT-20260808-host07-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→14→10→13→…→12→11→12→10
* 開始   : 2026-08-08 05:15:00 (UTC)
* 終了   : 2026-08-08 19:00:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.869, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260808-host07-002 active_connections の推移](charts/EVT-20260808-host07-002.svg)

# イベントID( EVT-20260808-host07-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→10→…→11→9→13→11
* 開始   : 2026-08-08 05:25:00 (UTC)
* 終了   : 2026-08-08 19:10:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.814, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260808-host07-003 active_connections の推移](charts/EVT-20260808-host07-003.svg)

# イベントID( EVT-20260808-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→11→12→14→…→9→12→10→12
* 開始   : 2026-08-08 05:50:00 (UTC)
* 終了   : 2026-08-08 19:40:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.757, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260808-host07-004 active_connections の推移](charts/EVT-20260808-host07-004.svg)

# イベントID( EVT-20260808-host07-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→12→11→12→…→10→9→12→11
* 開始   : 2026-08-08 05:55:00 (UTC)
* 終了   : 2026-08-08 20:00:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.774, 限界=2.701)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.1 時間
  - EVT-20260808-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.1 時間
  - EVT-20260808-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260808-host07-005 active_connections の推移](charts/EVT-20260808-host07-005.svg)

# イベントID( EVT-20260808-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→13→11→12→…→13→11→13→12
* 開始   : 2026-08-08 05:55:00 (UTC)
* 終了   : 2026-08-08 19:10:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.961, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260808-host07-006 active_connections の推移](charts/EVT-20260808-host07-006.svg)

# イベントID( EVT-20260809-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 17→15→20→17→18
* 開始   : 2026-08-09 12:00:00 (UTC)
* 終了   : 2026-08-09 12:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260809-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260809-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 8→8→4→8→8
* 開始   : 2026-08-10 22:35:00 (UTC)
* 終了   : 2026-08-10 22:35:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.4486(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260810-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 18→20→23→18→18
* 開始   : 2026-08-11 08:45:00 (UTC)
* 終了   : 2026-08-11 08:45:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260811-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→12→14→12→15
* 開始   : 2026-08-11 17:35:00 (UTC)
* 終了   : 2026-08-11 18:40:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7129(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260811-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260811-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260811-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260811-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→13→8→13→15
* 開始   : 2026-08-11 19:00:00 (UTC)
* 終了   : 2026-08-11 19:00:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.5963(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.789σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host07-009 active_connections の推移](charts/EVT-20260811-host07-009.svg)

# イベントID( EVT-20260811-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→13→9→15→11
* 開始   : 2026-08-11 19:10:00 (UTC)
* 終了   : 2026-08-11 19:10:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→12→8→10→12
* 開始   : 2026-08-11 20:15:00 (UTC)
* 終了   : 2026-08-11 20:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分

![EVT-20260811-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 8→9→5→8→10
* 開始   : 2026-08-11 22:20:00 (UTC)
* 終了   : 2026-08-11 22:20:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host10-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→7→4→7→11
* 開始   : 2026-08-12 00:35:00 (UTC)
* 終了   : 2026-08-12 00:35:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260812-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→10→12→9→…→9→5→11→10
* 開始   : 2026-08-12 02:35:00 (UTC)
* 終了   : 2026-08-12 02:45:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-007 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260812-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→13→15→11→11
* 開始   : 2026-08-12 03:45:00 (UTC)
* 終了   : 2026-08-12 03:45:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→10→16→14→16→14→16→15
* 開始   : 2026-08-12 05:00:00 (UTC)
* 終了   : 2026-08-12 05:10:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 18→20→24→22→22
* 開始   : 2026-08-12 10:00:00 (UTC)
* 終了   : 2026-08-12 10:00:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260812-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 18→18→14→19→19
* 開始   : 2026-08-12 16:05:00 (UTC)
* 終了   : 2026-08-12 16:05:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.7149(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.898σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host07-010 active_connections の推移](charts/EVT-20260812-host07-010.svg)

# イベントID( EVT-20260812-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 20→18→14→20→18
* 開始   : 2026-08-12 16:15:00 (UTC)
* 終了   : 2026-08-12 16:15:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.7336(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.541σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260812-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260812-host07-011 active_connections の推移](charts/EVT-20260812-host07-011.svg)

# イベントID( EVT-20260813-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→15→11→13
* 開始   : 2026-08-13 03:20:00 (UTC)
* 終了   : 2026-08-13 04:10:00 (UTC)
* 現象   : 2026-08-13 04:10:00 (UTC)を境に水準が 14.88から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.768, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→13→17→15→14
* 開始   : 2026-08-13 05:10:00 (UTC)
* 終了   : 2026-08-13 05:10:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→11→8→9→…→6→7→8→10
* 開始   : 2026-08-13 20:55:00 (UTC)
* 終了   : 2026-08-13 21:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.618σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host09-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260813-host04-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host07-009 active_connections の推移](charts/EVT-20260813-host07-009.svg)

# イベントID( EVT-20260813-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 7→9→4→8→7
* 開始   : 2026-08-13 23:50:00 (UTC)
* 終了   : 2026-08-13 23:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260813-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→9→10→9→8→10
* 開始   : 2026-08-14 01:15:00 (UTC)
* 終了   : 2026-08-14 01:50:00 (UTC)
* 現象   : 2026-08-14 01:50:00 (UTC)を境に水準が 14.97から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.248, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→13→16→14→14
* 開始   : 2026-08-14 04:35:00 (UTC)
* 終了   : 2026-08-14 04:35:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.444倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host07-002 active_connections の推移](charts/EVT-20260814-host07-002.svg)

# イベントID( EVT-20260814-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→13→18→14→14
* 開始   : 2026-08-14 05:45:00 (UTC)
* 終了   : 2026-08-14 05:45:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.403倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.607σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host07-003 active_connections の推移](charts/EVT-20260814-host07-003.svg)

# イベントID( EVT-20260814-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→18→15→18→15→18→15→17
* 開始   : 2026-08-14 06:30:00 (UTC)
* 終了   : 2026-08-14 07:30:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.256倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 30 分
  - EVT-20260814-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260814-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260814-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 19→23→17→21→…→21→24→19→21
* 開始   : 2026-08-14 14:25:00 (UTC)
* 終了   : 2026-08-14 14:35:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260814-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→13→10→13→12
* 開始   : 2026-08-14 18:40:00 (UTC)
* 終了   : 2026-08-14 18:40:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6857(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→14→10→14→14
* 開始   : 2026-08-14 18:45:00 (UTC)
* 終了   : 2026-08-14 18:45:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260814-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→11→10→8→…→10→8→14→13
* 開始   : 2026-08-14 19:50:00 (UTC)
* 終了   : 2026-08-14 19:55:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260814-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260814-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→11→9→7→11→9→7→11→9
* 開始   : 2026-08-14 20:25:00 (UTC)
* 終了   : 2026-08-14 20:30:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host07-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260814-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host16-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260814-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-075 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→11→13→14→…→11→12→13→10
* 開始   : 2026-08-15 04:20:00 (UTC)
* 終了   : 2026-08-15 18:35:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.016, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host07-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.2 時間

![EVT-20260815-host07-002 active_connections の推移](charts/EVT-20260815-host07-002.svg)

# イベントID( EVT-20260815-host07-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→11→10→12→…→10→12→10→11
* 開始   : 2026-08-15 05:20:00 (UTC)
* 終了   : 2026-08-15 19:30:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.803, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260815-host07-003 active_connections の推移](charts/EVT-20260815-host07-003.svg)

# イベントID( EVT-20260815-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→12→13→12→…→11→12→15→14
* 開始   : 2026-08-15 05:20:00 (UTC)
* 終了   : 2026-08-15 19:55:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.823, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260815-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260815-host07-004 active_connections の推移](charts/EVT-20260815-host07-004.svg)

# イベントID( EVT-20260815-host07-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→10→9→12→…→11→10→11→12
* 開始   : 2026-08-15 05:35:00 (UTC)
* 終了   : 2026-08-15 18:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.131, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260815-host07-005 active_connections の推移](charts/EVT-20260815-host07-005.svg)

# イベントID( EVT-20260815-host07-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→13→11→13→…→12→11→14→11
* 開始   : 2026-08-15 06:15:00 (UTC)
* 終了   : 2026-08-15 19:35:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.742, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260815-host07-006 active_connections の推移](charts/EVT-20260815-host07-006.svg)

# イベントID( EVT-20260815-host07-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 13→10→11→12→…→12→11→13→11
* 開始   : 2026-08-15 06:25:00 (UTC)
* 終了   : 2026-08-15 19:20:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.007, 限界=2.701)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260815-host07-007 active_connections の推移](charts/EVT-20260815-host07-007.svg)

# イベントID( EVT-20260817-host07-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→16→13→12→…→14→15→10→14
* 開始   : 2026-08-17 02:45:00 (UTC)
* 終了   : 2026-08-17 20:25:00 (UTC)
* 現象   : 2026-08-17 20:25:00 (UTC)を境に水準が 11.87から15.03へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.905, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.84, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 9→8→4→7→7
* 開始   : 2026-08-18 00:15:00 (UTC)
* 終了   : 2026-08-18 00:15:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260817-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-001 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260818-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 17→17→21→18→18
* 開始   : 2026-08-18 07:35:00 (UTC)
* 終了   : 2026-08-18 07:35:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 19→17→21→20→19→17→21→20→19
* 開始   : 2026-08-18 07:50:00 (UTC)
* 終了   : 2026-08-18 07:55:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260818-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host02-006 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260818-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 20→20→25→22→20
* 開始   : 2026-08-18 09:50:00 (UTC)
* 終了   : 2026-08-18 09:50:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.23倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260818-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 21→20→15→19→17
* 開始   : 2026-08-18 15:25:00 (UTC)
* 終了   : 2026-08-18 15:25:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7347(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.764σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host07-011 active_connections の推移](charts/EVT-20260818-host07-011.svg)

# イベントID( EVT-20260818-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 18→15→12→15→17
* 開始   : 2026-08-18 18:00:00 (UTC)
* 終了   : 2026-08-18 18:00:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→17→11→13→15
* 開始   : 2026-08-18 18:40:00 (UTC)
* 終了   : 2026-08-18 18:40:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host07-015 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→12→11→13→11→12→9→12→10
* 開始   : 2026-08-18 20:40:00 (UTC)
* 終了   : 2026-08-18 22:00:00 (UTC)
* 現象   : 2026-08-18 22:00:00 (UTC)を境に水準が 14.78から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.274, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→16→19→16→19→16→19→18
* 開始   : 2026-08-19 06:55:00 (UTC)
* 終了   : 2026-08-19 07:05:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260819-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→13→10→11→…→11→8→12→10
* 開始   : 2026-08-19 18:50:00 (UTC)
* 終了   : 2026-08-19 19:45:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host07-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host07-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 45 分
  - EVT-20260819-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260819-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260819-host07-013 active_connections の推移](charts/EVT-20260819-host07-013.svg)

# イベントID( EVT-20260819-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→13→10→14→13
* 開始   : 2026-08-19 19:10:00 (UTC)
* 終了   : 2026-08-19 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host07-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 7→8→13→10→8
* 開始   : 2026-08-20 00:50:00 (UTC)
* 終了   : 2026-08-20 00:50:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→14→16→13→12
* 開始   : 2026-08-20 04:40:00 (UTC)
* 終了   : 2026-08-20 04:40:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260820-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→16→19→15→14
* 開始   : 2026-08-20 06:00:00 (UTC)
* 終了   : 2026-08-20 06:00:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.365倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.569σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260820-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host07-003 active_connections の推移](charts/EVT-20260820-host07-003.svg)

# イベントID( EVT-20260820-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→19→23→18→20
* 開始   : 2026-08-20 08:30:00 (UTC)
* 終了   : 2026-08-20 08:30:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.29倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.599σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host07-008 active_connections の推移](charts/EVT-20260820-host07-008.svg)

# イベントID( EVT-20260820-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 19→19→24→20→22
* 開始   : 2026-08-20 09:20:00 (UTC)
* 終了   : 2026-08-20 09:20:00 (UTC)
* 現象   : 平常時(19.17)に対し 1.252倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→16→12→15→16
* 開始   : 2026-08-20 17:30:00 (UTC)
* 終了   : 2026-08-20 17:30:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 13→14→9→14→14
* 開始   : 2026-08-20 19:00:00 (UTC)
* 終了   : 2026-08-20 19:00:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6171(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.879σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host07-016 active_connections の推移](charts/EVT-20260820-host07-016.svg)

# イベントID( EVT-20260821-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→9→14→8→12
* 開始   : 2026-08-21 02:50:00 (UTC)
* 終了   : 2026-08-21 02:50:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-008 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260821-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 17→14→20→16→16
* 開始   : 2026-08-21 06:35:00 (UTC)
* 終了   : 2026-08-21 06:35:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.356倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.672σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260821-host07-005 active_connections の推移](charts/EVT-20260821-host07-005.svg)

# イベントID( EVT-20260821-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 20→19→16→19→16→19→20
* 開始   : 2026-08-21 16:05:00 (UTC)
* 終了   : 2026-08-21 17:00:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260821-host07-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-lsfhost01-049 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260821-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260821-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→18→16→18→…→18→14→18→17
* 開始   : 2026-08-21 16:05:00 (UTC)
* 終了   : 2026-08-21 16:35:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260821-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 18→17→14→15→17→14→15→17→16
* 開始   : 2026-08-21 16:40:00 (UTC)
* 終了   : 2026-08-21 16:45:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-049 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→10→6→12→9
* 開始   : 2026-08-21 21:10:00 (UTC)
* 終了   : 2026-08-21 21:10:00 (UTC)
* 現象   : 平常時(11)に対し 0.5455(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.483σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host07-014 active_connections の推移](charts/EVT-20260821-host07-014.svg)

# イベントID( EVT-20260821-host07-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→11→4→10→7
* 開始   : 2026-08-21 23:25:00 (UTC)
* 終了   : 2026-08-21 23:25:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.4364(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.607σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host07-016 active_connections の推移](charts/EVT-20260821-host07-016.svg)

# イベントID( EVT-20260822-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→14→11→13→…→15→12→13→12
* 開始   : 2026-08-22 04:50:00 (UTC)
* 終了   : 2026-08-22 19:10:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.014, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host07-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260822-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260822-host07-001 active_connections の推移](charts/EVT-20260822-host07-001.svg)

# イベントID( EVT-20260822-host07-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→10→11→12→…→13→12→13→11
* 開始   : 2026-08-22 05:05:00 (UTC)
* 終了   : 2026-08-22 18:45:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.829, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260822-host07-002 active_connections の推移](charts/EVT-20260822-host07-002.svg)

# イベントID( EVT-20260822-host07-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→9→8→13→…→15→13→14→15
* 開始   : 2026-08-22 05:20:00 (UTC)
* 終了   : 2026-08-22 19:05:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.013, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host07-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260822-host07-003 active_connections の推移](charts/EVT-20260822-host07-003.svg)

# イベントID( EVT-20260822-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→14→11→14→…→12→13→14→12
* 開始   : 2026-08-22 05:40:00 (UTC)
* 終了   : 2026-08-22 19:15:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.957, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host07-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260822-host07-004 active_connections の推移](charts/EVT-20260822-host07-004.svg)

# イベントID( EVT-20260822-host07-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→9→11→12→…→12→11→12→11
* 開始   : 2026-08-22 06:00:00 (UTC)
* 終了   : 2026-08-22 19:10:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.05, 限界=2.701)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host07-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260822-host07-005 active_connections の推移](charts/EVT-20260822-host07-005.svg)

# イベントID( EVT-20260822-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→12→…→11→12→16→11
* 開始   : 2026-08-22 06:00:00 (UTC)
* 終了   : 2026-08-22 17:50:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.134, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間

![EVT-20260822-host07-006 active_connections の推移](charts/EVT-20260822-host07-006.svg)

# イベントID( EVT-20260823-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→12→9→12→10
* 開始   : 2026-08-23 17:35:00 (UTC)
* 終了   : 2026-08-23 17:35:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.011σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260823-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host07-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→14→15→14→…→16→14→13→12
* 開始   : 2026-08-24 03:45:00 (UTC)
* 終了   : 2026-08-24 19:15:00 (UTC)
* 現象   : 2026-08-24 19:15:00 (UTC)を境に水準が 12から14.91へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.948, 限界=2.701)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.62, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host07-006 active_connections の推移](charts/EVT-20260824-host07-006.svg)

# イベントID( EVT-20260825-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→13→18→16→16
* 開始   : 2026-08-25 05:55:00 (UTC)
* 終了   : 2026-08-25 05:55:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 20→20→15→18→18
* 開始   : 2026-08-25 15:55:00 (UTC)
* 終了   : 2026-08-25 15:55:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.766(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260825-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→17→12→15→…→11→10→14→15
* 開始   : 2026-08-25 18:45:00 (UTC)
* 終了   : 2026-08-25 19:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260825-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 15 分
  - EVT-20260825-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260825-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→11→6→3→8→11→6→3→8
* 開始   : 2026-08-26 00:40:00 (UTC)
* 終了   : 2026-08-26 00:45:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-004 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260826-host07-001 active_connections の推移](charts/EVT-20260826-host07-001.svg)

# イベントID( EVT-20260826-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→15→12→14→15→12→14→10→11
* 開始   : 2026-08-26 04:00:00 (UTC)
* 終了   : 2026-08-26 04:10:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.309σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260826-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→15→17→13→17→13→17→16→14
* 開始   : 2026-08-26 05:15:00 (UTC)
* 終了   : 2026-08-26 05:40:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.394倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.556σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260826-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260826-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260826-host07-005 active_connections の推移](charts/EVT-20260826-host07-005.svg)

# イベントID( EVT-20260826-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 20→22→19→17→20→22→19→17→20
* 開始   : 2026-08-26 14:45:00 (UTC)
* 終了   : 2026-08-26 14:50:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260826-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 21→21→20→21→19→18→18→18→18
* 開始   : 2026-08-26 15:10:00 (UTC)
* 終了   : 2026-08-26 16:45:00 (UTC)
* 現象   : 2026-08-26 16:45:00 (UTC)を境に水準が 14.96から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.706σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.249, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→16→11→12→16→11→12→13
* 開始   : 2026-08-26 18:35:00 (UTC)
* 終了   : 2026-08-26 18:40:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260826-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 19→17→21→20→17→21→20→17→18
* 開始   : 2026-08-27 07:50:00 (UTC)
* 終了   : 2026-08-27 07:55:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→15→10→13→12
* 開始   : 2026-08-27 18:50:00 (UTC)
* 終了   : 2026-08-27 18:50:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260827-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→14→8→7→…→8→7→11→12
* 開始   : 2026-08-27 20:05:00 (UTC)
* 終了   : 2026-08-27 20:10:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-076 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-075 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260827-host07-010 active_connections の推移](charts/EVT-20260827-host07-010.svg)

# イベントID( EVT-20260828-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→11→9→11→12
* 開始   : 2026-08-28 02:40:00 (UTC)
* 終了   : 2026-08-28 03:00:00 (UTC)
* 現象   : 2026-08-28 03:00:00 (UTC)を境に水準が 15から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.072σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host07-001 active_connections の推移](charts/EVT-20260828-host07-001.svg)

# イベントID( EVT-20260828-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→11→15→12→12
* 開始   : 2026-08-28 04:15:00 (UTC)
* 終了   : 2026-08-28 04:15:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→10→9→12→…→10→11→10→11
* 開始   : 2026-08-29 04:15:00 (UTC)
* 終了   : 2026-08-29 19:05:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.676σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.136, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260829-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.6 時間
  - EVT-20260829-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260829-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260829-host07-001 active_connections の推移](charts/EVT-20260829-host07-001.svg)

# イベントID( EVT-20260829-host07-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→13→11→12→…→10→11→12→10
* 開始   : 2026-08-29 05:00:00 (UTC)
* 終了   : 2026-08-29 19:00:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.897, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260829-host07-002 active_connections の推移](charts/EVT-20260829-host07-002.svg)

# イベントID( EVT-20260829-host07-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→9→10→11→…→7→11→8→10
* 開始   : 2026-08-29 05:05:00 (UTC)
* 終了   : 2026-08-29 19:40:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.861, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260829-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260829-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260829-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260829-host07-003 active_connections の推移](charts/EVT-20260829-host07-003.svg)

# イベントID( EVT-20260829-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→10→8→12→…→11→10→11→13
* 開始   : 2026-08-29 05:25:00 (UTC)
* 終了   : 2026-08-29 18:50:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.613σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.139, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260829-host07-004 active_connections の推移](charts/EVT-20260829-host07-004.svg)

# イベントID( EVT-20260829-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→14→13→11→…→11→13→12→13
* 開始   : 2026-08-29 05:55:00 (UTC)
* 終了   : 2026-08-29 18:30:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.904, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260829-host07-005 active_connections の推移](charts/EVT-20260829-host07-005.svg)

# イベントID( EVT-20260829-host07-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 13→11→12→13→…→12→10→12→9
* 開始   : 2026-08-29 06:05:00 (UTC)
* 終了   : 2026-08-29 19:15:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.239, 限界=2.701)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260829-host07-006 active_connections の推移](charts/EVT-20260829-host07-006.svg)

# イベントID( EVT-20260801-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→8→12→8→6→12→8→6→8
* 開始   : 2026-08-01 22:30:00 (UTC)
* 終了   : 2026-08-01 22:40:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260801-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 9→8→11→8→…→8→12→9→8
* 開始   : 2026-08-01 23:50:00 (UTC)
* 終了   : 2026-08-02 00:00:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260801-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→10→8→14→…→8→14→12→13
* 開始   : 2026-08-02 05:25:00 (UTC)
* 終了   : 2026-08-02 05:30:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260802-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260802-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260802-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→16→18→15→12→18→15→12→15
* 開始   : 2026-08-02 09:25:00 (UTC)
* 終了   : 2026-08-02 09:35:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260802-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 17→16→12→14→…→14→18→14→16
* 開始   : 2026-08-02 10:50:00 (UTC)
* 終了   : 2026-08-02 11:00:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260802-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260802-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host07-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→10→10→11→11→12→11
* 開始   : 2026-08-02 19:35:00 (UTC)
* 終了   : 2026-08-02 20:05:00 (UTC)
* 現象   : 2026-08-02 20:05:00 (UTC)を境に水準が 11.84から14.75へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.857, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 8→9→5→8→5→8→5→9
* 開始   : 2026-08-02 23:45:00 (UTC)
* 終了   : 2026-08-02 23:55:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260802-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→10→9→7→10→9→9→10→11
* 開始   : 2026-08-03 01:15:00 (UTC)
* 終了   : 2026-08-03 02:10:00 (UTC)
* 現象   : 2026-08-03 02:10:00 (UTC)を境に水準が 11.81から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→9→9→10→8→9→7→8→10
* 開始   : 2026-08-03 22:30:00 (UTC)
* 終了   : 2026-08-03 23:10:00 (UTC)
* 現象   : 2026-08-03 23:10:00 (UTC)を境に水準が 14.98から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.872, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host07-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→9→8→9→6→9→8→10
* 開始   : 2026-08-03 23:20:00 (UTC)
* 終了   : 2026-08-03 23:55:00 (UTC)
* 現象   : 2026-08-03 23:55:00 (UTC)を境に水準が 14.82から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.98, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→9→13→11→13→11→13→12→11
* 開始   : 2026-08-04 03:20:00 (UTC)
* 終了   : 2026-08-04 03:30:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260804-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host07-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→12→14→13→12→11
* 開始   : 2026-08-04 04:15:00 (UTC)
* 終了   : 2026-08-04 04:40:00 (UTC)
* 現象   : 2026-08-04 04:40:00 (UTC)を境に水準が 14.88から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.809, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→14→13→15→14→13→15→12
* 開始   : 2026-08-04 04:45:00 (UTC)
* 終了   : 2026-08-04 04:55:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260804-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→20→15→17→20→15→18
* 開始   : 2026-08-04 07:40:00 (UTC)
* 終了   : 2026-08-04 07:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host07-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260804-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 18→17→20→21→…→20→21→16→19
* 開始   : 2026-08-04 07:45:00 (UTC)
* 終了   : 2026-08-04 07:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host07-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host07-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 20→21→21→21→21→20→19→18→20
* 開始   : 2026-08-04 14:55:00 (UTC)
* 終了   : 2026-08-04 15:35:00 (UTC)
* 現象   : 2026-08-04 15:35:00 (UTC)を境に水準が 15.07から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.703, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host07-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→10→9→10→…→10→8→9→10
* 開始   : 2026-08-04 20:25:00 (UTC)
* 終了   : 2026-08-04 20:35:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260804-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host07-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→8→10→11→8→10→8
* 開始   : 2026-08-04 21:00:00 (UTC)
* 終了   : 2026-08-04 21:05:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260804-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host07-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→11→14→15→…→14→15→13→10
* 開始   : 2026-08-05 03:50:00 (UTC)
* 終了   : 2026-08-05 03:55:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260805-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→13→16→13→16→13→15
* 開始   : 2026-08-05 05:20:00 (UTC)
* 終了   : 2026-08-05 05:25:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→15→17→14→17→14→17→15
* 開始   : 2026-08-05 06:00:00 (UTC)
* 終了   : 2026-08-05 06:35:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260805-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260805-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260805-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260805-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260805-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→20→20→20→20→20→18→18→22
* 開始   : 2026-08-05 15:40:00 (UTC)
* 終了   : 2026-08-05 16:30:00 (UTC)
* 現象   : 2026-08-05 16:30:00 (UTC)を境に水準が 15.06から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.82, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 19→20→16→18→16→18→16→18→17
* 開始   : 2026-08-05 15:55:00 (UTC)
* 終了   : 2026-08-05 16:05:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8033(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.721σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host07-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→10→10→13→10→12→8→10→12
* 開始   : 2026-08-05 20:15:00 (UTC)
* 終了   : 2026-08-05 21:40:00 (UTC)
* 現象   : 2026-08-05 21:40:00 (UTC)を境に水準が 15.11から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.607, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→11→9→11→…→11→8→12→11
* 開始   : 2026-08-05 20:20:00 (UTC)
* 終了   : 2026-08-05 20:30:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-063 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260805-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→14→12→8→14→12→8→10→11
* 開始   : 2026-08-05 20:35:00 (UTC)
* 終了   : 2026-08-05 20:45:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-063 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260805-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host07-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→6→5→7→6→5→7→8
* 開始   : 2026-08-05 23:15:00 (UTC)
* 終了   : 2026-08-05 23:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260805-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 18→15→19→20→…→19→21→17→18
* 開始   : 2026-08-06 07:05:00 (UTC)
* 終了   : 2026-08-06 07:30:00 (UTC)
* 現象   : 2026-08-06 07:30:00 (UTC)を境に水準が 15.18から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.024, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 18→20→22→19→20→22→19→18
* 開始   : 2026-08-06 08:40:00 (UTC)
* 終了   : 2026-08-06 08:45:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260806-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260806-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 20→18→23→21→24→23→21→24→21
* 開始   : 2026-08-06 09:35:00 (UTC)
* 終了   : 2026-08-06 09:45:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.554σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 23→22→18→19→…→19→24→23→21
* 開始   : 2026-08-06 13:40:00 (UTC)
* 終了   : 2026-08-06 13:50:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.8372(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260806-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 22→20→20→22→20
* 開始   : 2026-08-06 14:55:00 (UTC)
* 終了   : 2026-08-06 15:15:00 (UTC)
* 現象   : 2026-08-06 15:15:00 (UTC)を境に水準が 15.02から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→19→17→21→17→21→17→18
* 開始   : 2026-08-06 15:15:00 (UTC)
* 終了   : 2026-08-06 15:25:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260806-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260806-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 19→16→19→16→19→16→19
* 開始   : 2026-08-06 16:05:00 (UTC)
* 終了   : 2026-08-06 17:05:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260806-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260806-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→9→8→10→…→10→8→9→10
* 開始   : 2026-08-06 20:35:00 (UTC)
* 終了   : 2026-08-06 20:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host07-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260806-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host02-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→12→8→11→8→11→8→9→8
* 開始   : 2026-08-06 20:45:00 (UTC)
* 終了   : 2026-08-06 20:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host07-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host07-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260806-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host02-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host07-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 7→10→7→9→9→10→10→9→8
* 開始   : 2026-08-06 23:10:00 (UTC)
* 終了   : 2026-08-07 00:05:00 (UTC)
* 現象   : 2026-08-07 00:05:00 (UTC)を境に水準が 14.84から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.937, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→14→12→15→14→12→15→13→10
* 開始   : 2026-08-07 04:00:00 (UTC)
* 終了   : 2026-08-07 04:10:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260807-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→12→15→12→…→12→15→14→11
* 開始   : 2026-08-07 04:40:00 (UTC)
* 終了   : 2026-08-07 04:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.74σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host02-005 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260807-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→13→16→14→…→14→17→15→16
* 開始   : 2026-08-07 05:40:00 (UTC)
* 終了   : 2026-08-07 05:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260807-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260807-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260807-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 24→21→18→23→…→21→25→22→21
* 開始   : 2026-08-07 12:45:00 (UTC)
* 終了   : 2026-08-07 13:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.972σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host02-011 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-047 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 17→15→14→13→16→15→14→13→16
* 開始   : 2026-08-07 17:30:00 (UTC)
* 終了   : 2026-08-07 17:35:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260807-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 16→16→16→17→16→19
* 開始   : 2026-08-07 17:45:00 (UTC)
* 終了   : 2026-08-07 18:10:00 (UTC)
* 現象   : 2026-08-07 18:10:00 (UTC)を境に水準が 15.08から12.2へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.809, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 15→12→14→18→12→14→18→13→15
* 開始   : 2026-08-07 18:20:00 (UTC)
* 終了   : 2026-08-07 18:30:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260807-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host07-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→12→13→12→11→11
* 開始   : 2026-08-07 19:55:00 (UTC)
* 終了   : 2026-08-07 20:20:00 (UTC)
* 現象   : 2026-08-07 20:20:00 (UTC)を境に水準が 15から11.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.536, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→11→10→9→9→8→12
* 開始   : 2026-08-09 02:00:00 (UTC)
* 終了   : 2026-08-09 02:30:00 (UTC)
* 現象   : 2026-08-09 02:30:00 (UTC)を境に水準が 11.85から11.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.456, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→9→12→10→12→10→12→9
* 開始   : 2026-08-09 04:15:00 (UTC)
* 終了   : 2026-08-09 04:25:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260809-lsfhost01-011 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260809-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260809-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host07-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→11→11→13→11→12→14→14→14
* 開始   : 2026-08-09 05:05:00 (UTC)
* 終了   : 2026-08-09 06:10:00 (UTC)
* 現象   : 2026-08-09 06:10:00 (UTC)を境に水準が 11.78から12.21へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host07-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 17→16→15→15→16→16→15→15→18
* 開始   : 2026-08-09 09:05:00 (UTC)
* 終了   : 2026-08-09 09:50:00 (UTC)
* 現象   : 2026-08-09 09:50:00 (UTC)を境に水準が 11.96から12.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.081, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→10→10→9→9→8→9→10→11
* 開始   : 2026-08-10 22:00:00 (UTC)
* 終了   : 2026-08-10 23:10:00 (UTC)
* 現象   : 2026-08-10 23:10:00 (UTC)を境に水準が 14.9から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.022, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 8→9→5→8→5→8→5→8
* 開始   : 2026-08-10 23:55:00 (UTC)
* 終了   : 2026-08-11 00:05:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.5825(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260810-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260811-lsfhost01-001 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260811-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260810-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→12→13→14→12
* 開始   : 2026-08-11 03:20:00 (UTC)
* 終了   : 2026-08-11 03:40:00 (UTC)
* 現象   : 2026-08-11 03:40:00 (UTC)を境に水準が 15.04から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 9→13→14→15→…→15→14→15→14
* 開始   : 2026-08-11 04:35:00 (UTC)
* 終了   : 2026-08-11 04:55:00 (UTC)
* 現象   : 2026-08-11 04:55:00 (UTC)を境に水準が 15.02から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.674, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→12→15→13→12→15→13
* 開始   : 2026-08-11 04:45:00 (UTC)
* 終了   : 2026-08-11 04:50:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.304倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→14→16→14→…→16→17→15→17
* 開始   : 2026-08-11 05:25:00 (UTC)
* 終了   : 2026-08-11 05:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260811-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260811-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→17→13→18→…→18→20→19→15
* 開始   : 2026-08-11 06:55:00 (UTC)
* 終了   : 2026-08-11 07:05:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 22→22→20→22→22→22→24→24→22
* 開始   : 2026-08-11 10:10:00 (UTC)
* 終了   : 2026-08-11 11:15:00 (UTC)
* 現象   : 2026-08-11 11:15:00 (UTC)を境に水準が 15から15.17へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.86, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→9→8→12→9→8→12→11
* 開始   : 2026-08-11 20:45:00 (UTC)
* 終了   : 2026-08-11 20:50:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260811-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 10→9→8→9→8→9→11
* 開始   : 2026-08-11 21:05:00 (UTC)
* 終了   : 2026-08-11 21:10:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260811-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260811-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 9→11→9→12→11→9→12→9
* 開始   : 2026-08-12 01:35:00 (UTC)
* 終了   : 2026-08-12 01:45:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260812-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 9→12→11→13→12→11→13→10→11
* 開始   : 2026-08-12 03:15:00 (UTC)
* 終了   : 2026-08-12 03:25:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→14→17→18→…→17→18→16→15
* 開始   : 2026-08-12 06:05:00 (UTC)
* 終了   : 2026-08-12 06:10:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→21→22→18→21→22→18→19
* 開始   : 2026-08-12 08:50:00 (UTC)
* 終了   : 2026-08-12 08:55:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260812-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→16→12→11→…→12→11→14→12
* 開始   : 2026-08-12 18:30:00 (UTC)
* 終了   : 2026-08-12 18:35:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260812-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 17→15→12→11→…→12→11→12→13
* 開始   : 2026-08-12 18:55:00 (UTC)
* 終了   : 2026-08-12 19:00:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host13-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→12→11→12→11
* 開始   : 2026-08-12 20:30:00 (UTC)
* 終了   : 2026-08-12 21:00:00 (UTC)
* 現象   : 2026-08-12 21:00:00 (UTC)を境に水準が 14.86から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host07-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→8→7→11→8→7→11→10
* 開始   : 2026-08-12 21:15:00 (UTC)
* 終了   : 2026-08-12 21:20:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→13→16→13→16→13→16→14→16
* 開始   : 2026-08-13 05:15:00 (UTC)
* 終了   : 2026-08-13 05:25:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.315倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.67σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→15→18→16→19→18→16→19→16
* 開始   : 2026-08-13 06:30:00 (UTC)
* 終了   : 2026-08-13 06:40:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.256倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.575σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260813-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260813-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 16→15→18→19→…→18→19→18→17
* 開始   : 2026-08-13 06:55:00 (UTC)
* 終了   : 2026-08-13 07:00:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260813-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 19→16→14→15→16→14→15→16
* 開始   : 2026-08-13 17:25:00 (UTC)
* 終了   : 2026-08-13 17:30:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→15→13→12→13→12→13
* 開始   : 2026-08-13 18:10:00 (UTC)
* 終了   : 2026-08-13 18:20:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260813-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→11→9→12→…→9→8→13→12
* 開始   : 2026-08-13 20:25:00 (UTC)
* 終了   : 2026-08-13 20:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host12-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260813-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→7→11→7→11→7→12→11
* 開始   : 2026-08-13 21:30:00 (UTC)
* 終了   : 2026-08-13 21:40:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.6512(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.613σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260813-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260813-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→11→10→11→11→9→8→10→9
* 開始   : 2026-08-13 22:40:00 (UTC)
* 終了   : 2026-08-14 00:05:00 (UTC)
* 現象   : 2026-08-14 00:05:00 (UTC)を境に水準が 15.03から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 16→17→14→18→14→18→14→17→15
* 開始   : 2026-08-14 17:15:00 (UTC)
* 終了   : 2026-08-14 17:25:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260814-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→9→10→12→9→10→11
* 開始   : 2026-08-14 20:30:00 (UTC)
* 終了   : 2026-08-14 20:35:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.7297(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host07-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260814-host09-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260814-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host16-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260814-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host07-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 9→8→9→10→…→10→8→10→9
* 開始   : 2026-08-15 04:10:00 (UTC)
* 終了   : 2026-08-15 04:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.739, 限界=2.701)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260815-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260815-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→10→7→8→10→7→8→11
* 開始   : 2026-08-15 21:20:00 (UTC)
* 終了   : 2026-08-15 21:25:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.672(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260815-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 12→12→14→12
* 開始   : 2026-08-16 04:35:00 (UTC)
* 終了   : 2026-08-16 04:50:00 (UTC)
* 現象   : 2026-08-16 04:50:00 (UTC)を境に水準が 11.79から12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.539, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→13→17→16→13→17→16→12
* 開始   : 2026-08-16 08:00:00 (UTC)
* 終了   : 2026-08-16 08:05:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.325倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.908σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260816-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→11→14→11→14→11→14→16
* 開始   : 2026-08-16 16:20:00 (UTC)
* 終了   : 2026-08-16 16:30:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 8→6→4→8→…→8→11→6→8
* 開始   : 2026-08-16 23:25:00 (UTC)
* 終了   : 2026-08-16 23:35:00 (UTC)
* 現象   : 平常時(8)に対し 0.5(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.793σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260816-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 8→6→11→8→5→11→8→5→9
* 開始   : 2026-08-17 00:15:00 (UTC)
* 終了   : 2026-08-17 00:25:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260817-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260817-host01-001 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260817-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 7→9→10→10→7→8→9
* 開始   : 2026-08-18 00:05:00 (UTC)
* 終了   : 2026-08-18 00:35:00 (UTC)
* 現象   : 2026-08-18 00:35:00 (UTC)を境に水準が 14.74から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.791, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→11→13→9→13→9→13→11→10
* 開始   : 2026-08-18 03:25:00 (UTC)
* 終了   : 2026-08-18 03:35:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260818-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 16→15→19→20→19→15→19→20→19
* 開始   : 2026-08-18 07:05:00 (UTC)
* 終了   : 2026-08-18 07:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260818-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 21→19→20→21→22→22→21
* 開始   : 2026-08-18 07:10:00 (UTC)
* 終了   : 2026-08-18 09:10:00 (UTC)
* 現象   : 2026-08-18 09:10:00 (UTC)を境に水準が 14.93から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.791, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 21→20→23→24→20→23→24→20→21
* 開始   : 2026-08-18 10:00:00 (UTC)
* 終了   : 2026-08-18 10:05:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260818-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260818-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host07-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 23→21→22→22→22→23→23
* 開始   : 2026-08-18 13:15:00 (UTC)
* 終了   : 2026-08-18 13:45:00 (UTC)
* 現象   : 2026-08-18 13:45:00 (UTC)を境に水準が 15.02から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.791, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 16→18→14→15→18→14→15→17
* 開始   : 2026-08-18 17:25:00 (UTC)
* 終了   : 2026-08-18 17:30:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 7→9→5→9→…→9→11→10→9
* 開始   : 2026-08-19 00:20:00 (UTC)
* 終了   : 2026-08-19 00:30:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260819-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→9→11→10→8→8→9→9→12
* 開始   : 2026-08-19 00:40:00 (UTC)
* 終了   : 2026-08-19 01:20:00 (UTC)
* 現象   : 2026-08-19 01:20:00 (UTC)を境に水準が 15.07から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.703, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→11→15→16→13→11→15→16→13
* 開始   : 2026-08-19 05:15:00 (UTC)
* 終了   : 2026-08-19 05:20:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260819-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 13→14→17→18→17→18→15→14
* 開始   : 2026-08-19 05:55:00 (UTC)
* 終了   : 2026-08-19 06:05:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→17→18→16→17→18→16
* 開始   : 2026-08-19 06:35:00 (UTC)
* 終了   : 2026-08-19 06:40:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 18→19→19→18→20→19→19→21→22
* 開始   : 2026-08-19 07:50:00 (UTC)
* 終了   : 2026-08-19 08:50:00 (UTC)
* 現象   : 2026-08-19 08:50:00 (UTC)を境に水準が 15.16から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.015, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 23→23→25→22→22→23→21→23→24
* 開始   : 2026-08-19 10:55:00 (UTC)
* 終了   : 2026-08-19 11:45:00 (UTC)
* 現象   : 2026-08-19 11:45:00 (UTC)を境に水準が 15.07から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.483, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 19→22→18→24→…→18→24→19→21
* 開始   : 2026-08-19 14:30:00 (UTC)
* 終了   : 2026-08-19 14:35:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.8538(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 19→17→15→16→…→16→14→16→17
* 開始   : 2026-08-19 16:45:00 (UTC)
* 終了   : 2026-08-19 16:55:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260819-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→12→13→15→16→12→13→15
* 開始   : 2026-08-19 17:55:00 (UTC)
* 終了   : 2026-08-19 18:00:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.7385(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.967σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host07-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 15→19→13→15→13→15→13→14→17
* 開始   : 2026-08-19 18:00:00 (UTC)
* 終了   : 2026-08-19 18:10:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host07-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260819-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→11→10→12→10→12→10→13
* 開始   : 2026-08-19 19:20:00 (UTC)
* 終了   : 2026-08-19 19:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host07-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260819-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260819-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→13→10→13
* 開始   : 2026-08-19 19:55:00 (UTC)
* 終了   : 2026-08-19 20:00:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260819-host02-014 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-063 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260819-host07-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host07-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 6→7→5→9→4→5→9→4→9
* 開始   : 2026-08-19 23:20:00 (UTC)
* 終了   : 2026-08-19 23:30:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-079 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260819-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host07-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→16→18→15→…→15→19→17→15
* 開始   : 2026-08-20 06:35:00 (UTC)
* 終了   : 2026-08-20 06:45:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260820-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260820-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 16→17→19→18→…→18→20→16→17
* 開始   : 2026-08-20 07:05:00 (UTC)
* 終了   : 2026-08-20 07:15:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host07-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260820-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 16→17→13→20→…→17→13→20→17
* 開始   : 2026-08-20 07:05:00 (UTC)
* 終了   : 2026-08-20 07:15:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host07-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260820-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 18→20→17→20→17→20→19
* 開始   : 2026-08-20 07:30:00 (UTC)
* 終了   : 2026-08-20 07:40:00 (UTC)
* 現象   : 平常時(16.75)に対し 1.194倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 19→24→23→19→24→23→21
* 開始   : 2026-08-20 10:15:00 (UTC)
* 終了   : 2026-08-20 10:20:00 (UTC)
* 現象   : 平常時(20)に対し 1.2倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.779σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260820-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 22→21→24→24→23→22
* 開始   : 2026-08-20 10:40:00 (UTC)
* 終了   : 2026-08-20 11:05:00 (UTC)
* 現象   : 2026-08-20 11:05:00 (UTC)を境に水準が 14.87から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.248, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 23→23→22→21→23→22→23
* 開始   : 2026-08-20 13:05:00 (UTC)
* 終了   : 2026-08-20 14:30:00 (UTC)
* 現象   : 2026-08-20 14:30:00 (UTC)を境に水準が 14.83から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.248, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 21→20→20→20→19→22→22→21→21
* 開始   : 2026-08-20 14:25:00 (UTC)
* 終了   : 2026-08-20 15:15:00 (UTC)
* 現象   : 2026-08-20 15:15:00 (UTC)を境に水準が 15.03から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 16→17→13→17→12→13→17→12→16
* 開始   : 2026-08-20 17:50:00 (UTC)
* 終了   : 2026-08-20 18:00:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7839(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260820-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-017 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→14→16→14
* 開始   : 2026-08-20 19:10:00 (UTC)
* 終了   : 2026-08-20 19:35:00 (UTC)
* 現象   : 2026-08-20 19:35:00 (UTC)を境に水準が 14.9から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.539, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host07-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-018 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→12→15→11→10→11→13
* 開始   : 2026-08-20 19:50:00 (UTC)
* 終了   : 2026-08-20 20:20:00 (UTC)
* 現象   : 2026-08-20 20:20:00 (UTC)を境に水準が 14.87から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.456, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host07-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host07-019 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 10→10→9→9→10→10→10
* 開始   : 2026-08-20 22:50:00 (UTC)
* 終了   : 2026-08-20 23:20:00 (UTC)
* 現象   : 2026-08-20 23:20:00 (UTC)を境に水準が 15.01から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.21, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host07-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→12→13→10→12→10→11→13→13
* 開始   : 2026-08-21 02:35:00 (UTC)
* 終了   : 2026-08-21 03:50:00 (UTC)
* 現象   : 2026-08-21 03:50:00 (UTC)を境に水準が 14.94から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.329, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 12→11→15→12→15→12→15→12→14
* 開始   : 2026-08-21 03:35:00 (UTC)
* 終了   : 2026-08-21 04:50:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829倍(7)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.1 時間
  - EVT-20260821-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260821-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260821-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 45 分
  - EVT-20260821-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分

![EVT-20260821-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→12→16→15→12→16→15→14
* 開始   : 2026-08-21 05:35:00 (UTC)
* 終了   : 2026-08-21 05:40:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260821-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260821-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260821-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 19→20→21→22→…→21→22→21→19
* 開始   : 2026-08-21 08:30:00 (UTC)
* 終了   : 2026-08-21 08:35:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 22→18→23→22→18→23→22→19
* 開始   : 2026-08-21 09:15:00 (UTC)
* 終了   : 2026-08-21 09:20:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 24→24→22→21→22→25
* 開始   : 2026-08-21 12:05:00 (UTC)
* 終了   : 2026-08-21 12:35:00 (UTC)
* 現象   : 2026-08-21 12:35:00 (UTC)を境に水準が 14.85から13.27へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.2σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.468, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→12→11→12→…→12→10→12→14
* 開始   : 2026-08-21 19:20:00 (UTC)
* 終了   : 2026-08-21 19:30:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→10→12→10→12→10→12→11
* 開始   : 2026-08-21 19:30:00 (UTC)
* 終了   : 2026-08-21 19:40:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.575σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host05-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host07-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 7→9→5→10→9→5→10→7
* 開始   : 2026-08-21 23:20:00 (UTC)
* 終了   : 2026-08-21 23:25:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.5714(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.618σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-016 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260821-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host07-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 9→11→9→11→…→9→10→12→9
* 開始   : 2026-08-22 18:55:00 (UTC)
* 終了   : 2026-08-22 19:25:00 (UTC)
* 現象   : 30分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.911, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260822-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260822-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260822-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260822-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分

![EVT-20260822-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→10→7→9→6→9→9→9→10
* 開始   : 2026-08-22 23:45:00 (UTC)
* 終了   : 2026-08-23 00:40:00 (UTC)
* 現象   : 2026-08-23 00:40:00 (UTC)を境に水準が 11.81から11.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260822-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→10→14→9→14→9→14→10→13
* 開始   : 2026-08-23 04:55:00 (UTC)
* 終了   : 2026-08-23 05:05:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260823-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260823-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260823-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260823-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host07-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→17→14→14→18→15→16→16→15
* 開始   : 2026-08-23 07:50:00 (UTC)
* 終了   : 2026-08-23 09:55:00 (UTC)
* 現象   : 2026-08-23 09:55:00 (UTC)を境に水準が 11.96から12.62へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.081, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 9→10→8→10→…→10→14→10→11
* 開始   : 2026-08-23 18:40:00 (UTC)
* 終了   : 2026-08-23 18:50:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260823-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→11→8→10→8→10→8→12→8
* 開始   : 2026-08-23 19:15:00 (UTC)
* 終了   : 2026-08-23 19:25:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260823-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260823-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260823-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host07-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→9→9→9→9→8→8→8→10
* 開始   : 2026-08-23 21:35:00 (UTC)
* 終了   : 2026-08-23 23:20:00 (UTC)
* 現象   : 2026-08-23 23:20:00 (UTC)を境に水準が 11.84から14.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.695, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→11→13→11→13→11→13→11→12
* 開始   : 2026-08-25 03:25:00 (UTC)
* 終了   : 2026-08-25 03:35:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.405倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.618σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-012 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260825-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260825-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 16→17→14→17→18
* 開始   : 2026-08-25 05:50:00 (UTC)
* 終了   : 2026-08-25 06:20:00 (UTC)
* 現象   : 2026-08-25 06:20:00 (UTC)を境に水準が 15.01から15.19へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 16→14→18→15→18→15→18→15→17
* 開始   : 2026-08-25 06:25:00 (UTC)
* 終了   : 2026-08-25 06:35:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260825-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 21→25→19→22→21→25→19→22→20
* 開始   : 2026-08-25 12:55:00 (UTC)
* 終了   : 2026-08-25 13:00:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260825-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→17→14→16→14→16→14→16→15
* 開始   : 2026-08-25 17:20:00 (UTC)
* 終了   : 2026-08-25 17:30:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7925(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.555σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260825-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260825-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→14→10→11→9→10→11→9→12
* 開始   : 2026-08-25 19:55:00 (UTC)
* 終了   : 2026-08-25 20:05:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→11→5→7→5→7→5→9
* 開始   : 2026-08-25 23:35:00 (UTC)
* 終了   : 2026-08-25 23:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260825-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 8→7→11→12→…→11→12→10→9
* 開始   : 2026-08-26 01:20:00 (UTC)
* 終了   : 2026-08-26 01:25:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host07-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→14→14→15
* 開始   : 2026-08-26 05:05:00 (UTC)
* 終了   : 2026-08-26 05:20:00 (UTC)
* 現象   : 2026-08-26 05:20:00 (UTC)を境に水準が 14.97から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.024, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→20→23→20→23→20→21
* 開始   : 2026-08-26 09:55:00 (UTC)
* 終了   : 2026-08-26 10:00:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 21→20→24→21→20→24→21→20
* 開始   : 2026-08-26 11:30:00 (UTC)
* 終了   : 2026-08-26 11:35:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260826-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 19→20→17→16→…→17→16→19→17
* 開始   : 2026-08-26 16:05:00 (UTC)
* 終了   : 2026-08-26 16:10:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260826-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 15→13→14→12→13→14→12→14→13
* 開始   : 2026-08-26 18:05:00 (UTC)
* 終了   : 2026-08-26 18:15:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260826-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host07-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→13→13→11→14→12→11→11→13
* 開始   : 2026-08-26 19:50:00 (UTC)
* 終了   : 2026-08-26 20:30:00 (UTC)
* 現象   : 2026-08-26 20:30:00 (UTC)を境に水準が 14.99から15.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.102, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→12→8→14→8→14→8→11→10
* 開始   : 2026-08-26 20:25:00 (UTC)
* 終了   : 2026-08-26 20:35:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6857(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260826-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→11→10→8→8
* 開始   : 2026-08-27 00:00:00 (UTC)
* 終了   : 2026-08-27 00:20:00 (UTC)
* 現象   : 2026-08-27 00:20:00 (UTC)を境に水準が 14.91から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→17→16→14→17→16→17
* 開始   : 2026-08-27 05:45:00 (UTC)
* 終了   : 2026-08-27 05:50:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.291倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.676σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host07-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 23→23→22→21→22→20→20→21→22
* 開始   : 2026-08-27 13:40:00 (UTC)
* 終了   : 2026-08-27 14:40:00 (UTC)
* 現象   : 2026-08-27 14:40:00 (UTC)を境に水準が 15.14から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.592, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 20→17→14→17→14→17→14→17→18
* 開始   : 2026-08-27 16:45:00 (UTC)
* 終了   : 2026-08-27 16:55:00 (UTC)
* 現象   : 木曜16時台の平常値(17.85)に対し 14であった
* 説明   : ALG-A1: 移動平均からの残差が 2.961σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.038σ 外れた (平常値=17.85)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260827-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260827-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 17→20→14→15→20→14→15→14
* 開始   : 2026-08-27 17:20:00 (UTC)
* 終了   : 2026-08-27 17:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7925(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.564σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→17→12→13→17→12→13→14
* 開始   : 2026-08-27 18:35:00 (UTC)
* 終了   : 2026-08-27 18:40:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.432σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host07-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→15→12→12→13
* 開始   : 2026-08-27 19:25:00 (UTC)
* 終了   : 2026-08-27 19:45:00 (UTC)
* 現象   : 2026-08-27 19:45:00 (UTC)を境に水準が 15から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 15→16→19→16→19→16→14
* 開始   : 2026-08-28 06:50:00 (UTC)
* 終了   : 2026-08-28 06:55:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.253倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260828-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260828-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260828-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host07-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 16→15→18→16→15→15→17
* 開始   : 2026-08-28 17:40:00 (UTC)
* 終了   : 2026-08-28 18:10:00 (UTC)
* 現象   : 2026-08-28 18:10:00 (UTC)を境に水準が 14.83から12.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.456, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→11→12→13→11→12→13
* 開始   : 2026-08-28 19:10:00 (UTC)
* 終了   : 2026-08-28 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→12→10→12→10→12→10→12
* 開始   : 2026-08-28 19:35:00 (UTC)
* 終了   : 2026-08-28 19:45:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.7362(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260828-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host14-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260828-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→12→9→12→9→12→9→10→12
* 開始   : 2026-08-28 20:25:00 (UTC)
* 終了   : 2026-08-28 20:35:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260828-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host07-007 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
