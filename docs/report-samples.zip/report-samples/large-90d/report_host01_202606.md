# host01 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host01 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 352 (SEVERE: 24, FATAL: 153, WARN: 175, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 19 | 128 | 144 | 291 | ALG-A1, ALG-A2, ALG-A3, ALG-A4, ALG-A5, ALG-B4 |
| eu | 4 | 22 | 31 | 57 | ALG-A1, ALG-A4, ALG-B4 |
| ou | 1 | 0 | 0 | 1 | ALG-A1, ALG-A2, ALG-B2, ALG-B5, ALG-C1 |
| fgc_delta | 0 | 1 | 0 | 1 | ALG-B2 |
| fgct_delta | 0 | 1 | 0 | 1 | ALG-B2 |
| mu | 0 | 1 | 0 | 1 | ALG-B2, ALG-B5 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260601-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-B2 Mann-Kendall 傾向検定, ALG-B5 線形回帰の傾き, ALG-C1 上限への張り付き
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app01, host=host01
* 値     : 42.93→49.34→55.9→62.4→68.95→75.29→81.89→88.41→94.88
* 開始   : 2026-06-01 00:00:00 (UTC)
* 終了   : 2026-08-29 23:55:00 (UTC)
* 現象   : 90.0日で 42.93から94.88へ増加した(平均 0.5777/日)
* 説明   : ALG-A1: 移動平均からの残差が 2.018σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 4.097 倍に達した (閾値 3)
             ALG-B2: Mann-Kendall 検定で有意な増加傾向を検出した (S=581662, p=0, Sen勾配=1.249/日)
             ALG-B5: 線形回帰の傾きが 1 日あたり 0.5777、決定係数 R²=0.9865 (総増加 51.99)
             ALG-C1: 実際の上限 100 の 90% (90) 以上が 11.8 時間続いた (期間中の平均 93.03, 最大 96.29, 143 点)
* 原因候補 : 負荷増に伴う正常な増加 (確度: 中) — 同時刻に負荷指標(active_connections または run)のアノマリーも出ているため

![EVT-20260601-host01-002 ou の推移](charts/EVT-20260601-host01-002.svg)

# イベントID( EVT-20260605-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 21→19→213→23→…→19→20→19→21
* 開始   : 2026-06-05 14:00:00 (UTC)
* 終了   : 2026-06-05 15:00:00 (UTC)
* 現象   : 2026-06-05 15:00:00 (UTC)を境に水準が 15.72から13.63へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 101.2σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 129.2 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=213)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=37.77, 限界=3.181)
             ALG-A5: 同じ曜日・時刻帯の平常値から 145.6σ 外れた (平常値=20.61)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=190.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host01-005 active_connections の推移](charts/EVT-20260605-host01-005.svg)

# イベントID( EVT-20260607-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→26→23→25→…→15→17→15→17
* 開始   : 2026-06-07 09:00:00 (UTC)
* 終了   : 2026-06-07 11:50:00 (UTC)
* 現象   : 2026-06-07 11:50:00 (UTC)を境に水準が 11.87から13.48へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 8.57σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 8.431 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.13, 限界=2.7)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.473σ 外れた (平常値=15.37)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.856, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host01-007 active_connections の推移](charts/EVT-20260607-host01-007.svg)

# イベントID( EVT-20260608-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 48.68→53.14→52.88→47.61→…→41.67→41.21→41.47→40.9
* 開始   : 2026-06-08 01:50:00 (UTC)
* 終了   : 2026-06-08 21:55:00 (UTC)
* 現象   : 2026-06-08 21:55:00 (UTC)を境に水準が 40.72から50.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.307σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=8.074, 限界=7.23)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=25.37, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-001 eu の推移](charts/EVT-20260608-host01-001.svg)

# イベントID( EVT-20260608-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→13→14→16→…→12→14→13→12
* 開始   : 2026-06-08 02:05:00 (UTC)
* 終了   : 2026-06-08 21:50:00 (UTC)
* 現象   : 2026-06-08 21:50:00 (UTC)を境に水準が 11.88から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.198, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.004, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-002 active_connections の推移](charts/EVT-20260608-host01-002.svg)

# イベントID( EVT-20260608-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→13→12→11→…→14→16→13→12
* 開始   : 2026-06-08 02:40:00 (UTC)
* 終了   : 2026-06-08 20:25:00 (UTC)
* 現象   : 2026-06-08 20:25:00 (UTC)を境に水準が 11.72から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.919σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.655, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.99, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-004 active_connections の推移](charts/EVT-20260608-host01-004.svg)

# イベントID( EVT-20260608-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→17→14→17→…→15→13→11→14
* 開始   : 2026-06-08 03:20:00 (UTC)
* 終了   : 2026-06-08 19:55:00 (UTC)
* 現象   : 2026-06-08 19:55:00 (UTC)を境に水準が 11.85から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.608σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.147, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.851, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-006 active_connections の推移](charts/EVT-20260608-host01-006.svg)

# イベントID( EVT-20260608-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 21→18→21→22→…→13→12→11→13
* 開始   : 2026-06-08 10:15:00 (UTC)
* 終了   : 2026-06-08 21:50:00 (UTC)
* 現象   : 2026-06-08 21:50:00 (UTC)を境に水準が 13.21から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.844, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-008 active_connections の推移](charts/EVT-20260608-host01-008.svg)

# イベントID( EVT-20260615-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 50.67→49.29→53.21→58.12→…→44.85→45.55→44.8→41.96
* 開始   : 2026-06-15 01:25:00 (UTC)
* 終了   : 2026-06-15 22:35:00 (UTC)
* 現象   : 2026-06-15 22:35:00 (UTC)を境に水準が 40.68から49.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=8.526, 限界=7.23)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=27.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-002 eu の推移](charts/EVT-20260615-host01-002.svg)

# イベントID( EVT-20260615-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→18→…→17→16→15→14
* 開始   : 2026-06-15 02:05:00 (UTC)
* 終了   : 2026-06-15 19:45:00 (UTC)
* 現象   : 2026-06-15 19:45:00 (UTC)を境に水準が 11.85から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.727, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.417, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-004 active_connections の推移](charts/EVT-20260615-host01-004.svg)

# イベントID( EVT-20260615-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→16→…→16→14→11→14
* 開始   : 2026-06-15 02:55:00 (UTC)
* 終了   : 2026-06-15 20:00:00 (UTC)
* 現象   : 2026-06-15 20:00:00 (UTC)を境に水準が 11.92から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.386σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.207, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-005 active_connections の推移](charts/EVT-20260615-host01-005.svg)

# イベントID( EVT-20260615-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→16→15→16→…→15→13→14→15
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 20:35:00 (UTC)
* 現象   : 2026-06-15 20:35:00 (UTC)を境に水準が 11.9から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.447σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.975, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.831, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-006 active_connections の推移](charts/EVT-20260615-host01-006.svg)

# イベントID( EVT-20260615-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→16→…→12→15→12→14
* 開始   : 2026-06-15 03:55:00 (UTC)
* 終了   : 2026-06-15 19:40:00 (UTC)
* 現象   : 2026-06-15 19:40:00 (UTC)を境に水準が 11.97から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.038, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.004, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-007 active_connections の推移](charts/EVT-20260615-host01-007.svg)

# イベントID( EVT-20260615-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→17→16→15→…→12→13→11→12
* 開始   : 2026-06-15 04:00:00 (UTC)
* 終了   : 2026-06-15 19:30:00 (UTC)
* 現象   : 2026-06-15 19:30:00 (UTC)を境に水準が 11.99から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.084σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.724, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.851, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-008 active_connections の推移](charts/EVT-20260615-host01-008.svg)

# イベントID( EVT-20260622-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→18→19→17→…→16→14→10→14
* 開始   : 2026-06-22 02:15:00 (UTC)
* 終了   : 2026-06-22 20:50:00 (UTC)
* 現象   : 2026-06-22 20:50:00 (UTC)を境に水準が 11.85から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.8, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.958, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host01-001 active_connections の推移](charts/EVT-20260622-host01-001.svg)

# イベントID( EVT-20260622-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 42.68→45→45.87→49.59→…→50.46→47.49→46.38→48.34
* 開始   : 2026-06-22 02:40:00 (UTC)
* 終了   : 2026-06-22 20:55:00 (UTC)
* 現象   : 2026-06-22 20:55:00 (UTC)を境に水準が 40.7から49.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.816σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=8.31, 限界=7.23)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=21.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host01-002 eu の推移](charts/EVT-20260622-host01-002.svg)

# イベントID( EVT-20260622-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→16→14→16→…→13→14→11→14
* 開始   : 2026-06-22 03:25:00 (UTC)
* 終了   : 2026-06-22 19:40:00 (UTC)
* 現象   : 2026-06-22 19:40:00 (UTC)を境に水準が 11.9から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.719, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.927, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host01-004 active_connections の推移](charts/EVT-20260622-host01-004.svg)

# イベントID( EVT-20260622-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 12→16→15→16→…→18→15→13→15
* 開始   : 2026-06-22 03:30:00 (UTC)
* 終了   : 2026-06-22 20:25:00 (UTC)
* 現象   : 2026-06-22 20:25:00 (UTC)を境に水準が 11.85から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.669, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.51, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host01-005 active_connections の推移](charts/EVT-20260622-host01-005.svg)

# イベントID( EVT-20260622-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→14→15→16→…→15→12→11→12
* 開始   : 2026-06-22 04:00:00 (UTC)
* 終了   : 2026-06-22 19:10:00 (UTC)
* 現象   : 2026-06-22 19:10:00 (UTC)を境に水準が 11.98から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.808, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.873, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host01-007 active_connections の推移](charts/EVT-20260622-host01-007.svg)

# イベントID( EVT-20260629-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→13→17→14→…→15→13→12→13
* 開始   : 2026-06-29 02:35:00 (UTC)
* 終了   : 2026-06-29 20:30:00 (UTC)
* 現象   : 2026-06-29 20:30:00 (UTC)を境に水準が 11.87から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.914, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host01-001 active_connections の推移](charts/EVT-20260629-host01-001.svg)

# イベントID( EVT-20260629-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→20→19→18→…→15→14→12→13
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 20:10:00 (UTC)
* 現象   : 2026-06-29 20:10:00 (UTC)を境に水準が 11.99から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.762, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.852, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host01-003 active_connections の推移](charts/EVT-20260629-host01-003.svg)

# イベントID( EVT-20260629-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 52.33→46.34→46.65→49.01→…→43.5→45.11→40.23→45.66
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 21:00:00 (UTC)
* 現象   : 2026-06-29 21:00:00 (UTC)を境に水準が 40.81から50.17へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.192σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=7.306, 限界=7.23)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=27.61, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host01-004 eu の推移](charts/EVT-20260629-host01-004.svg)

# イベントID( EVT-20260629-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→14→13→14→…→15→11→10→13
* 開始   : 2026-06-29 03:50:00 (UTC)
* 終了   : 2026-06-29 20:55:00 (UTC)
* 現象   : 2026-06-29 20:55:00 (UTC)を境に水準が 12から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.185σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.796, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host01-006 active_connections の推移](charts/EVT-20260629-host01-006.svg)

# イベントID( EVT-20260629-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 16→14→18→15→…→14→15→14→13
* 開始   : 2026-06-29 04:20:00 (UTC)
* 終了   : 2026-06-29 21:05:00 (UTC)
* 現象   : 2026-06-29 21:05:00 (UTC)を境に水準が 12.01から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.033, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.879, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host01-007 active_connections の推移](charts/EVT-20260629-host01-007.svg)

# イベントID( EVT-20260601-host01-001 )

* イベント種別 : ALG-B2 Mann-Kendall 傾向検定, ALG-B5 線形回帰の傾き
* 脅威度 : FATAL
* データ : jvm_gc / mu (Metaspace 使用量) / container=app01, host=host01
* 値     : 55.12→59.21→63.19→67.37→71.63→75.57→79.83→83.84→88.07
* 開始   : 2026-06-01 00:00:00 (UTC)
* 終了   : 2026-08-29 23:55:00 (UTC)
* 現象   : 90.0日で 55.12から88.07へ増加した(平均 0.3666/日)
* 説明   : ALG-B2: Mann-Kendall 検定で有意な増加傾向を検出した (S=579900, p=0, Sen勾配=0.7925/日)
             ALG-B5: 線形回帰の傾きが 1 日あたり 0.3666、決定係数 R²=0.9982 (総増加 32.99)
* 原因候補 : クラスローダリーク(動的クラス生成) (確度: 中) — Metaspace の使用量が増え続けているため

![EVT-20260601-host01-001 mu の推移](charts/EVT-20260601-host01-001.svg)

# イベントID( EVT-20260601-host01-003 )

* イベント種別 : ALG-B2 Mann-Kendall 傾向検定
* 脅威度 : FATAL
* データ : jvm_gc / fgc_delta (区間 Full GC 回数) / container=app01, host=host01
* 値     : 0→0→0.08333→0.08333→0.1667→0.25→0.3333→0.4583→0.5652
* 開始   : 2026-06-01 00:05:00 (UTC)
* 終了   : 2026-08-29 23:55:00 (UTC)
* 現象   : 90.0日で 0から0.5652へ増加した(平均 0.01316/日)
* 説明   : ALG-B2: Mann-Kendall 検定で有意な増加傾向を検出した (S=515236, p=0, Sen勾配=0.01316/日)
* 原因候補 : 該当する候補なし (確度: —)

![EVT-20260601-host01-003 fgc_delta の推移](charts/EVT-20260601-host01-003.svg)

# イベントID( EVT-20260601-host01-004 )

* イベント種別 : ALG-B2 Mann-Kendall 傾向検定
* 脅威度 : FATAL
* データ : jvm_gc / fgct_delta (区間 Full GC 時間) / container=app01, host=host01
* 値     : 0.018→0.02579→0.04904→0.08779→0.142→0.2111→0.2961→0.3966→0.5126
* 開始   : 2026-06-01 00:05:00 (UTC)
* 終了   : 2026-08-29 23:55:00 (UTC)
* 現象   : 90.0日で 0.018から0.5126へ増加した(平均 0.0119/日)
* 説明   : ALG-B2: Mann-Kendall 検定で有意な増加傾向を検出した (S=582590, p=0, Sen勾配=0.0119/日)
* 原因候補 : 該当する候補なし (確度: —)

![EVT-20260601-host01-004 fgct_delta の推移](charts/EVT-20260601-host01-004.svg)

# イベントID( EVT-20260601-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→9→14→10→10
* 開始   : 2026-06-01 02:45:00 (UTC)
* 終了   : 2026-06-01 02:45:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-009 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→15→18→15→16
* 開始   : 2026-06-01 05:50:00 (UTC)
* 終了   : 2026-06-01 05:50:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→18→19→21→…→19→21→17→19
* 開始   : 2026-06-01 07:20:00 (UTC)
* 終了   : 2026-06-01 07:25:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 18→19→25→18→19
* 開始   : 2026-06-01 08:55:00 (UTC)
* 終了   : 2026-06-01 08:55:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.351倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.433σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 4.721 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 19→19→16→19→19
* 開始   : 2026-06-01 15:00:00 (UTC)
* 終了   : 2026-06-01 15:00:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 18→18→15→20→18
* 開始   : 2026-06-01 16:10:00 (UTC)
* 終了   : 2026-06-01 16:10:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 17→14→20→18→19
* 開始   : 2026-06-02 06:55:00 (UTC)
* 終了   : 2026-06-02 06:55:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.185σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 22→20→17→19→20
* 開始   : 2026-06-02 14:35:00 (UTC)
* 終了   : 2026-06-02 14:35:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→19→14→18→14→18→14→18→15
* 開始   : 2026-06-02 17:15:00 (UTC)
* 終了   : 2026-06-02 17:40:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 25 分
  - EVT-20260602-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260602-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 17→18→12→14→13
* 開始   : 2026-06-02 18:00:00 (UTC)
* 終了   : 2026-06-02 18:00:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.72(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 16→14→10→16→14
* 開始   : 2026-06-02 18:25:00 (UTC)
* 終了   : 2026-06-02 18:25:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.678(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→11→8→12→12
* 開始   : 2026-06-02 20:00:00 (UTC)
* 終了   : 2026-06-02 20:00:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 41.22→39.42→31.43→36.61→…→36.61→30.5→35.95→44.64
* 開始   : 2026-06-02 20:20:00 (UTC)
* 終了   : 2026-06-02 20:30:00 (UTC)
* 現象   : 平常時(42.87)に対し 0.7331(31.43)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260602-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260602-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host01-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→13→17→14→11
* 開始   : 2026-06-03 04:50:00 (UTC)
* 終了   : 2026-06-03 04:50:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260603-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→16→13→17→17
* 開始   : 2026-06-03 17:25:00 (UTC)
* 終了   : 2026-06-03 17:45:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 15 分
  - EVT-20260603-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260603-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260603-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260603-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 17→15→12→14→15
* 開始   : 2026-06-03 18:05:00 (UTC)
* 終了   : 2026-06-03 18:05:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7164(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 8→6→12→7→8
* 開始   : 2026-06-04 00:55:00 (UTC)
* 終了   : 2026-06-04 00:55:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-004 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→15→17→13→13
* 開始   : 2026-06-04 05:00:00 (UTC)
* 終了   : 2026-06-04 05:00:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-020 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260604-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 18→16→20→19→…→18→21→17→18
* 開始   : 2026-06-04 07:30:00 (UTC)
* 終了   : 2026-06-04 08:10:00 (UTC)
* 現象   : 40分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-005 (同一ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260604-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260604-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260604-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 23→23→18→22→21
* 開始   : 2026-06-04 13:35:00 (UTC)
* 終了   : 2026-06-04 13:35:00 (UTC)
* 現象   : 平常時(22.58)に対し 0.797(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.185σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→15→18→15→15
* 開始   : 2026-06-05 06:10:00 (UTC)
* 終了   : 2026-06-05 06:10:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 64.94→67.9→77.96→71.44→68.98
* 開始   : 2026-06-05 10:10:00 (UTC)
* 終了   : 2026-06-05 10:10:00 (UTC)
* 現象   : 平常時(66.01)に対し 1.181倍(77.96)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.303σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-036 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-035 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→17→13→17→18
* 開始   : 2026-06-05 17:05:00 (UTC)
* 終了   : 2026-06-05 17:05:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host01-006 (同一ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→12→8→11→12
* 開始   : 2026-06-05 20:05:00 (UTC)
* 終了   : 2026-06-05 20:05:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host01-011 (同一ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260605-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host08-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-072 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host01-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 40.54→45.15→41.22→40.61→…→39.59→36.14→36.2→38.57
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 19:15:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.731, 限界=7.23)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260606-host01-001 eu の推移](charts/EVT-20260606-host01-001.svg)

# イベントID( EVT-20260606-host01-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 13→12→10→12→…→13→12→15→12
* 開始   : 2026-06-06 05:40:00 (UTC)
* 終了   : 2026-06-06 18:00:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.215, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host01-001 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260606-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260606-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.1 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260606-host01-002 active_connections の推移](charts/EVT-20260606-host01-002.svg)

# イベントID( EVT-20260606-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→12→10→12→…→12→13→12→11
* 開始   : 2026-06-06 05:45:00 (UTC)
* 終了   : 2026-06-06 18:35:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.779, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host01-001 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260606-host01-003 active_connections の推移](charts/EVT-20260606-host01-003.svg)

# イベントID( EVT-20260606-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 12→10→12→10→…→11→12→11→13
* 開始   : 2026-06-06 05:45:00 (UTC)
* 終了   : 2026-06-06 19:40:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.379, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host01-001 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260606-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host01-004 active_connections の推移](charts/EVT-20260606-host01-004.svg)

# イベントID( EVT-20260606-host01-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→9→11→12→…→11→10→12→10
* 開始   : 2026-06-06 05:55:00 (UTC)
* 終了   : 2026-06-06 19:40:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.028, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host01-001 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260606-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260606-host01-005 active_connections の推移](charts/EVT-20260606-host01-005.svg)

# イベントID( EVT-20260606-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→11→17→13→…→13→14→13→12
* 開始   : 2026-06-06 06:30:00 (UTC)
* 終了   : 2026-06-06 19:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.503σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.448, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host01-001 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.8 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host01-006 active_connections の推移](charts/EVT-20260606-host01-006.svg)

# イベントID( EVT-20260606-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 14→13→11→12→…→11→12→11→13
* 開始   : 2026-06-06 06:35:00 (UTC)
* 終了   : 2026-06-06 18:50:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.727, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host01-001 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260606-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.7 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260606-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 10→8→4→5→…→4→5→9→6
* 開始   : 2026-06-07 00:45:00 (UTC)
* 終了   : 2026-06-07 00:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 7→11→4→9→8
* 開始   : 2026-06-07 01:05:00 (UTC)
* 終了   : 2026-06-07 01:05:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.243σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 16→14→11→17→16
* 開始   : 2026-06-07 12:05:00 (UTC)
* 終了   : 2026-06-07 12:05:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.6911(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 53.75→51.2→39.75→48.96→47.67
* 開始   : 2026-06-07 14:15:00 (UTC)
* 終了   : 2026-06-07 14:15:00 (UTC)
* 現象   : 平常時(52.13)に対し 0.7626(39.75)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.42σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 14→18→17→18→…→18→15→16→13
* 開始   : 2026-06-08 02:15:00 (UTC)
* 終了   : 2026-06-08 20:25:00 (UTC)
* 現象   : 2026-06-08 20:25:00 (UTC)を境に水準が 11.88から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.293, 限界=3.181)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.931, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host01-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→14→…→20→18→21→20
* 開始   : 2026-06-08 03:00:00 (UTC)
* 終了   : 2026-06-08 09:00:00 (UTC)
* 現象   : 2026-06-08 09:00:00 (UTC)を境に水準が 12.63から14.95へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.87, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.995, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→15→16→15→…→10→13→10→14
* 開始   : 2026-06-08 03:30:00 (UTC)
* 終了   : 2026-06-08 21:00:00 (UTC)
* 現象   : 2026-06-08 21:00:00 (UTC)を境に水準が 11.84から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.011, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.768, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→13→16→15→…→15→16→15→12
* 開始   : 2026-06-09 05:00:00 (UTC)
* 終了   : 2026-06-09 05:10:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260609-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→13→17→14→11
* 開始   : 2026-06-09 05:30:00 (UTC)
* 終了   : 2026-06-09 05:30:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 57.95→54.97→69.83→62.55→59.16
* 開始   : 2026-06-09 08:15:00 (UTC)
* 終了   : 2026-06-09 08:15:00 (UTC)
* 現象   : 平常時(58.23)に対し 1.199倍(69.83)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 19→21→23→18→18
* 開始   : 2026-06-09 08:20:00 (UTC)
* 終了   : 2026-06-09 08:20:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 18→18→13→14→15
* 開始   : 2026-06-09 17:15:00 (UTC)
* 終了   : 2026-06-09 18:00:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 15 分
  - EVT-20260609-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260609-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 48.66→51.17→38.7→48.65→43.97
* 開始   : 2026-06-09 18:50:00 (UTC)
* 終了   : 2026-06-09 18:50:00 (UTC)
* 現象   : 平常時(49.59)に対し 0.7803(38.7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.01σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→15→18→13→15
* 開始   : 2026-06-10 05:20:00 (UTC)
* 終了   : 2026-06-10 05:20:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.421倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.706σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host01-001 active_connections の推移](charts/EVT-20260610-host01-001.svg)

# イベントID( EVT-20260610-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 49.98→46.81→60.16→56.89→54.87
* 開始   : 2026-06-10 06:25:00 (UTC)
* 終了   : 2026-06-10 06:25:00 (UTC)
* 現象   : 平常時(49.16)に対し 1.224倍(60.16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 16→16→20→14→16
* 開始   : 2026-06-10 07:00:00 (UTC)
* 終了   : 2026-06-10 07:00:00 (UTC)
* 現象   : 平常時(15)に対し 1.333倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.474σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host01-003 active_connections の推移](charts/EVT-20260610-host01-003.svg)

# イベントID( EVT-20260610-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→16→21→17→19
* 開始   : 2026-06-10 07:25:00 (UTC)
* 終了   : 2026-06-10 07:25:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.306倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 19→20→24→19→19
* 開始   : 2026-06-10 08:35:00 (UTC)
* 終了   : 2026-06-10 08:35:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.28倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.648σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host01-005 active_connections の推移](charts/EVT-20260610-host01-005.svg)

# イベントID( EVT-20260610-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→13→11→12→…→12→9→11→10
* 開始   : 2026-06-10 19:30:00 (UTC)
* 終了   : 2026-06-10 19:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host01-007 active_connections の推移](charts/EVT-20260610-host01-007.svg)

# イベントID( EVT-20260610-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 10→11→6→8→9
* 開始   : 2026-06-10 21:25:00 (UTC)
* 終了   : 2026-06-10 21:25:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.5496(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.435σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→12→17→12→13
* 開始   : 2026-06-11 04:45:00 (UTC)
* 終了   : 2026-06-11 04:45:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.437倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.62σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host01-004 active_connections の推移](charts/EVT-20260611-host01-004.svg)

# イベントID( EVT-20260611-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→14→19→15→15
* 開始   : 2026-06-11 05:55:00 (UTC)
* 終了   : 2026-06-11 05:55:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.434倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.015σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host01-005 active_connections の推移](charts/EVT-20260611-host01-005.svg)

# イベントID( EVT-20260611-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 21→22→23→22→22→21→21→22
* 開始   : 2026-06-11 14:05:00 (UTC)
* 終了   : 2026-06-11 15:05:00 (UTC)
* 現象   : 2026-06-11 15:05:00 (UTC)を境に水準が 14.98から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.851, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 64.01→65.54→56.08→66.94→69.89
* 開始   : 2026-06-11 14:05:00 (UTC)
* 終了   : 2026-06-11 14:05:00 (UTC)
* 現象   : 平常時(67.4)に対し 0.8321(56.08)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 18→20→14→16→15
* 開始   : 2026-06-11 17:05:00 (UTC)
* 終了   : 2026-06-11 17:05:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host01-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 18→17→22→18→19
* 開始   : 2026-06-12 07:40:00 (UTC)
* 終了   : 2026-06-12 07:40:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.307倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.613σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host01-008 active_connections の推移](charts/EVT-20260612-host01-008.svg)

# イベントID( EVT-20260612-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 21→21→26→22→21
* 開始   : 2026-06-12 11:40:00 (UTC)
* 終了   : 2026-06-12 11:40:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 66.36→72.89→58.78→69.95→71.39
* 開始   : 2026-06-12 11:45:00 (UTC)
* 終了   : 2026-06-12 11:45:00 (UTC)
* 現象   : 平常時(70.56)に対し 0.833(58.78)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260612-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 44.01→44.79→35.06→45.21→41.15
* 開始   : 2026-06-12 19:20:00 (UTC)
* 終了   : 2026-06-12 19:20:00 (UTC)
* 現象   : 平常時(46.27)に対し 0.7577(35.06)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-083 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-084 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host01-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 11→12→11→12→…→13→12→14→11
* 開始   : 2026-06-13 04:40:00 (UTC)
* 終了   : 2026-06-13 19:05:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.735, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260613-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260613-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260613-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 12→10→9→10→…→11→13→14→11
* 開始   : 2026-06-13 05:05:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.775, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260613-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260613-host01-003 active_connections の推移](charts/EVT-20260613-host01-003.svg)

# イベントID( EVT-20260613-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 43.51→46.08→34.42→39.16→…→43.13→42.29→41.29→38.56
* 開始   : 2026-06-13 05:15:00 (UTC)
* 終了   : 2026-06-13 18:40:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.412, 限界=7.23)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260613-host01-004 eu の推移](charts/EVT-20260613-host01-004.svg)

# イベントID( EVT-20260613-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→11→12→11→…→10→12→13→12
* 開始   : 2026-06-13 05:30:00 (UTC)
* 終了   : 2026-06-13 18:40:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.627σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.96, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260613-host01-005 active_connections の推移](charts/EVT-20260613-host01-005.svg)

# イベントID( EVT-20260613-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→13→14→13→…→14→15→12→14
* 開始   : 2026-06-13 05:55:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.744, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260613-host01-006 active_connections の推移](charts/EVT-20260613-host01-006.svg)

# イベントID( EVT-20260613-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→13→9→11→…→13→12→13→11
* 開始   : 2026-06-13 06:00:00 (UTC)
* 終了   : 2026-06-13 19:20:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.977, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260613-host01-007 active_connections の推移](charts/EVT-20260613-host01-007.svg)

# イベントID( EVT-20260613-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→13→…→9→11→13→12
* 開始   : 2026-06-13 06:45:00 (UTC)
* 終了   : 2026-06-13 18:45:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.123, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 11.9 時間
  - EVT-20260613-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260613-host01-008 active_connections の推移](charts/EVT-20260613-host01-008.svg)

# イベントID( EVT-20260614-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→13→17→14→13
* 開始   : 2026-06-14 07:55:00 (UTC)
* 終了   : 2026-06-14 07:55:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→12→7→10→9
* 開始   : 2026-06-14 19:35:00 (UTC)
* 終了   : 2026-06-14 19:35:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 8→9→5→9→10
* 開始   : 2026-06-14 21:10:00 (UTC)
* 終了   : 2026-06-14 21:10:00 (UTC)
* 現象   : 平常時(10)に対し 0.5(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host01-008 active_connections の推移](charts/EVT-20260614-host01-008.svg)

# イベントID( EVT-20260615-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 16→18→17→18→…→15→16→13→15
* 開始   : 2026-06-15 01:40:00 (UTC)
* 終了   : 2026-06-15 22:05:00 (UTC)
* 現象   : 2026-06-15 22:05:00 (UTC)を境に水準が 11.78から15.03へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.234, 限界=3.181)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→17→12→17→16
* 開始   : 2026-06-16 17:35:00 (UTC)
* 終了   : 2026-06-16 17:35:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.6923(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.724σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host01-007 active_connections の推移](charts/EVT-20260616-host01-007.svg)

# イベントID( EVT-20260616-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 16→15→11→12→15→11→12→14
* 開始   : 2026-06-16 18:25:00 (UTC)
* 終了   : 2026-06-16 18:30:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→9→7→12→12
* 開始   : 2026-06-16 20:25:00 (UTC)
* 終了   : 2026-06-16 20:25:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260616-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→12→15→12→12
* 開始   : 2026-06-17 03:40:00 (UTC)
* 終了   : 2026-06-17 03:40:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 15→18→21→18→19
* 開始   : 2026-06-17 07:15:00 (UTC)
* 終了   : 2026-06-17 07:15:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.292倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 14→13→9→14→13
* 開始   : 2026-06-17 19:30:00 (UTC)
* 終了   : 2026-06-17 19:30:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-071 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host13-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 43.66→38.47→31.3→43.36→43.53
* 開始   : 2026-06-17 20:10:00 (UTC)
* 終了   : 2026-06-17 20:10:00 (UTC)
* 現象   : 平常時(42.3)に対し 0.74(31.3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host13-019 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 8→11→14→11→…→11→13→9→12
* 開始   : 2026-06-18 03:20:00 (UTC)
* 終了   : 2026-06-18 03:30:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.5倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 23→20→19→21→20→19→21
* 開始   : 2026-06-18 13:45:00 (UTC)
* 終了   : 2026-06-18 14:20:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-038 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-037 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260618-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→15→12→16→14
* 開始   : 2026-06-18 17:45:00 (UTC)
* 終了   : 2026-06-18 17:45:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7164(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→14→8→11→11
* 開始   : 2026-06-18 20:20:00 (UTC)
* 終了   : 2026-06-18 20:20:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-055 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260618-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→10→14→10→…→10→15→13→12
* 開始   : 2026-06-19 04:10:00 (UTC)
* 終了   : 2026-06-19 04:20:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.569σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→13→17→12→15
* 開始   : 2026-06-19 05:15:00 (UTC)
* 終了   : 2026-06-19 05:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→15→19→13→15
* 開始   : 2026-06-19 06:00:00 (UTC)
* 終了   : 2026-06-19 06:00:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.365倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.552σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host01-007 active_connections の推移](charts/EVT-20260619-host01-007.svg)

# イベントID( EVT-20260619-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 16→18→20→19→…→19→13→17→16
* 開始   : 2026-06-19 07:05:00 (UTC)
* 終了   : 2026-06-19 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-018 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260619-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→16→21→17→16
* 開始   : 2026-06-19 07:30:00 (UTC)
* 終了   : 2026-06-19 07:30:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 34.49→36.43→24.16→36.11→36.4
* 開始   : 2026-06-19 21:35:00 (UTC)
* 終了   : 2026-06-19 21:35:00 (UTC)
* 現象   : 平常時(36.62)に対し 0.6597(24.16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→8→6→11→10
* 開始   : 2026-06-19 21:55:00 (UTC)
* 終了   : 2026-06-19 21:55:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→8→6→13→8→6→13→8→9
* 開始   : 2026-06-20 03:15:00 (UTC)
* 終了   : 2026-06-20 04:20:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667倍(6)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260620-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260620-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260620-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-lsfhost01-004 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260620-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host01-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 38.25→36.2→34.23→35.73→…→40.06→45.9→43.09→39.52
* 開始   : 2026-06-20 04:50:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.485, 限界=7.23)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host01-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260620-host01-002 eu の推移](charts/EVT-20260620-host01-002.svg)

# イベントID( EVT-20260620-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→13→12→13→…→10→12→11→12
* 開始   : 2026-06-20 05:15:00 (UTC)
* 終了   : 2026-06-20 18:55:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.156σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.249, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-002 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260620-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260620-host01-004 active_connections の推移](charts/EVT-20260620-host01-004.svg)

# イベントID( EVT-20260620-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→11→10→12→…→11→12→13→11
* 開始   : 2026-06-20 05:55:00 (UTC)
* 終了   : 2026-06-20 18:45:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.173, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-002 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260620-host01-005 active_connections の推移](charts/EVT-20260620-host01-005.svg)

# イベントID( EVT-20260620-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→11→10→13→…→13→12→13→12
* 開始   : 2026-06-20 06:20:00 (UTC)
* 終了   : 2026-06-20 19:50:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.75, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host01-002 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260620-host01-006 active_connections の推移](charts/EVT-20260620-host01-006.svg)

# イベントID( EVT-20260620-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→12→10→12→…→11→10→12→9
* 開始   : 2026-06-20 06:20:00 (UTC)
* 終了   : 2026-06-20 19:55:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.776, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host01-002 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260620-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260620-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260620-host01-007 active_connections の推移](charts/EVT-20260620-host01-007.svg)

# イベントID( EVT-20260620-host01-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→14→13→14→…→11→12→11→13
* 開始   : 2026-06-20 06:50:00 (UTC)
* 終了   : 2026-06-20 18:45:00 (UTC)
* 現象   : 11.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.244, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-002 (同一ホスト) jvm_gc / eu : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間

![EVT-20260620-host01-008 active_connections の推移](charts/EVT-20260620-host01-008.svg)

# イベントID( EVT-20260620-host01-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 12→14→13→11→…→12→11→12→11
* 開始   : 2026-06-20 07:00:00 (UTC)
* 終了   : 2026-06-20 18:15:00 (UTC)
* 現象   : 11.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.572, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-002 (同一ホスト) jvm_gc / eu : FATAL / 重なり 11.2 時間
  - EVT-20260620-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260620-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間

![EVT-20260620-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→8→3→10→9
* 開始   : 2026-06-21 00:15:00 (UTC)
* 終了   : 2026-06-21 00:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.3214(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.428σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host01-001 active_connections の推移](charts/EVT-20260621-host01-001.svg)

# イベントID( EVT-20260622-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→14→16→13→…→14→12→14→12
* 開始   : 2026-06-22 02:50:00 (UTC)
* 終了   : 2026-06-22 20:45:00 (UTC)
* 現象   : 2026-06-22 20:45:00 (UTC)を境に水準が 11.87から14.89へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.438, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.134, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host01-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 14→16→15→16→…→15→17→15→16
* 開始   : 2026-06-22 03:35:00 (UTC)
* 終了   : 2026-06-22 20:30:00 (UTC)
* 現象   : 2026-06-22 20:30:00 (UTC)を境に水準が 11.91から14.91へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.355, 限界=3.181)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→11→6→11→10
* 開始   : 2026-06-22 20:20:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.5373(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.613σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260622-lsfhost01-052 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260622-host01-008 active_connections の推移](charts/EVT-20260622-host01-008.svg)

# イベントID( EVT-20260622-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 9→11→5→7→7
* 開始   : 2026-06-22 22:40:00 (UTC)
* 終了   : 2026-06-22 22:40:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260622-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 55.77→59.96→66.33→53.51→55.15
* 開始   : 2026-06-23 07:20:00 (UTC)
* 終了   : 2026-06-23 07:20:00 (UTC)
* 現象   : 平常時(53.67)に対し 1.236倍(66.33)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.5σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host01-005 eu の推移](charts/EVT-20260623-host01-005.svg)

# イベントID( EVT-20260623-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 19→19→20→23→18→18→21
* 開始   : 2026-06-23 07:50:00 (UTC)
* 終了   : 2026-06-23 08:20:00 (UTC)
* 現象   : 2026-06-23 08:20:00 (UTC)を境に水準が 15.01から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.668σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.879, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 18→17→23→20→21
* 開始   : 2026-06-23 08:50:00 (UTC)
* 終了   : 2026-06-23 08:50:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 60.8→54.88→47.5→53.66→53.8
* 開始   : 2026-06-23 16:50:00 (UTC)
* 終了   : 2026-06-23 16:50:00 (UTC)
* 現象   : 平常時(58.86)に対し 0.807(47.5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 14→13→10→11→13→10→11→14
* 開始   : 2026-06-23 18:40:00 (UTC)
* 終了   : 2026-06-23 18:45:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260623-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260623-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→11→8→11→11
* 開始   : 2026-06-23 20:05:00 (UTC)
* 終了   : 2026-06-23 20:05:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 7→8→12→6→7
* 開始   : 2026-06-24 00:15:00 (UTC)
* 終了   : 2026-06-24 00:15:00 (UTC)
* 現象   : 平常時(7.25)に対し 1.655倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 9→8→11→7→…→7→12→7→9
* 開始   : 2026-06-24 01:10:00 (UTC)
* 終了   : 2026-06-24 01:20:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-005 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260624-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 9→10→14→10→11
* 開始   : 2026-06-24 03:00:00 (UTC)
* 終了   : 2026-06-24 03:00:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→11→17→16→…→17→16→14→15
* 開始   : 2026-06-24 04:35:00 (UTC)
* 終了   : 2026-06-24 05:15:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260624-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host01-006 active_connections の推移](charts/EVT-20260624-host01-006.svg)

# イベントID( EVT-20260624-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 57.63→64.17→72.7→55.74→…→55.74→67.27→61.48→63.4
* 開始   : 2026-06-24 08:20:00 (UTC)
* 終了   : 2026-06-24 08:30:00 (UTC)
* 現象   : 平常時(58.3)に対し 1.247倍(72.7)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.98σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260624-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host01-009 eu の推移](charts/EVT-20260624-host01-009.svg)

# イベントID( EVT-20260624-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 20→20→17→21→20
* 開始   : 2026-06-24 15:05:00 (UTC)
* 終了   : 2026-06-24 15:05:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 52.58→55.76→41.2→49.9→49.1
* 開始   : 2026-06-24 18:10:00 (UTC)
* 終了   : 2026-06-24 18:10:00 (UTC)
* 現象   : 平常時(52.83)に対し 0.7799(41.2)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host12-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→12→9→12→12
* 開始   : 2026-06-24 19:35:00 (UTC)
* 終了   : 2026-06-24 19:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host12-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host01-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→9→6→9→8
* 開始   : 2026-06-24 21:25:00 (UTC)
* 終了   : 2026-06-24 21:25:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host01-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→10→15→10→12
* 開始   : 2026-06-25 02:55:00 (UTC)
* 終了   : 2026-06-25 02:55:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.579倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.843σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host01-001 active_connections の推移](charts/EVT-20260625-host01-001.svg)

# イベントID( EVT-20260625-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→14→17→12→…→12→16→14→15
* 開始   : 2026-06-25 05:10:00 (UTC)
* 終了   : 2026-06-25 05:20:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.416σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→14→17→19→…→17→19→15→16
* 開始   : 2026-06-25 06:10:00 (UTC)
* 終了   : 2026-06-25 06:15:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260625-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 20→16→14→18→17
* 開始   : 2026-06-25 16:45:00 (UTC)
* 終了   : 2026-06-25 16:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-062 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→12→9→13→12
* 開始   : 2026-06-25 19:20:00 (UTC)
* 終了   : 2026-06-25 19:20:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 14→13→9→10→9→10→9→13→12
* 開始   : 2026-06-25 20:05:00 (UTC)
* 終了   : 2026-06-25 21:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.447σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-012 (同一ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260625-host01-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-084 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260625-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host11-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 42.67→43.94→31.04→41.57→41.02
* 開始   : 2026-06-25 20:05:00 (UTC)
* 終了   : 2026-06-25 20:05:00 (UTC)
* 現象   : 平常時(43.31)に対し 0.7168(31.04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→10→7→9→10
* 開始   : 2026-06-25 20:30:00 (UTC)
* 終了   : 2026-06-25 20:30:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 42.64→45.71→53.33→47.22→50.3
* 開始   : 2026-06-26 05:20:00 (UTC)
* 終了   : 2026-06-26 05:20:00 (UTC)
* 現象   : 平常時(42.38)に対し 1.258倍(53.33)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 21→20→24→18→21
* 開始   : 2026-06-26 09:20:00 (UTC)
* 終了   : 2026-06-26 09:20:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.241倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 19→21→24→21→20
* 開始   : 2026-06-26 09:20:00 (UTC)
* 終了   : 2026-06-26 09:20:00 (UTC)
* 現象   : 平常時(19.17)に対し 1.252倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.377σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 19→20→24→21→…→21→23→22→23
* 開始   : 2026-06-26 09:55:00 (UTC)
* 終了   : 2026-06-26 10:05:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 21→21→17→20→22
* 開始   : 2026-06-26 14:15:00 (UTC)
* 終了   : 2026-06-26 14:15:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→16→10→14→10→14→10→14→12
* 開始   : 2026-06-26 18:50:00 (UTC)
* 終了   : 2026-06-26 19:00:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host01-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→11→10→13→…→12→10→12→11
* 開始   : 2026-06-27 04:40:00 (UTC)
* 終了   : 2026-06-27 19:25:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.747, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 14.1 時間
  - EVT-20260627-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.7 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260627-host01-002 active_connections の推移](charts/EVT-20260627-host01-002.svg)

# イベントID( EVT-20260627-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→11→13→12→…→12→10→12→11
* 開始   : 2026-06-27 05:15:00 (UTC)
* 終了   : 2026-06-27 19:10:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.123, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260627-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260627-host01-003 active_connections の推移](charts/EVT-20260627-host01-003.svg)

# イベントID( EVT-20260627-host01-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 38.37→35.01→36.61→40.03→…→36.82→37.76→38→39.43
* 開始   : 2026-06-27 05:20:00 (UTC)
* 終了   : 2026-06-27 19:25:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.858, 限界=7.23)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260627-host01-004 eu の推移](charts/EVT-20260627-host01-004.svg)

# イベントID( EVT-20260627-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→14→13→12→…→13→12→13→11
* 開始   : 2026-06-27 05:40:00 (UTC)
* 終了   : 2026-06-27 18:05:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.786, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260627-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260627-host01-005 active_connections の推移](charts/EVT-20260627-host01-005.svg)

# イベントID( EVT-20260627-host01-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 14→12→13→15→…→11→13→14→12
* 開始   : 2026-06-27 06:00:00 (UTC)
* 終了   : 2026-06-27 18:05:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.352, 限界=3.181)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260627-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host01-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→13→10→13→…→12→11→14→13
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 18:45:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.879, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260627-host01-007 active_connections の推移](charts/EVT-20260627-host01-007.svg)

# イベントID( EVT-20260627-host01-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→11→…→14→13→14→15
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 19:05:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.05, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host01-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host01-004 (同一ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260627-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260627-host01-008 active_connections の推移](charts/EVT-20260627-host01-008.svg)

# イベントID( EVT-20260628-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→10→7→11→11
* 開始   : 2026-06-28 19:00:00 (UTC)
* 終了   : 2026-06-28 19:00:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6043(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260628-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 36.7→40.22→26.5→38→35.98
* 開始   : 2026-06-28 20:05:00 (UTC)
* 終了   : 2026-06-28 20:05:00 (UTC)
* 現象   : 平常時(38.08)に対し 0.6959(26.5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-037 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260628-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 10→9→8→9→10→10
* 開始   : 2026-06-28 23:30:00 (UTC)
* 終了   : 2026-06-29 00:10:00 (UTC)
* 現象   : 2026-06-29 00:10:00 (UTC)を境に水準が 11.79から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.328σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.79, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host01-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→14→13→15→…→15→14→16→15
* 開始   : 2026-06-29 02:35:00 (UTC)
* 終了   : 2026-06-29 20:15:00 (UTC)
* 現象   : 2026-06-29 20:15:00 (UTC)を境に水準が 11.79から14.93へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.761, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host01-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 15→16→15→16→…→15→14→12→14
* 開始   : 2026-06-29 03:10:00 (UTC)
* 終了   : 2026-06-29 20:50:00 (UTC)
* 現象   : 2026-06-29 20:50:00 (UTC)を境に水準が 11.82から14.88へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.622, 限界=3.181)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→9→14→12→10
* 開始   : 2026-06-30 03:15:00 (UTC)
* 終了   : 2026-06-30 03:15:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→15→19→14→15
* 開始   : 2026-06-30 06:15:00 (UTC)
* 終了   : 2026-06-30 06:15:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.349倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host01-002 active_connections の推移](charts/EVT-20260630-host01-002.svg)

# イベントID( EVT-20260630-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 18→17→13→14→…→13→14→15→14
* 開始   : 2026-06-30 17:05:00 (UTC)
* 終了   : 2026-06-30 17:10:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.301σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260630-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260630-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 18→16→13→16→13→16→15
* 開始   : 2026-06-30 17:40:00 (UTC)
* 終了   : 2026-06-30 17:45:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260630-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 15→16→12→11→…→12→11→14→15
* 開始   : 2026-06-30 18:25:00 (UTC)
* 終了   : 2026-06-30 18:30:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.7619(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→10→6→8→10
* 開始   : 2026-06-30 21:30:00 (UTC)
* 終了   : 2026-06-30 21:30:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.185σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 6→5→12→8→7
* 開始   : 2026-06-30 23:20:00 (UTC)
* 終了   : 2026-06-30 23:20:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 8→9→5→8→5→8→5→8→7
* 開始   : 2026-06-01 00:35:00 (UTC)
* 終了   : 2026-06-01 00:45:00 (UTC)
* 現象   : 平常時(8.429)に対し 0.5932(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 16→17→20→19→20→19→20→18→19
* 開始   : 2026-06-01 07:35:00 (UTC)
* 終了   : 2026-06-01 07:45:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.548σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 60.79→64.23→68.47→61.2→…→61.2→68.19→66.12→58.44
* 開始   : 2026-06-01 08:40:00 (UTC)
* 終了   : 2026-06-01 08:50:00 (UTC)
* 現象   : 平常時(59.22)に対し 1.156倍(68.47)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 20→21→22→19→…→19→23→20→21
* 開始   : 2026-06-01 08:55:00 (UTC)
* 終了   : 2026-06-01 09:05:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→13→…→13→9→12→11
* 開始   : 2026-06-01 19:40:00 (UTC)
* 終了   : 2026-06-01 19:50:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-016 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260601-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260601-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→11→10→12→…→12→9→11→12
* 開始   : 2026-06-01 19:45:00 (UTC)
* 終了   : 2026-06-01 19:55:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260601-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 31.31→33.28→37.43→21.98→…→21.98→36.89→35.66→27.19
* 開始   : 2026-06-02 01:25:00 (UTC)
* 終了   : 2026-06-02 01:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.23σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-004 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260602-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 10→11→15→14→11→15→14
* 開始   : 2026-06-02 04:55:00 (UTC)
* 終了   : 2026-06-02 05:00:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.353倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.737σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 44.91→40.64→50.26→49.74→…→50.26→49.74→44.62→47.84
* 開始   : 2026-06-02 05:10:00 (UTC)
* 終了   : 2026-06-02 05:15:00 (UTC)
* 現象   : 平常時(42.08)に対し 1.194倍(50.26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260602-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→14→16→17→16→17→15
* 開始   : 2026-06-02 05:25:00 (UTC)
* 終了   : 2026-06-02 05:35:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260602-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 22→24→19→23→24→19→23→22
* 開始   : 2026-06-02 11:05:00 (UTC)
* 終了   : 2026-06-02 11:10:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 24→24→23→24→25→22→21→21→23
* 開始   : 2026-06-02 11:55:00 (UTC)
* 終了   : 2026-06-02 13:10:00 (UTC)
* 現象   : 2026-06-02 13:10:00 (UTC)を境に水準が 14.97から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.009, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 19→23→19→16→23→19→16→18→19
* 開始   : 2026-06-02 15:25:00 (UTC)
* 終了   : 2026-06-02 15:35:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.185倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 18→17→17→18→16→15→16→13→16
* 開始   : 2026-06-02 16:45:00 (UTC)
* 終了   : 2026-06-02 18:30:00 (UTC)
* 現象   : 2026-06-02 18:30:00 (UTC)を境に水準が 14.86から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.224, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→17→14→17→14→16
* 開始   : 2026-06-02 17:15:00 (UTC)
* 終了   : 2026-06-02 17:20:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.785(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.677σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260602-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 50.38→55.85→42.79→42.41→…→42.79→42.41→44.23→47.33
* 開始   : 2026-06-02 18:10:00 (UTC)
* 終了   : 2026-06-02 18:15:00 (UTC)
* 現象   : 平常時(52.11)に対し 0.8212(42.79)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.575σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 9→10→13→10→13→10→9
* 開始   : 2026-06-03 03:10:00 (UTC)
* 終了   : 2026-06-03 03:15:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.405倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260603-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→14→12→11→14→12→13
* 開始   : 2026-06-03 04:15:00 (UTC)
* 終了   : 2026-06-03 04:20:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 24→23→22→25→21→20→21→22→22
* 開始   : 2026-06-03 12:40:00 (UTC)
* 終了   : 2026-06-03 13:50:00 (UTC)
* 現象   : 2026-06-03 13:50:00 (UTC)を境に水準が 14.94から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.198, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 22→21→22→24→22→21→20→22→21
* 開始   : 2026-06-03 13:35:00 (UTC)
* 終了   : 2026-06-03 14:25:00 (UTC)
* 現象   : 2026-06-03 14:25:00 (UTC)を境に水準が 14.98から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 21→22→21→21→21→19→18→20→20
* 開始   : 2026-06-03 14:30:00 (UTC)
* 終了   : 2026-06-03 15:45:00 (UTC)
* 現象   : 2026-06-03 15:45:00 (UTC)を境に水準が 14.91から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 46.95→42.5→37.73→42.63→…→42.63→37.7→42.08→43.82
* 開始   : 2026-06-03 19:25:00 (UTC)
* 終了   : 2026-06-03 19:35:00 (UTC)
* 現象   : 平常時(45.97)に対し 0.8207(37.73)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→13→11→10→…→11→10→12→11
* 開始   : 2026-06-03 19:30:00 (UTC)
* 終了   : 2026-06-03 19:35:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-009 (同一ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260603-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 10→9→5→12→10→9→5→12→10
* 開始   : 2026-06-03 22:20:00 (UTC)
* 終了   : 2026-06-03 22:25:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.5714(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.622σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-082 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 37.01→42.71→44.66→41.46→…→41.46→46.02→45.53→45.96
* 開始   : 2026-06-04 04:20:00 (UTC)
* 終了   : 2026-06-04 04:30:00 (UTC)
* 現象   : 平常時(37.15)に対し 1.202倍(44.66)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 15→16→18→17→…→17→19→18→17
* 開始   : 2026-06-04 06:45:00 (UTC)
* 終了   : 2026-06-04 06:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 57.25→56.3→46.37→52.29→…→52.29→60.61→57.2→59.68
* 開始   : 2026-06-04 07:25:00 (UTC)
* 終了   : 2026-06-04 07:35:00 (UTC)
* 現象   : 平常時(53.99)に対し 0.8589(46.37)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 19→22→21→22→…→20→23→19→20
* 開始   : 2026-06-04 08:40:00 (UTC)
* 終了   : 2026-06-04 09:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 23→22→25→24
* 開始   : 2026-06-04 13:25:00 (UTC)
* 終了   : 2026-06-04 13:40:00 (UTC)
* 現象   : 2026-06-04 13:40:00 (UTC)を境に水準が 15.06から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 15→15→14→14→13→12→12→13→14
* 開始   : 2026-06-04 18:50:00 (UTC)
* 終了   : 2026-06-04 19:45:00 (UTC)
* 現象   : 2026-06-04 19:45:00 (UTC)を境に水準が 14.81から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.277, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→11→8→9→8→9→8→11→9
* 開始   : 2026-06-04 21:00:00 (UTC)
* 終了   : 2026-06-04 21:10:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 9→6→10→6→10→6→8→10
* 開始   : 2026-06-04 21:35:00 (UTC)
* 終了   : 2026-06-04 21:45:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.595(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.851σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 12→13→12→15→16→17
* 開始   : 2026-06-05 04:40:00 (UTC)
* 終了   : 2026-06-05 05:05:00 (UTC)
* 現象   : 2026-06-05 05:05:00 (UTC)を境に水準が 14.92から15.55へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.024σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.879, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 18→19→15→17→17→18
* 開始   : 2026-06-05 06:30:00 (UTC)
* 終了   : 2026-06-05 06:55:00 (UTC)
* 現象   : 2026-06-05 06:55:00 (UTC)を境に水準が 14.89から14.54へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.795, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 61.54→55.99→50.71→49.98→…→50.71→49.98→58.5→57.76
* 開始   : 2026-06-05 17:00:00 (UTC)
* 終了   : 2026-06-05 17:05:00 (UTC)
* 現象   : 平常時(58.28)に対し 0.87(50.71)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host01-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 16→17→14→15→…→15→13→14→13
* 開始   : 2026-06-05 17:55:00 (UTC)
* 終了   : 2026-06-05 18:05:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 15→12→13→13→14
* 開始   : 2026-06-05 19:25:00 (UTC)
* 終了   : 2026-06-05 19:45:00 (UTC)
* 現象   : 2026-06-05 19:45:00 (UTC)を境に水準が 15.71から11.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.733, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→10→12→9→10→12→9→13→11
* 開始   : 2026-06-05 19:40:00 (UTC)
* 終了   : 2026-06-05 19:50:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260605-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-070 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260605-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 42.13→37.55→33.35→33.77→…→33.35→33.77→42.35→37.78
* 開始   : 2026-06-05 20:00:00 (UTC)
* 終了   : 2026-06-05 20:05:00 (UTC)
* 現象   : 平常時(42.48)に対し 0.7851(33.35)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.523σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host01-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host08-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-072 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→11→7→10→11→7→10
* 開始   : 2026-06-05 21:05:00 (UTC)
* 終了   : 2026-06-05 21:10:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.6316(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.861σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-078 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-076 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-077 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→7→10→9→7→10
* 開始   : 2026-06-05 21:20:00 (UTC)
* 終了   : 2026-06-05 21:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.6562(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.564σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-079 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260605-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-078 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 30.18→29.62→38.37→23.24→…→38.37→23.24→29.04→35.6
* 開始   : 2026-06-06 22:15:00 (UTC)
* 終了   : 2026-06-06 22:20:00 (UTC)
* 現象   : 平常時(30.71)に対し 1.249倍(38.37)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.116σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 8→9→5→4→…→5→4→6→9
* 開始   : 2026-06-07 00:10:00 (UTC)
* 終了   : 2026-06-07 00:15:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260607-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260607-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→10→12→9→…→9→13→10→8
* 開始   : 2026-06-07 04:00:00 (UTC)
* 終了   : 2026-06-07 04:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260607-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→15→13→13→14→15→15→15→17
* 開始   : 2026-06-07 07:40:00 (UTC)
* 終了   : 2026-06-07 08:55:00 (UTC)
* 現象   : 2026-06-07 08:55:00 (UTC)を境に水準が 11.8から12.68へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.01, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 48.27→46.85→56.5→39.44→…→56.5→39.44→48.67→49.47
* 開始   : 2026-06-07 08:45:00 (UTC)
* 終了   : 2026-06-07 08:50:00 (UTC)
* 現象   : 平常時(47.11)に対し 1.199倍(56.5)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.594σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260607-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 15→17→17→16→17→15→15→15→15
* 開始   : 2026-06-07 14:35:00 (UTC)
* 終了   : 2026-06-07 15:30:00 (UTC)
* 現象   : 2026-06-07 15:30:00 (UTC)を境に水準が 11.84から14.32へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.759, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host01-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→9→12→9
* 開始   : 2026-06-07 22:40:00 (UTC)
* 終了   : 2026-06-07 22:55:00 (UTC)
* 現象   : 2026-06-07 22:55:00 (UTC)を境に水準が 11.72から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.915, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→9→10→9→9→9→9
* 開始   : 2026-06-08 21:35:00 (UTC)
* 終了   : 2026-06-08 22:05:00 (UTC)
* 現象   : 2026-06-08 22:05:00 (UTC)を境に水準が 15から14.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 33.93→31.09→36.93→33.94→30.09→27.06→35.42→33.71→33.04
* 開始   : 2026-06-09 00:10:00 (UTC)
* 終了   : 2026-06-09 00:55:00 (UTC)
* 現象   : 2026-06-09 00:55:00 (UTC)を境に水準が 49.95から49.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=22.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 39.56→42.46→49.68→48.52→…→44.13→49.55→45.96→39.75
* 開始   : 2026-06-09 04:40:00 (UTC)
* 終了   : 2026-06-09 04:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.588σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 17→12→17→19→…→17→19→16→17
* 開始   : 2026-06-09 06:35:00 (UTC)
* 終了   : 2026-06-09 06:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260609-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 20→19→23→19→23→19→23→21→22
* 開始   : 2026-06-09 09:25:00 (UTC)
* 終了   : 2026-06-09 09:35:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 24→24→23→22→23→21→24
* 開始   : 2026-06-09 12:10:00 (UTC)
* 終了   : 2026-06-09 12:40:00 (UTC)
* 現象   : 2026-06-09 12:40:00 (UTC)を境に水準が 14.96から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 66.13→69.33→70.15→71.03→66.43→72.93
* 開始   : 2026-06-09 14:20:00 (UTC)
* 終了   : 2026-06-09 14:45:00 (UTC)
* 現象   : 2026-06-09 14:45:00 (UTC)を境に水準が 49.93から50.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=21.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 17→16→19→16→15→16→18→15
* 開始   : 2026-06-09 17:25:00 (UTC)
* 終了   : 2026-06-09 18:00:00 (UTC)
* 現象   : 2026-06-09 18:00:00 (UTC)を境に水準が 14.99から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.059, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 19→17→15→16→16→16→17→15
* 開始   : 2026-06-09 17:35:00 (UTC)
* 終了   : 2026-06-09 18:10:00 (UTC)
* 現象   : 2026-06-09 18:10:00 (UTC)を境に水準が 14.94から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→14→16→9→…→16→9→12→13
* 開始   : 2026-06-09 19:50:00 (UTC)
* 終了   : 2026-06-09 19:55:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 9→10→7→9→…→9→13→10→8
* 開始   : 2026-06-09 21:35:00 (UTC)
* 終了   : 2026-06-09 21:45:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host16-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-078 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260609-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host01-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→9→9→9→8→9→7→8
* 開始   : 2026-06-09 23:45:00 (UTC)
* 終了   : 2026-06-10 00:20:00 (UTC)
* 現象   : 2026-06-10 00:20:00 (UTC)を境に水準が 14.85から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.851, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host01-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 22→21→21→21→22→23→22
* 開始   : 2026-06-10 09:20:00 (UTC)
* 終了   : 2026-06-10 09:50:00 (UTC)
* 現象   : 2026-06-10 09:50:00 (UTC)を境に水準が 14.97から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.026, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→10→8→13→8→13→8→11→8
* 開始   : 2026-06-10 21:20:00 (UTC)
* 終了   : 2026-06-10 21:30:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host01-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→7→11→7→…→7→12→8→7
* 開始   : 2026-06-11 00:55:00 (UTC)
* 終了   : 2026-06-11 01:05:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-004 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260611-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→9→12→9→12→9→12→10→8
* 開始   : 2026-06-11 02:35:00 (UTC)
* 終了   : 2026-06-11 02:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260611-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→11→14→12→11→14→12→14
* 開始   : 2026-06-11 04:05:00 (UTC)
* 終了   : 2026-06-11 04:10:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 18→20→22→15→…→22→15→18→17
* 開始   : 2026-06-11 08:35:00 (UTC)
* 終了   : 2026-06-11 08:40:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host01-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 18→20→21→20→…→20→22→21→20
* 開始   : 2026-06-11 08:40:00 (UTC)
* 終了   : 2026-06-11 08:50:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host01-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 22→21→20→22→21→21→22→23
* 開始   : 2026-06-11 09:35:00 (UTC)
* 終了   : 2026-06-11 10:10:00 (UTC)
* 現象   : 2026-06-11 10:10:00 (UTC)を境に水準が 14.84から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 62.53→63.05→71.44→67.85→…→67.85→74.13→66.24→69.28
* 開始   : 2026-06-11 10:00:00 (UTC)
* 終了   : 2026-06-11 10:10:00 (UTC)
* 現象   : 平常時(64.09)に対し 1.115倍(71.44)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 22→21→21→21→21→22→22→22→22
* 開始   : 2026-06-11 12:50:00 (UTC)
* 終了   : 2026-06-11 14:40:00 (UTC)
* 現象   : 2026-06-11 14:40:00 (UTC)を境に水準が 14.83から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.49σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 19→18→15→17→18→15→17→16
* 開始   : 2026-06-11 17:05:00 (UTC)
* 終了   : 2026-06-11 17:10:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host01-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→13→15→12→13→15→12→13→15
* 開始   : 2026-06-11 18:00:00 (UTC)
* 終了   : 2026-06-11 18:10:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260611-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260611-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 9→12→6→7→12→6→7→10
* 開始   : 2026-06-11 21:55:00 (UTC)
* 終了   : 2026-06-11 22:00:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.5854(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.978σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-079 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 5→6→10→8→…→8→11→7→9
* 開始   : 2026-06-12 00:45:00 (UTC)
* 終了   : 2026-06-12 00:55:00 (UTC)
* 現象   : 平常時(7.083)に対し 1.412倍(10)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 9→10→13→10→13→10
* 開始   : 2026-06-12 02:45:00 (UTC)
* 終了   : 2026-06-12 02:50:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.472倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.914σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 9→10→13→12→10→13→12→11
* 開始   : 2026-06-12 03:20:00 (UTC)
* 終了   : 2026-06-12 03:25:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.393倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 13→16→13→16→13→16→13→15
* 開始   : 2026-06-12 05:00:00 (UTC)
* 終了   : 2026-06-12 05:10:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.343倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.853σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→16→18→18→16→16→17→18→17
* 開始   : 2026-06-12 05:10:00 (UTC)
* 終了   : 2026-06-12 07:00:00 (UTC)
* 現象   : 2026-06-12 07:00:00 (UTC)を境に水準が 14.88から14.62へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.457, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 14→13→17→16→17→16→17→15→16
* 開始   : 2026-06-12 06:00:00 (UTC)
* 終了   : 2026-06-12 06:10:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.564σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260612-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-034 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→16→18→17→18→17→18→17→15
* 開始   : 2026-06-12 06:25:00 (UTC)
* 終了   : 2026-06-12 06:35:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.256倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.548σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-036 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-035 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 19→20→19→21
* 開始   : 2026-06-12 08:10:00 (UTC)
* 終了   : 2026-06-12 08:25:00 (UTC)
* 現象   : 2026-06-12 08:25:00 (UTC)を境に水準が 14.97から14.34へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 24→22→22→22→21→21→20→22
* 開始   : 2026-06-12 13:30:00 (UTC)
* 終了   : 2026-06-12 14:05:00 (UTC)
* 現象   : 2026-06-12 14:05:00 (UTC)を境に水準が 15から12.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.059, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 21→17→20→17→…→19→20→17→19
* 開始   : 2026-06-12 15:15:00 (UTC)
* 終了   : 2026-06-12 15:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260612-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 18→16→14→15→13→14→15→13→15
* 開始   : 2026-06-12 17:30:00 (UTC)
* 終了   : 2026-06-12 17:40:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.785(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.664σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 17→16→15→14→16→14→15→15→13
* 開始   : 2026-06-12 17:50:00 (UTC)
* 終了   : 2026-06-12 18:35:00 (UTC)
* 現象   : 2026-06-12 18:35:00 (UTC)を境に水準が 14.81から12.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.255, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host01-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→12→…→12→9→12→11
* 開始   : 2026-06-12 19:40:00 (UTC)
* 終了   : 2026-06-12 19:50:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host01-018 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host01-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 12→9→11→9→11→9→13→10
* 開始   : 2026-06-12 19:45:00 (UTC)
* 終了   : 2026-06-12 19:55:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host01-017 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host01-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host01-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 11→8→14→10→11→8→14→10
* 開始   : 2026-06-12 20:55:00 (UTC)
* 終了   : 2026-06-12 21:00:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-089 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-088 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host01-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 7→10→4→10→…→10→11→9→10
* 開始   : 2026-06-13 00:50:00 (UTC)
* 終了   : 2026-06-13 01:00:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.4898(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.911σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260613-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→9→5→11→8→9→5→11→8
* 開始   : 2026-06-14 00:35:00 (UTC)
* 終了   : 2026-06-14 00:40:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260614-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 12→11→10→11→12→11→11→13→12
* 開始   : 2026-06-14 04:55:00 (UTC)
* 終了   : 2026-06-14 05:35:00 (UTC)
* 現象   : 2026-06-14 05:35:00 (UTC)を境に水準が 11.73から12.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.319, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→16→17→16→15→18
* 開始   : 2026-06-14 10:45:00 (UTC)
* 終了   : 2026-06-14 11:10:00 (UTC)
* 現象   : 2026-06-14 11:10:00 (UTC)を境に水準が 11.91から13.28へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.638, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→18→16→12→18→16→12→15→16
* 開始   : 2026-06-14 14:10:00 (UTC)
* 終了   : 2026-06-14 14:20:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260614-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260614-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host01-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→12→14→11→11→12→13→13
* 開始   : 2026-06-14 18:45:00 (UTC)
* 終了   : 2026-06-14 19:20:00 (UTC)
* 現象   : 2026-06-14 19:20:00 (UTC)を境に水準が 11.85から14.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.852, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 10→6→11→9→8→9→8→9→10
* 開始   : 2026-06-15 00:45:00 (UTC)
* 終了   : 2026-06-15 01:40:00 (UTC)
* 現象   : 2026-06-15 01:40:00 (UTC)を境に水準が 11.83から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.394σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 7→8→11→8→11→8→9
* 開始   : 2026-06-16 00:45:00 (UTC)
* 終了   : 2026-06-16 00:50:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-003 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260616-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 43.19→44.81→51.3→46.99→…→46.99→37.23→43.26→51.78
* 開始   : 2026-06-16 04:40:00 (UTC)
* 終了   : 2026-06-16 05:10:00 (UTC)
* 現象   : 平常時(41.19)に対し 1.187倍(48.89)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260616-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 13→11→15→12→11→15→12→14
* 開始   : 2026-06-16 04:50:00 (UTC)
* 終了   : 2026-06-16 04:55:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-002 (同一ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260616-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 52.4→48.42→55.25→49.36→…→49.36→57.11→49.75→55.57
* 開始   : 2026-06-16 06:15:00 (UTC)
* 終了   : 2026-06-16 06:25:00 (UTC)
* 現象   : 平常時(47.89)に対し 1.154倍(55.25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260616-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 50.09→58.75→62.29→57.2→…→57.2→64.64→56.46→62.01
* 開始   : 2026-06-16 07:50:00 (UTC)
* 終了   : 2026-06-16 08:00:00 (UTC)
* 現象   : 平常時(53.47)に対し 1.165倍(62.29)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.437σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 18→19→24→23→19→24→23→22
* 開始   : 2026-06-16 10:15:00 (UTC)
* 終了   : 2026-06-16 10:20:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.195倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.737σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260616-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→18→13→14→…→14→12→17→15
* 開始   : 2026-06-16 18:00:00 (UTC)
* 終了   : 2026-06-16 18:10:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260616-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260616-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 41.86→47.77→38.36→41.79→…→41.79→37.89→43.4→44.47
* 開始   : 2026-06-16 19:05:00 (UTC)
* 終了   : 2026-06-16 19:15:00 (UTC)
* 現象   : 平常時(47.55)に対し 0.8067(38.36)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.54σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-060 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260616-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 13→14→12→14→11→11
* 開始   : 2026-06-16 19:55:00 (UTC)
* 終了   : 2026-06-16 21:00:00 (UTC)
* 現象   : 2026-06-16 21:00:00 (UTC)を境に水準が 14.96から14.83へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.638, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→11→10→11→11→12→10→10→10
* 開始   : 2026-06-16 20:50:00 (UTC)
* 終了   : 2026-06-16 21:40:00 (UTC)
* 現象   : 2026-06-16 21:40:00 (UTC)を境に水準が 14.94から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.768, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 35.08→39.2→30.6→29.8→…→30.6→29.8→35.02→33.5
* 開始   : 2026-06-16 21:00:00 (UTC)
* 終了   : 2026-06-16 21:05:00 (UTC)
* 現象   : 平常時(38.23)に対し 0.8005(30.6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 57.85→56.35→52.32→49.98→55.55→58.58→60.51→59.38→58.95
* 開始   : 2026-06-17 06:40:00 (UTC)
* 終了   : 2026-06-17 07:30:00 (UTC)
* 現象   : 2026-06-17 07:30:00 (UTC)を境に水準が 49.92から49.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=21.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 14→18→19→18→…→19→20→19→18
* 開始   : 2026-06-17 07:25:00 (UTC)
* 終了   : 2026-06-17 07:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 17→15→13→16→…→16→12→17→16
* 開始   : 2026-06-17 17:05:00 (UTC)
* 終了   : 2026-06-17 17:50:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host01-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260617-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 18→16→15→14→…→15→14→15→17
* 開始   : 2026-06-17 17:15:00 (UTC)
* 終了   : 2026-06-17 17:20:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host01-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 49.79→49.37→41.55→43.06→…→41.55→43.06→44.68→47.64
* 開始   : 2026-06-17 18:20:00 (UTC)
* 終了   : 2026-06-17 18:25:00 (UTC)
* 現象   : 平常時(51.71)に対し 0.8036(41.55)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.807σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 12→13→11→12→…→12→10→12→13
* 開始   : 2026-06-17 19:05:00 (UTC)
* 終了   : 2026-06-17 19:15:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 27.57→28.7→23.18→22.17→…→23.18→22.17→29.86→24.11
* 開始   : 2026-06-18 00:00:00 (UTC)
* 終了   : 2026-06-18 01:10:00 (UTC)
* 現象   : 平常時(32.29)に対し 0.7179倍(23.18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.517σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-003 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-002 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260618-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 49.01→45.67→48.82→45.27→52.95→47.05→53.95
* 開始   : 2026-06-18 04:50:00 (UTC)
* 終了   : 2026-06-18 05:20:00 (UTC)
* 現象   : 2026-06-18 05:20:00 (UTC)を境に水準が 49.65から50.23へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=21.89, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 13→17→13→18→17→13→18→15
* 開始   : 2026-06-18 06:00:00 (UTC)
* 終了   : 2026-06-18 06:30:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260618-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 18→19→23→21→19→23→21→20
* 開始   : 2026-06-18 09:10:00 (UTC)
* 終了   : 2026-06-18 09:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.185倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 19→21→24→18→…→24→18→22→21
* 開始   : 2026-06-18 10:00:00 (UTC)
* 終了   : 2026-06-18 10:05:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260618-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 23→22→24→23→22→24→23
* 開始   : 2026-06-18 13:05:00 (UTC)
* 終了   : 2026-06-18 13:35:00 (UTC)
* 現象   : 2026-06-18 13:35:00 (UTC)を境に水準が 15.07から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.026, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 22→21→19→20→20→23
* 開始   : 2026-06-18 14:55:00 (UTC)
* 終了   : 2026-06-18 15:20:00 (UTC)
* 現象   : 2026-06-18 15:20:00 (UTC)を境に水準が 14.9から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.638, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 66.2→65.88→60.51→58.35→61.37→66.67→57.17→59.77→55.42
* 開始   : 2026-06-18 15:20:00 (UTC)
* 終了   : 2026-06-18 16:45:00 (UTC)
* 現象   : 2026-06-18 16:45:00 (UTC)を境に水準が 49.89から50.17へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=22.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host01-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 19→20→17→15→17→18→16→17
* 開始   : 2026-06-18 17:05:00 (UTC)
* 終了   : 2026-06-18 17:40:00 (UTC)
* 現象   : 2026-06-18 17:40:00 (UTC)を境に水準が 14.96から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.851, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 30.62→30.14→28.48→28.72→32.1→28.88→35.77→33.8→31.17
* 開始   : 2026-06-19 00:00:00 (UTC)
* 終了   : 2026-06-19 00:55:00 (UTC)
* 現象   : 2026-06-19 00:55:00 (UTC)を境に水準が 49.94から49.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=21.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 29.68→37.46→41.07→31.31→…→31.31→40.9→38.09→40.74
* 開始   : 2026-06-19 02:20:00 (UTC)
* 終了   : 2026-06-19 02:30:00 (UTC)
* 現象   : 平常時(33.26)に対し 1.235倍(41.07)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 13→10→11→13
* 開始   : 2026-06-19 02:30:00 (UTC)
* 終了   : 2026-06-19 02:45:00 (UTC)
* 現象   : 2026-06-19 02:45:00 (UTC)を境に水準が 15.07から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 12→9→13→14→…→13→14→12→11
* 開始   : 2026-06-19 04:05:00 (UTC)
* 終了   : 2026-06-19 04:10:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 21→23→18→25→…→18→25→21→23
* 開始   : 2026-06-19 11:10:00 (UTC)
* 終了   : 2026-06-19 11:15:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-034 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260619-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 21→25→23→21→25→23→22
* 開始   : 2026-06-19 12:50:00 (UTC)
* 終了   : 2026-06-19 12:55:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.158倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host01-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 20→18→16→19→…→20→16→19→18
* 開始   : 2026-06-19 15:45:00 (UTC)
* 終了   : 2026-06-19 16:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.678σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260619-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 20 分
  - EVT-20260619-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 15 分
  - EVT-20260619-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 16→14→17→16→14→17→16
* 開始   : 2026-06-19 17:15:00 (UTC)
* 終了   : 2026-06-19 17:20:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260619-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→14→13→14→…→14→12→17→16
* 開始   : 2026-06-19 17:45:00 (UTC)
* 終了   : 2026-06-19 18:25:00 (UTC)
* 現象   : 2026-06-19 18:25:00 (UTC)を境に水準が 14.98から12.2へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.937, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host01-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→9→10→12→9→10→12→10
* 開始   : 2026-06-20 05:00:00 (UTC)
* 終了   : 2026-06-20 05:05:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.902, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host01-002 (同一ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260620-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host01-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 9→8→10→9→8→10
* 開始   : 2026-06-20 20:35:00 (UTC)
* 終了   : 2026-06-20 20:40:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.011, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260620-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260620-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host01-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 12→10→12→14→13→11→12→14→14
* 開始   : 2026-06-21 04:45:00 (UTC)
* 終了   : 2026-06-21 05:30:00 (UTC)
* 現象   : 2026-06-21 05:30:00 (UTC)を境に水準が 11.89から12.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host01-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 16→17→14→17→16→15
* 開始   : 2026-06-21 09:10:00 (UTC)
* 終了   : 2026-06-21 09:35:00 (UTC)
* 現象   : 2026-06-21 09:35:00 (UTC)を境に水準が 11.84から12.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.873, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 14→16→11→15→11→15→11→15→13
* 開始   : 2026-06-21 15:50:00 (UTC)
* 終了   : 2026-06-21 16:00:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.7586(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260621-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 15→14→11→14→…→14→17→14→12
* 開始   : 2026-06-21 16:05:00 (UTC)
* 終了   : 2026-06-21 16:25:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260621-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 8→7→12→6→…→12→6→8→10
* 開始   : 2026-06-21 22:35:00 (UTC)
* 終了   : 2026-06-21 22:40:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 8→7→12→6→…→12→6→8→9
* 開始   : 2026-06-22 22:10:00 (UTC)
* 終了   : 2026-06-22 22:15:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260622-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 7→10→8→10→9→8→9→9→10
* 開始   : 2026-06-23 00:30:00 (UTC)
* 終了   : 2026-06-23 01:25:00 (UTC)
* 現象   : 2026-06-23 01:25:00 (UTC)を境に水準が 14.9から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.51, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 8→5→11→9→11→9→11→10→9
* 開始   : 2026-06-23 01:00:00 (UTC)
* 終了   : 2026-06-23 01:10:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 12→13→14→15→…→14→15→14→15
* 開始   : 2026-06-23 04:40:00 (UTC)
* 終了   : 2026-06-23 05:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260623-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260623-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260623-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 17→17→16→18→16→18→15→18→19
* 開始   : 2026-06-23 06:30:00 (UTC)
* 終了   : 2026-06-23 07:15:00 (UTC)
* 現象   : 2026-06-23 07:15:00 (UTC)を境に水準が 14.93から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.064, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host01-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 70.27→69.18→72.99→72.5→72.08→69.38→73.7→72.51→72.85
* 開始   : 2026-06-23 12:00:00 (UTC)
* 終了   : 2026-06-23 12:40:00 (UTC)
* 現象   : 2026-06-23 12:40:00 (UTC)を境に水準が 49.81から50.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=24.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 35.07→33.85→39.78→38.52→…→38.52→41.88→36.91→33.43
* 開始   : 2026-06-24 02:45:00 (UTC)
* 終了   : 2026-06-24 02:55:00 (UTC)
* 現象   : 平常時(32.37)に対し 1.229倍(39.78)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 11→13→11→14→14→15
* 開始   : 2026-06-24 03:55:00 (UTC)
* 終了   : 2026-06-24 04:20:00 (UTC)
* 現象   : 2026-06-24 04:20:00 (UTC)を境に水準が 14.94から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.879, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 12→11→15→13→11→15→13
* 開始   : 2026-06-24 05:10:00 (UTC)
* 終了   : 2026-06-24 05:15:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→13→16→12→16→12→16→14
* 開始   : 2026-06-24 05:10:00 (UTC)
* 終了   : 2026-06-24 05:20:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host01-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 20→23→19→22→23→19→22→19
* 開始   : 2026-06-24 13:05:00 (UTC)
* 終了   : 2026-06-24 13:10:00 (UTC)
* 現象   : 平常時(22)に対し 0.8636(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-041 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260624-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 65.13→56.99→52.29→50.2→…→52.29→50.2→57.11→55.23
* 開始   : 2026-06-24 16:25:00 (UTC)
* 終了   : 2026-06-24 16:30:00 (UTC)
* 現象   : 平常時(60.45)に対し 0.8651(52.29)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-052 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 17→18→15→14→16→18→15→14→16
* 開始   : 2026-06-24 17:05:00 (UTC)
* 終了   : 2026-06-24 18:15:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-015 (同一ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260624-host01-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260624-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260624-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260624-host12-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 17→18→14→17→18→14→17→16
* 開始   : 2026-06-24 17:35:00 (UTC)
* 終了   : 2026-06-24 17:40:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host01-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 15→12→14→11→12→14→11→14→13
* 開始   : 2026-06-24 18:30:00 (UTC)
* 終了   : 2026-06-24 18:40:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-065 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host01-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 19→19→18→17→20
* 開始   : 2026-06-25 06:40:00 (UTC)
* 終了   : 2026-06-25 07:00:00 (UTC)
* 現象   : 2026-06-25 07:00:00 (UTC)を境に水準が 14.96から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.569σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 14→15→18→16→…→16→19→17→18
* 開始   : 2026-06-25 06:50:00 (UTC)
* 終了   : 2026-06-25 07:00:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260625-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 18→19→16→15→19→16→15→19→18
* 開始   : 2026-06-25 15:55:00 (UTC)
* 終了   : 2026-06-25 16:00:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.817(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260625-host01-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / eu (Eden 使用量) / container=app01, host=host01
* 値     : 49.96→52.95→45.85→45.97→…→45.85→45.97→48.97→48.05
* 開始   : 2026-06-25 17:40:00 (UTC)
* 終了   : 2026-06-25 17:45:00 (UTC)
* 現象   : 平常時(55.43)に対し 0.8272(45.85)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.647σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 11→13→17→13→…→13→10→14→11
* 開始   : 2026-06-25 19:10:00 (UTC)
* 終了   : 2026-06-25 19:20:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.283倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.627σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 11→13→12→7→13→12→7→12→11
* 開始   : 2026-06-26 03:20:00 (UTC)
* 終了   : 2026-06-26 04:20:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260626-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分

![EVT-20260626-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 13→16→13→16→13→14
* 開始   : 2026-06-26 05:10:00 (UTC)
* 終了   : 2026-06-26 05:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 22→22→22→19→21→20→23→22
* 開始   : 2026-06-26 13:35:00 (UTC)
* 終了   : 2026-06-26 14:50:00 (UTC)
* 現象   : 2026-06-26 14:50:00 (UTC)を境に水準が 15.06から12.75へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.059, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 20→19→16→18→…→18→15→17→18
* 開始   : 2026-06-26 16:30:00 (UTC)
* 終了   : 2026-06-26 16:40:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host01-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 15→19→12→16→15→19→12→16→15
* 開始   : 2026-06-26 17:40:00 (UTC)
* 終了   : 2026-06-26 17:45:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host01-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→14→10→14→10→14→11
* 開始   : 2026-06-26 19:10:00 (UTC)
* 終了   : 2026-06-26 19:15:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7059(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.895σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host01-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_4
* 値     : 14→13→10→13→10→13→10→11
* 開始   : 2026-06-26 19:20:00 (UTC)
* 終了   : 2026-06-26 19:30:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7101(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.861σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260626-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260626-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host01-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host01-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 10→8→10→10→10→8→8
* 開始   : 2026-06-26 23:15:00 (UTC)
* 終了   : 2026-06-26 23:45:00 (UTC)
* 現象   : 2026-06-26 23:45:00 (UTC)を境に水準が 14.88から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.745, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host01-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host01-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 6→9→11→8→11→8→11→10→8
* 開始   : 2026-06-27 02:00:00 (UTC)
* 終了   : 2026-06-27 02:10:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host01-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 9→8→10→11→11→11→11
* 開始   : 2026-06-28 02:40:00 (UTC)
* 終了   : 2026-06-28 03:10:00 (UTC)
* 現象   : 2026-06-28 03:10:00 (UTC)を境に水準が 11.81から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.026, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host01-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host01-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_1
* 値     : 12→13→13→13
* 開始   : 2026-06-28 05:00:00 (UTC)
* 終了   : 2026-06-28 05:15:00 (UTC)
* 現象   : 2026-06-28 05:15:00 (UTC)を境に水準が 11.85から11.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host01-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 11→12→14→12→14→12
* 開始   : 2026-06-28 06:00:00 (UTC)
* 終了   : 2026-06-28 06:05:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260628-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host01-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_2
* 値     : 15→15→12→14→14→16→13→15
* 開始   : 2026-06-28 07:10:00 (UTC)
* 終了   : 2026-06-28 07:45:00 (UTC)
* 現象   : 2026-06-28 07:45:00 (UTC)を境に水準が 11.79から12.52へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.852, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host01-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host01-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 16→14→12→11→…→12→11→15→14
* 開始   : 2026-06-28 15:00:00 (UTC)
* 終了   : 2026-06-28 15:05:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260628-host01-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 7→5→11→10→7→5→11→10→8
* 開始   : 2026-06-29 23:30:00 (UTC)
* 終了   : 2026-06-29 23:35:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260629-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260629-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260629-host01-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_6
* 値     : 15→16→19→17→…→17→20→19→17
* 開始   : 2026-06-30 07:00:00 (UTC)
* 終了   : 2026-06-30 07:10:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260630-host01-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_3
* 値     : 15→12→11→12→11→14
* 開始   : 2026-06-30 18:35:00 (UTC)
* 終了   : 2026-06-30 18:45:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260630-host01-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host01-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host01, port=7003, datasource=OraclePool_5
* 値     : 15→17→12→15→12→15→12→15→13
* 開始   : 2026-06-30 18:40:00 (UTC)
* 終了   : 2026-06-30 18:50:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.7619(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.62σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260630-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host01-008 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
