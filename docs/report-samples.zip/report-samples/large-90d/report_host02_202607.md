# host02 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host02 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 383 (SEVERE: 25, FATAL: 136, WARN: 222, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 22 | 117 | 184 | 323 | ALG-A1, ALG-A2, ALG-A3, ALG-A4, ALG-A5, ALG-B4 |
| ou | 3 | 19 | 29 | 51 | ALG-A1, ALG-A4, ALG-B4 |
| mu | 0 | 0 | 9 | 9 | ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260701-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→41→31→36→…→10→12→13→12
* 開始   : 2026-07-01 03:00:00 (UTC)
* 終了   : 2026-07-01 04:45:00 (UTC)
* 現象   : 2026-07-01 04:45:00 (UTC)を境に水準が 14.94から16.29へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 12.06σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 20.91 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=41)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=5.931, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=30.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host02-002 active_connections の推移](charts/EVT-20260701-host02-002.svg)

# イベントID( EVT-20260706-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→17→16→17→…→14→12→13→14
* 開始   : 2026-07-06 02:50:00 (UTC)
* 終了   : 2026-07-06 21:45:00 (UTC)
* 現象   : 2026-07-06 21:45:00 (UTC)を境に水準が 11.82から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.835, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.779, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host02-003 active_connections の推移](charts/EVT-20260706-host02-003.svg)

# イベントID( EVT-20260706-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 15→17→18→19→…→16→14→11→13
* 開始   : 2026-07-06 03:10:00 (UTC)
* 終了   : 2026-07-06 20:25:00 (UTC)
* 現象   : 2026-07-06 20:25:00 (UTC)を境に水準が 11.89から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.846, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host02-004 active_connections の推移](charts/EVT-20260706-host02-004.svg)

# イベントID( EVT-20260706-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→15→14→12→…→16→13→12→14
* 開始   : 2026-07-06 03:10:00 (UTC)
* 終了   : 2026-07-06 20:55:00 (UTC)
* 現象   : 2026-07-06 20:55:00 (UTC)を境に水準が 11.87から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.255, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.502, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host02-006 active_connections の推移](charts/EVT-20260706-host02-006.svg)

# イベントID( EVT-20260706-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.044e+04→1.109e+04→1.137e+04→1.04e+04→…→1.055e+04→1.016e+04→1.017e+04→1.019e+04
* 開始   : 2026-07-06 03:25:00 (UTC)
* 終了   : 2026-07-06 19:45:00 (UTC)
* 現象   : 2026-07-06 19:45:00 (UTC)を境に水準が 9794から1.024e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.442σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=571.9, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2472, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host02-007 ou の推移](charts/EVT-20260706-host02-007.svg)

# イベントID( EVT-20260706-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→13→16→14→…→12→14→12→11
* 開始   : 2026-07-06 03:45:00 (UTC)
* 終了   : 2026-07-06 21:50:00 (UTC)
* 現象   : 2026-07-06 21:50:00 (UTC)を境に水準が 11.86から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.943, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host02-008 active_connections の推移](charts/EVT-20260706-host02-008.svg)

# イベントID( EVT-20260706-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 16→15→18→17→…→12→13→12→11
* 開始   : 2026-07-06 04:05:00 (UTC)
* 終了   : 2026-07-06 20:50:00 (UTC)
* 現象   : 2026-07-06 20:50:00 (UTC)を境に水準が 11.98から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.735, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host02-009 active_connections の推移](charts/EVT-20260706-host02-009.svg)

# イベントID( EVT-20260708-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 12→11→45→51→…→13→11→13→14
* 開始   : 2026-07-08 02:50:00 (UTC)
* 終了   : 2026-07-08 04:50:00 (UTC)
* 現象   : 2026-07-08 04:50:00 (UTC)を境に水準が 14.99から16.38へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 13.5σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 23.61 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=45)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=7.087, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=36.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host02-004 active_connections の推移](charts/EVT-20260708-host02-004.svg)

# イベントID( EVT-20260713-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→15→17→14→…→15→16→14→15
* 開始   : 2026-07-13 01:15:00 (UTC)
* 終了   : 2026-07-13 20:55:00 (UTC)
* 現象   : 2026-07-13 20:55:00 (UTC)を境に水準が 11.72から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.139, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.03, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host02-002 active_connections の推移](charts/EVT-20260713-host02-002.svg)

# イベントID( EVT-20260713-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 17→15→17→18→…→12→13→11→10
* 開始   : 2026-07-13 01:50:00 (UTC)
* 終了   : 2026-07-13 20:05:00 (UTC)
* 現象   : 2026-07-13 20:05:00 (UTC)を境に水準が 11.84から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.831, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host02-003 active_connections の推移](charts/EVT-20260713-host02-003.svg)

# イベントID( EVT-20260713-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 15→18→16→19→…→17→15→13→15
* 開始   : 2026-07-13 02:30:00 (UTC)
* 終了   : 2026-07-13 18:45:00 (UTC)
* 現象   : 2026-07-13 18:45:00 (UTC)を境に水準が 11.87から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.169, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.905, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host02-004 active_connections の推移](charts/EVT-20260713-host02-004.svg)

# イベントID( EVT-20260713-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→12→15→12→…→13→15→14→12
* 開始   : 2026-07-13 04:20:00 (UTC)
* 終了   : 2026-07-13 21:30:00 (UTC)
* 現象   : 2026-07-13 21:30:00 (UTC)を境に水準が 12.03から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.941, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host02-006 active_connections の推移](charts/EVT-20260713-host02-006.svg)

# イベントID( EVT-20260713-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→12→16→14→…→13→14→12→13
* 開始   : 2026-07-13 04:45:00 (UTC)
* 終了   : 2026-07-13 19:15:00 (UTC)
* 現象   : 2026-07-13 19:15:00 (UTC)を境に水準が 11.94から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.09, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host02-007 active_connections の推移](charts/EVT-20260713-host02-007.svg)

# イベントID( EVT-20260715-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→12→44→46→…→14→12→13→14
* 開始   : 2026-07-15 02:55:00 (UTC)
* 終了   : 2026-07-15 04:50:00 (UTC)
* 現象   : 2026-07-15 04:50:00 (UTC)を境に水準が 14.95から16.29へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 13.08σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 22.93 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=44)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=6.829, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=32.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host02-001 active_connections の推移](charts/EVT-20260715-host02-001.svg)

# イベントID( EVT-20260720-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→14→13→14→…→13→12→11→12
* 開始   : 2026-07-20 01:40:00 (UTC)
* 終了   : 2026-07-20 19:55:00 (UTC)
* 現象   : 2026-07-20 19:55:00 (UTC)を境に水準が 11.83から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.321σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.696, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.659, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host02-001 active_connections の推移](charts/EVT-20260720-host02-001.svg)

# イベントID( EVT-20260720-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 15→16→17→19→…→15→14→15→13
* 開始   : 2026-07-20 01:55:00 (UTC)
* 終了   : 2026-07-20 21:00:00 (UTC)
* 現象   : 2026-07-20 21:00:00 (UTC)を境に水準が 11.8から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.836, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host02-002 active_connections の推移](charts/EVT-20260720-host02-002.svg)

# イベントID( EVT-20260720-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→15→18→14→…→14→13→14→13
* 開始   : 2026-07-20 03:00:00 (UTC)
* 終了   : 2026-07-20 20:40:00 (UTC)
* 現象   : 2026-07-20 20:40:00 (UTC)を境に水準が 11.94から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.391σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.236, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host02-005 active_connections の推移](charts/EVT-20260720-host02-005.svg)

# イベントID( EVT-20260720-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→16→15→18→…→11→14→12→13
* 開始   : 2026-07-20 03:20:00 (UTC)
* 終了   : 2026-07-20 19:05:00 (UTC)
* 現象   : 2026-07-20 19:05:00 (UTC)を境に水準が 11.8から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.892, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.334, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host02-006 active_connections の推移](charts/EVT-20260720-host02-006.svg)

# イベントID( EVT-20260720-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.056e+04→1.039e+04→1.063e+04→1.127e+04→…→1.05e+04→1.03e+04→1.018e+04→1.006e+04
* 開始   : 2026-07-20 03:55:00 (UTC)
* 終了   : 2026-07-20 19:20:00 (UTC)
* 現象   : 2026-07-20 19:20:00 (UTC)を境に水準が 9831から1.026e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.053σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=576.8, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2505, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host02-007 ou の推移](charts/EVT-20260720-host02-007.svg)

# イベントID( EVT-20260722-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 11→13→43→39→…→10→15→13→14
* 開始   : 2026-07-22 02:50:00 (UTC)
* 終了   : 2026-07-22 04:45:00 (UTC)
* 現象   : 2026-07-22 04:45:00 (UTC)を境に水準が 15.07から16.37へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 12.95σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=43)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=6.681, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=35.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host02-003 active_connections の推移](charts/EVT-20260722-host02-003.svg)

# イベントID( EVT-20260727-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 16→17→20→17→…→13→14→11→12
* 開始   : 2026-07-27 02:30:00 (UTC)
* 終了   : 2026-07-27 20:50:00 (UTC)
* 現象   : 2026-07-27 20:50:00 (UTC)を境に水準が 11.82から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.853, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host02-003 active_connections の推移](charts/EVT-20260727-host02-003.svg)

# イベントID( EVT-20260727-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→15→16→14→…→16→13→15→14
* 開始   : 2026-07-27 03:00:00 (UTC)
* 終了   : 2026-07-27 19:30:00 (UTC)
* 現象   : 2026-07-27 19:30:00 (UTC)を境に水準が 11.84から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.826, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host02-006 active_connections の推移](charts/EVT-20260727-host02-006.svg)

# イベントID( EVT-20260727-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 16→15→17→16→…→13→16→12→15
* 開始   : 2026-07-27 03:30:00 (UTC)
* 終了   : 2026-07-27 20:00:00 (UTC)
* 現象   : 2026-07-27 20:00:00 (UTC)を境に水準が 11.98から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.825, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.389, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host02-007 active_connections の推移](charts/EVT-20260727-host02-007.svg)

# イベントID( EVT-20260727-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.061e+04→1.026e+04→1.089e+04→1.069e+04→…→1.051e+04→1.071e+04→1.06e+04→1.037e+04
* 開始   : 2026-07-27 04:25:00 (UTC)
* 終了   : 2026-07-27 18:55:00 (UTC)
* 現象   : 2026-07-27 18:55:00 (UTC)を境に水準が 9801から1.025e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=820.4, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2245, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host02-008 ou の推移](charts/EVT-20260727-host02-008.svg)

# イベントID( EVT-20260729-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→11→41→46→…→12→13→11→13
* 開始   : 2026-07-29 02:55:00 (UTC)
* 終了   : 2026-07-29 04:45:00 (UTC)
* 現象   : 2026-07-29 04:45:00 (UTC)を境に水準が 15から16.47へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 12.12σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 21.25 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=41)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=5.504, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=29.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host02-003 active_connections の推移](charts/EVT-20260729-host02-003.svg)

# イベントID( EVT-20260701-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 6→8→12→7→10
* 開始   : 2026-07-01 01:10:00 (UTC)
* 終了   : 2026-07-01 01:10:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1e+04→1.026e+04→1.079e+04→9693
* 開始   : 2026-07-01 03:40:00 (UTC)
* 終了   : 2026-07-01 03:55:00 (UTC)
* 現象   : 2026-07-01 03:55:00 (UTC)を境に水準が 1.025e+04から1.026e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.073σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2150, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→14→17→15→14
* 開始   : 2026-07-01 05:25:00 (UTC)
* 終了   : 2026-07-01 05:25:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→16→19→16→16
* 開始   : 2026-07-01 06:30:00 (UTC)
* 終了   : 2026-07-01 06:30:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 24→21→17→23→24
* 開始   : 2026-07-01 13:40:00 (UTC)
* 終了   : 2026-07-01 13:40:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.7757(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.423σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 22→22→26→22→23
* 開始   : 2026-07-01 13:45:00 (UTC)
* 終了   : 2026-07-01 13:45:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.214倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→18→14→17→18
* 開始   : 2026-07-01 17:05:00 (UTC)
* 終了   : 2026-07-01 17:05:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-054 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260701-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 7→8→5→3→…→5→3→9→6
* 開始   : 2026-07-02 00:00:00 (UTC)
* 終了   : 2026-07-02 00:05:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.5825(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260702-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host02-001 active_connections の推移](charts/EVT-20260702-host02-001.svg)

# イベントID( EVT-20260702-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 6→9→13→7→7
* 開始   : 2026-07-02 01:35:00 (UTC)
* 終了   : 2026-07-02 01:35:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-lsfhost01-004 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 9→11→9→11→…→11→12→14→15
* 開始   : 2026-07-02 03:00:00 (UTC)
* 終了   : 2026-07-02 04:30:00 (UTC)
* 現象   : 1.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-6.376, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host02-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260702-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260702-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260702-host02-005 active_connections の推移](charts/EVT-20260702-host02-005.svg)

# イベントID( EVT-20260702-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→12→15→12→12
* 開始   : 2026-07-02 04:10:00 (UTC)
* 終了   : 2026-07-02 04:10:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→13→15→13→12
* 開始   : 2026-07-02 04:15:00 (UTC)
* 終了   : 2026-07-02 04:15:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→12→16→12→13
* 開始   : 2026-07-02 04:35:00 (UTC)
* 終了   : 2026-07-02 04:35:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 16→15→19→14→17
* 開始   : 2026-07-02 06:25:00 (UTC)
* 終了   : 2026-07-02 06:25:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 20→21→26→24→21
* 開始   : 2026-07-02 10:55:00 (UTC)
* 終了   : 2026-07-02 10:55:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.219倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 22→23→17→22→21
* 開始   : 2026-07-02 14:05:00 (UTC)
* 終了   : 2026-07-02 14:05:00 (UTC)
* 現象   : 平常時(21.75)に対し 0.7816(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→14→9→13→12
* 開始   : 2026-07-02 19:25:00 (UTC)
* 終了   : 2026-07-02 19:25:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host02-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9898→1.012e+04→8992→9830→…→9830→9131→9627→9714
* 開始   : 2026-07-02 19:45:00 (UTC)
* 終了   : 2026-07-02 19:55:00 (UTC)
* 現象   : 平常時(1.005e+04)に対し 0.8947(8992)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260702-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host02-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-020 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→11→8→10→13
* 開始   : 2026-07-02 20:05:00 (UTC)
* 終了   : 2026-07-02 20:05:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260702-host02-020 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-021 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→11→14→9→10
* 開始   : 2026-07-02 21:35:00 (UTC)
* 終了   : 2026-07-02 21:35:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-019 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host02-021 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→8→13→8→10
* 開始   : 2026-07-03 02:20:00 (UTC)
* 終了   : 2026-07-03 02:20:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 17→18→14→17→…→17→13→15→14
* 開始   : 2026-07-03 16:45:00 (UTC)
* 終了   : 2026-07-03 17:30:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.7467(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.313σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260703-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260703-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260703-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260703-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→10→6→10→8
* 開始   : 2026-07-03 21:10:00 (UTC)
* 終了   : 2026-07-03 21:10:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9024→9331→1.012e+04→8770→8684
* 開始   : 2026-07-04 01:35:00 (UTC)
* 終了   : 2026-07-04 01:35:00 (UTC)
* 現象   : 平常時(9091)に対し 1.113倍(1.012e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.061σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260704-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→9→10→8→9→10→13
* 開始   : 2026-07-04 04:10:00 (UTC)
* 終了   : 2026-07-04 04:40:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.514倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.333σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.863, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260704-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260704-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260704-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260704-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260704-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→11→12→11→…→15→13→15→12
* 開始   : 2026-07-04 04:55:00 (UTC)
* 終了   : 2026-07-04 18:00:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.953, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260704-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260704-host02-009 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10.3 時間
  - EVT-20260704-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.4 時間
  - EVT-20260704-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 20 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260704-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260704-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260704-host02-004 active_connections の推移](charts/EVT-20260704-host02-004.svg)

# イベントID( EVT-20260704-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→12→11→10→…→14→13→14→13
* 開始   : 2026-07-04 05:35:00 (UTC)
* 終了   : 2026-07-04 18:30:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.76, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host02-009 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10.3 時間
  - EVT-20260704-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.4 時間
  - EVT-20260704-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 20 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260704-host02-005 active_connections の推移](charts/EVT-20260704-host02-005.svg)

# イベントID( EVT-20260704-host02-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→11→12→11→…→10→13→12→11
* 開始   : 2026-07-04 05:35:00 (UTC)
* 終了   : 2026-07-04 19:30:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.083, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host02-009 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10.3 時間
  - EVT-20260704-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.4 時間
  - EVT-20260704-host02-012 (同一ホスト) jvm_gc / ou : WARN / 重なり 25 分
  - EVT-20260704-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 20 分
  - EVT-20260704-host02-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260704-host02-006 active_connections の推移](charts/EVT-20260704-host02-006.svg)

# イベントID( EVT-20260704-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→11→13→10→…→11→13→12→11
* 開始   : 2026-07-04 05:50:00 (UTC)
* 終了   : 2026-07-04 19:35:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.213, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260704-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260704-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260704-host02-009 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10.3 時間
  - EVT-20260704-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.4 時間
  - EVT-20260704-host02-012 (同一ホスト) jvm_gc / ou : WARN / 重なり 25 分
  - EVT-20260704-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 20 分
  - EVT-20260704-host02-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260704-host02-007 active_connections の推移](charts/EVT-20260704-host02-007.svg)

# イベントID( EVT-20260704-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→11→9→12→…→11→10→11→9
* 開始   : 2026-07-04 06:05:00 (UTC)
* 終了   : 2026-07-04 19:25:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.771, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260704-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260704-host02-009 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10.3 時間
  - EVT-20260704-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.4 時間
  - EVT-20260704-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 20 分
  - EVT-20260704-host02-012 (同一ホスト) jvm_gc / ou : WARN / 重なり 20 分
  - EVT-20260704-host02-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260704-host02-008 active_connections の推移](charts/EVT-20260704-host02-008.svg)

# イベントID( EVT-20260704-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.064e+04→9875→9441→1.051e+04→…→1.041e+04→9668→1.044e+04→1.023e+04
* 開始   : 2026-07-04 06:55:00 (UTC)
* 終了   : 2026-07-04 17:15:00 (UTC)
* 現象   : 10.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.055σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-723.8, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.3 時間
  - EVT-20260704-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.3 時間
  - EVT-20260704-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.3 時間
  - EVT-20260704-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.3 時間
  - EVT-20260704-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.3 時間
  - EVT-20260704-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.4 時間
  - EVT-20260704-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 20 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.3 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.3 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.3 時間

![EVT-20260704-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 7→9→4→9→9
* 開始   : 2026-07-04 22:45:00 (UTC)
* 終了   : 2026-07-04 22:45:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260704-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 13→14→16→14→11
* 開始   : 2026-07-05 06:15:00 (UTC)
* 終了   : 2026-07-05 06:15:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→15→18→15→14
* 開始   : 2026-07-05 08:45:00 (UTC)
* 終了   : 2026-07-05 08:45:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→17→11→17→13
* 開始   : 2026-07-05 11:30:00 (UTC)
* 終了   : 2026-07-05 11:30:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 16→11→9→12→13
* 開始   : 2026-07-05 17:20:00 (UTC)
* 終了   : 2026-07-05 17:20:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9726→9791→1.08e+04→9626→9882
* 開始   : 2026-07-05 17:45:00 (UTC)
* 終了   : 2026-07-05 17:45:00 (UTC)
* 現象   : 平常時(9783)に対し 1.104倍(1.08e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260705-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→11→15→11→13
* 開始   : 2026-07-07 03:55:00 (UTC)
* 終了   : 2026-07-07 03:55:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 20→23→26→23→21
* 開始   : 2026-07-07 12:50:00 (UTC)
* 終了   : 2026-07-07 12:50:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→16→12→17→15
* 開始   : 2026-07-07 17:45:00 (UTC)
* 終了   : 2026-07-07 17:45:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7129(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.365σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260707-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 16→13→11→15→…→15→10→15→14
* 開始   : 2026-07-07 18:25:00 (UTC)
* 終了   : 2026-07-07 18:35:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7293(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.848σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260707-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→11→6→8→10
* 開始   : 2026-07-07 21:05:00 (UTC)
* 終了   : 2026-07-07 21:05:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260707-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260707-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9470→9704→8296→9033→9074
* 開始   : 2026-07-07 21:35:00 (UTC)
* 終了   : 2026-07-07 21:35:00 (UTC)
* 現象   : 平常時(9490)に対し 0.8742(8296)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.569σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host02-015 ou の推移](charts/EVT-20260707-host02-015.svg)

# イベントID( EVT-20260708-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 17→18→22→17→17
* 開始   : 2026-07-08 07:35:00 (UTC)
* 終了   : 2026-07-08 07:35:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.327倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.801σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host02-006 active_connections の推移](charts/EVT-20260708-host02-006.svg)

# イベントID( EVT-20260708-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 19→22→24→22→24→22→21
* 開始   : 2026-07-08 09:20:00 (UTC)
* 終了   : 2026-07-08 09:25:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.22倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-lsfhost01-038 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260708-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 11→9→10→9→…→11→13→14→12
* 開始   : 2026-07-09 03:00:00 (UTC)
* 終了   : 2026-07-09 04:40:00 (UTC)
* 現象   : 1.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.604, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260709-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-009 (他ホスト) lsf_queue / run : WARN / 重なり 35 分
  - EVT-20260709-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260709-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260709-host02-002 active_connections の推移](charts/EVT-20260709-host02-002.svg)

# イベントID( EVT-20260709-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 15→13→18→16→13
* 開始   : 2026-07-09 05:40:00 (UTC)
* 終了   : 2026-07-09 05:40:00 (UTC)
* 現象   : 平常時(13)に対し 1.385倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host02-003 active_connections の推移](charts/EVT-20260709-host02-003.svg)

# イベントID( EVT-20260709-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 16→18→22→18→…→18→21→20→19
* 開始   : 2026-07-09 07:55:00 (UTC)
* 終了   : 2026-07-09 08:05:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.282倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.02e+04→9746→9047→9720→9918
* 開始   : 2026-07-09 19:35:00 (UTC)
* 終了   : 2026-07-09 19:35:00 (UTC)
* 現象   : 平常時(1.006e+04)に対し 0.8989(9047)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 19→18→22→18→18
* 開始   : 2026-07-10 08:15:00 (UTC)
* 終了   : 2026-07-10 08:15:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.075σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 17→20→14→16→18
* 開始   : 2026-07-10 16:35:00 (UTC)
* 終了   : 2026-07-10 16:35:00 (UTC)
* 現象   : 平常時(19)に対し 0.7368(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260710-host02-007 active_connections の推移](charts/EVT-20260710-host02-007.svg)

# イベントID( EVT-20260710-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→14→12→14→16
* 開始   : 2026-07-10 17:50:00 (UTC)
* 終了   : 2026-07-10 17:50:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→15→10→13→13
* 開始   : 2026-07-10 18:50:00 (UTC)
* 終了   : 2026-07-10 18:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.429σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9745→1.041e+04→9113→9886→1.038e+04
* 開始   : 2026-07-10 19:05:00 (UTC)
* 終了   : 2026-07-10 19:05:00 (UTC)
* 現象   : 平常時(1.014e+04)に対し 0.8988(9113)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260710-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9860→9884→8638→9561→9738
* 開始   : 2026-07-10 20:35:00 (UTC)
* 終了   : 2026-07-10 20:35:00 (UTC)
* 現象   : 平常時(9838)に対し 0.878(8638)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.586σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-076 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260710-host02-012 ou の推移](charts/EVT-20260710-host02-012.svg)

# イベントID( EVT-20260711-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 10→11→10→11→…→11→9→11→12
* 開始   : 2026-07-11 05:15:00 (UTC)
* 終了   : 2026-07-11 18:50:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.045, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host02-001 (同一ホスト) jvm_gc / ou : WARN / 重なり 12.2 時間
  - EVT-20260711-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 7.8 時間
  - EVT-20260711-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 2.4 時間
  - EVT-20260711-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260711-host02-011 (同一ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260711-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→13→10→11→…→14→11→10→11
* 開始   : 2026-07-11 05:30:00 (UTC)
* 終了   : 2026-07-11 18:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.545σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.278, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host02-001 (同一ホスト) jvm_gc / ou : WARN / 重なり 11.9 時間
  - EVT-20260711-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 7.8 時間
  - EVT-20260711-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 2.4 時間
  - EVT-20260711-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260711-host02-003 active_connections の推移](charts/EVT-20260711-host02-003.svg)

# イベントID( EVT-20260711-host02-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 13→12→9→13→…→10→11→12→11
* 開始   : 2026-07-11 05:40:00 (UTC)
* 終了   : 2026-07-11 19:10:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.83, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host02-001 (同一ホスト) jvm_gc / ou : WARN / 重なり 11.8 時間
  - EVT-20260711-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 7.8 時間
  - EVT-20260711-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 2.4 時間
  - EVT-20260711-host02-011 (同一ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260711-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分

![EVT-20260711-host02-004 active_connections の推移](charts/EVT-20260711-host02-004.svg)

# イベントID( EVT-20260711-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→10→12→13→…→11→12→14→11
* 開始   : 2026-07-11 05:45:00 (UTC)
* 終了   : 2026-07-11 19:35:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.986, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260711-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260711-host02-001 (同一ホスト) jvm_gc / ou : WARN / 重なり 11.7 時間
  - EVT-20260711-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 7.8 時間
  - EVT-20260711-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 2.4 時間
  - EVT-20260711-host02-011 (同一ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260711-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分

![EVT-20260711-host02-005 active_connections の推移](charts/EVT-20260711-host02-005.svg)

# イベントID( EVT-20260711-host02-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→10→13→10→…→14→10→12→13
* 開始   : 2026-07-11 05:55:00 (UTC)
* 終了   : 2026-07-11 19:50:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.143, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260711-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host02-001 (同一ホスト) jvm_gc / ou : WARN / 重なり 11.5 時間
  - EVT-20260711-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 7.8 時間
  - EVT-20260711-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 2.4 時間
  - EVT-20260711-host02-011 (同一ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260711-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分

![EVT-20260711-host02-006 active_connections の推移](charts/EVT-20260711-host02-006.svg)

# イベントID( EVT-20260712-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 16→15→10→16→15
* 開始   : 2026-07-12 10:40:00 (UTC)
* 終了   : 2026-07-12 10:40:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.6557(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.661σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 8921→9200→9977→9876→…→9977→9876→8863→9510
* 開始   : 2026-07-12 21:20:00 (UTC)
* 終了   : 2026-07-12 22:10:00 (UTC)
* 現象   : 平常時(9442)に対し 0.8895倍(8399)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.119σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260712-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-lsfhost01-044 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260712-lsfhost01-047 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260712-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260712-lsfhost01-045 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260712-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260712-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260712-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260712-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.052e+04→1.045e+04→1.033e+04→1.017e+04→…→1.046e+04→1.056e+04→1.01e+04→1.016e+04
* 開始   : 2026-07-13 06:00:00 (UTC)
* 終了   : 2026-07-13 17:15:00 (UTC)
* 現象   : 2026-07-13 17:15:00 (UTC)を境に水準が 9814から1.025e+04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=555.4, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2830, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→11→15→11→8
* 開始   : 2026-07-14 03:30:00 (UTC)
* 終了   : 2026-07-14 03:30:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.579倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.845σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-006 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260714-host02-001 active_connections の推移](charts/EVT-20260714-host02-001.svg)

# イベントID( EVT-20260714-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9843→9914→1.12e+04→1.001e+04→1.027e+04
* 開始   : 2026-07-14 05:30:00 (UTC)
* 終了   : 2026-07-14 05:30:00 (UTC)
* 現象   : 平常時(9842)に対し 1.138倍(1.12e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.073σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host02-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host02-004 ou の推移](charts/EVT-20260714-host02-004.svg)

# イベントID( EVT-20260714-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 18→17→15→17→17→18
* 開始   : 2026-07-14 06:10:00 (UTC)
* 終了   : 2026-07-14 06:35:00 (UTC)
* 現象   : 2026-07-14 06:35:00 (UTC)を境に水準が 14.81から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.196σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.43, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 18→19→23→19→21
* 開始   : 2026-07-14 08:25:00 (UTC)
* 終了   : 2026-07-14 08:25:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.133σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 16→15→9→12→12
* 開始   : 2026-07-14 19:05:00 (UTC)
* 終了   : 2026-07-14 19:05:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6243(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.801σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host02-009 active_connections の推移](charts/EVT-20260714-host02-009.svg)

# イベントID( EVT-20260714-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→10→6→9→11
* 開始   : 2026-07-14 21:05:00 (UTC)
* 終了   : 2026-07-14 21:05:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.5496(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.423σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260714-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 8→7→13→9→8
* 開始   : 2026-07-14 23:20:00 (UTC)
* 終了   : 2026-07-14 23:20:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260714-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→13→16→14→11
* 開始   : 2026-07-15 04:40:00 (UTC)
* 終了   : 2026-07-15 04:40:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260715-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 20→20→26→21→21
* 開始   : 2026-07-15 09:20:00 (UTC)
* 終了   : 2026-07-15 09:20:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.333倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.525σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260715-host02-005 active_connections の推移](charts/EVT-20260715-host02-005.svg)

# イベントID( EVT-20260715-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 19→19→24→21→21
* 開始   : 2026-07-15 09:20:00 (UTC)
* 終了   : 2026-07-15 09:20:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.258倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.437σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260715-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 20→21→26→22→21
* 開始   : 2026-07-15 12:35:00 (UTC)
* 終了   : 2026-07-15 12:35:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→10→7→8→6→7→8→6→10
* 開始   : 2026-07-15 21:35:00 (UTC)
* 終了   : 2026-07-15 21:45:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.6462(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.673σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 9→11→10→9→…→12→13→12→13
* 開始   : 2026-07-16 03:00:00 (UTC)
* 終了   : 2026-07-16 04:35:00 (UTC)
* 現象   : 1.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.143, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260716-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-011 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260716-host02-002 active_connections の推移](charts/EVT-20260716-host02-002.svg)

# イベントID( EVT-20260716-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→15→19→14→16
* 開始   : 2026-07-16 06:20:00 (UTC)
* 終了   : 2026-07-16 06:20:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.075σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 15→16→18→17→…→17→19→16→18
* 開始   : 2026-07-16 06:25:00 (UTC)
* 終了   : 2026-07-16 06:35:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.271倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260716-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 21→20→16→18→20
* 開始   : 2026-07-16 15:15:00 (UTC)
* 終了   : 2026-07-16 15:15:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 18→18→15→17→18
* 開始   : 2026-07-16 16:15:00 (UTC)
* 終了   : 2026-07-16 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.075σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→14→10→14→14
* 開始   : 2026-07-16 18:55:00 (UTC)
* 終了   : 2026-07-16 18:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-073 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260716-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 10→10→6→9→9
* 開始   : 2026-07-16 21:00:00 (UTC)
* 終了   : 2026-07-16 21:00:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.5414(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.539σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host02-012 active_connections の推移](charts/EVT-20260716-host02-012.svg)

# イベントID( EVT-20260717-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 19→21→24→22→20
* 開始   : 2026-07-17 09:45:00 (UTC)
* 終了   : 2026-07-17 09:45:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→9→5→10→9
* 開始   : 2026-07-17 22:20:00 (UTC)
* 終了   : 2026-07-17 22:20:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.133σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-091 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host02-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→12→10→11→…→13→11→12→13
* 開始   : 2026-07-18 05:05:00 (UTC)
* 終了   : 2026-07-18 18:05:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.981, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host02-005 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.5 時間
  - EVT-20260718-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260718-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.1 時間
  - EVT-20260718-host02-008 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260718-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260718-host02-001 active_connections の推移](charts/EVT-20260718-host02-001.svg)

# イベントID( EVT-20260718-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→12→11→12→…→11→15→14→13
* 開始   : 2026-07-18 05:05:00 (UTC)
* 終了   : 2026-07-18 21:15:00 (UTC)
* 現象   : 16.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.437σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.832, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260718-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260718-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host02-005 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.5 時間
  - EVT-20260718-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.1 時間
  - EVT-20260718-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260718-host02-008 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.4 時間
  - EVT-20260718-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間

![EVT-20260718-host02-002 active_connections の推移](charts/EVT-20260718-host02-002.svg)

# イベントID( EVT-20260718-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→11→10→13→…→14→11→12→11
* 開始   : 2026-07-18 05:15:00 (UTC)
* 終了   : 2026-07-18 20:30:00 (UTC)
* 現象   : 15.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.724, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260718-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-005 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.5 時間
  - EVT-20260718-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.1 時間
  - EVT-20260718-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260718-host02-008 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260718-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間

![EVT-20260718-host02-003 active_connections の推移](charts/EVT-20260718-host02-003.svg)

# イベントID( EVT-20260718-host02-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→11→10→12→…→13→12→13→12
* 開始   : 2026-07-18 05:25:00 (UTC)
* 終了   : 2026-07-18 18:50:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.998, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host02-005 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.5 時間
  - EVT-20260718-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.1 時間
  - EVT-20260718-host02-008 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260718-host02-004 active_connections の推移](charts/EVT-20260718-host02-004.svg)

# イベントID( EVT-20260718-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9445→9828→1.008e+04→1.022e+04→…→9573→1.008e+04→9828→9987
* 開始   : 2026-07-18 05:30:00 (UTC)
* 終了   : 2026-07-18 18:00:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-547.4, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.1 時間
  - EVT-20260718-host02-008 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260718-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260718-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host02-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 15→12→11→12→…→11→13→12→11
* 開始   : 2026-07-18 05:45:00 (UTC)
* 終了   : 2026-07-18 18:40:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.802, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260718-host02-005 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.2 時間
  - EVT-20260718-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.1 時間
  - EVT-20260718-host02-008 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間

![EVT-20260718-host02-006 active_connections の推移](charts/EVT-20260718-host02-006.svg)

# イベントID( EVT-20260719-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→8→13→9→9
* 開始   : 2026-07-19 03:00:00 (UTC)
* 終了   : 2026-07-19 03:00:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.608倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9176→9911→1.049e+04→9218→9815
* 開始   : 2026-07-19 03:35:00 (UTC)
* 終了   : 2026-07-19 03:35:00 (UTC)
* 現象   : 平常時(9466)に対し 1.108倍(1.049e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.051σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260719-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 10→8→14→12→10
* 開始   : 2026-07-19 04:15:00 (UTC)
* 終了   : 2026-07-19 04:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 16→15→16→16→18→14→14→17→16
* 開始   : 2026-07-19 13:35:00 (UTC)
* 終了   : 2026-07-19 14:40:00 (UTC)
* 現象   : 2026-07-19 14:40:00 (UTC)を境に水準が 11.75から14.14へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.966σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.572, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→7→9→12→7→9→12→13
* 開始   : 2026-07-19 18:05:00 (UTC)
* 終了   : 2026-07-19 18:10:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.5563(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.918σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host02-013 (同一ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260719-host02-012 active_connections の推移](charts/EVT-20260719-host02-012.svg)

# イベントID( EVT-20260719-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 13→11→6→11→8→6→11→8→10
* 開始   : 2026-07-19 19:10:00 (UTC)
* 終了   : 2026-07-19 19:20:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.5143(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.961σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host02-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→15→17→15→…→16→15→16→15
* 開始   : 2026-07-20 02:45:00 (UTC)
* 終了   : 2026-07-20 20:20:00 (UTC)
* 現象   : 2026-07-20 20:20:00 (UTC)を境に水準が 11.89から14.91へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.794, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.946, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 8→8→4→8→9
* 開始   : 2026-07-20 23:35:00 (UTC)
* 終了   : 2026-07-20 23:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260720-lsfhost01-062 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260720-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→15→19→16→14
* 開始   : 2026-07-21 06:10:00 (UTC)
* 終了   : 2026-07-21 06:10:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.333倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host02-003 (同一ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260721-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9609→9190→1.03e+04→1e+04→9370
* 開始   : 2026-07-22 02:40:00 (UTC)
* 終了   : 2026-07-22 02:40:00 (UTC)
* 現象   : 平常時(9266)に対し 1.111倍(1.03e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260722-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 20→20→16→20→19
* 開始   : 2026-07-22 15:35:00 (UTC)
* 終了   : 2026-07-22 15:35:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.7711(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260722-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 16→17→13→17→16
* 開始   : 2026-07-22 17:30:00 (UTC)
* 終了   : 2026-07-22 17:30:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→11→6→10→9
* 開始   : 2026-07-22 21:15:00 (UTC)
* 終了   : 2026-07-22 21:15:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 9→11→13→11→…→13→12→13→14
* 開始   : 2026-07-23 03:00:00 (UTC)
* 終了   : 2026-07-23 04:30:00 (UTC)
* 現象   : 1.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-6.89, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-003 (同一ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260723-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260723-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-011 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260723-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260723-host02-002 active_connections の推移](charts/EVT-20260723-host02-002.svg)

# イベントID( EVT-20260723-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.002e+04→9684→1.076e+04→9880→9555
* 開始   : 2026-07-23 04:30:00 (UTC)
* 終了   : 2026-07-23 04:30:00 (UTC)
* 現象   : 平常時(9636)に対し 1.116倍(1.076e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.346σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 15→18→16→20→18→16→20→17→15
* 開始   : 2026-07-23 06:30:00 (UTC)
* 終了   : 2026-07-23 06:40:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260723-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.108e+04→1.036e+04→9700→1.019e+04→1.036e+04
* 開始   : 2026-07-23 17:20:00 (UTC)
* 終了   : 2026-07-23 17:20:00 (UTC)
* 現象   : 平常時(1.076e+04)に対し 0.9014(9700)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.173σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→14→17→14→16
* 開始   : 2026-07-24 05:30:00 (UTC)
* 終了   : 2026-07-24 05:30:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260724-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 19→16→15→18→19→16→15→18
* 開始   : 2026-07-24 15:20:00 (UTC)
* 終了   : 2026-07-24 16:10:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260724-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260724-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→8→4→8→9
* 開始   : 2026-07-25 03:15:00 (UTC)
* 終了   : 2026-07-25 03:15:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.4486(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260725-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 13→11→9→13→…→10→12→14→12
* 開始   : 2026-07-25 04:20:00 (UTC)
* 終了   : 2026-07-25 19:50:00 (UTC)
* 現象   : 15.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.937, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260725-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.8 時間
  - EVT-20260725-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.6 時間
  - EVT-20260725-host02-010 (同一ホスト) jvm_gc / ou : WARN / 重なり 1.2 時間
  - EVT-20260725-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260725-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15.2 時間

![EVT-20260725-host02-002 active_connections の推移](charts/EVT-20260725-host02-002.svg)

# イベントID( EVT-20260725-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→10→12→10→…→15→11→15→12
* 開始   : 2026-07-25 05:25:00 (UTC)
* 終了   : 2026-07-25 20:20:00 (UTC)
* 現象   : 14.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.947, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260725-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260725-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.8 時間
  - EVT-20260725-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.6 時間
  - EVT-20260725-host02-010 (同一ホスト) jvm_gc / ou : WARN / 重なり 1.4 時間
  - EVT-20260725-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260725-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260725-host02-003 active_connections の推移](charts/EVT-20260725-host02-003.svg)

# イベントID( EVT-20260725-host02-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→10→11→12→…→13→12→11→13
* 開始   : 2026-07-25 05:25:00 (UTC)
* 終了   : 2026-07-25 17:50:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.957, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.8 時間
  - EVT-20260725-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.6 時間
  - EVT-20260725-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間

![EVT-20260725-host02-004 active_connections の推移](charts/EVT-20260725-host02-004.svg)

# イベントID( EVT-20260725-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→13→11→13→…→11→13→11→13
* 開始   : 2026-07-25 05:30:00 (UTC)
* 終了   : 2026-07-25 20:00:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.029, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260725-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260725-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.8 時間
  - EVT-20260725-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.6 時間
  - EVT-20260725-host02-010 (同一ホスト) jvm_gc / ou : WARN / 重なり 1.4 時間
  - EVT-20260725-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260725-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.5 時間

![EVT-20260725-host02-005 active_connections の推移](charts/EVT-20260725-host02-005.svg)

# イベントID( EVT-20260725-host02-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9624→1.042e+04→1.011e+04→1.016e+04→…→9887→1.057e+04→1.025e+04→9902
* 開始   : 2026-07-25 05:30:00 (UTC)
* 終了   : 2026-07-25 17:20:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-590.4, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260725-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.6 時間
  - EVT-20260725-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間

![EVT-20260725-host02-006 ou の推移](charts/EVT-20260725-host02-006.svg)

# イベントID( EVT-20260725-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→12→11→12→…→14→12→13→14
* 開始   : 2026-07-25 05:50:00 (UTC)
* 終了   : 2026-07-25 18:25:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.786, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.5 時間
  - EVT-20260725-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.6 時間
  - EVT-20260725-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間

![EVT-20260725-host02-007 active_connections の推移](charts/EVT-20260725-host02-007.svg)

# イベントID( EVT-20260726-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 10→9→15→11→13
* 開始   : 2026-07-26 05:00:00 (UTC)
* 終了   : 2026-07-26 05:00:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.093e+04→1.047e+04→9237→9867→1.045e+04
* 開始   : 2026-07-26 10:15:00 (UTC)
* 終了   : 2026-07-26 10:15:00 (UTC)
* 現象   : 平常時(1.042e+04)に対し 0.8866(9237)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.529σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 8→12→6→7→…→6→7→9→11
* 開始   : 2026-07-26 19:50:00 (UTC)
* 終了   : 2026-07-26 19:55:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260726-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 8→7→12→7→7
* 開始   : 2026-07-27 00:45:00 (UTC)
* 終了   : 2026-07-27 00:45:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260727-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260727-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host02-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→17→16→18→…→13→15→17→16
* 開始   : 2026-07-27 02:50:00 (UTC)
* 終了   : 2026-07-27 20:40:00 (UTC)
* 現象   : 2026-07-27 20:40:00 (UTC)を境に水準が 11.75から15.12へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.831, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→14→15→13→…→15→14→13→12
* 開始   : 2026-07-27 02:55:00 (UTC)
* 終了   : 2026-07-27 20:00:00 (UTC)
* 現象   : 2026-07-27 20:00:00 (UTC)を境に水準が 11.94から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.832, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→10→15→13→11
* 開始   : 2026-07-28 04:05:00 (UTC)
* 終了   : 2026-07-28 04:05:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→11→14→10→11→14→10→13
* 開始   : 2026-07-28 18:55:00 (UTC)
* 終了   : 2026-07-28 19:05:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.75(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 8→9→12→9→8
* 開始   : 2026-07-29 01:05:00 (UTC)
* 終了   : 2026-07-29 01:05:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→14→16→12→13
* 開始   : 2026-07-29 04:25:00 (UTC)
* 終了   : 2026-07-29 04:25:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→14→8→10→12
* 開始   : 2026-07-29 19:50:00 (UTC)
* 終了   : 2026-07-29 19:50:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.6316(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260729-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260729-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→8→11→12→…→11→12→15→13
* 開始   : 2026-07-30 03:00:00 (UTC)
* 終了   : 2026-07-30 04:35:00 (UTC)
* 現象   : 1.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-5.873, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260730-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260730-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260730-lsfhost01-017 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分

![EVT-20260730-host02-001 active_connections の推移](charts/EVT-20260730-host02-001.svg)

# イベントID( EVT-20260730-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 17→17→20→18→18
* 開始   : 2026-07-30 07:05:00 (UTC)
* 終了   : 2026-07-30 07:05:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260730-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 21→19→19→19→17→20→20→20→22
* 開始   : 2026-07-30 07:25:00 (UTC)
* 終了   : 2026-07-30 08:35:00 (UTC)
* 現象   : 2026-07-30 08:35:00 (UTC)を境に水準が 14.93から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.684σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 20→21→25→20→20
* 開始   : 2026-07-30 10:00:00 (UTC)
* 終了   : 2026-07-30 10:00:00 (UTC)
* 現象   : 平常時(20.17)に対し 1.24倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.371σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 21→26→22→25→26→22→25→21
* 開始   : 2026-07-30 11:00:00 (UTC)
* 終了   : 2026-07-30 11:10:00 (UTC)
* 現象   : 平常時(21)に対し 1.238倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-050 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260730-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host02-009 active_connections の推移](charts/EVT-20260730-host02-009.svg)

# イベントID( EVT-20260730-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→13→9→11→…→11→10→14→12
* 開始   : 2026-07-30 19:25:00 (UTC)
* 終了   : 2026-07-30 19:35:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-014 (同一ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→10→4→12→…→4→12→9→8
* 開始   : 2026-07-31 00:25:00 (UTC)
* 終了   : 2026-07-31 00:30:00 (UTC)
* 現象   : 金曜0時台の平常値(8.077)に対し 4であった
* 説明   : ALG-A1: 移動平均からの残差が 3.158σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.499σ 外れた (平常値=8.077)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-002 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260731-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→11→17→15→12
* 開始   : 2026-07-31 05:30:00 (UTC)
* 終了   : 2026-07-31 05:30:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 18→19→16→17→18→19→16→17→18
* 開始   : 2026-07-31 15:45:00 (UTC)
* 終了   : 2026-07-31 15:50:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 9→11→13→12→11→13→12→9
* 開始   : 2026-07-01 03:35:00 (UTC)
* 終了   : 2026-07-01 03:40:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260701-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→10→14→11→14→11→14→10→11
* 開始   : 2026-07-01 03:50:00 (UTC)
* 終了   : 2026-07-01 04:00:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.377倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.669σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→13→16→13→17→16→13→17→15
* 開始   : 2026-07-01 05:25:00 (UTC)
* 終了   : 2026-07-01 05:35:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260701-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260701-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 16→20→16→18→20
* 開始   : 2026-07-01 06:45:00 (UTC)
* 終了   : 2026-07-01 07:05:00 (UTC)
* 現象   : 2026-07-01 07:05:00 (UTC)を境に水準が 16.09から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.048e+04→1.01e+04→9706→1.03e+04→…→1.03e+04→9406→1.018e+04→1.06e+04
* 開始   : 2026-07-01 17:55:00 (UTC)
* 終了   : 2026-07-01 18:05:00 (UTC)
* 現象   : 平常時(1.041e+04)に対し 0.9324(9706)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→12→10→12→…→12→9→11→13
* 開始   : 2026-07-01 19:25:00 (UTC)
* 終了   : 2026-07-01 19:35:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.7229(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.69σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260701-host01-010 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260701-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→9→9→10→12→9→9→11→12
* 開始   : 2026-07-02 01:40:00 (UTC)
* 終了   : 2026-07-02 02:25:00 (UTC)
* 現象   : 2026-07-02 02:25:00 (UTC)を境に水準が 14.89から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.314, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→7→12→11→13→12→11→13→11
* 開始   : 2026-07-02 02:55:00 (UTC)
* 終了   : 2026-07-02 03:05:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260702-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260702-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 16→19→20→21→…→17→21→19→18
* 開始   : 2026-07-02 07:45:00 (UTC)
* 終了   : 2026-07-02 08:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260702-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260702-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 18→21→17→18→21→17→18
* 開始   : 2026-07-02 08:10:00 (UTC)
* 終了   : 2026-07-02 08:15:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 20→20→22→20→20→22
* 開始   : 2026-07-02 08:20:00 (UTC)
* 終了   : 2026-07-02 08:45:00 (UTC)
* 現象   : 2026-07-02 08:45:00 (UTC)を境に水準が 15.07から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.513, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.111e+04→1.12e+04→1.025e+04→1.171e+04→…→1.025e+04→1.171e+04→1.135e+04→1.086e+04
* 開始   : 2026-07-02 09:40:00 (UTC)
* 終了   : 2026-07-02 09:45:00 (UTC)
* 現象   : 平常時(1.096e+04)に対し 0.9352(1.025e+04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.12σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260702-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→14→13→13→10→14→14→11→13
* 開始   : 2026-07-02 19:25:00 (UTC)
* 終了   : 2026-07-02 20:05:00 (UTC)
* 現象   : 2026-07-02 20:05:00 (UTC)を境に水準が 15.01から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.282, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host02-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 12→15→10→12→15→10→12→11
* 開始   : 2026-07-02 19:35:00 (UTC)
* 終了   : 2026-07-02 19:40:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.7273(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.625σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260702-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host02-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-022 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9793→9783→8849→9596→…→9596→8681→9773→9270
* 開始   : 2026-07-02 21:45:00 (UTC)
* 終了   : 2026-07-02 21:55:00 (UTC)
* 現象   : 平常時(9589)に対し 0.9229(8849)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-019 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-lsfhost01-080 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host01-012 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260702-host02-022 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host02-023 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→9→10→9
* 開始   : 2026-07-02 22:45:00 (UTC)
* 終了   : 2026-07-03 00:05:00 (UTC)
* 現象   : 2026-07-03 00:05:00 (UTC)を境に水準が 14.9から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.62, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host02-023 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 19→19→22→21→21
* 開始   : 2026-07-03 08:20:00 (UTC)
* 終了   : 2026-07-03 08:40:00 (UTC)
* 現象   : 2026-07-03 08:40:00 (UTC)を境に水準が 15.08から14.19へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host02-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 22→22→23
* 開始   : 2026-07-03 14:20:00 (UTC)
* 終了   : 2026-07-03 14:30:00 (UTC)
* 現象   : 2026-07-03 14:30:00 (UTC)を境に水準が 14.85から12.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 17→20→15→16→15→16→15→19→20
* 開始   : 2026-07-03 16:25:00 (UTC)
* 終了   : 2026-07-03 16:35:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.786(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.854σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 16→13→15→13→16→15→15
* 開始   : 2026-07-03 18:50:00 (UTC)
* 終了   : 2026-07-03 19:20:00 (UTC)
* 現象   : 2026-07-03 19:20:00 (UTC)を境に水準が 14.93から12.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.805, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→8→9→8→9→8→9
* 開始   : 2026-07-03 21:00:00 (UTC)
* 終了   : 2026-07-03 21:10:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6857(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.573σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-080 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260703-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260703-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→8→10→9→…→9→12→11→10
* 開始   : 2026-07-04 04:10:00 (UTC)
* 終了   : 2026-07-04 04:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.323, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260704-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260704-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260704-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260704-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260704-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260704-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260704-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 13→15→14→13→…→14→13→16→11
* 開始   : 2026-07-04 08:00:00 (UTC)
* 終了   : 2026-07-04 16:25:00 (UTC)
* 現象   : 8.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.897, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間
  - EVT-20260704-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間
  - EVT-20260704-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間
  - EVT-20260704-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間
  - EVT-20260704-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間
  - EVT-20260704-host02-009 (同一ホスト) jvm_gc / ou : FATAL / 重なり 8.4 時間
  - EVT-20260704-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 20 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.4 時間

![EVT-20260704-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host02-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2486→2494→2482→2517→…→2496→2484→2531→2484
* 開始   : 2026-07-04 13:00:00 (UTC)
* 終了   : 2026-07-04 13:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-50.52, 限界=49.87)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260704-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260704-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260704-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260704-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260704-host02-009 (同一ホスト) jvm_gc / ou : FATAL / 重なり 20 分
  - EVT-20260704-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分

![EVT-20260704-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host02-012 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9724→9632→9107→9514→…→9214→9544→9839→9178
* 開始   : 2026-07-04 19:05:00 (UTC)
* 終了   : 2026-07-04 19:30:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-543.2, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260704-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260704-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260704-host02-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260704-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260704-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260704-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分

![EVT-20260704-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host02-013 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 10→12→9→11→12→9→11→9
* 開始   : 2026-07-04 19:10:00 (UTC)
* 終了   : 2026-07-04 19:15:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.889, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host02-012 (同一ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260704-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260704-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→11→9→9→11→10→12
* 開始   : 2026-07-05 03:20:00 (UTC)
* 終了   : 2026-07-05 04:05:00 (UTC)
* 現象   : 2026-07-05 04:05:00 (UTC)を境に水準が 11.9から11.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→11→15→13→…→13→9→14→15
* 開始   : 2026-07-05 06:45:00 (UTC)
* 終了   : 2026-07-05 06:55:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260705-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→18→12→14→…→14→18→13→14
* 開始   : 2026-07-05 09:40:00 (UTC)
* 終了   : 2026-07-05 09:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260705-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260705-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9621→9965→1.099e+04→1.084e+04→…→1.084e+04→1.129e+04→1.052e+04→9986
* 開始   : 2026-07-05 10:10:00 (UTC)
* 終了   : 2026-07-05 10:20:00 (UTC)
* 現象   : 2026-07-05 10:20:00 (UTC)を境に水準が 9804から9936へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.351σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2130, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→13→18→16→13→18→16→17
* 開始   : 2026-07-05 10:15:00 (UTC)
* 終了   : 2026-07-05 10:20:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260705-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→17→19→14→19→14→19→16→15
* 開始   : 2026-07-05 12:30:00 (UTC)
* 終了   : 2026-07-05 12:40:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→13→18→14→…→14→12→14→16
* 開始   : 2026-07-05 14:55:00 (UTC)
* 終了   : 2026-07-05 15:05:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260705-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260705-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 7→9→11→5→…→11→5→10→7
* 開始   : 2026-07-06 00:55:00 (UTC)
* 終了   : 2026-07-06 01:00:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260706-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→7→9→9→10→9→9→10→11
* 開始   : 2026-07-06 01:25:00 (UTC)
* 終了   : 2026-07-06 02:50:00 (UTC)
* 現象   : 2026-07-06 02:50:00 (UTC)を境に水準が 11.82から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 18→21→20→19→…→17→20→16→17
* 開始   : 2026-07-06 03:10:00 (UTC)
* 終了   : 2026-07-06 20:55:00 (UTC)
* 現象   : 2026-07-06 20:55:00 (UTC)を境に水準が 11.83から14.94へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.537, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.781, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2548→2546→2542→2512→2531→2540→2513→2526→2575
* 開始   : 2026-07-06 07:40:00 (UTC)
* 終了   : 2026-07-06 16:20:00 (UTC)
* 現象   : 2026-07-06 16:20:00 (UTC)を境に水準が 2481から2498へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=53.3, 限界=49.87)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=263.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→15→14→12→15→14
* 開始   : 2026-07-07 05:10:00 (UTC)
* 終了   : 2026-07-07 05:15:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260707-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260707-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 16→17→18→15→16→17→18→15→16
* 開始   : 2026-07-07 06:15:00 (UTC)
* 終了   : 2026-07-07 06:20:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 21→20→20→19
* 開始   : 2026-07-07 08:10:00 (UTC)
* 終了   : 2026-07-07 08:25:00 (UTC)
* 現象   : 2026-07-07 08:25:00 (UTC)を境に水準が 14.98から16.52へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.008, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 19→22→20→22→20→22→21→20
* 開始   : 2026-07-07 08:40:00 (UTC)
* 終了   : 2026-07-07 08:50:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.189倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.447σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260707-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260707-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.113e+04→1.125e+04→1.042e+04→1.066e+04→…→1.066e+04→1.008e+04→1.061e+04→1.082e+04
* 開始   : 2026-07-07 14:00:00 (UTC)
* 終了   : 2026-07-07 14:10:00 (UTC)
* 現象   : 平常時(1.114e+04)に対し 0.935(1.042e+04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260707-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 21→20→17→18→17→18→17→19→20
* 開始   : 2026-07-07 15:30:00 (UTC)
* 終了   : 2026-07-07 15:40:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.8226(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260707-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→13→18→11→13→18→11→13
* 開始   : 2026-07-07 18:10:00 (UTC)
* 終了   : 2026-07-07 18:15:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260707-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260707-lsfhost01-052 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260707-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-053 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260707-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→15→11→10→12→15→11→10→12
* 開始   : 2026-07-07 19:30:00 (UTC)
* 終了   : 2026-07-07 19:35:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host02-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 12→12→11→12→10→10
* 開始   : 2026-07-07 21:05:00 (UTC)
* 終了   : 2026-07-07 21:30:00 (UTC)
* 現象   : 2026-07-07 21:30:00 (UTC)を境に水準が 15.01から16.42へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.513, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 6→8→11→8→11→8→11→8
* 開始   : 2026-07-08 01:15:00 (UTC)
* 終了   : 2026-07-08 01:25:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→8→12→9→8→12→9→11
* 開始   : 2026-07-08 02:15:00 (UTC)
* 終了   : 2026-07-08 02:20:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260708-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→8→5→10→…→10→12→9→10
* 開始   : 2026-07-08 02:30:00 (UTC)
* 終了   : 2026-07-08 02:40:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-006 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260708-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.006e+04→1.016e+04→9299→9615→…→9949→9345→1.011e+04→1.02e+04
* 開始   : 2026-07-08 04:25:00 (UTC)
* 終了   : 2026-07-08 05:20:00 (UTC)
* 現象   : 55分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.31σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260708-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 55 分
  - EVT-20260708-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260708-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260708-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260708-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 20→19→21→18→…→18→22→19→18
* 開始   : 2026-07-08 08:20:00 (UTC)
* 終了   : 2026-07-08 08:30:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.161倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260708-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→19→22→21→…→19→23→21→19
* 開始   : 2026-07-08 08:55:00 (UTC)
* 終了   : 2026-07-08 09:15:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.858σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260708-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-lsfhost01-037 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260708-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 24→19→25→24→19→25→24→20
* 開始   : 2026-07-08 11:55:00 (UTC)
* 終了   : 2026-07-08 12:00:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260708-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 22→19→25→20→22→19→25→20→22
* 開始   : 2026-07-08 12:25:00 (UTC)
* 終了   : 2026-07-08 12:30:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260708-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host02-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.146e+04→1.174e+04→1.101e+04→1.125e+04
* 開始   : 2026-07-08 13:55:00 (UTC)
* 終了   : 2026-07-08 14:10:00 (UTC)
* 現象   : 2026-07-08 14:10:00 (UTC)を境に水準が 1.023e+04から1.026e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2221, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 18→15→15→17→15→15→14→14→15
* 開始   : 2026-07-08 16:15:00 (UTC)
* 終了   : 2026-07-08 18:25:00 (UTC)
* 現象   : 2026-07-08 18:25:00 (UTC)を境に水準が 14.99から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.609, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→14→12→13→…→12→10→15→12
* 開始   : 2026-07-08 18:15:00 (UTC)
* 終了   : 2026-07-08 19:05:00 (UTC)
* 現象   : 50分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260708-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 50 分
  - EVT-20260708-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→13→10→9→…→10→9→12→13
* 開始   : 2026-07-08 20:00:00 (UTC)
* 終了   : 2026-07-08 20:05:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260708-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→11→12→11→13→11→12→11→14
* 開始   : 2026-07-09 02:50:00 (UTC)
* 終了   : 2026-07-09 04:05:00 (UTC)
* 現象   : 2026-07-09 04:05:00 (UTC)を境に水準が 15.02から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260709-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→14→17→18→15→14→17→18→15
* 開始   : 2026-07-09 05:45:00 (UTC)
* 終了   : 2026-07-09 05:50:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.379σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260709-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→18→19→20→…→19→20→16→17
* 開始   : 2026-07-09 07:05:00 (UTC)
* 終了   : 2026-07-09 07:10:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-029 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260709-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 22→25→21→26→25→21→26→21→22
* 開始   : 2026-07-09 11:45:00 (UTC)
* 終了   : 2026-07-09 11:55:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260709-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.091e+04→1.075e+04→1.155e+04→1.003e+04→…→1.155e+04→1.003e+04→1.067e+04→1.059e+04
* 開始   : 2026-07-09 16:00:00 (UTC)
* 終了   : 2026-07-09 16:05:00 (UTC)
* 現象   : 平常時(1.082e+04)に対し 1.067倍(1.155e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.177σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→11→12→10→…→10→11→10→13
* 開始   : 2026-07-09 19:20:00 (UTC)
* 終了   : 2026-07-09 19:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260709-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260709-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260709-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→16→14→13→16→14
* 開始   : 2026-07-10 05:20:00 (UTC)
* 終了   : 2026-07-10 05:25:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.297倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host02-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→14→16→14→…→14→17→13→14
* 開始   : 2026-07-10 05:20:00 (UTC)
* 終了   : 2026-07-10 05:30:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.306倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.615σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host02-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→18→19→18→16→18→19→18→15
* 開始   : 2026-07-10 06:40:00 (UTC)
* 終了   : 2026-07-10 06:45:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260710-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 16→18→19→17→16→18→19→17
* 開始   : 2026-07-10 06:55:00 (UTC)
* 終了   : 2026-07-10 07:00:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260710-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260710-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 20→18→22→18→…→20→23→21→22
* 開始   : 2026-07-10 08:45:00 (UTC)
* 終了   : 2026-07-10 09:10:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260710-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→15→12→13→12
* 開始   : 2026-07-10 19:20:00 (UTC)
* 終了   : 2026-07-10 19:40:00 (UTC)
* 現象   : 2026-07-10 19:40:00 (UTC)を境に水準が 14.98から11.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.061e+04→1.016e+04→1.029e+04→1.035e+04→…→1.03e+04→9633→1.025e+04→9949
* 開始   : 2026-07-11 05:00:00 (UTC)
* 終了   : 2026-07-11 17:25:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.822σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-550.8, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260711-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260711-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260711-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260711-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 7.8 時間
  - EVT-20260711-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 2.4 時間
  - EVT-20260711-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260711-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 12→13→12→14→…→12→14→15→14
* 開始   : 2026-07-11 07:25:00 (UTC)
* 終了   : 2026-07-11 07:30:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(12)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.709, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host02-001 (同一ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260711-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 14→13→11→15→…→14→12→14→12
* 開始   : 2026-07-11 08:45:00 (UTC)
* 終了   : 2026-07-11 16:30:00 (UTC)
* 現象   : 7.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-5.176, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 7.8 時間
  - EVT-20260711-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 7.8 時間
  - EVT-20260711-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 7.8 時間
  - EVT-20260711-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 7.8 時間
  - EVT-20260711-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 7.8 時間
  - EVT-20260711-host02-001 (同一ホスト) jvm_gc / ou : WARN / 重なり 7.8 時間
  - EVT-20260711-host02-010 (同一ホスト) jvm_gc / mu : WARN / 重なり 2.4 時間
  - EVT-20260711-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 7.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 7.8 時間

![EVT-20260711-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2488→2494→2469→2485→…→2469→2485→2487→2508
* 開始   : 2026-07-11 09:25:00 (UTC)
* 終了   : 2026-07-11 09:30:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(2469)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-52.27, 限界=49.87)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host02-001 (同一ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260711-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260711-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2491→2499→2474→2471→…→2471→2506→2515→2484
* 開始   : 2026-07-11 13:25:00 (UTC)
* 終了   : 2026-07-11 15:50:00 (UTC)
* 現象   : 2.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-56.71, 限界=49.87)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 2.4 時間
  - EVT-20260711-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 2.4 時間
  - EVT-20260711-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 2.4 時間
  - EVT-20260711-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 2.4 時間
  - EVT-20260711-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 2.4 時間
  - EVT-20260711-host02-001 (同一ホスト) jvm_gc / ou : WARN / 重なり 2.4 時間
  - EVT-20260711-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 2.4 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 2.4 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 2.4 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 2.4 時間

![EVT-20260711-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host02-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9617→9412→8824→9864→…→9864→9394→9706→9328
* 開始   : 2026-07-11 18:50:00 (UTC)
* 終了   : 2026-07-11 19:00:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8824)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-542.9, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260711-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host02-012 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 8→11→9→8→…→11→9→11→10
* 開始   : 2026-07-11 20:20:00 (UTC)
* 終了   : 2026-07-11 20:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.443, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260711-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260711-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260711-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260711-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 12→12→10→10→10→13→11→13→13
* 開始   : 2026-07-12 04:25:00 (UTC)
* 終了   : 2026-07-12 05:10:00 (UTC)
* 現象   : 2026-07-12 05:10:00 (UTC)を境に水準が 11.88から12.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.521, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→10→14→15→…→14→15→11→14
* 開始   : 2026-07-12 05:50:00 (UTC)
* 終了   : 2026-07-12 05:55:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260712-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.015e+04→9819→1.058e+04→9888→…→9888→1.059e+04→9850→1.021e+04
* 開始   : 2026-07-12 07:40:00 (UTC)
* 終了   : 2026-07-12 07:50:00 (UTC)
* 現象   : 平常時(9821)に対し 1.077倍(1.058e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260712-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host02-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 18→16→14→15→15
* 開始   : 2026-07-12 08:40:00 (UTC)
* 終了   : 2026-07-12 09:00:00 (UTC)
* 現象   : 2026-07-12 09:00:00 (UTC)を境に水準が 11.92から12.77へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host02-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 18→16→17→17→16
* 開始   : 2026-07-12 09:15:00 (UTC)
* 終了   : 2026-07-12 09:35:00 (UTC)
* 現象   : 2026-07-12 09:35:00 (UTC)を境に水準が 11.88から12.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.524, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.023e+04→1.016e+04→9961→1.008e+04→9894→9500→1.035e+04→9935→1.002e+04
* 開始   : 2026-07-12 18:00:00 (UTC)
* 終了   : 2026-07-12 19:10:00 (UTC)
* 現象   : 2026-07-12 19:10:00 (UTC)を境に水準が 9799から1.02e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2229, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→8→6→8→6→8→6→7→9
* 開始   : 2026-07-12 21:30:00 (UTC)
* 終了   : 2026-07-12 21:40:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host02-008 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260712-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-lsfhost01-044 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260712-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260712-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 7→8→12→5→…→12→5→7→8
* 開始   : 2026-07-12 23:00:00 (UTC)
* 終了   : 2026-07-12 23:05:00 (UTC)
* 現象   : 平常時(8.167)に対し 1.469倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 9→8→9→8→8→11→11→8→12
* 開始   : 2026-07-13 00:35:00 (UTC)
* 終了   : 2026-07-13 01:15:00 (UTC)
* 現象   : 2026-07-13 01:15:00 (UTC)を境に水準が 11.88から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.269, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 17→18→17→18→…→19→17→16→15
* 開始   : 2026-07-13 03:00:00 (UTC)
* 終了   : 2026-07-13 20:25:00 (UTC)
* 現象   : 2026-07-13 20:25:00 (UTC)を境に水準が 11.93から14.9へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.694, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2560→2550→2544→2546→2559→2533→2545→2521→2546
* 開始   : 2026-07-13 09:45:00 (UTC)
* 終了   : 2026-07-13 13:45:00 (UTC)
* 現象   : 2026-07-13 13:45:00 (UTC)を境に水準が 2488から2500へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=52.66, 限界=49.87)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=264.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→7→13→11→9→7→13→11
* 開始   : 2026-07-13 20:35:00 (UTC)
* 終了   : 2026-07-13 20:40:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260713-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9716→9388→9971→1.001e+04→9485→9880
* 開始   : 2026-07-13 21:00:00 (UTC)
* 終了   : 2026-07-13 21:25:00 (UTC)
* 現象   : 2026-07-13 21:25:00 (UTC)を境に水準が 1.021e+04から1.024e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2739, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→14→15→13→14→15→13→12
* 開始   : 2026-07-14 04:55:00 (UTC)
* 終了   : 2026-07-14 05:00:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260714-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→14→16→13→14→16→13→14
* 開始   : 2026-07-14 05:30:00 (UTC)
* 終了   : 2026-07-14 05:35:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host02-004 (同一ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260714-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 19→16→17→19→16→17→19
* 開始   : 2026-07-14 15:40:00 (UTC)
* 終了   : 2026-07-14 15:45:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.8136(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260714-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host02-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 20→19→20→17→20→17→16→19→17
* 開始   : 2026-07-14 16:15:00 (UTC)
* 終了   : 2026-07-14 17:15:00 (UTC)
* 現象   : 2026-07-14 17:15:00 (UTC)を境に水準が 14.88から16.34へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.277, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→9→6→7→6→7→6→9→10
* 開始   : 2026-07-14 21:50:00 (UTC)
* 終了   : 2026-07-14 22:00:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260714-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9972→9560→9774→1.015e+04→9620→1.003e+04→1.021e+04→1.022e+04→1.047e+04
* 開始   : 2026-07-15 03:05:00 (UTC)
* 終了   : 2026-07-15 03:45:00 (UTC)
* 現象   : 2026-07-15 03:45:00 (UTC)を境に水準が 1.024e+04から1.027e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2633, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9707→1.037e+04→1.058e+04→1.07e+04→…→1.058e+04→1.07e+04→1.027e+04→9707
* 開始   : 2026-07-15 05:20:00 (UTC)
* 終了   : 2026-07-15 05:25:00 (UTC)
* 現象   : 平常時(9907)に対し 1.068倍(1.058e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.002σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host02-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 16→18→14→17→16
* 開始   : 2026-07-15 17:30:00 (UTC)
* 終了   : 2026-07-15 17:50:00 (UTC)
* 現象   : 2026-07-15 17:50:00 (UTC)を境に水準が 14.94から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→18→13→15→…→15→12→15→14
* 開始   : 2026-07-15 18:05:00 (UTC)
* 終了   : 2026-07-15 18:15:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260715-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260715-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260715-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260715-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 8→9→12→13→…→12→13→11→9
* 開始   : 2026-07-16 02:40:00 (UTC)
* 終了   : 2026-07-16 02:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.437σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 16→18→19→16→18→19→16→17
* 開始   : 2026-07-16 06:50:00 (UTC)
* 終了   : 2026-07-16 06:55:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 19→18→21→19→…→19→22→19→20
* 開始   : 2026-07-16 08:35:00 (UTC)
* 終了   : 2026-07-16 08:45:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.161倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.118e+04→1.115e+04→1.16e+04→1.078e+04→…→1.078e+04→1.161e+04→1.118e+04→1.065e+04
* 開始   : 2026-07-16 09:20:00 (UTC)
* 終了   : 2026-07-16 09:30:00 (UTC)
* 現象   : 平常時(1.076e+04)に対し 1.079倍(1.16e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.535σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260716-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260716-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 21→24→19→24→19→24→20→21
* 開始   : 2026-07-16 10:05:00 (UTC)
* 終了   : 2026-07-16 10:15:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.215倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.982σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 9→6→8→9→6→8
* 開始   : 2026-07-16 21:50:00 (UTC)
* 終了   : 2026-07-16 21:55:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.595(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.865σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-087 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260716-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-084 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260716-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 8→5→11→5→11→9
* 開始   : 2026-07-17 00:25:00 (UTC)
* 終了   : 2026-07-17 00:35:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-004 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260717-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→8→11→9→9→10→11→10→11
* 開始   : 2026-07-17 01:45:00 (UTC)
* 終了   : 2026-07-17 03:05:00 (UTC)
* 現象   : 2026-07-17 03:05:00 (UTC)を境に水準が 14.9から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.383, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→11→14→13→…→13→15→10→12
* 開始   : 2026-07-17 03:35:00 (UTC)
* 終了   : 2026-07-17 03:45:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.495σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260717-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→14→16→15→…→16→15→16→14
* 開始   : 2026-07-17 05:10:00 (UTC)
* 終了   : 2026-07-17 05:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.916σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260717-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 19→17→21→19→17→21→19→18
* 開始   : 2026-07-17 08:10:00 (UTC)
* 終了   : 2026-07-17 08:15:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.437σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 18→19→17→19→…→19→16→17→21
* 開始   : 2026-07-17 16:00:00 (UTC)
* 終了   : 2026-07-17 16:10:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 18→16→14→15→…→15→13→16→15
* 開始   : 2026-07-17 17:10:00 (UTC)
* 終了   : 2026-07-17 17:20:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 15→18→15→16→14→15→15→16→15
* 開始   : 2026-07-17 17:55:00 (UTC)
* 終了   : 2026-07-17 18:35:00 (UTC)
* 現象   : 2026-07-17 18:35:00 (UTC)を境に水準が 15から12.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.269, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→17→13→15→17→13→15→18
* 開始   : 2026-07-17 18:00:00 (UTC)
* 終了   : 2026-07-17 18:05:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7879(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260717-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260717-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→11→13→11→13→11→14
* 開始   : 2026-07-17 18:55:00 (UTC)
* 終了   : 2026-07-17 19:05:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.7416(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.69σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-079 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260717-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-lsfhost01-080 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260717-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→11→10→12→10
* 開始   : 2026-07-17 20:45:00 (UTC)
* 終了   : 2026-07-17 21:55:00 (UTC)
* 現象   : 2026-07-17 21:55:00 (UTC)を境に水準が 15から11.8へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.29, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 10→7→10→7→10→7→10→9
* 開始   : 2026-07-17 21:10:00 (UTC)
* 終了   : 2026-07-17 21:20:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.6512(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.621σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-lsfhost01-087 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260717-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 15→14→13→14→…→13→12→14→13
* 開始   : 2026-07-18 07:50:00 (UTC)
* 終了   : 2026-07-18 16:55:00 (UTC)
* 現象   : 9.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.798, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.1 時間
  - EVT-20260718-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.1 時間
  - EVT-20260718-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.1 時間
  - EVT-20260718-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.1 時間
  - EVT-20260718-host02-005 (同一ホスト) jvm_gc / ou : FATAL / 重なり 9.1 時間
  - EVT-20260718-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.1 時間
  - EVT-20260718-host02-008 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260718-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 9.1 時間
  - EVT-20260718-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 9.1 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 9.1 時間

![EVT-20260718-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2459→2492→2464→2473→…→2478→2482→2495→2499
* 開始   : 2026-07-18 08:55:00 (UTC)
* 終了   : 2026-07-18 09:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-56.06, 限界=49.87)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260718-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260718-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260718-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260718-host02-005 (同一ホスト) jvm_gc / ou : FATAL / 重なり 15 分
  - EVT-20260718-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260718-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260718-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260718-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260718-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→9→10→9→…→9→10→9→10
* 開始   : 2026-07-18 19:20:00 (UTC)
* 終了   : 2026-07-18 19:45:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.117, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260718-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260718-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260718-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260718-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260718-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260718-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分

![EVT-20260718-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→8→9→9→9→9→10
* 開始   : 2026-07-19 01:35:00 (UTC)
* 終了   : 2026-07-19 02:05:00 (UTC)
* 現象   : 2026-07-19 02:05:00 (UTC)を境に水準が 11.73から11.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.805, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→10→12→13→10→12→13→10→8
* 開始   : 2026-07-19 03:40:00 (UTC)
* 終了   : 2026-07-19 03:45:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260719-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260719-lsfhost01-005 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260719-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 19→15→16→16→17→15→16→17→17
* 開始   : 2026-07-19 10:25:00 (UTC)
* 終了   : 2026-07-19 11:05:00 (UTC)
* 現象   : 2026-07-19 11:05:00 (UTC)を境に水準が 11.89から13.22へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 18→17→17→17→17
* 開始   : 2026-07-19 11:30:00 (UTC)
* 終了   : 2026-07-19 11:50:00 (UTC)
* 現象   : 2026-07-19 11:50:00 (UTC)を境に水準が 11.83から13.51へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.157, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 18→17→17→16
* 開始   : 2026-07-19 13:50:00 (UTC)
* 終了   : 2026-07-19 14:05:00 (UTC)
* 現象   : 2026-07-19 14:05:00 (UTC)を境に水準が 11.78から13.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.01, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host02-010 )

* イベント種別 : ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 15→14→18→14→18→14
* 開始   : 2026-07-19 15:10:00 (UTC)
* 終了   : 2026-07-19 15:15:00 (UTC)
* 現象   : 日曜15時台の平常値(14.13)に対し 18であった
* 説明   : ALG-A5: 同じ曜日・時刻帯の平常値から 3.035σ 外れた (平常値=14.13)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→16→15→13→16→15
* 開始   : 2026-07-19 15:50:00 (UTC)
* 終了   : 2026-07-19 16:15:00 (UTC)
* 現象   : 2026-07-19 16:15:00 (UTC)を境に水準が 11.91から14.44へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.547, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.045e+04→9666→9188→9010→…→9188→9010→9567→9249
* 開始   : 2026-07-19 18:10:00 (UTC)
* 終了   : 2026-07-19 18:15:00 (UTC)
* 現象   : 平常時(9951)に対し 0.9233(9188)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host02-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260719-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260719-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9628→9566→8520→1.011e+04→…→8520→1.011e+04→9629→9874
* 開始   : 2026-07-19 21:30:00 (UTC)
* 終了   : 2026-07-19 21:35:00 (UTC)
* 現象   : 平常時(9399)に対し 0.9065(8520)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.625σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260719-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 18→19→20→19→…→21→20→16→19
* 開始   : 2026-07-20 02:25:00 (UTC)
* 終了   : 2026-07-20 20:25:00 (UTC)
* 現象   : 2026-07-20 20:25:00 (UTC)を境に水準が 11.71から15へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.567, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2529→2518→2513→2517→2504→2528→2520→2529→2518
* 開始   : 2026-07-20 09:15:00 (UTC)
* 終了   : 2026-07-20 16:15:00 (UTC)
* 現象   : 2026-07-20 16:15:00 (UTC)を境に水準が 2483から2499へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=49.7, 限界=49.87)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=264.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 9→9→10→9
* 開始   : 2026-07-20 23:30:00 (UTC)
* 終了   : 2026-07-20 23:45:00 (UTC)
* 現象   : 2026-07-20 23:45:00 (UTC)を境に水準が 14.91から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.008, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 8889→9371→8459→9944→…→8459→9944→9068→9280
* 開始   : 2026-07-21 00:15:00 (UTC)
* 終了   : 2026-07-21 00:20:00 (UTC)
* 現象   : 平常時(9236)に対し 0.9159(8459)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260721-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 9→10→10→9→10→11→12
* 開始   : 2026-07-21 01:40:00 (UTC)
* 終了   : 2026-07-21 02:10:00 (UTC)
* 現象   : 2026-07-21 02:10:00 (UTC)を境に水準が 14.94から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.765, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.011e+04→1.049e+04→1.072e+04→9987→…→1.001e+04→1.087e+04→1.066e+04→1.034e+04
* 開始   : 2026-07-21 05:50:00 (UTC)
* 終了   : 2026-07-21 06:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260721-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→15→17→15→17→15→17→14→16
* 開始   : 2026-07-21 06:15:00 (UTC)
* 終了   : 2026-07-21 06:25:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 18→19→21→19→…→19→22→19→18
* 開始   : 2026-07-21 08:20:00 (UTC)
* 終了   : 2026-07-21 08:30:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260721-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.126e+04→1.112e+04→1.074e+04→1.054e+04→…→1.134e+04→1.062e+04→1.113e+04→1.096e+04
* 開始   : 2026-07-21 13:35:00 (UTC)
* 終了   : 2026-07-21 13:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.003σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-047 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260721-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 19→17→15→18→…→15→14→17→14
* 開始   : 2026-07-21 17:15:00 (UTC)
* 終了   : 2026-07-21 17:35:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260721-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 16→16→15→13→15→14→16→14
* 開始   : 2026-07-21 18:30:00 (UTC)
* 終了   : 2026-07-21 19:05:00 (UTC)
* 現象   : 2026-07-21 19:05:00 (UTC)を境に水準が 15.07から16.39へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.017, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→13→9→8→9→13→9→8→9
* 開始   : 2026-07-21 20:30:00 (UTC)
* 終了   : 2026-07-21 20:35:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→12→9→8→…→9→8→11→10
* 開始   : 2026-07-21 20:50:00 (UTC)
* 終了   : 2026-07-21 21:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260721-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→8→11→10→9→10→10→8→10
* 開始   : 2026-07-22 01:25:00 (UTC)
* 終了   : 2026-07-22 03:45:00 (UTC)
* 現象   : 2026-07-22 03:45:00 (UTC)を境に水準が 14.97から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.578, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→12→15→14→15→14→15→12→11
* 開始   : 2026-07-22 04:35:00 (UTC)
* 終了   : 2026-07-22 04:45:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260722-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host02-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 19→18→21→19→20→20→19
* 開始   : 2026-07-22 07:50:00 (UTC)
* 終了   : 2026-07-22 08:20:00 (UTC)
* 現象   : 2026-07-22 08:20:00 (UTC)を境に水準が 15.02から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.389, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 24→22→24→21→22→23→21→22
* 開始   : 2026-07-22 12:40:00 (UTC)
* 終了   : 2026-07-22 13:15:00 (UTC)
* 現象   : 2026-07-22 13:15:00 (UTC)を境に水準が 15.14から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.063, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→15→11→13→…→11→10→13→12
* 開始   : 2026-07-22 19:15:00 (UTC)
* 終了   : 2026-07-22 19:35:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 20 分
  - EVT-20260722-host06-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host13-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-073 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260722-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 8→11→8→11→8→9
* 開始   : 2026-07-23 01:50:00 (UTC)
* 終了   : 2026-07-23 02:40:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.321σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-lsfhost01-009 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260723-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-006 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260723-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→14→16→13→16→13→16→14→15
* 開始   : 2026-07-23 05:25:00 (UTC)
* 終了   : 2026-07-23 05:35:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 17→19→18→21
* 開始   : 2026-07-23 07:20:00 (UTC)
* 終了   : 2026-07-23 07:35:00 (UTC)
* 現象   : 2026-07-23 07:35:00 (UTC)を境に水準が 14.96から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.031, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.136e+04→1.124e+04→1.119e+04→1.154e+04→1.123e+04→1.113e+04→1.115e+04→1.126e+04→1.152e+04
* 開始   : 2026-07-23 14:00:00 (UTC)
* 終了   : 2026-07-23 14:55:00 (UTC)
* 現象   : 2026-07-23 14:55:00 (UTC)を境に水準が 1.023e+04から1.026e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2332, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host02-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 20→20→18→17
* 開始   : 2026-07-23 16:50:00 (UTC)
* 終了   : 2026-07-23 17:05:00 (UTC)
* 現象   : 2026-07-23 17:05:00 (UTC)を境に水準が 14.91から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.031, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 19→18→15→18→15→16
* 開始   : 2026-07-23 17:00:00 (UTC)
* 終了   : 2026-07-23 17:05:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→13→11→13→…→13→10→14→13
* 開始   : 2026-07-23 19:10:00 (UTC)
* 終了   : 2026-07-23 19:20:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260723-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→9→6→12→…→6→12→8→11
* 開始   : 2026-07-24 02:20:00 (UTC)
* 終了   : 2026-07-24 02:25:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→9→14→12→9→14→12→13
* 開始   : 2026-07-24 03:50:00 (UTC)
* 終了   : 2026-07-24 03:55:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.388倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.738σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260724-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→12→14→12→14→12
* 開始   : 2026-07-24 04:20:00 (UTC)
* 終了   : 2026-07-24 04:25:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→15→17→14→17→14→17→15
* 開始   : 2026-07-24 05:35:00 (UTC)
* 終了   : 2026-07-24 05:45:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host02-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260724-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→16→14→17→16→14→17→15→16
* 開始   : 2026-07-24 05:40:00 (UTC)
* 終了   : 2026-07-24 05:50:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host02-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260724-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260724-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→14→17→18→…→17→18→17→14
* 開始   : 2026-07-24 06:10:00 (UTC)
* 終了   : 2026-07-24 06:15:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260724-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host02-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 24→22→23→22→23→22→21→26→22
* 開始   : 2026-07-24 10:55:00 (UTC)
* 終了   : 2026-07-24 11:35:00 (UTC)
* 現象   : 2026-07-24 11:35:00 (UTC)を境に水準が 14.93から13.57へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.501, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host02-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 17→18→17→17→15→12→14→14→15
* 開始   : 2026-07-24 17:15:00 (UTC)
* 終了   : 2026-07-24 19:20:00 (UTC)
* 現象   : 2026-07-24 19:20:00 (UTC)を境に水準が 14.93から11.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.294, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→19→13→14→15→19→13→14→17
* 開始   : 2026-07-24 17:35:00 (UTC)
* 終了   : 2026-07-24 17:40:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260724-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host02-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 16→16→14→15→14→16→16→15→14
* 開始   : 2026-07-24 18:10:00 (UTC)
* 終了   : 2026-07-24 18:55:00 (UTC)
* 現象   : 2026-07-24 18:55:00 (UTC)を境に水準が 15.07から11.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→9→12→9→12→9→10→11
* 開始   : 2026-07-24 20:10:00 (UTC)
* 終了   : 2026-07-24 20:20:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.7013(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260724-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→9→7→11→9→7→11→9
* 開始   : 2026-07-24 20:45:00 (UTC)
* 終了   : 2026-07-24 20:50:00 (UTC)
* 現象   : 金曜20時台の平常値(10.79)に対し 7であった
* 説明   : ALG-A1: 移動平均からの残差が 2.79σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.034σ 外れた (平常値=10.79)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260724-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 13→10→14→12→…→14→13→14→12
* 開始   : 2026-07-25 07:55:00 (UTC)
* 終了   : 2026-07-25 16:30:00 (UTC)
* 現象   : 8.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.596, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.6 時間
  - EVT-20260725-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.6 時間
  - EVT-20260725-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.6 時間
  - EVT-20260725-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.6 時間
  - EVT-20260725-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 8.6 時間
  - EVT-20260725-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.6 時間
  - EVT-20260725-host02-009 (同一ホスト) jvm_gc / mu : WARN / 重なり 15 分
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.6 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.6 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 8.6 時間

![EVT-20260725-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2485→2478→2466→2485→…→2465→2464→2521→2522
* 開始   : 2026-07-25 09:50:00 (UTC)
* 終了   : 2026-07-25 10:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-50.95, 限界=49.87)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 15 分
  - EVT-20260725-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host02-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 15 分

![EVT-20260725-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9082→9397→8836→8945→…→9075→9577→9559→9333
* 開始   : 2026-07-25 18:35:00 (UTC)
* 終了   : 2026-07-25 20:00:00 (UTC)
* 現象   : 1.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.42σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-640, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.4 時間
  - EVT-20260725-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.4 時間
  - EVT-20260725-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.2 時間
  - EVT-20260725-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 1.4 時間
  - EVT-20260725-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.4 時間
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.4 時間
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.4 時間
  - EVT-20260725-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.4 時間
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.4 時間

![EVT-20260725-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host02-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→10→8→10→…→8→10→11→9
* 開始   : 2026-07-25 19:20:00 (UTC)
* 終了   : 2026-07-25 19:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.82, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host02-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host02-010 (同一ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260725-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260725-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→10→10→11
* 開始   : 2026-07-26 00:00:00 (UTC)
* 終了   : 2026-07-26 00:15:00 (UTC)
* 現象   : 2026-07-26 00:15:00 (UTC)を境に水準が 11.77から11.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.031, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 9→10→11→9→9→10→9→11→11
* 開始   : 2026-07-26 01:40:00 (UTC)
* 終了   : 2026-07-26 03:15:00 (UTC)
* 現象   : 2026-07-26 03:15:00 (UTC)を境に水準が 11.75から11.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.042, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 8→10→6→12→…→6→12→8→10
* 開始   : 2026-07-26 03:10:00 (UTC)
* 終了   : 2026-07-26 03:15:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260726-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→12→16→12→17→16→12→17→13
* 開始   : 2026-07-26 07:25:00 (UTC)
* 終了   : 2026-07-26 07:35:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260726-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→17→18→15→13→17→18→15
* 開始   : 2026-07-26 08:55:00 (UTC)
* 終了   : 2026-07-26 09:00:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→18→15→19→18→15→19→15→14
* 開始   : 2026-07-26 11:30:00 (UTC)
* 終了   : 2026-07-26 11:40:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260726-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260726-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→17→17→18→16→17
* 開始   : 2026-07-26 12:55:00 (UTC)
* 終了   : 2026-07-26 13:20:00 (UTC)
* 現象   : 2026-07-26 13:20:00 (UTC)を境に水準が 11.74から13.76へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.264, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.021e+04→1.03e+04→9443→1.095e+04→…→9443→1.095e+04→9976→9776
* 開始   : 2026-07-26 15:20:00 (UTC)
* 終了   : 2026-07-26 15:25:00 (UTC)
* 現象   : 平常時(1.025e+04)に対し 0.9214(9443)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.406σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260726-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→8→5→8→…→8→11→7→10
* 開始   : 2026-07-26 23:45:00 (UTC)
* 終了   : 2026-07-27 00:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.553σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分

![EVT-20260726-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 19→20→17→19→…→20→19→20→18
* 開始   : 2026-07-27 01:50:00 (UTC)
* 終了   : 2026-07-27 20:50:00 (UTC)
* 現象   : 2026-07-27 20:50:00 (UTC)を境に水準が 11.84から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.726, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.781, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2536→2553→2501→2515→2545→2539→2566→2574→2551
* 開始   : 2026-07-27 09:25:00 (UTC)
* 終了   : 2026-07-27 16:25:00 (UTC)
* 現象   : 2026-07-27 16:25:00 (UTC)を境に水準が 2486から2498へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=260, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9538→1.01e+04→1.083e+04→1.092e+04→…→1.083e+04→1.092e+04→1.021e+04→1.04e+04
* 開始   : 2026-07-28 05:50:00 (UTC)
* 終了   : 2026-07-28 05:55:00 (UTC)
* 現象   : 平常時(9932)に対し 1.09倍(1.083e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.674σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 18→16→20→21→18→16→20→21→18
* 開始   : 2026-07-28 07:40:00 (UTC)
* 終了   : 2026-07-28 07:45:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.231倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.615σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260728-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 16→18→20→17→…→17→21→18→17
* 開始   : 2026-07-28 07:55:00 (UTC)
* 終了   : 2026-07-28 08:05:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260728-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 21→23→24→18→…→24→18→22→20
* 開始   : 2026-07-28 10:10:00 (UTC)
* 終了   : 2026-07-28 10:15:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 21→19→22→22→21
* 開始   : 2026-07-28 15:35:00 (UTC)
* 終了   : 2026-07-28 15:55:00 (UTC)
* 現象   : 2026-07-28 15:55:00 (UTC)を境に水準が 14.95から16.42へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→13→16→13→…→14→12→15→14
* 開始   : 2026-07-28 17:55:00 (UTC)
* 終了   : 2026-07-28 18:15:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260728-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260728-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→13→12→15→…→15→11→16→14
* 開始   : 2026-07-28 18:25:00 (UTC)
* 終了   : 2026-07-28 18:35:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260728-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260728-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→10
* 開始   : 2026-07-29 00:40:00 (UTC)
* 終了   : 2026-07-29 00:55:00 (UTC)
* 現象   : 2026-07-29 00:55:00 (UTC)を境に水準が 14.86から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.031, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→14→16→13→16→13→16→13→14
* 開始   : 2026-07-29 05:25:00 (UTC)
* 終了   : 2026-07-29 05:35:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.306倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.615σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260729-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 20→19→21→21→19
* 開始   : 2026-07-29 07:40:00 (UTC)
* 終了   : 2026-07-29 08:00:00 (UTC)
* 現象   : 2026-07-29 08:00:00 (UTC)を境に水準が 16.38から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 24→22→22→23→20→23→22→23→24
* 開始   : 2026-07-29 12:20:00 (UTC)
* 終了   : 2026-07-29 14:00:00 (UTC)
* 現象   : 2026-07-29 14:00:00 (UTC)を境に水準が 14.96から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→18→13→15→18→13→15
* 開始   : 2026-07-29 17:40:00 (UTC)
* 終了   : 2026-07-29 17:45:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7879(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.437σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260729-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→15→11→15→…→15→10→11→12
* 開始   : 2026-07-29 19:20:00 (UTC)
* 終了   : 2026-07-29 19:30:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260729-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→14→10→13→14→10→13→12
* 開始   : 2026-07-29 19:40:00 (UTC)
* 終了   : 2026-07-29 19:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260729-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260729-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→14→16→9→…→16→9→15→13
* 開始   : 2026-07-30 05:00:00 (UTC)
* 終了   : 2026-07-30 05:05:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.343倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.865σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260730-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→12→15→13→12→15→13→14
* 開始   : 2026-07-30 05:15:00 (UTC)
* 終了   : 2026-07-30 05:20:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 18→17→20→18→20→18→20→19
* 開始   : 2026-07-30 07:35:00 (UTC)
* 終了   : 2026-07-30 07:45:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 19→16→21→18→21→18→21→18→17
* 開始   : 2026-07-30 08:00:00 (UTC)
* 終了   : 2026-07-30 08:10:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.248倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.906σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 21→23→19→18→19→18→23→20
* 開始   : 2026-07-30 14:30:00 (UTC)
* 終了   : 2026-07-30 14:40:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 20→17→19→20→17→19→18
* 開始   : 2026-07-30 15:35:00 (UTC)
* 終了   : 2026-07-30 15:40:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260730-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 20→19→16→19→16
* 開始   : 2026-07-30 16:20:00 (UTC)
* 終了   : 2026-07-30 16:25:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.817(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 18→14→18→14→18→17
* 開始   : 2026-07-30 16:50:00 (UTC)
* 終了   : 2026-07-30 16:55:00 (UTC)
* 現象   : 木曜16時台の平常値(17.82)に対し 14であった
* 説明   : ALG-A1: 移動平均からの残差が 2.97σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.016σ 外れた (平常値=17.82)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260730-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260730-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.005e+04→9716→9324→9563→…→9563→1.058e+04→1.018e+04→9906
* 開始   : 2026-07-30 18:55:00 (UTC)
* 終了   : 2026-07-30 19:35:00 (UTC)
* 現象   : 平常時(1.029e+04)に対し 0.9242(9512)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260730-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-080 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 20 分

![EVT-20260730-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 13→15→12→12→12→10→13→14
* 開始   : 2026-07-30 19:30:00 (UTC)
* 終了   : 2026-07-30 20:05:00 (UTC)
* 現象   : 2026-07-30 20:05:00 (UTC)を境に水準が 14.91から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.445, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host02-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→11→12→11→11→10→9→12→10
* 開始   : 2026-07-30 21:15:00 (UTC)
* 終了   : 2026-07-30 21:55:00 (UTC)
* 現象   : 2026-07-30 21:55:00 (UTC)を境に水準が 14.93から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.282, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host02-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host02-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→7→9→6→7→9→6→8→10
* 開始   : 2026-07-30 21:55:00 (UTC)
* 終了   : 2026-07-30 22:05:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-085 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260730-host02-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→7→11→12→10→7→11→12→10
* 開始   : 2026-07-31 02:25:00 (UTC)
* 終了   : 2026-07-31 02:30:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260731-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→11→15→12→11→15→12
* 開始   : 2026-07-31 04:15:00 (UTC)
* 終了   : 2026-07-31 04:20:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260731-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→15→13→11→15→13→11
* 開始   : 2026-07-31 04:30:00 (UTC)
* 終了   : 2026-07-31 04:35:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.611σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-014 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260731-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→17→13→17→13→17→16→15
* 開始   : 2026-07-31 05:50:00 (UTC)
* 終了   : 2026-07-31 06:00:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260731-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→13→18→15→18→15→18→17→15
* 開始   : 2026-07-31 06:25:00 (UTC)
* 終了   : 2026-07-31 06:35:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260731-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260731-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.042e+04→1.034e+04→1.092e+04→1.106e+04→…→1.092e+04→1.106e+04→1.05e+04→1.084e+04
* 開始   : 2026-07-31 06:25:00 (UTC)
* 終了   : 2026-07-31 06:30:00 (UTC)
* 現象   : 平常時(1.021e+04)に対し 1.069倍(1.092e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host02-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→18→19→16→18→19→16→18
* 開始   : 2026-07-31 06:55:00 (UTC)
* 終了   : 2026-07-31 07:00:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 20→21→23→22→…→22→17→20→21
* 開始   : 2026-07-31 09:20:00 (UTC)
* 終了   : 2026-07-31 09:30:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.447σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260731-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 24→23→22→23
* 開始   : 2026-07-31 10:00:00 (UTC)
* 終了   : 2026-07-31 10:15:00 (UTC)
* 現象   : 2026-07-31 10:15:00 (UTC)を境に水準が 14.98から13.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.008, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 18→18→17→18→18→17→16→19
* 開始   : 2026-07-31 16:20:00 (UTC)
* 終了   : 2026-07-31 16:55:00 (UTC)
* 現象   : 2026-07-31 16:55:00 (UTC)を境に水準が 14.91から12.39へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.063, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 18→14→18→14→18→14→15→14
* 開始   : 2026-07-31 17:30:00 (UTC)
* 終了   : 2026-07-31 17:40:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host02-015 (同一ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260731-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260731-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260731-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.092e+04→1.024e+04→9790→9856→…→9770→1.12e+04→1.001e+04→1.007e+04
* 開始   : 2026-07-31 17:30:00 (UTC)
* 終了   : 2026-07-31 17:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.581σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host02-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260731-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260731-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260731-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260731-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260731-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 15→13→11→10→13→11→10→13→11
* 開始   : 2026-07-31 19:30:00 (UTC)
* 終了   : 2026-07-31 19:35:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host15-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host02-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→9→13→9→13→9→11→13
* 開始   : 2026-07-31 20:00:00 (UTC)
* 終了   : 2026-07-31 20:10:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.553σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260731-host02-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host02-018 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 13→12→11→12→12→10→14→11→12
* 開始   : 2026-07-31 20:05:00 (UTC)
* 終了   : 2026-07-31 20:55:00 (UTC)
* 現象   : 2026-07-31 20:55:00 (UTC)を境に水準が 15.09から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host02-018 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
