# host02 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host02 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 350 (SEVERE: 26, FATAL: 128, WARN: 196, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 23 | 105 | 147 | 275 | ALG-A1, ALG-A2, ALG-A3, ALG-A4, ALG-A5, ALG-B4 |
| ou | 3 | 23 | 38 | 64 | ALG-A1, ALG-A4, ALG-B4 |
| mu | 0 | 0 | 11 | 11 | ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260802-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→8→5→11→5→11→5→11→7
* 開始   : 2026-08-02 21:25:00 (UTC)
* 終了   : 2026-08-02 21:35:00 (UTC)
* 現象   : 日曜21時台の平常値(9.007)に対し 5であった
* 説明   : ALG-A1: 移動平均からの残差が 3.208σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.198σ 外れた (平常値=9.007)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260802-lsfhost01-036 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260802-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host02-007 active_connections の推移](charts/EVT-20260802-host02-007.svg)

# イベントID( EVT-20260803-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→15→14→11→…→11→13→11→12
* 開始   : 2026-08-03 02:45:00 (UTC)
* 終了   : 2026-08-03 21:05:00 (UTC)
* 現象   : 2026-08-03 21:05:00 (UTC)を境に水準が 11.82から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.447σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.786, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host02-003 active_connections の推移](charts/EVT-20260803-host02-003.svg)

# イベントID( EVT-20260803-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→16→14→16→…→13→15→13→15
* 開始   : 2026-08-03 02:50:00 (UTC)
* 終了   : 2026-08-03 19:50:00 (UTC)
* 現象   : 2026-08-03 19:50:00 (UTC)を境に水準が 11.89から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.104, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.75, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host02-004 active_connections の推移](charts/EVT-20260803-host02-004.svg)

# イベントID( EVT-20260803-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 15→16→18→16→…→16→14→16→14
* 開始   : 2026-08-03 03:00:00 (UTC)
* 終了   : 2026-08-03 19:40:00 (UTC)
* 現象   : 2026-08-03 19:40:00 (UTC)を境に水準が 11.83から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.264, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.352, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host02-006 active_connections の推移](charts/EVT-20260803-host02-006.svg)

# イベントID( EVT-20260803-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 16→17→15→16→…→17→15→13→15
* 開始   : 2026-08-03 03:15:00 (UTC)
* 終了   : 2026-08-03 18:40:00 (UTC)
* 現象   : 2026-08-03 18:40:00 (UTC)を境に水準が 11.96から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.732σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.685, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host02-007 active_connections の推移](charts/EVT-20260803-host02-007.svg)

# イベントID( EVT-20260803-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→13→15→14→…→15→13→12→13
* 開始   : 2026-08-03 04:05:00 (UTC)
* 終了   : 2026-08-03 20:40:00 (UTC)
* 現象   : 2026-08-03 20:40:00 (UTC)を境に水準が 11.83から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.307, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.031, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host02-009 active_connections の推移](charts/EVT-20260803-host02-009.svg)

# イベントID( EVT-20260805-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 11→9→41→49→…→13→12→13→12
* 開始   : 2026-08-05 02:50:00 (UTC)
* 終了   : 2026-08-05 04:50:00 (UTC)
* 現象   : 2026-08-05 04:50:00 (UTC)を境に水準が 15.01から16.21へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 11.93σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 20.91 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=41)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=6.127, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=29.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host02-001 active_connections の推移](charts/EVT-20260805-host02-001.svg)

# イベントID( EVT-20260810-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→17→16→15→…→13→14→12→14
* 開始   : 2026-08-10 01:20:00 (UTC)
* 終了   : 2026-08-10 20:30:00 (UTC)
* 現象   : 2026-08-10 20:30:00 (UTC)を境に水準が 11.87から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.682, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host02-001 active_connections の推移](charts/EVT-20260810-host02-001.svg)

# イベントID( EVT-20260810-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.059e+04→1.079e+04→1.06e+04→1.085e+04→…→1.048e+04→1.074e+04→1.04e+04→9594
* 開始   : 2026-08-10 02:30:00 (UTC)
* 終了   : 2026-08-10 19:00:00 (UTC)
* 現象   : 2026-08-10 19:00:00 (UTC)を境に水準が 9779から1.025e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.795σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=529.8, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2338, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host02-002 ou の推移](charts/EVT-20260810-host02-002.svg)

# イベントID( EVT-20260810-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→16→17→13→…→15→14→12→14
* 開始   : 2026-08-10 02:50:00 (UTC)
* 終了   : 2026-08-10 20:55:00 (UTC)
* 現象   : 2026-08-10 20:55:00 (UTC)を境に水準が 11.86から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.095, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host02-003 active_connections の推移](charts/EVT-20260810-host02-003.svg)

# イベントID( EVT-20260810-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→16→14→15→…→15→13→14→12
* 開始   : 2026-08-10 02:50:00 (UTC)
* 終了   : 2026-08-10 20:15:00 (UTC)
* 現象   : 2026-08-10 20:15:00 (UTC)を境に水準が 11.93から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.782, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.057, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host02-004 active_connections の推移](charts/EVT-20260810-host02-004.svg)

# イベントID( EVT-20260810-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→19→17→15→…→12→13→14→13
* 開始   : 2026-08-10 03:20:00 (UTC)
* 終了   : 2026-08-10 20:25:00 (UTC)
* 現象   : 2026-08-10 20:25:00 (UTC)を境に水準が 11.9から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.232, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.34, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host02-006 active_connections の推移](charts/EVT-20260810-host02-006.svg)

# イベントID( EVT-20260812-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→42→36→39→…→11→13→14→13
* 開始   : 2026-08-12 02:50:00 (UTC)
* 終了   : 2026-08-12 04:45:00 (UTC)
* 現象   : 2026-08-12 04:45:00 (UTC)を境に水準が 15.04から16.3へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 12.38σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 21.58 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=42)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=6.719, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=31.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host02-002 active_connections の推移](charts/EVT-20260812-host02-002.svg)

# イベントID( EVT-20260817-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→18→16→19→…→15→14→15→14
* 開始   : 2026-08-17 02:00:00 (UTC)
* 終了   : 2026-08-17 19:00:00 (UTC)
* 現象   : 2026-08-17 19:00:00 (UTC)を境に水準が 11.87から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.774, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host02-003 active_connections の推移](charts/EVT-20260817-host02-003.svg)

# イベントID( EVT-20260817-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→16→17→14→…→19→15→16→17
* 開始   : 2026-08-17 02:35:00 (UTC)
* 終了   : 2026-08-17 21:45:00 (UTC)
* 現象   : 2026-08-17 21:45:00 (UTC)を境に水準が 11.9から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.365σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.653, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host02-004 active_connections の推移](charts/EVT-20260817-host02-004.svg)

# イベントID( EVT-20260817-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→12→16→17→…→15→13→10→15
* 開始   : 2026-08-17 03:00:00 (UTC)
* 終了   : 2026-08-17 21:50:00 (UTC)
* 現象   : 2026-08-17 21:50:00 (UTC)を境に水準が 11.84から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.952, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.063, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host02-006 active_connections の推移](charts/EVT-20260817-host02-006.svg)

# イベントID( EVT-20260817-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 15→17→18→16→…→16→11→13→14
* 開始   : 2026-08-17 03:05:00 (UTC)
* 終了   : 2026-08-17 18:50:00 (UTC)
* 現象   : 2026-08-17 18:50:00 (UTC)を境に水準が 11.91から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.282, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.191, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host02-007 active_connections の推移](charts/EVT-20260817-host02-007.svg)

# イベントID( EVT-20260817-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.035e+04→1.164e+04→1.042e+04→1.106e+04→…→1.056e+04→1.034e+04→1.022e+04→1.042e+04
* 開始   : 2026-08-17 06:35:00 (UTC)
* 終了   : 2026-08-17 19:40:00 (UTC)
* 現象   : 2026-08-17 19:40:00 (UTC)を境に水準が 9809から1.024e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.709σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=597.9, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2130, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host02-008 ou の推移](charts/EVT-20260817-host02-008.svg)

# イベントID( EVT-20260819-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→11→41→44→…→12→13→12→14
* 開始   : 2026-08-19 02:20:00 (UTC)
* 終了   : 2026-08-19 04:50:00 (UTC)
* 現象   : 2026-08-19 04:50:00 (UTC)を境に水準が 15.02から16.27へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 11.93σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 20.91 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=41)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=6.784, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=32.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host02-001 active_connections の推移](charts/EVT-20260819-host02-001.svg)

# イベントID( EVT-20260824-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→15→16→14→…→14→16→14→15
* 開始   : 2026-08-24 00:55:00 (UTC)
* 終了   : 2026-08-24 21:45:00 (UTC)
* 現象   : 2026-08-24 21:45:00 (UTC)を境に水準が 11.8から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.848σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.945, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.381, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host02-002 active_connections の推移](charts/EVT-20260824-host02-002.svg)

# イベントID( EVT-20260824-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→14→15→13→…→11→13→12→11
* 開始   : 2026-08-24 02:35:00 (UTC)
* 終了   : 2026-08-24 20:45:00 (UTC)
* 現象   : 2026-08-24 20:45:00 (UTC)を境に水準が 11.82から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.854, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.125, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host02-004 active_connections の推移](charts/EVT-20260824-host02-004.svg)

# イベントID( EVT-20260824-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 16→14→18→14→…→12→13→11→12
* 開始   : 2026-08-24 02:35:00 (UTC)
* 終了   : 2026-08-24 21:30:00 (UTC)
* 現象   : 2026-08-24 21:30:00 (UTC)を境に水準が 11.73から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.353, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host02-005 active_connections の推移](charts/EVT-20260824-host02-005.svg)

# イベントID( EVT-20260824-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→16→15→14→…→15→16→12→13
* 開始   : 2026-08-24 03:15:00 (UTC)
* 終了   : 2026-08-24 20:00:00 (UTC)
* 現象   : 2026-08-24 20:00:00 (UTC)を境に水準が 11.85から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.692, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.75, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host02-006 active_connections の推移](charts/EVT-20260824-host02-006.svg)

# イベントID( EVT-20260824-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→15→19→15→…→12→15→14→12
* 開始   : 2026-08-24 03:35:00 (UTC)
* 終了   : 2026-08-24 21:20:00 (UTC)
* 現象   : 2026-08-24 21:20:00 (UTC)を境に水準が 11.94から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.291, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.34, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host02-007 active_connections の推移](charts/EVT-20260824-host02-007.svg)

# イベントID( EVT-20260824-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.005e+04→9750→1.086e+04→1.058e+04→…→1.081e+04→1.062e+04→1.054e+04→1.058e+04
* 開始   : 2026-08-24 04:05:00 (UTC)
* 終了   : 2026-08-24 20:30:00 (UTC)
* 現象   : 2026-08-24 20:30:00 (UTC)を境に水準が 9796から1.024e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.515σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=522.6, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2620, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host02-008 ou の推移](charts/EVT-20260824-host02-008.svg)

# イベントID( EVT-20260826-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A3 Tukey の外れ値境界, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 12→9→36→44→…→12→14→12→14
* 開始   : 2026-08-26 02:50:00 (UTC)
* 終了   : 2026-08-26 04:40:00 (UTC)
* 現象   : 2026-08-26 04:40:00 (UTC)を境に水準が 14.92から16.24へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 10.3σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 18.21 倍に達した (閾値 3)
             ALG-A3: 系列全体の四分位範囲から外れた (Q1=10, Q3=18, 値=36)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=5.229, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=26.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host02-002 active_connections の推移](charts/EVT-20260826-host02-002.svg)

# イベントID( EVT-20260801-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 7→8→12→5→…→12→5→6→8
* 開始   : 2026-08-01 00:55:00 (UTC)
* 終了   : 2026-08-01 01:00:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260801-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→11→14→10→9
* 開始   : 2026-08-01 03:25:00 (UTC)
* 終了   : 2026-08-01 03:25:00 (UTC)
* 現象   : 平常時(9.167)に対し 1.527倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260801-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260801-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→10→11→13→…→11→12→11→13
* 開始   : 2026-08-01 04:30:00 (UTC)
* 終了   : 2026-08-01 19:05:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.878, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260801-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 9.9 時間
  - EVT-20260801-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.3 時間
  - EVT-20260801-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 1.0 時間
  - EVT-20260801-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 30 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間

![EVT-20260801-host02-003 active_connections の推移](charts/EVT-20260801-host02-003.svg)

# イベントID( EVT-20260801-host02-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→12→14→12→…→12→11→12→14
* 開始   : 2026-08-01 04:35:00 (UTC)
* 終了   : 2026-08-01 19:35:00 (UTC)
* 現象   : 15.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.752, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260801-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 9.9 時間
  - EVT-20260801-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.3 時間
  - EVT-20260801-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 1.0 時間
  - EVT-20260801-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 30 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間

![EVT-20260801-host02-004 active_connections の推移](charts/EVT-20260801-host02-004.svg)

# イベントID( EVT-20260801-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 10→11→12→10→…→11→12→13→12
* 開始   : 2026-08-01 05:30:00 (UTC)
* 終了   : 2026-08-01 19:25:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.133σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.081, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 9.9 時間
  - EVT-20260801-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.3 時間
  - EVT-20260801-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 1.0 時間
  - EVT-20260801-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 30 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間

![EVT-20260801-host02-005 active_connections の推移](charts/EVT-20260801-host02-005.svg)

# イベントID( EVT-20260801-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→9→11→13→…→10→12→10→12
* 開始   : 2026-08-01 05:55:00 (UTC)
* 終了   : 2026-08-01 18:35:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.615σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.48, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 9.9 時間
  - EVT-20260801-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.3 時間
  - EVT-20260801-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 1.0 時間
  - EVT-20260801-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 30 分
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間

![EVT-20260801-host02-006 active_connections の推移](charts/EVT-20260801-host02-006.svg)

# イベントID( EVT-20260801-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→12→13→12→…→12→13→14→11
* 開始   : 2026-08-01 06:20:00 (UTC)
* 終了   : 2026-08-01 19:00:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.767, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 9.9 時間
  - EVT-20260801-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 9.3 時間
  - EVT-20260801-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 1.0 時間
  - EVT-20260801-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 30 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.4 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間

![EVT-20260801-host02-007 active_connections の推移](charts/EVT-20260801-host02-007.svg)

# イベントID( EVT-20260801-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9906→1.004e+04→9817→1.042e+04→…→9672→1.021e+04→1.027e+04→1.015e+04
* 開始   : 2026-08-01 08:10:00 (UTC)
* 終了   : 2026-08-01 18:05:00 (UTC)
* 現象   : 9.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-561.8, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260801-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260801-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260801-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260801-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間
  - EVT-20260801-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.9 時間
  - EVT-20260801-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 1.0 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 9.9 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 9.9 時間
  - EVT-20260801-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 9.9 時間

![EVT-20260801-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→7→4→7→11
* 開始   : 2026-08-03 00:35:00 (UTC)
* 終了   : 2026-08-03 00:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260803-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 10→8→4→10→7
* 開始   : 2026-08-03 01:15:00 (UTC)
* 終了   : 2026-08-03 01:15:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.191σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260803-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.079e+04→1.081e+04→1.146e+04→1.08e+04→…→1.079e+04→1.032e+04→1.056e+04→1.096e+04
* 開始   : 2026-08-03 02:50:00 (UTC)
* 終了   : 2026-08-03 20:35:00 (UTC)
* 現象   : 2026-08-03 20:35:00 (UTC)を境に水準が 9769から1.022e+04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=574.3, 限界=525.8)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2585, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→9→10→9→13
* 開始   : 2026-08-04 01:10:00 (UTC)
* 終了   : 2026-08-04 01:35:00 (UTC)
* 現象   : 2026-08-04 01:35:00 (UTC)を境に水準が 14.91から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 16→17→20→16→17
* 開始   : 2026-08-04 07:25:00 (UTC)
* 終了   : 2026-08-04 07:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→15→21→18→18
* 開始   : 2026-08-04 07:40:00 (UTC)
* 終了   : 2026-08-04 07:40:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.292倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.307σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 17→17→13→16→17
* 開始   : 2026-08-04 17:05:00 (UTC)
* 終了   : 2026-08-04 17:05:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9710→9603→8896→1.026e+04→9444
* 開始   : 2026-08-04 19:50:00 (UTC)
* 終了   : 2026-08-04 19:50:00 (UTC)
* 現象   : 平常時(1.004e+04)に対し 0.8863(8896)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.41σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→15→14→17→15→14→17→14→13
* 開始   : 2026-08-05 04:50:00 (UTC)
* 終了   : 2026-08-05 05:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-lsfhost01-015 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分

![EVT-20260805-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 20→18→17→20→17→20→17→18→20
* 開始   : 2026-08-05 15:35:00 (UTC)
* 終了   : 2026-08-05 16:50:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.8361倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260805-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→17→12→15→14
* 開始   : 2026-08-05 17:40:00 (UTC)
* 終了   : 2026-08-05 17:40:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.7094(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.423σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→14→9→12→12
* 開始   : 2026-08-05 19:50:00 (UTC)
* 終了   : 2026-08-05 19:50:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 9→11→9→8→…→10→13→12→14
* 開始   : 2026-08-06 03:00:00 (UTC)
* 終了   : 2026-08-06 04:35:00 (UTC)
* 現象   : 1.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-6.51, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260806-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260806-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 1.2 時間
  - EVT-20260806-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 35 分
  - EVT-20260806-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260806-host02-003 active_connections の推移](charts/EVT-20260806-host02-003.svg)

# イベントID( EVT-20260806-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→12→17→16→14→12→17→16→14
* 開始   : 2026-08-06 05:20:00 (UTC)
* 終了   : 2026-08-06 05:25:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→11→17→15→14
* 開始   : 2026-08-06 05:40:00 (UTC)
* 終了   : 2026-08-06 05:40:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→18→20→16→17
* 開始   : 2026-08-06 06:55:00 (UTC)
* 終了   : 2026-08-06 06:55:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.129e+04→1.182e+04→1.023e+04→1.146e+04→1.089e+04
* 開始   : 2026-08-06 12:25:00 (UTC)
* 終了   : 2026-08-06 12:25:00 (UTC)
* 現象   : 平常時(1.136e+04)に対し 0.9001(1.023e+04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260806-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.117e+04→1.094e+04→1.113e+04→1.103e+04→1.117e+04→1.094e+04→1.083e+04→1.094e+04→1.053e+04
* 開始   : 2026-08-06 15:45:00 (UTC)
* 終了   : 2026-08-06 16:55:00 (UTC)
* 現象   : 2026-08-06 16:55:00 (UTC)を境に水準が 1.024e+04から1.021e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.189σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2200, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 8→9→12→9→9
* 開始   : 2026-08-07 01:30:00 (UTC)
* 終了   : 2026-08-07 01:30:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260807-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→13→8→11→15→8→11→15→12
* 開始   : 2026-08-07 04:10:00 (UTC)
* 終了   : 2026-08-07 04:20:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→12→15→13→13
* 開始   : 2026-08-07 04:25:00 (UTC)
* 終了   : 2026-08-07 04:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260807-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9570→9730→1.085e+04→1.016e+04→9501
* 開始   : 2026-08-07 04:40:00 (UTC)
* 終了   : 2026-08-07 04:40:00 (UTC)
* 現象   : 平常時(9653)に対し 1.124倍(1.085e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host02-005 ou の推移](charts/EVT-20260807-host02-005.svg)

# イベントID( EVT-20260807-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→16→18→16→15
* 開始   : 2026-08-07 06:00:00 (UTC)
* 終了   : 2026-08-07 06:00:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.12e+04→1.161e+04→1.027e+04→1.043e+04→…→1.027e+04→1.043e+04→1.086e+04→1.169e+04
* 開始   : 2026-08-07 12:55:00 (UTC)
* 終了   : 2026-08-07 13:00:00 (UTC)
* 現象   : 平常時(1.13e+04)に対し 0.9088(1.027e+04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.078σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260807-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→13→11→13→11→12
* 開始   : 2026-08-07 19:00:00 (UTC)
* 終了   : 2026-08-07 19:30:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.75(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260807-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260807-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-074 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260807-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host02-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 12→10→11→10→…→13→12→13→11
* 開始   : 2026-08-08 05:05:00 (UTC)
* 終了   : 2026-08-08 18:35:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.777, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.9 時間
  - EVT-20260808-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.1 時間
  - EVT-20260808-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260808-host02-004 active_connections の推移](charts/EVT-20260808-host02-004.svg)

# イベントID( EVT-20260808-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→9→11→13→…→9→12→13→10
* 開始   : 2026-08-08 05:05:00 (UTC)
* 終了   : 2026-08-08 19:00:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.329, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.9 時間
  - EVT-20260808-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.1 時間
  - EVT-20260808-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260808-host02-005 active_connections の推移](charts/EVT-20260808-host02-005.svg)

# イベントID( EVT-20260808-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.005e+04→9697→9598→9707→…→9870→1.048e+04→1.084e+04→1.065e+04
* 開始   : 2026-08-08 05:25:00 (UTC)
* 終了   : 2026-08-08 18:20:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.472σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-605, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.1 時間
  - EVT-20260808-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260808-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→12→13→10→…→12→11→12→13
* 開始   : 2026-08-08 05:45:00 (UTC)
* 終了   : 2026-08-08 18:35:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.893, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.6 時間
  - EVT-20260808-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.1 時間
  - EVT-20260808-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260808-host02-007 active_connections の推移](charts/EVT-20260808-host02-007.svg)

# イベントID( EVT-20260808-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→12→…→13→12→14→13
* 開始   : 2026-08-08 06:00:00 (UTC)
* 終了   : 2026-08-08 19:05:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.879, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.3 時間
  - EVT-20260808-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.1 時間
  - EVT-20260808-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260808-host02-008 active_connections の推移](charts/EVT-20260808-host02-008.svg)

# イベントID( EVT-20260808-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→12→10→12→…→12→10→12→9
* 開始   : 2026-08-08 06:15:00 (UTC)
* 終了   : 2026-08-08 19:25:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.501, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 12.1 時間
  - EVT-20260808-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10.1 時間
  - EVT-20260808-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260808-host02-009 active_connections の推移](charts/EVT-20260808-host02-009.svg)

# イベントID( EVT-20260808-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9016→9612→1.055e+04→9226→9843
* 開始   : 2026-08-08 20:25:00 (UTC)
* 終了   : 2026-08-08 20:25:00 (UTC)
* 現象   : 平常時(9460)に対し 1.115倍(1.055e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.261σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260808-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→9→4→7→7
* 開始   : 2026-08-08 22:50:00 (UTC)
* 終了   : 2026-08-08 22:50:00 (UTC)
* 現象   : 平常時(8.833)に対し 0.4528(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260808-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 14→15→10→14→13
* 開始   : 2026-08-09 16:10:00 (UTC)
* 終了   : 2026-08-09 16:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→14→16→14→…→14→13→14→12
* 開始   : 2026-08-10 04:25:00 (UTC)
* 終了   : 2026-08-10 19:25:00 (UTC)
* 現象   : 2026-08-10 19:25:00 (UTC)を境に水準が 11.99から15.01へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.05, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.524, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 19→19→22→20→19
* 開始   : 2026-08-11 08:20:00 (UTC)
* 終了   : 2026-08-11 08:20:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9301→9538→8708→9338→9606
* 開始   : 2026-08-11 20:15:00 (UTC)
* 終了   : 2026-08-11 20:15:00 (UTC)
* 現象   : 平常時(9830)に対し 0.8858(8708)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.355σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→13→15→12→11
* 開始   : 2026-08-12 03:50:00 (UTC)
* 終了   : 2026-08-12 03:50:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 20→19→21→23→19→21→23→19→18
* 開始   : 2026-08-12 08:50:00 (UTC)
* 終了   : 2026-08-12 08:55:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.161倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260812-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 22→21→26→21→21
* 開始   : 2026-08-12 11:00:00 (UTC)
* 終了   : 2026-08-12 11:00:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.233倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 18→15→18→15→18→15→18→16
* 開始   : 2026-08-12 16:45:00 (UTC)
* 終了   : 2026-08-12 17:40:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host13-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 30 分
  - EVT-20260812-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260812-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260812-host02-009 active_connections の推移](charts/EVT-20260812-host02-009.svg)

# イベントID( EVT-20260813-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 8→7→12→6→8
* 開始   : 2026-08-13 00:20:00 (UTC)
* 終了   : 2026-08-13 00:20:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-002 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260813-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→8→12→11→…→10→12→10→12
* 開始   : 2026-08-13 03:00:00 (UTC)
* 終了   : 2026-08-13 04:35:00 (UTC)
* 現象   : 1.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-7.055, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260813-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260813-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260813-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260813-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260813-host02-002 active_connections の推移](charts/EVT-20260813-host02-002.svg)

# イベントID( EVT-20260813-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 13→9→16→14→14
* 開始   : 2026-08-13 04:55:00 (UTC)
* 終了   : 2026-08-13 04:55:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.433倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.379σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260813-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→14→16→14→…→14→18→13→16
* 開始   : 2026-08-13 05:35:00 (UTC)
* 終了   : 2026-08-13 05:45:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260813-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260813-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 21→24→19→22→…→22→17→21→22
* 開始   : 2026-08-13 12:45:00 (UTC)
* 終了   : 2026-08-13 12:55:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260813-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→12→7→11→15→7→11→15→10
* 開始   : 2026-08-14 03:20:00 (UTC)
* 終了   : 2026-08-14 03:30:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260814-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→12→15→13→12
* 開始   : 2026-08-14 04:00:00 (UTC)
* 終了   : 2026-08-14 04:00:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.475倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.379σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→13→15→12→14
* 開始   : 2026-08-14 04:15:00 (UTC)
* 終了   : 2026-08-14 04:15:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 22→19→26→21→23
* 開始   : 2026-08-14 13:05:00 (UTC)
* 終了   : 2026-08-14 13:05:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.219倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 23→19→17→23→20
* 開始   : 2026-08-14 14:15:00 (UTC)
* 終了   : 2026-08-14 14:15:00 (UTC)
* 現象   : 平常時(21.58)に対し 0.7876(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260814-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 19→21→15→17→…→17→16→19→16
* 開始   : 2026-08-14 16:00:00 (UTC)
* 終了   : 2026-08-14 16:10:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.7627(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260814-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 20→19→15→16→…→15→16→18→17
* 開始   : 2026-08-14 16:30:00 (UTC)
* 終了   : 2026-08-14 16:35:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.766(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 19→17→14→15→17→14→15→16
* 開始   : 2026-08-14 16:55:00 (UTC)
* 終了   : 2026-08-14 17:00:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260814-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9999→9907→9305→9964→…→9964→1.064e+04→9460→1.056e+04
* 開始   : 2026-08-14 18:25:00 (UTC)
* 終了   : 2026-08-14 20:30:00 (UTC)
* 現象   : 平常時(1.023e+04)に対し 0.8974(9176)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.136σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260814-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260814-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host16-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260814-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9554→9611→1.035e+04→9750→1.007e+04
* 開始   : 2026-08-15 04:25:00 (UTC)
* 終了   : 2026-08-15 04:25:00 (UTC)
* 現象   : 平常時(9325)に対し 1.109倍(1.035e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260815-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260815-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 10→8→10→8→…→12→13→14→12
* 開始   : 2026-08-15 04:45:00 (UTC)
* 終了   : 2026-08-15 18:10:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260815-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260815-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 11.8 時間
  - EVT-20260815-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260815-host02-004 active_connections の推移](charts/EVT-20260815-host02-004.svg)

# イベントID( EVT-20260815-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→10→11→10→…→13→15→14→12
* 開始   : 2026-08-15 05:10:00 (UTC)
* 終了   : 2026-08-15 17:05:00 (UTC)
* 現象   : 11.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.294, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260815-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260815-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260815-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.9 時間
  - EVT-20260815-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 11.1 時間
  - EVT-20260815-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260815-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260815-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間

![EVT-20260815-host02-005 active_connections の推移](charts/EVT-20260815-host02-005.svg)

# イベントID( EVT-20260815-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 14→15→10→12→…→9→11→12→11
* 開始   : 2026-08-15 05:10:00 (UTC)
* 終了   : 2026-08-15 19:35:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.075σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.938, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260815-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 11.8 時間
  - EVT-20260815-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260815-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 50 分
  - EVT-20260815-host02-012 (同一ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260815-host02-006 active_connections の推移](charts/EVT-20260815-host02-006.svg)

# イベントID( EVT-20260815-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→12→10→13→…→12→11→12→11
* 開始   : 2026-08-15 05:40:00 (UTC)
* 終了   : 2026-08-15 18:30:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.159, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260815-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 11.8 時間
  - EVT-20260815-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260815-host02-007 active_connections の推移](charts/EVT-20260815-host02-007.svg)

# イベントID( EVT-20260815-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 13→12→10→12→…→13→10→12→11
* 開始   : 2026-08-15 06:10:00 (UTC)
* 終了   : 2026-08-15 19:15:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.132, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260815-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.9 時間
  - EVT-20260815-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 11.6 時間
  - EVT-20260815-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260815-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 35 分
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間

![EVT-20260815-host02-009 active_connections の推移](charts/EVT-20260815-host02-009.svg)

# イベントID( EVT-20260815-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→4→7→11→4→7→11→8→7
* 開始   : 2026-08-15 22:20:00 (UTC)
* 終了   : 2026-08-15 22:30:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260815-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→15→16→13→…→16→15→13→16
* 開始   : 2026-08-17 01:20:00 (UTC)
* 終了   : 2026-08-17 20:25:00 (UTC)
* 現象   : 2026-08-17 20:25:00 (UTC)を境に水準が 11.93から14.93へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.853, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.837, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 8→8→13→7→6
* 開始   : 2026-08-17 22:55:00 (UTC)
* 終了   : 2026-08-17 22:55:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.191σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260817-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9204→9436→9735→9442→9528→9496→9433→9570→9468
* 開始   : 2026-08-17 23:55:00 (UTC)
* 終了   : 2026-08-18 01:15:00 (UTC)
* 現象   : 2026-08-18 01:15:00 (UTC)を境に水準が 1.022e+04から1.022e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.537σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2135, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host02-013 ou の推移](charts/EVT-20260817-host02-013.svg)

# イベントID( EVT-20260818-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→15→18→15→14
* 開始   : 2026-08-18 05:50:00 (UTC)
* 終了   : 2026-08-18 05:50:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host02-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260818-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→16→21→15→17
* 開始   : 2026-08-18 07:25:00 (UTC)
* 終了   : 2026-08-18 07:25:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 16→14→11→13→14
* 開始   : 2026-08-18 18:40:00 (UTC)
* 終了   : 2026-08-18 18:40:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→9→6→8→8
* 開始   : 2026-08-18 22:00:00 (UTC)
* 終了   : 2026-08-18 22:00:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→8→5→9→10
* 開始   : 2026-08-18 22:20:00 (UTC)
* 終了   : 2026-08-18 22:20:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.5128(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 19→18→21→19→…→22→21→17→21
* 開始   : 2026-08-19 07:45:00 (UTC)
* 終了   : 2026-08-19 08:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.8σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260819-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260819-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 20→18→22→20→19
* 開始   : 2026-08-19 07:55:00 (UTC)
* 終了   : 2026-08-19 07:55:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.133σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 20→20→24→21→22
* 開始   : 2026-08-19 09:15:00 (UTC)
* 終了   : 2026-08-19 09:15:00 (UTC)
* 現象   : 平常時(19.17)に対し 1.252倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.371σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.03e+04→9424→8741→9262→9614
* 開始   : 2026-08-19 20:00:00 (UTC)
* 終了   : 2026-08-19 20:00:00 (UTC)
* 現象   : 平常時(9953)に対し 0.8783(8741)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.62σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-063 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260819-host02-014 ou の推移](charts/EVT-20260819-host02-014.svg)

# イベントID( EVT-20260820-host02-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 10→9→10→7→…→12→11→12→13
* 開始   : 2026-08-20 03:00:00 (UTC)
* 終了   : 2026-08-20 04:35:00 (UTC)
* 現象   : 1.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-6.765, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host02-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-008 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 25 分
  - EVT-20260820-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260820-host02-001 active_connections の推移](charts/EVT-20260820-host02-001.svg)

# イベントID( EVT-20260820-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9885→1.029e+04→1.138e+04→1.058e+04→1.001e+04
* 開始   : 2026-08-20 06:20:00 (UTC)
* 終了   : 2026-08-20 06:20:00 (UTC)
* 現象   : 平常時(1.011e+04)に対し 1.125倍(1.138e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.766σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host02-005 ou の推移](charts/EVT-20260820-host02-005.svg)

# イベントID( EVT-20260820-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→16→19→18→…→19→18→15→16
* 開始   : 2026-08-20 06:35:00 (UTC)
* 終了   : 2026-08-20 06:45:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260820-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260820-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 20→15→22→18→18
* 開始   : 2026-08-20 07:55:00 (UTC)
* 終了   : 2026-08-20 07:55:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.133σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→14→13→12→…→13→12→14→18
* 開始   : 2026-08-20 18:00:00 (UTC)
* 終了   : 2026-08-20 19:05:00 (UTC)
* 現象   : 1.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260820-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host07-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host02-012 active_connections の推移](charts/EVT-20260820-host02-012.svg)

# イベントID( EVT-20260820-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9672→1.001e+04→8960→9374→9693
* 開始   : 2026-08-20 19:45:00 (UTC)
* 終了   : 2026-08-20 19:45:00 (UTC)
* 現象   : 平常時(9995)に対し 0.8964(8960)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→11→7→9→10
* 開始   : 2026-08-20 20:40:00 (UTC)
* 終了   : 2026-08-20 20:40:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9636→9039→1.057e+04→9649→9329
* 開始   : 2026-08-21 03:25:00 (UTC)
* 終了   : 2026-08-21 03:25:00 (UTC)
* 現象   : 平常時(9526)に対し 1.11倍(1.057e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260821-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→15→18→14→16
* 開始   : 2026-08-21 06:00:00 (UTC)
* 終了   : 2026-08-21 06:00:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 17→15→18→20→16→15→18→20→16
* 開始   : 2026-08-21 07:05:00 (UTC)
* 終了   : 2026-08-21 07:10:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 19→20→23→19→20
* 開始   : 2026-08-21 08:15:00 (UTC)
* 終了   : 2026-08-21 08:15:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.26倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260821-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→14→7→11→12
* 開始   : 2026-08-21 20:45:00 (UTC)
* 終了   : 2026-08-21 20:45:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6087(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.133σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→9→5→8→9
* 開始   : 2026-08-21 21:55:00 (UTC)
* 終了   : 2026-08-21 21:55:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.191σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host11-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 7→10→4→7→9
* 開始   : 2026-08-21 22:45:00 (UTC)
* 終了   : 2026-08-21 22:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-080 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260821-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 12→11→13→11→…→13→11→15→13
* 開始   : 2026-08-22 05:30:00 (UTC)
* 終了   : 2026-08-22 18:20:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.904, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260822-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.0 時間
  - EVT-20260822-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.7 時間
  - EVT-20260822-host02-012 (同一ホスト) jvm_gc / mu : WARN / 重なり 1.6 時間
  - EVT-20260822-host02-005 (同一ホスト) jvm_gc / ou : WARN / 重なり 25 分
  - EVT-20260822-host02-013 (同一ホスト) jvm_gc / mu : WARN / 重なり 10 分
  - EVT-20260822-host02-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260822-host02-003 active_connections の推移](charts/EVT-20260822-host02-003.svg)

# イベントID( EVT-20260822-host02-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→11→13→10→…→13→12→13→12
* 開始   : 2026-08-22 05:40:00 (UTC)
* 終了   : 2026-08-22 19:55:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.135, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.0 時間
  - EVT-20260822-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.7 時間
  - EVT-20260822-host02-012 (同一ホスト) jvm_gc / mu : WARN / 重なり 1.6 時間
  - EVT-20260822-host02-005 (同一ホスト) jvm_gc / ou : WARN / 重なり 20 分
  - EVT-20260822-host02-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260822-host02-013 (同一ホスト) jvm_gc / mu : WARN / 重なり 10 分

![EVT-20260822-host02-006 active_connections の推移](charts/EVT-20260822-host02-006.svg)

# イベントID( EVT-20260822-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→14→10→13→…→14→12→14→13
* 開始   : 2026-08-22 05:50:00 (UTC)
* 終了   : 2026-08-22 18:20:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.16, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260822-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.0 時間
  - EVT-20260822-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.7 時間
  - EVT-20260822-host02-012 (同一ホスト) jvm_gc / mu : WARN / 重なり 1.6 時間
  - EVT-20260822-host02-005 (同一ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260822-host02-013 (同一ホスト) jvm_gc / mu : WARN / 重なり 10 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260822-host02-007 active_connections の推移](charts/EVT-20260822-host02-007.svg)

# イベントID( EVT-20260822-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→14→12→14→…→9→12→10→11
* 開始   : 2026-08-22 06:00:00 (UTC)
* 終了   : 2026-08-22 20:15:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.069, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.0 時間
  - EVT-20260822-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.7 時間
  - EVT-20260822-host02-012 (同一ホスト) jvm_gc / mu : WARN / 重なり 1.6 時間
  - EVT-20260822-host02-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260822-host02-013 (同一ホスト) jvm_gc / mu : WARN / 重なり 10 分
  - EVT-20260822-host02-014 (同一ホスト) jvm_gc / ou : WARN / 重なり 10 分

![EVT-20260822-host02-008 active_connections の推移](charts/EVT-20260822-host02-008.svg)

# イベントID( EVT-20260822-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 12→14→12→14→…→12→14→11→13
* 開始   : 2026-08-22 06:55:00 (UTC)
* 終了   : 2026-08-22 18:40:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.831, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260822-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260822-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.0 時間
  - EVT-20260822-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.7 時間
  - EVT-20260822-host02-012 (同一ホスト) jvm_gc / mu : WARN / 重なり 1.6 時間
  - EVT-20260822-host02-013 (同一ホスト) jvm_gc / mu : WARN / 重なり 10 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間

![EVT-20260822-host02-009 active_connections の推移](charts/EVT-20260822-host02-009.svg)

# イベントID( EVT-20260822-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9922→1.016e+04→9569→1.017e+04→…→9991→9773→9871→1.01e+04
* 開始   : 2026-08-22 07:05:00 (UTC)
* 終了   : 2026-08-22 18:05:00 (UTC)
* 現象   : 11.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-556.2, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.0 時間
  - EVT-20260822-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.0 時間
  - EVT-20260822-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.0 時間
  - EVT-20260822-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.0 時間
  - EVT-20260822-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.0 時間
  - EVT-20260822-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.7 時間
  - EVT-20260822-host02-012 (同一ホスト) jvm_gc / mu : WARN / 重なり 1.6 時間
  - EVT-20260822-host02-013 (同一ホスト) jvm_gc / mu : WARN / 重なり 10 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.0 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.0 時間

![EVT-20260822-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host02-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 8→9→7→10→…→10→4→10→8
* 開始   : 2026-08-22 21:25:00 (UTC)
* 終了   : 2026-08-22 21:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260822-host02-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.052e+04→1.016e+04→9797→1.055e+04→…→1.055e+04→9610→1.015e+04→1.041e+04
* 開始   : 2026-08-23 13:45:00 (UTC)
* 終了   : 2026-08-23 14:15:00 (UTC)
* 現象   : 平常時(1.034e+04)に対し 1.103倍(1.14e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.179σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host02-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260823-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260823-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260823-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260823-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 8944→8794→1.045e+04→9553→9241
* 開始   : 2026-08-24 00:20:00 (UTC)
* 終了   : 2026-08-24 00:20:00 (UTC)
* 現象   : 平常時(9195)に対し 1.137倍(1.045e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.757σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260824-host02-001 ou の推移](charts/EVT-20260824-host02-001.svg)

# イベントID( EVT-20260824-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 19→17→18→17→…→22→17→18→21
* 開始   : 2026-08-24 02:00:00 (UTC)
* 終了   : 2026-08-24 21:25:00 (UTC)
* 現象   : 2026-08-24 21:25:00 (UTC)を境に水準が 11.72から15.1へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.493, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.781, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 17→19→23→18→23→18→23→20
* 開始   : 2026-08-25 09:00:00 (UTC)
* 終了   : 2026-08-25 09:10:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.249σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 18→18→14→19→18
* 開始   : 2026-08-25 16:35:00 (UTC)
* 終了   : 2026-08-25 16:35:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 16→17→11→15→15
* 開始   : 2026-08-25 18:20:00 (UTC)
* 終了   : 2026-08-25 18:20:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.6769(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.661σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host02-009 active_connections の推移](charts/EVT-20260825-host02-009.svg)

# イベントID( EVT-20260826-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 10→10→14→11→10
* 開始   : 2026-08-26 03:05:00 (UTC)
* 終了   : 2026-08-26 03:05:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.017σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260826-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 21→21→25→21→23
* 開始   : 2026-08-26 10:40:00 (UTC)
* 終了   : 2026-08-26 10:40:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 21→20→16→18→20
* 開始   : 2026-08-26 15:20:00 (UTC)
* 終了   : 2026-08-26 15:20:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 12→8→11→12→…→12→10→15→11
* 開始   : 2026-08-27 03:05:00 (UTC)
* 終了   : 2026-08-27 04:35:00 (UTC)
* 現象   : 1.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-8.832, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-013 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-016 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260827-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host02-002 active_connections の推移](charts/EVT-20260827-host02-002.svg)

# イベントID( EVT-20260827-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 18→18→23→21→21
* 開始   : 2026-08-27 09:05:00 (UTC)
* 終了   : 2026-08-27 09:05:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260827-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→14→10→12→12
* 開始   : 2026-08-27 18:45:00 (UTC)
* 終了   : 2026-08-27 18:45:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.678(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→9→5→8→9
* 開始   : 2026-08-27 22:05:00 (UTC)
* 終了   : 2026-08-27 22:05:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 19→20→16→20→19
* 開始   : 2026-08-28 15:20:00 (UTC)
* 終了   : 2026-08-28 15:20:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260828-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 16→10→15→11→10→15→11→15→13
* 開始   : 2026-08-28 18:40:00 (UTC)
* 終了   : 2026-08-28 18:50:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host03-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 8→11→6→9→11
* 開始   : 2026-08-28 21:15:00 (UTC)
* 終了   : 2026-08-28 21:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host13-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-069 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260828-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 6→7→12→9→8
* 開始   : 2026-08-29 00:00:00 (UTC)
* 終了   : 2026-08-29 00:00:00 (UTC)
* 現象   : 平常時(7.333)に対し 1.636倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260829-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 8955→8847→1.014e+04→9088→9054
* 開始   : 2026-08-29 00:40:00 (UTC)
* 終了   : 2026-08-29 00:40:00 (UTC)
* 現象   : 平常時(9126)に対し 1.111倍(1.014e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260829-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→9→10→12→…→12→11→12→11
* 開始   : 2026-08-29 04:30:00 (UTC)
* 終了   : 2026-08-29 18:45:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.91, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host02-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260829-host02-012 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.7 時間
  - EVT-20260829-host02-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.7 時間
  - EVT-20260829-host02-014 (同一ホスト) jvm_gc / mu : WARN / 重なり 35 分
  - EVT-20260829-host02-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260829-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260829-host02-006 active_connections の推移](charts/EVT-20260829-host02-006.svg)

# イベントID( EVT-20260829-host02-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→8→10→9→…→9→10→14→10
* 開始   : 2026-08-29 05:05:00 (UTC)
* 終了   : 2026-08-29 20:25:00 (UTC)
* 現象   : 15.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.218, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host02-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260829-host02-012 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.7 時間
  - EVT-20260829-host02-015 (同一ホスト) jvm_gc / ou : FATAL / 重なり 30 分
  - EVT-20260829-host02-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.7 時間
  - EVT-20260829-host02-014 (同一ホスト) jvm_gc / mu : WARN / 重なり 35 分
  - EVT-20260829-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260829-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間

![EVT-20260829-host02-007 active_connections の推移](charts/EVT-20260829-host02-007.svg)

# イベントID( EVT-20260829-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 14→13→11→15→…→8→12→8→12
* 開始   : 2026-08-29 05:35:00 (UTC)
* 終了   : 2026-08-29 18:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.918, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host02-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260829-host02-012 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.7 時間
  - EVT-20260829-host02-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.7 時間
  - EVT-20260829-host02-014 (同一ホスト) jvm_gc / mu : WARN / 重なり 35 分
  - EVT-20260829-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260829-host02-008 active_connections の推移](charts/EVT-20260829-host02-008.svg)

# イベントID( EVT-20260829-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 13→16→12→15→…→11→13→12→11
* 開始   : 2026-08-29 06:25:00 (UTC)
* 終了   : 2026-08-29 18:10:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.833, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260829-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260829-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260829-host02-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260829-host02-012 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.2 時間
  - EVT-20260829-host02-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.7 時間
  - EVT-20260829-host02-014 (同一ホスト) jvm_gc / mu : WARN / 重なり 35 分
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間

![EVT-20260829-host02-010 active_connections の推移](charts/EVT-20260829-host02-010.svg)

# イベントID( EVT-20260829-host02-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 15→13→11→14→…→14→11→14→13
* 開始   : 2026-08-29 06:30:00 (UTC)
* 終了   : 2026-08-29 19:10:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.916, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260829-host02-012 (同一ホスト) jvm_gc / ou : FATAL / 重なり 11.7 時間
  - EVT-20260829-host02-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.7 時間
  - EVT-20260829-host02-014 (同一ホスト) jvm_gc / mu : WARN / 重なり 35 分
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260829-host02-011 active_connections の推移](charts/EVT-20260829-host02-011.svg)

# イベントID( EVT-20260829-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.048e+04→1.025e+04→9975→1.012e+04→…→9933→1.007e+04→1.038e+04→9607
* 開始   : 2026-08-29 07:00:00 (UTC)
* 終了   : 2026-08-29 18:40:00 (UTC)
* 現象   : 11.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-537.6, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260829-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260829-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260829-host02-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260829-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260829-host02-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.7 時間
  - EVT-20260829-host02-014 (同一ホスト) jvm_gc / mu : WARN / 重なり 35 分
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.7 時間

![EVT-20260829-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9933→9461→9523→9184→…→9184→9266→9420→9173
* 開始   : 2026-08-29 19:50:00 (UTC)
* 終了   : 2026-08-29 20:20:00 (UTC)
* 現象   : 30分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.06σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-540.2, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260829-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260829-lsfhost01-037 (他ホスト) lsf_queue / run : FATAL / 重なり 30 分
  - EVT-20260829-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260829-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260829-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.027e+04→9558→9826→1e+04→…→9968→9680→1.091e+04→9612
* 開始   : 2026-08-01 06:30:00 (UTC)
* 終了   : 2026-08-01 07:00:00 (UTC)
* 現象   : 30分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-582.1, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260801-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260801-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260801-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260801-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 30 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 30 分
  - EVT-20260801-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分

![EVT-20260801-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 15→14→15→17→…→13→14→13→14
* 開始   : 2026-08-01 07:45:00 (UTC)
* 終了   : 2026-08-01 17:05:00 (UTC)
* 現象   : 9.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.779, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.3 時間
  - EVT-20260801-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.3 時間
  - EVT-20260801-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.3 時間
  - EVT-20260801-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.3 時間
  - EVT-20260801-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 9.3 時間
  - EVT-20260801-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 8.9 時間
  - EVT-20260801-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 1.0 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 9.3 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 9.3 時間
  - EVT-20260801-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 9.3 時間

![EVT-20260801-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host02-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2536→2502→2497→2488→…→2506→2479→2531→2484
* 開始   : 2026-08-01 12:35:00 (UTC)
* 終了   : 2026-08-01 13:35:00 (UTC)
* 現象   : 1.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-62.43, 限界=49.87)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.0 時間
  - EVT-20260801-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.0 時間
  - EVT-20260801-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.0 時間
  - EVT-20260801-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.0 時間
  - EVT-20260801-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.0 時間
  - EVT-20260801-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 1.0 時間
  - EVT-20260801-host02-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 1.0 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 1.0 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 1.0 時間
  - EVT-20260801-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.0 時間

![EVT-20260801-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→12→6→10→12→6→10
* 開始   : 2026-08-01 21:25:00 (UTC)
* 終了   : 2026-08-01 21:30:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.6102(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.669σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260801-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 8→9→11→8→…→8→12→9→8
* 開始   : 2026-08-02 01:35:00 (UTC)
* 終了   : 2026-08-02 01:45:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260802-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 17→16→13→12→…→13→12→13→17
* 開始   : 2026-08-02 10:55:00 (UTC)
* 終了   : 2026-08-02 11:00:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260802-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260802-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.039e+04→1.052e+04→1.104e+04→9857→…→9857→1.112e+04→1.014e+04→1.047e+04
* 開始   : 2026-08-02 12:10:00 (UTC)
* 終了   : 2026-08-02 12:20:00 (UTC)
* 現象   : 平常時(1.025e+04)に対し 1.077倍(1.104e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.361σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.052e+04→1.032e+04→9628→1.037e+04→…→1.037e+04→9661→1.031e+04→1.037e+04
* 開始   : 2026-08-02 14:15:00 (UTC)
* 終了   : 2026-08-02 14:25:00 (UTC)
* 現象   : 平常時(1.041e+04)に対し 0.9245(9628)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.35σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260802-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host02-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→10→12→10→14→11
* 開始   : 2026-08-02 20:15:00 (UTC)
* 終了   : 2026-08-02 20:40:00 (UTC)
* 現象   : 2026-08-02 20:40:00 (UTC)を境に水準が 11.96から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.43, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 12→10→10→10→11→11→11→10→11
* 開始   : 2026-08-02 20:45:00 (UTC)
* 終了   : 2026-08-02 21:30:00 (UTC)
* 現象   : 2026-08-02 21:30:00 (UTC)を境に水準が 11.8から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.521, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 19→21→22→21→…→19→20→17→19
* 開始   : 2026-08-03 03:30:00 (UTC)
* 終了   : 2026-08-03 20:40:00 (UTC)
* 現象   : 2026-08-03 20:40:00 (UTC)を境に水準が 11.9から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.655, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.538, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2525→2518→2520→2516→2525→2519→2548→2546→2550
* 開始   : 2026-08-03 08:30:00 (UTC)
* 終了   : 2026-08-03 14:25:00 (UTC)
* 現象   : 2026-08-03 14:25:00 (UTC)を境に水準が 2485から2499へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=50.11, 限界=49.87)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=250.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→11→10→12→8→9→9→10→11
* 開始   : 2026-08-03 21:10:00 (UTC)
* 終了   : 2026-08-03 21:50:00 (UTC)
* 現象   : 2026-08-03 21:50:00 (UTC)を境に水準が 14.86から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.396, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9703→9489→8686→8670→…→8686→8670→8813→9685
* 開始   : 2026-08-03 23:20:00 (UTC)
* 終了   : 2026-08-03 23:25:00 (UTC)
* 現象   : 平常時(9498)に対し 0.9145(8686)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.426σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260803-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260803-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260803-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260803-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 8→9→11→10→11→10→11→7
* 開始   : 2026-08-04 01:10:00 (UTC)
* 終了   : 2026-08-04 01:20:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.447σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 11→9→9→10→10→8→10→10→11
* 開始   : 2026-08-04 01:20:00 (UTC)
* 終了   : 2026-08-04 02:05:00 (UTC)
* 現象   : 2026-08-04 02:05:00 (UTC)を境に水準が 14.86から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.521, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9304→9435→9958→1.003e+04→…→9958→1.003e+04→9464→9319
* 開始   : 2026-08-04 02:55:00 (UTC)
* 終了   : 2026-08-04 03:00:00 (UTC)
* 現象   : 平常時(9193)に対し 1.083倍(9958)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→14→11→12
* 開始   : 2026-08-04 03:15:00 (UTC)
* 終了   : 2026-08-04 03:40:00 (UTC)
* 現象   : 2026-08-04 03:40:00 (UTC)を境に水準が 14.9から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.547, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→12→14→15→…→14→15→14→13
* 開始   : 2026-08-04 04:55:00 (UTC)
* 終了   : 2026-08-04 05:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.019e+04→1.007e+04→1.068e+04→1.072e+04→…→1.068e+04→1.072e+04→1.057e+04→1.024e+04
* 開始   : 2026-08-04 06:15:00 (UTC)
* 終了   : 2026-08-04 06:20:00 (UTC)
* 現象   : 平常時(9952)に対し 1.073倍(1.068e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.166σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260804-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 18→20→20→16→19
* 開始   : 2026-08-04 07:05:00 (UTC)
* 終了   : 2026-08-04 07:25:00 (UTC)
* 現象   : 2026-08-04 07:25:00 (UTC)を境に水準が 15.04から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.796σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 16→15→13→12→14→15→14→15
* 開始   : 2026-08-04 18:40:00 (UTC)
* 終了   : 2026-08-04 19:15:00 (UTC)
* 現象   : 2026-08-04 19:15:00 (UTC)を境に水準が 15.02から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→13→11→10→…→11→10→12→14
* 開始   : 2026-08-04 19:00:00 (UTC)
* 終了   : 2026-08-04 19:05:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260804-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host02-014 )

* イベント種別 : ALG-A2 Hampel フィルタ
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 15→11→10→12→…→12→9→14→12
* 開始   : 2026-08-04 19:20:00 (UTC)
* 終了   : 2026-08-04 19:30:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host04-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 17→16→16→17→17
* 開始   : 2026-08-05 17:45:00 (UTC)
* 終了   : 2026-08-05 18:35:00 (UTC)
* 現象   : 2026-08-05 18:35:00 (UTC)を境に水準が 14.95から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.573σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.021e+04→1.004e+04→8897→8883→…→8897→8883→9513→9524
* 開始   : 2026-08-05 21:05:00 (UTC)
* 終了   : 2026-08-05 21:10:00 (UTC)
* 現象   : 平常時(9735)に対し 0.9139(8897)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 8→9→10→7→10→10
* 開始   : 2026-08-06 00:20:00 (UTC)
* 終了   : 2026-08-06 00:45:00 (UTC)
* 現象   : 2026-08-06 00:45:00 (UTC)を境に水準が 16.2から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.513, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→6→5→11→…→5→11→9→7
* 開始   : 2026-08-06 00:35:00 (UTC)
* 終了   : 2026-08-06 00:40:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.437σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-002 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260806-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→17→14→17→14→17→13
* 開始   : 2026-08-06 05:50:00 (UTC)
* 終了   : 2026-08-06 06:00:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.283倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.631σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260806-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260806-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.113e+04→1.13e+04→1.028e+04→1.078e+04→1.113e+04→1.116e+04→1.073e+04→1.064e+04
* 開始   : 2026-08-06 07:25:00 (UTC)
* 終了   : 2026-08-06 08:00:00 (UTC)
* 現象   : 2026-08-06 08:00:00 (UTC)を境に水準が 1.022e+04から1.024e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2257, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 16→17→19→18→…→18→20→18→20
* 開始   : 2026-08-06 07:35:00 (UTC)
* 終了   : 2026-08-06 07:45:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260806-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260806-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 19→18→21→18→21→18→21→20→19
* 開始   : 2026-08-06 08:15:00 (UTC)
* 終了   : 2026-08-06 08:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260806-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 23→24→21→21→22→23→23
* 開始   : 2026-08-06 12:00:00 (UTC)
* 終了   : 2026-08-06 12:30:00 (UTC)
* 現象   : 2026-08-06 12:30:00 (UTC)を境に水準が 15.14から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.805, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 17→14→17→14→17
* 開始   : 2026-08-06 17:15:00 (UTC)
* 終了   : 2026-08-06 17:20:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7814(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.732σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→11→8→10→8→10→8→11
* 開始   : 2026-08-06 20:50:00 (UTC)
* 終了   : 2026-08-06 21:00:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-016 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host02-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 10→11→14→8→…→14→8→10→11
* 開始   : 2026-08-06 20:50:00 (UTC)
* 終了   : 2026-08-06 20:55:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host02-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9187→8992→9958→8528→…→9958→8528→9348→9656
* 開始   : 2026-08-07 02:25:00 (UTC)
* 終了   : 2026-08-07 02:30:00 (UTC)
* 現象   : 平常時(9136)に対し 1.09倍(9958)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-007 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260807-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→12→16→15→…→15→17→13→11
* 開始   : 2026-08-07 05:00:00 (UTC)
* 終了   : 2026-08-07 05:10:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.315倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 21→21→19→22→19→21→21→22→22
* 開始   : 2026-08-07 08:30:00 (UTC)
* 終了   : 2026-08-07 09:20:00 (UTC)
* 現象   : 2026-08-07 09:20:00 (UTC)を境に水準が 15.05から14.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 22→21→25→23→21→25→23→21
* 開始   : 2026-08-07 11:35:00 (UTC)
* 終了   : 2026-08-07 11:40:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.158倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.379σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260807-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 22→20→23→23→24
* 開始   : 2026-08-07 12:50:00 (UTC)
* 終了   : 2026-08-07 13:10:00 (UTC)
* 現象   : 2026-08-07 13:10:00 (UTC)を境に水準が 14.92から13.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 23→20→19→18→…→19→18→21→22
* 開始   : 2026-08-07 13:05:00 (UTC)
* 終了   : 2026-08-07 13:10:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 22→21→23
* 開始   : 2026-08-07 15:35:00 (UTC)
* 終了   : 2026-08-07 15:45:00 (UTC)
* 現象   : 2026-08-07 15:45:00 (UTC)を境に水準が 15.12から12.54へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.756, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→11→10→11→11→11→10→12
* 開始   : 2026-08-07 20:50:00 (UTC)
* 終了   : 2026-08-07 21:25:00 (UTC)
* 現象   : 2026-08-07 21:25:00 (UTC)を境に水準が 14.94から11.79へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.063, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→10→6→8→10→6→8
* 開始   : 2026-08-07 23:05:00 (UTC)
* 終了   : 2026-08-07 23:10:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host02-017 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-086 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260807-host11-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-085 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260807-host02-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host02-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 9→8→6→5→8→6→5→8→11
* 開始   : 2026-08-07 23:05:00 (UTC)
* 終了   : 2026-08-07 23:10:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host02-016 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-086 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260807-host11-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-085 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260807-host02-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 12→9→5→8→8→8→11→10
* 開始   : 2026-08-08 00:45:00 (UTC)
* 終了   : 2026-08-08 01:20:00 (UTC)
* 現象   : 2026-08-08 01:20:00 (UTC)を境に水準が 14.98から11.81へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.625σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.352, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260808-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→11→7→9→…→9→13→12→9
* 開始   : 2026-08-08 04:15:00 (UTC)
* 終了   : 2026-08-08 04:25:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host02-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260808-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-lsfhost01-006 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260808-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260808-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260808-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host02-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 8→10→9→8→10→9→11
* 開始   : 2026-08-08 04:20:00 (UTC)
* 終了   : 2026-08-08 04:30:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.854, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host02-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260808-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-lsfhost01-007 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260808-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 16→15→16→15→…→13→17→16→18
* 開始   : 2026-08-08 07:25:00 (UTC)
* 終了   : 2026-08-08 17:30:00 (UTC)
* 現象   : 10.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.964, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間
  - EVT-20260808-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間
  - EVT-20260808-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10.1 時間
  - EVT-20260808-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間
  - EVT-20260808-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間
  - EVT-20260808-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間
  - EVT-20260808-host02-011 (同一ホスト) jvm_gc / mu : WARN / 重なり 5 分
  - EVT-20260808-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10.1 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 10.1 時間

![EVT-20260808-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host02-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2494→2491→2488→2508→…→2488→2508→2487→2490
* 開始   : 2026-08-08 11:35:00 (UTC)
* 終了   : 2026-08-08 11:40:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(2488)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-52.98, 限界=49.87)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host02-006 (同一ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260808-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分

![EVT-20260808-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 8→11→7→11→7→11→7→9→8
* 開始   : 2026-08-08 20:35:00 (UTC)
* 終了   : 2026-08-08 20:45:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260808-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260808-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9219→9575→9955→9237→…→9903→9980→9126→9495
* 開始   : 2026-08-09 01:50:00 (UTC)
* 終了   : 2026-08-09 02:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.35σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-006 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260809-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→9→9→9→10→12→12→12→11
* 開始   : 2026-08-09 02:55:00 (UTC)
* 終了   : 2026-08-09 05:30:00 (UTC)
* 現象   : 2026-08-09 05:30:00 (UTC)を境に水準が 11.67から12.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→15→14→11→15→14→13
* 開始   : 2026-08-09 06:40:00 (UTC)
* 終了   : 2026-08-09 06:45:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260809-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 18→16→19→13→15→16→19→13→15
* 開始   : 2026-08-09 11:40:00 (UTC)
* 終了   : 2026-08-09 11:45:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260809-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 15→13→13→15→14→15→16
* 開始   : 2026-08-09 16:45:00 (UTC)
* 終了   : 2026-08-09 17:15:00 (UTC)
* 現象   : 2026-08-09 17:15:00 (UTC)を境に水準が 11.85から14.59へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.765, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 12→10→9→8→9→9→10→10
* 開始   : 2026-08-09 21:00:00 (UTC)
* 終了   : 2026-08-09 22:15:00 (UTC)
* 現象   : 2026-08-09 22:15:00 (UTC)を境に水準が 11.79から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.982σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.063, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 16→19→18→20→…→18→19→17→16
* 開始   : 2026-08-10 02:55:00 (UTC)
* 終了   : 2026-08-10 20:15:00 (UTC)
* 現象   : 2026-08-10 20:15:00 (UTC)を境に水準が 11.81から15.01へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=5.12, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2568→2548→2518→2552→2546→2534→2537→2555→2548
* 開始   : 2026-08-10 08:25:00 (UTC)
* 終了   : 2026-08-10 14:25:00 (UTC)
* 現象   : 2026-08-10 14:25:00 (UTC)を境に水準が 2483から2499へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=61.55, 限界=49.87)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=265.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 9→6→9→6→9
* 開始   : 2026-08-10 22:05:00 (UTC)
* 終了   : 2026-08-10 22:10:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260810-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→10→6→11→…→11→5→7→8
* 開始   : 2026-08-10 22:50:00 (UTC)
* 終了   : 2026-08-10 23:00:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260810-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260810-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260810-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→11→13→9→11→13→9→10
* 開始   : 2026-08-11 03:30:00 (UTC)
* 終了   : 2026-08-11 03:35:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.437σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260811-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→14→13→11→14→13→11
* 開始   : 2026-08-11 04:05:00 (UTC)
* 終了   : 2026-08-11 04:10:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→13→15→16
* 開始   : 2026-08-11 04:55:00 (UTC)
* 終了   : 2026-08-11 05:10:00 (UTC)
* 現象   : 2026-08-11 05:10:00 (UTC)を境に水準が 14.93から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.031, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 16→21→22→18→22→18→22→20
* 開始   : 2026-08-11 08:25:00 (UTC)
* 終了   : 2026-08-11 08:35:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260811-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260811-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260811-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260811-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.125e+04→1.117e+04→1.194e+04→1.108e+04→…→1.108e+04→1.19e+04→1.142e+04→1.086e+04
* 開始   : 2026-08-11 12:00:00 (UTC)
* 終了   : 2026-08-11 12:10:00 (UTC)
* 現象   : 平常時(1.117e+04)に対し 1.068倍(1.194e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 23→25→24→21→22→22→25→23→24
* 開始   : 2026-08-11 12:05:00 (UTC)
* 終了   : 2026-08-11 12:55:00 (UTC)
* 現象   : 2026-08-11 12:55:00 (UTC)を境に水準が 15.05から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.484, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→8→12→8→12→8→11
* 開始   : 2026-08-11 20:30:00 (UTC)
* 終了   : 2026-08-11 20:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.495σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host10-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→8→7→12→8→7→12→11
* 開始   : 2026-08-11 21:05:00 (UTC)
* 終了   : 2026-08-11 21:10:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.672(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260811-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260811-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9391→9337→8576→9309→…→9309→8364→8714→9285
* 開始   : 2026-08-11 23:40:00 (UTC)
* 終了   : 2026-08-12 00:55:00 (UTC)
* 現象   : 平常時(9339)に対し 0.9183倍(8576)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260812-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-002 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-003 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260811-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 7→10→10→7→10→10→11→9
* 開始   : 2026-08-12 01:10:00 (UTC)
* 終了   : 2026-08-12 01:45:00 (UTC)
* 現象   : 2026-08-12 01:45:00 (UTC)を境に水準が 14.97から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.063, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 12→13→15→12→15→12→15→14
* 開始   : 2026-08-12 04:45:00 (UTC)
* 終了   : 2026-08-12 04:55:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 22→23→25→22→…→22→19→20→23
* 開始   : 2026-08-12 12:55:00 (UTC)
* 終了   : 2026-08-12 13:05:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260812-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 22→20→17→18→20→17→18→19
* 開始   : 2026-08-12 15:25:00 (UTC)
* 終了   : 2026-08-12 15:30:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260812-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host02-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.021e+04→9631→9910→1.009e+04→9306→1.012e+04→9629→9987→1.009e+04
* 開始   : 2026-08-12 19:45:00 (UTC)
* 終了   : 2026-08-12 20:25:00 (UTC)
* 現象   : 2026-08-12 20:25:00 (UTC)を境に水準が 1.019e+04から1.028e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2182, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→12→10
* 開始   : 2026-08-12 21:00:00 (UTC)
* 終了   : 2026-08-12 21:10:00 (UTC)
* 現象   : 2026-08-12 21:10:00 (UTC)を境に水準が 15から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host02-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9290→9212→9350→9194→9327→9680→9452→8947→9560
* 開始   : 2026-08-12 23:40:00 (UTC)
* 終了   : 2026-08-13 00:20:00 (UTC)
* 現象   : 2026-08-13 00:20:00 (UTC)を境に水準が 1.02e+04から1.027e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2492, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→17→18→15→17→18→15→18
* 開始   : 2026-08-13 06:40:00 (UTC)
* 終了   : 2026-08-13 06:45:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260813-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.104e+04→1.102e+04→1.121e+04→1.098e+04→1.123e+04→1.101e+04→1.139e+04→1.14e+04→1.111e+04
* 開始   : 2026-08-13 08:00:00 (UTC)
* 終了   : 2026-08-13 09:20:00 (UTC)
* 現象   : 2026-08-13 09:20:00 (UTC)を境に水準が 1.022e+04から1.026e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2283, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 18→16→14→17→16→14→17→18
* 開始   : 2026-08-13 17:15:00 (UTC)
* 終了   : 2026-08-13 17:20:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→12→10→11→…→12→9→11→13
* 開始   : 2026-08-13 19:45:00 (UTC)
* 終了   : 2026-08-13 20:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260813-lsfhost01-053 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260813-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260813-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→12→8→11→12→8→11→10
* 開始   : 2026-08-13 20:55:00 (UTC)
* 終了   : 2026-08-13 21:00:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260813-host04-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 17→18→19→18→…→18→20→18→17
* 開始   : 2026-08-14 07:05:00 (UTC)
* 終了   : 2026-08-14 07:15:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260814-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.076e+04→1.111e+04→1.152e+04→1.167e+04→…→1.167e+04→1.164e+04→1.155e+04→1.107e+04
* 開始   : 2026-08-14 08:55:00 (UTC)
* 終了   : 2026-08-14 09:05:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.543σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260814-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 21→19→23→20→23→20→23→20→22
* 開始   : 2026-08-14 09:15:00 (UTC)
* 終了   : 2026-08-14 09:25:00 (UTC)
* 現象   : 平常時(19.25)に対し 1.195倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.625σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-041 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260814-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 19→18→19→19→18→17→19
* 開始   : 2026-08-14 16:15:00 (UTC)
* 終了   : 2026-08-14 16:45:00 (UTC)
* 現象   : 2026-08-14 16:45:00 (UTC)を境に水準が 15.06から12.35へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.765, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 14→12→16→14→12→16→12
* 開始   : 2026-08-14 18:35:00 (UTC)
* 終了   : 2026-08-14 18:40:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (同一ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260814-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260814-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host02-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 10→11→7→11→7→10
* 開始   : 2026-08-14 21:35:00 (UTC)
* 終了   : 2026-08-14 21:40:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260814-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 8952→9460→9698→9604→…→9604→9762→9107→9055
* 開始   : 2026-08-15 00:15:00 (UTC)
* 終了   : 2026-08-15 00:25:00 (UTC)
* 現象   : 平常時(9021)に対し 1.075倍(9698)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260815-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→10→6→9→…→6→9→12→10
* 開始   : 2026-08-15 03:50:00 (UTC)
* 終了   : 2026-08-15 03:55:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(6)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.785, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260815-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host02-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.018e+04→1.019e+04→1.049e+04→1.062e+04→…→9599→1.005e+04→9732→9520
* 開始   : 2026-08-15 06:00:00 (UTC)
* 終了   : 2026-08-15 17:45:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-592, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260815-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.1 時間
  - EVT-20260815-host02-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 8.8 時間
  - EVT-20260815-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間

![EVT-20260815-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 13→12→15→13→…→15→16→15→16
* 開始   : 2026-08-15 08:05:00 (UTC)
* 終了   : 2026-08-15 16:50:00 (UTC)
* 現象   : 8.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.956, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260815-host02-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260815-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260815-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260815-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260815-host02-008 (同一ホスト) jvm_gc / ou : WARN / 重なり 8.8 時間
  - EVT-20260815-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.8 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 8.8 時間

![EVT-20260815-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host02-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→10→12→10→…→9→11→12→9
* 開始   : 2026-08-15 18:40:00 (UTC)
* 終了   : 2026-08-15 19:30:00 (UTC)
* 現象   : 50分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.723, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260815-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260815-host02-012 (同一ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260815-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260815-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260815-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260815-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分

![EVT-20260815-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host02-012 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9558→9870→8931→9658→…→9421→9320→9337→1e+04
* 開始   : 2026-08-15 19:25:00 (UTC)
* 終了   : 2026-08-15 19:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-535.3, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260815-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260815-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host02-013 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 9→10→9→10→…→9→8→12→9
* 開始   : 2026-08-15 19:45:00 (UTC)
* 終了   : 2026-08-15 20:10:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.999, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260815-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260815-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260815-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260815-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260815-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→6→8→10→6→8→10
* 開始   : 2026-08-15 22:00:00 (UTC)
* 終了   : 2026-08-15 22:05:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260815-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→10→11→12→10→11→12→10→8
* 開始   : 2026-08-16 01:15:00 (UTC)
* 終了   : 2026-08-16 01:20:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260816-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260816-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→12→10→11→12→11→11→12→12
* 開始   : 2026-08-16 03:55:00 (UTC)
* 終了   : 2026-08-16 04:50:00 (UTC)
* 現象   : 2026-08-16 04:50:00 (UTC)を境に水準が 11.9から12.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host02-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→13→15→14→13→15→16→17→15
* 開始   : 2026-08-16 15:35:00 (UTC)
* 終了   : 2026-08-16 16:20:00 (UTC)
* 現象   : 2026-08-16 16:20:00 (UTC)を境に水準が 11.95から14.35へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.028e+04→1.019e+04→9398→9210→…→9800→9055→9751→9880
* 開始   : 2026-08-16 17:20:00 (UTC)
* 終了   : 2026-08-16 17:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260816-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260816-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260816-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260816-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 14→11→9→13→11→9→13→12
* 開始   : 2026-08-16 18:40:00 (UTC)
* 終了   : 2026-08-16 18:45:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.7105(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→11→11→11
* 開始   : 2026-08-16 21:30:00 (UTC)
* 終了   : 2026-08-16 21:45:00 (UTC)
* 現象   : 2026-08-16 21:45:00 (UTC)を境に水準が 11.85から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→10→7→6→10→7→9→9
* 開始   : 2026-08-16 23:20:00 (UTC)
* 終了   : 2026-08-16 23:55:00 (UTC)
* 現象   : 2026-08-16 23:55:00 (UTC)を境に水準が 11.81から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.063, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host02-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 18→19→21→20→…→17→18→17→18
* 開始   : 2026-08-17 01:00:00 (UTC)
* 終了   : 2026-08-17 20:30:00 (UTC)
* 現象   : 2026-08-17 20:30:00 (UTC)を境に水準が 11.9から15.11へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=4.489, 限界=4.488)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.538, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host02-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9687→9486→1.001e+04→9750→1.021e+04→9438→9838→9827→1.027e+04
* 開始   : 2026-08-17 02:50:00 (UTC)
* 終了   : 2026-08-17 05:15:00 (UTC)
* 現象   : 2026-08-17 05:15:00 (UTC)を境に水準が 9768から1.022e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2251, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2560→2543→2498→2553→2549→2547→2551→2553→2568
* 開始   : 2026-08-17 08:25:00 (UTC)
* 終了   : 2026-08-17 09:15:00 (UTC)
* 現象   : 2026-08-17 09:15:00 (UTC)を境に水準が 2484から2498へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=55.51, 限界=49.87)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=265.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host02-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2538→2554→2535→2541→2543→2503→2524→2517→2578
* 開始   : 2026-08-17 10:50:00 (UTC)
* 終了   : 2026-08-17 14:20:00 (UTC)
* 現象   : 2026-08-17 14:20:00 (UTC)を境に水準が 2487から2498へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=293.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host02-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→11→10→10
* 開始   : 2026-08-17 23:00:00 (UTC)
* 終了   : 2026-08-17 23:15:00 (UTC)
* 現象   : 2026-08-17 23:15:00 (UTC)を境に水準が 15から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.031, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→12→10→13→12→10→13→9→10
* 開始   : 2026-08-18 02:25:00 (UTC)
* 終了   : 2026-08-18 02:35:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.032e+04→1.042e+04→1.003e+04→1.025e+04→1.046e+04→1.022e+04→1.044e+04→9795→1.074e+04
* 開始   : 2026-08-18 04:30:00 (UTC)
* 終了   : 2026-08-18 06:25:00 (UTC)
* 現象   : 2026-08-18 06:25:00 (UTC)を境に水準が 1.022e+04から1.024e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.46σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2245, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 13→14→17→15→14→17→15
* 開始   : 2026-08-18 05:50:00 (UTC)
* 終了   : 2026-08-18 05:55:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.291倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.69σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host02-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260818-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.045e+04→1.06e+04→1.122e+04→1.133e+04→…→1.122e+04→1.133e+04→1.075e+04→1.086e+04
* 開始   : 2026-08-18 07:45:00 (UTC)
* 終了   : 2026-08-18 07:50:00 (UTC)
* 現象   : 平常時(1.047e+04)に対し 1.071倍(1.122e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260818-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 23→20→19→19→20→18→22→20→19
* 開始   : 2026-08-18 15:20:00 (UTC)
* 終了   : 2026-08-18 16:10:00 (UTC)
* 現象   : 2026-08-18 16:10:00 (UTC)を境に水準が 14.99から16.35へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 11→12→11→12→10→12→11
* 開始   : 2026-08-18 21:00:00 (UTC)
* 終了   : 2026-08-18 22:00:00 (UTC)
* 現象   : 2026-08-18 22:00:00 (UTC)を境に水準が 14.9から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.308, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9857→9592→1.01e+04→8740→…→8740→1.009e+04→9681→9817
* 開始   : 2026-08-19 02:45:00 (UTC)
* 終了   : 2026-08-19 02:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.114σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260819-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260819-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.045e+04→1.012e+04→1.083e+04→1.102e+04→…→1.083e+04→1.102e+04→1.039e+04→1.061e+04
* 開始   : 2026-08-19 06:15:00 (UTC)
* 終了   : 2026-08-19 06:20:00 (UTC)
* 現象   : 平常時(1.016e+04)に対し 1.066倍(1.083e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260819-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260819-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 13→16→17→15→…→15→18→17→16
* 開始   : 2026-08-19 06:25:00 (UTC)
* 終了   : 2026-08-19 06:35:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 17→16→19→16→…→16→20→18→17
* 開始   : 2026-08-19 07:15:00 (UTC)
* 終了   : 2026-08-19 07:25:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260819-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 20→21→21→19→19→21
* 開始   : 2026-08-19 08:00:00 (UTC)
* 終了   : 2026-08-19 08:25:00 (UTC)
* 現象   : 2026-08-19 08:25:00 (UTC)を境に水準が 15.01から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.573σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.547, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 23→22→19→21→22→19→21
* 開始   : 2026-08-19 13:15:00 (UTC)
* 終了   : 2026-08-19 13:20:00 (UTC)
* 現象   : 平常時(23)に対し 0.8261(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.796σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.088e+04→1.13e+04→1.114e+04→1.103e+04→1.115e+04→1.066e+04→1.167e+04
* 開始   : 2026-08-19 14:55:00 (UTC)
* 終了   : 2026-08-19 15:25:00 (UTC)
* 現象   : 2026-08-19 15:25:00 (UTC)を境に水準が 1.024e+04から1.024e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2429, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 20→23→17→20→17→20→17→19
* 開始   : 2026-08-19 15:25:00 (UTC)
* 終了   : 2026-08-19 15:35:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.495σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260819-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→17→14→15→…→15→13→15→16
* 開始   : 2026-08-19 17:40:00 (UTC)
* 終了   : 2026-08-19 17:50:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host02-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9618→9017→9096→9100→8962→9136→9238→9581→9320
* 開始   : 2026-08-19 22:40:00 (UTC)
* 終了   : 2026-08-19 23:40:00 (UTC)
* 現象   : 2026-08-19 23:40:00 (UTC)を境に水準が 1.023e+04から1.025e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2181, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→11→13→12→11→11
* 開始   : 2026-08-20 03:00:00 (UTC)
* 終了   : 2026-08-20 03:25:00 (UTC)
* 現象   : 2026-08-20 03:25:00 (UTC)を境に水準が 14.85から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.188, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→9→13→11→13→11→13→10→11
* 開始   : 2026-08-20 03:25:00 (UTC)
* 終了   : 2026-08-20 03:35:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host02-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-008 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260820-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→8→13→10→8→13→10→12
* 開始   : 2026-08-20 03:30:00 (UTC)
* 終了   : 2026-08-20 03:35:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host02-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-008 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260820-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 19→18→22→17→22→17→22→20→19
* 開始   : 2026-08-20 09:10:00 (UTC)
* 終了   : 2026-08-20 09:20:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260820-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 21→20→24→19→20→24→19→20
* 開始   : 2026-08-20 11:05:00 (UTC)
* 終了   : 2026-08-20 11:10:00 (UTC)
* 現象   : 平常時(20.75)に対し 1.157倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 19→18→17→20→18→17→20→19
* 開始   : 2026-08-20 15:45:00 (UTC)
* 終了   : 2026-08-20 15:50:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host02-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.082e+04→1.034e+04→1.102e+04→1.117e+04
* 開始   : 2026-08-20 17:40:00 (UTC)
* 終了   : 2026-08-20 17:55:00 (UTC)
* 現象   : 2026-08-20 17:55:00 (UTC)を境に水準が 1.024e+04から1.026e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2510, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 10→13→9→12→11
* 開始   : 2026-08-20 20:20:00 (UTC)
* 終了   : 2026-08-20 21:45:00 (UTC)
* 現象   : 2026-08-20 21:45:00 (UTC)を境に水準が 14.93から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.524, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 13→14→15→14→…→14→16→15→14
* 開始   : 2026-08-21 05:15:00 (UTC)
* 終了   : 2026-08-21 05:25:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260821-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260821-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.045e+04→9980→1.06e+04→1.069e+04→…→1.06e+04→1.069e+04→1.021e+04→9935
* 開始   : 2026-08-21 05:40:00 (UTC)
* 終了   : 2026-08-21 05:45:00 (UTC)
* 現象   : 平常時(9901)に対し 1.071倍(1.06e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260821-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260821-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.131e+04→1.116e+04→1.159e+04→1.044e+04→1.116e+04→1.086e+04→1.089e+04→1.079e+04→1.149e+04
* 開始   : 2026-08-21 07:30:00 (UTC)
* 終了   : 2026-08-21 08:15:00 (UTC)
* 現象   : 2026-08-21 08:15:00 (UTC)を境に水準が 1.025e+04から1.014e+04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2783, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 22→21→25→19→22→21→25→19→22
* 開始   : 2026-08-21 13:15:00 (UTC)
* 終了   : 2026-08-21 13:20:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260821-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 18→15→18→15→18→19
* 開始   : 2026-08-21 16:40:00 (UTC)
* 終了   : 2026-08-21 16:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-049 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host02-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 11→12→13→10→11→11→11
* 開始   : 2026-08-21 20:40:00 (UTC)
* 終了   : 2026-08-21 21:10:00 (UTC)
* 現象   : 2026-08-21 21:10:00 (UTC)を境に水準が 14.85から12.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.389, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 11→9→6→10→9→6→10→8
* 開始   : 2026-08-21 22:10:00 (UTC)
* 終了   : 2026-08-21 22:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host05-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→11→9→8→12
* 開始   : 2026-08-22 01:55:00 (UTC)
* 終了   : 2026-08-22 02:25:00 (UTC)
* 現象   : 2026-08-22 02:25:00 (UTC)を境に水準が 15.02から11.6へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260822-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host02-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9242→8735→9493→9638→…→9638→9674→1.018e+04→9636
* 開始   : 2026-08-22 04:10:00 (UTC)
* 終了   : 2026-08-22 04:20:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9493)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-531.9, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260822-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260822-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260822-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260822-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host02-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 10→12→11→12→11→12→13
* 開始   : 2026-08-22 05:30:00 (UTC)
* 終了   : 2026-08-22 05:35:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(11)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.734, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host02-005 (同一ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260822-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9693→8946→9034→9838→…→9765→9063→9909→1.015e+04
* 開始   : 2026-08-22 05:35:00 (UTC)
* 終了   : 2026-08-22 06:00:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-584.3, 限界=525.8)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260822-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260822-host02-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 25 分
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260822-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260822-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分

![EVT-20260822-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host02-011 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 16→13→14→16→…→18→13→16→12
* 開始   : 2026-08-22 08:25:00 (UTC)
* 終了   : 2026-08-22 17:05:00 (UTC)
* 現象   : 8.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.561, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.7 時間
  - EVT-20260822-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.7 時間
  - EVT-20260822-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.7 時間
  - EVT-20260822-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.7 時間
  - EVT-20260822-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.7 時間
  - EVT-20260822-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 8.7 時間
  - EVT-20260822-host02-012 (同一ホスト) jvm_gc / mu : WARN / 重なり 1.6 時間
  - EVT-20260822-host02-013 (同一ホスト) jvm_gc / mu : WARN / 重なり 10 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.7 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 8.7 時間

![EVT-20260822-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host02-012 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2465→2505→2448→2512→…→2468→2519→2494→2486
* 開始   : 2026-08-22 11:35:00 (UTC)
* 終了   : 2026-08-22 13:10:00 (UTC)
* 現象   : 1.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-54.13, 限界=49.87)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.6 時間
  - EVT-20260822-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.6 時間
  - EVT-20260822-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.6 時間
  - EVT-20260822-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.6 時間
  - EVT-20260822-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 1.6 時間
  - EVT-20260822-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 1.6 時間
  - EVT-20260822-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 1.6 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.6 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 1.6 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.6 時間

![EVT-20260822-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host02-013 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2504→2472→2485→2480→…→2480→2475→2536→2500
* 開始   : 2026-08-22 15:10:00 (UTC)
* 終了   : 2026-08-22 15:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-54.39, 限界=49.87)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host02-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host02-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host02-010 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260822-host02-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260822-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9883→9632→8931→9882→…→9882→8862→9272→9748
* 開始   : 2026-08-22 19:10:00 (UTC)
* 終了   : 2026-08-22 19:20:00 (UTC)
* 現象   : 平常時(9749)に対し 0.9161(8931)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260822-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host02-015 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 11→8→9→11→…→11→9→12→10
* 開始   : 2026-08-22 19:30:00 (UTC)
* 終了   : 2026-08-22 19:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.777, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260822-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分

![EVT-20260822-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→11→8→12→10→12→12→10→13
* 開始   : 2026-08-23 02:50:00 (UTC)
* 終了   : 2026-08-23 04:35:00 (UTC)
* 現象   : 2026-08-23 04:35:00 (UTC)を境に水準が 11.6から11.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 10→11→13→11→…→11→7→10→9
* 開始   : 2026-08-23 04:15:00 (UTC)
* 終了   : 2026-08-23 04:25:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260823-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 15→12→11→17→…→11→17→15→14
* 開始   : 2026-08-23 08:55:00 (UTC)
* 終了   : 2026-08-23 09:00:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-019 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260823-lsfhost01-021 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260823-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260823-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→17→13→16→13→16→13→15→16
* 開始   : 2026-08-23 13:50:00 (UTC)
* 終了   : 2026-08-23 14:00:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host02-004 (同一ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260823-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260823-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 15→14→11→12→14→11→12→14
* 開始   : 2026-08-23 16:10:00 (UTC)
* 終了   : 2026-08-23 16:15:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.75(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260823-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260823-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260823-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host02-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2515→2524→2553→2537→2511→2483→2506→2540→2533
* 開始   : 2026-08-24 06:30:00 (UTC)
* 終了   : 2026-08-24 07:25:00 (UTC)
* 現象   : 2026-08-24 07:25:00 (UTC)を境に水準が 2482から2497へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=272.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host02-010 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2556→2526→2498→2547→2516→2533→2514→2600→2580
* 開始   : 2026-08-24 10:35:00 (UTC)
* 終了   : 2026-08-24 15:05:00 (UTC)
* 現象   : 2026-08-24 15:05:00 (UTC)を境に水準が 2487から2498へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=50.87, 限界=49.87)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=299.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9413→9220→1.021e+04→8776→…→1.021e+04→8776→8957→8875
* 開始   : 2026-08-24 22:45:00 (UTC)
* 終了   : 2026-08-24 22:50:00 (UTC)
* 現象   : 平常時(9447)に対し 1.081倍(1.021e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260824-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host02-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 7→8→11→7→8→11→7→9
* 開始   : 2026-08-24 23:05:00 (UTC)
* 終了   : 2026-08-24 23:10:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260824-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260824-host02-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host02-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 7→9→9→8→8→10→9→10→12
* 開始   : 2026-08-24 23:35:00 (UTC)
* 終了   : 2026-08-25 00:40:00 (UTC)
* 現象   : 2026-08-25 00:40:00 (UTC)を境に水準が 14.99から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9691→9945→9712→9618
* 開始   : 2026-08-25 00:35:00 (UTC)
* 終了   : 2026-08-25 00:50:00 (UTC)
* 現象   : 2026-08-25 00:50:00 (UTC)を境に水準が 1.021e+04から1.024e+04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=2180, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host02-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 9504→9827→1.009e+04→9310→…→9310→1.034e+04→8932→9670
* 開始   : 2026-08-25 03:15:00 (UTC)
* 終了   : 2026-08-25 03:25:00 (UTC)
* 現象   : 平常時(9391)に対し 1.075倍(1.009e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.01e+04→9900→1.032e+04→1.053e+04→…→1.032e+04→1.053e+04→9835→9714
* 開始   : 2026-08-25 04:30:00 (UTC)
* 終了   : 2026-08-25 04:35:00 (UTC)
* 現象   : 平常時(9633)に対し 1.071倍(1.032e+04)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.051σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-014 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260825-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 15→18→14→18→14→18→17→16
* 開始   : 2026-08-25 06:45:00 (UTC)
* 終了   : 2026-08-25 06:55:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260825-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 15→19→20→17→15→19→20→17
* 開始   : 2026-08-25 07:15:00 (UTC)
* 終了   : 2026-08-25 07:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host02-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 23→22→22→23→21→25→21→23
* 開始   : 2026-08-25 10:05:00 (UTC)
* 終了   : 2026-08-25 10:40:00 (UTC)
* 現象   : 2026-08-25 10:40:00 (UTC)を境に水準が 14.98から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.063, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host02-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 9→6→5→11→…→5→11→9→7
* 開始   : 2026-08-26 01:10:00 (UTC)
* 終了   : 2026-08-26 01:15:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 10→12→15→9→13→12→15→9→13
* 開始   : 2026-08-26 04:35:00 (UTC)
* 終了   : 2026-08-26 04:40:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.263σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260826-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 17→16→19→17→20→19→17→20→18
* 開始   : 2026-08-26 07:20:00 (UTC)
* 終了   : 2026-08-26 07:30:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260826-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host02-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 17→18→21→17→18→21→17→20
* 開始   : 2026-08-26 07:45:00 (UTC)
* 終了   : 2026-08-26 07:50:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.229倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.748σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 17→21→19→21→19→21→19→20
* 開始   : 2026-08-26 08:25:00 (UTC)
* 終了   : 2026-08-26 08:35:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 21→25→22→19→25→22→19→23→24
* 開始   : 2026-08-26 11:35:00 (UTC)
* 終了   : 2026-08-26 11:45:00 (UTC)
* 現象   : 平常時(22)に対し 1.136倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260826-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_6
* 値     : 21→19→17→22→19→17→22→21
* 開始   : 2026-08-26 14:40:00 (UTC)
* 終了   : 2026-08-26 14:45:00 (UTC)
* 現象   : 水曜14時台の平常値(20.7)に対し 17であった
* 説明   : ALG-A1: 移動平均からの残差が 2.679σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.131σ 外れた (平常値=20.7)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260826-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260826-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host02-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : jvm_gc / ou (Old 使用量) / container=app02, host=host02
* 値     : 1.137e+04→1.077e+04→1.038e+04→1.175e+04→…→1.038e+04→1.175e+04→1.1e+04→1.07e+04
* 開始   : 2026-08-26 14:55:00 (UTC)
* 終了   : 2026-08-26 15:00:00 (UTC)
* 現象   : 平常時(1.109e+04)に対し 0.9364(1.038e+04)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host02-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host02-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 15→14→13→12→15→13→14→13→15
* 開始   : 2026-08-26 18:05:00 (UTC)
* 終了   : 2026-08-26 20:05:00 (UTC)
* 現象   : 2026-08-26 20:05:00 (UTC)を境に水準が 14.93から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.609, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host02-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 10→11→7→10→11→7→10→8
* 開始   : 2026-08-26 21:35:00 (UTC)
* 終了   : 2026-08-26 21:40:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.6667(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-074 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260826-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host02-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 11→12→8→10→8→10→10→9→8
* 開始   : 2026-08-26 21:50:00 (UTC)
* 終了   : 2026-08-26 22:55:00 (UTC)
* 現象   : 2026-08-26 22:55:00 (UTC)を境に水準が 14.92から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.439, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host02-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host02-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 9→10→11→8→7→9→11→9→14
* 開始   : 2026-08-27 00:40:00 (UTC)
* 終了   : 2026-08-27 01:20:00 (UTC)
* 現象   : 2026-08-27 01:20:00 (UTC)を境に水準が 16.11から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=14.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host02-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 16→14→14→15→14→16
* 開始   : 2026-08-27 05:05:00 (UTC)
* 終了   : 2026-08-27 05:30:00 (UTC)
* 現象   : 2026-08-27 05:30:00 (UTC)を境に水準が 15から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 15→17→18→16→15→17→18→16
* 開始   : 2026-08-27 06:00:00 (UTC)
* 終了   : 2026-08-27 06:05:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260827-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host02-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 23→23→25→22→22→24→23→21→22
* 開始   : 2026-08-27 10:30:00 (UTC)
* 終了   : 2026-08-27 11:20:00 (UTC)
* 現象   : 2026-08-27 11:20:00 (UTC)を境に水準が 15.05から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host02-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host02-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 23→19→21→23→19→21
* 開始   : 2026-08-27 13:35:00 (UTC)
* 終了   : 2026-08-27 13:40:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8444(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260827-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260827-host02-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host02-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 21→19→16→20→16→20→16→19
* 開始   : 2026-08-27 16:05:00 (UTC)
* 終了   : 2026-08-27 16:15:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host02-001 )

* イベント種別 : ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 7→8→6→9→8→6→9→11
* 開始   : 2026-08-28 02:00:00 (UTC)
* 終了   : 2026-08-28 02:05:00 (UTC)
* 現象   : 金曜2時台の平常値(9.542)に対し 6であった
* 説明   : ALG-A5: 同じ曜日・時刻帯の平常値から 3.168σ 外れた (平常値=9.542)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260828-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260828-host02-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host02-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 16→16→15→15→17→18
* 開始   : 2026-08-28 05:25:00 (UTC)
* 終了   : 2026-08-28 05:50:00 (UTC)
* 現象   : 2026-08-28 05:50:00 (UTC)を境に水準が 14.95から14.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.513, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host02-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 23→23→21→23→21→22→22→22
* 開始   : 2026-08-28 12:55:00 (UTC)
* 終了   : 2026-08-28 13:55:00 (UTC)
* 現象   : 2026-08-28 13:55:00 (UTC)を境に水準が 15.02から12.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.205σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.251, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host02-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 15→16→13→12→…→13→12→13→15
* 開始   : 2026-08-28 18:10:00 (UTC)
* 終了   : 2026-08-28 18:15:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host02-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 9→12→11
* 開始   : 2026-08-28 22:00:00 (UTC)
* 終了   : 2026-08-28 22:10:00 (UTC)
* 現象   : 2026-08-28 22:10:00 (UTC)を境に水準が 15.03から11.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.773, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host02-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host02-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_1
* 値     : 9→6→8→12→6→8→12→7→9
* 開始   : 2026-08-28 22:05:00 (UTC)
* 終了   : 2026-08-28 22:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260828-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host02-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 9→7→6→7→6→7
* 開始   : 2026-08-28 22:40:00 (UTC)
* 終了   : 2026-08-28 22:45:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260828-host02-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host02-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 8→12→8→12→8→12→10→9
* 開始   : 2026-08-29 02:20:00 (UTC)
* 終了   : 2026-08-29 02:30:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.455倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.611σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260829-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260829-host02-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host02-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_4
* 値     : 8→9→12→10→9→12→10→8
* 開始   : 2026-08-29 03:15:00 (UTC)
* 終了   : 2026-08-29 03:20:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260829-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260829-lsfhost01-006 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260829-host02-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host02-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_5
* 値     : 9→10→8→10→…→12→11→12→11
* 開始   : 2026-08-29 04:20:00 (UTC)
* 終了   : 2026-08-29 04:50:00 (UTC)
* 現象   : 30分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.837, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260829-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 25 分
  - EVT-20260829-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 25 分
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260829-host02-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host02-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 12→9→12→9→…→12→9→14→13
* 開始   : 2026-08-29 06:05:00 (UTC)
* 終了   : 2026-08-29 06:10:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(12)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.525, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260829-host02-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host02-013 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_3
* 値     : 13→14→12→13→…→13→14→15→14
* 開始   : 2026-08-29 07:35:00 (UTC)
* 終了   : 2026-08-29 16:15:00 (UTC)
* 現象   : 8.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-4.74, 限界=4.488)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.7 時間
  - EVT-20260829-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.7 時間
  - EVT-20260829-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.7 時間
  - EVT-20260829-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.7 時間
  - EVT-20260829-host02-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 8.7 時間
  - EVT-20260829-host02-012 (同一ホスト) jvm_gc / ou : FATAL / 重なり 8.7 時間
  - EVT-20260829-host02-014 (同一ホスト) jvm_gc / mu : WARN / 重なり 35 分
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.7 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 8.7 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 8.7 時間

![EVT-20260829-host02-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host02-014 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : jvm_gc / mu (Metaspace 使用量) / container=app02, host=host02
* 値     : 2510→2475→2498→2493→…→2475→2492→2478→2485
* 開始   : 2026-08-29 08:55:00 (UTC)
* 終了   : 2026-08-29 09:30:00 (UTC)
* 現象   : 35分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-52.83, 限界=49.87)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host02-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260829-host02-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260829-host02-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260829-host02-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260829-host02-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260829-host02-012 (同一ホスト) jvm_gc / ou : FATAL / 重なり 35 分
  - EVT-20260829-host02-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 35 分
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 35 分

![EVT-20260829-host02-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host02-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host02, port=7003, datasource=OraclePool_2
* 値     : 9→10→10→10→9
* 開始   : 2026-08-29 22:35:00 (UTC)
* 終了   : 2026-08-29 22:55:00 (UTC)
* 現象   : 2026-08-29 22:55:00 (UTC)を境に水準が 11.87から7.923へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.524, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260829-host02-016 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
