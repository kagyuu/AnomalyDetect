# host13 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host13 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 292 (SEVERE: 19, FATAL: 117, WARN: 156, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 19 | 117 | 156 | 292 | ALG-A1, ALG-A2, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260803-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→17→16→17→…→12→14→11→14
* 開始   : 2026-08-03 02:00:00 (UTC)
* 終了   : 2026-08-03 20:45:00 (UTC)
* 現象   : 2026-08-03 20:45:00 (UTC)を境に水準が 11.83から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.685, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.914, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host13-001 active_connections の推移](charts/EVT-20260803-host13-001.svg)

# イベントID( EVT-20260803-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→17→15→13→…→13→15→13→16
* 開始   : 2026-08-03 02:25:00 (UTC)
* 終了   : 2026-08-03 21:05:00 (UTC)
* 現象   : 2026-08-03 21:05:00 (UTC)を境に水準が 11.97から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.664, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host13-002 active_connections の推移](charts/EVT-20260803-host13-002.svg)

# イベントID( EVT-20260803-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 17→16→17→15→…→14→13→10→14
* 開始   : 2026-08-03 03:15:00 (UTC)
* 終了   : 2026-08-03 19:50:00 (UTC)
* 現象   : 2026-08-03 19:50:00 (UTC)を境に水準が 11.9から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.197, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host13-003 active_connections の推移](charts/EVT-20260803-host13-003.svg)

# イベントID( EVT-20260803-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→15→…→12→11→14→12
* 開始   : 2026-08-03 03:55:00 (UTC)
* 終了   : 2026-08-03 20:50:00 (UTC)
* 現象   : 2026-08-03 20:50:00 (UTC)を境に水準が 11.99から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.739, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host13-006 active_connections の推移](charts/EVT-20260803-host13-006.svg)

# イベントID( EVT-20260810-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 14→15→14→13→…→15→14→12→14
* 開始   : 2026-08-10 02:05:00 (UTC)
* 終了   : 2026-08-10 20:05:00 (UTC)
* 現象   : 2026-08-10 20:05:00 (UTC)を境に水準が 11.94から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.073, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host13-001 active_connections の推移](charts/EVT-20260810-host13-001.svg)

# イベントID( EVT-20260810-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→16→15→16→…→15→14→15→14
* 開始   : 2026-08-10 02:20:00 (UTC)
* 終了   : 2026-08-10 20:05:00 (UTC)
* 現象   : 2026-08-10 20:05:00 (UTC)を境に水準が 11.81から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.756, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.812, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host13-002 active_connections の推移](charts/EVT-20260810-host13-002.svg)

# イベントID( EVT-20260810-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 17→16→17→19→…→13→12→10→13
* 開始   : 2026-08-10 03:00:00 (UTC)
* 終了   : 2026-08-10 20:25:00 (UTC)
* 現象   : 2026-08-10 20:25:00 (UTC)を境に水準が 12.01から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.824, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.444, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host13-003 active_connections の推移](charts/EVT-20260810-host13-003.svg)

# イベントID( EVT-20260810-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→13→15→16→…→13→15→14→12
* 開始   : 2026-08-10 03:05:00 (UTC)
* 終了   : 2026-08-10 21:00:00 (UTC)
* 現象   : 2026-08-10 21:00:00 (UTC)を境に水準が 11.94から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.903, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host13-004 active_connections の推移](charts/EVT-20260810-host13-004.svg)

# イベントID( EVT-20260810-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 14→16→15→16→…→17→13→12→13
* 開始   : 2026-08-10 04:10:00 (UTC)
* 終了   : 2026-08-10 20:50:00 (UTC)
* 現象   : 2026-08-10 20:50:00 (UTC)を境に水準が 11.93から15.22へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.766, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.75, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host13-006 active_connections の推移](charts/EVT-20260810-host13-006.svg)

# イベントID( EVT-20260817-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→13→16→15→…→15→16→11→14
* 開始   : 2026-08-17 01:15:00 (UTC)
* 終了   : 2026-08-17 20:25:00 (UTC)
* 現象   : 2026-08-17 20:25:00 (UTC)を境に水準が 11.83から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.711, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.805, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host13-001 active_connections の推移](charts/EVT-20260817-host13-001.svg)

# イベントID( EVT-20260817-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 16→17→18→16→…→15→17→14→16
* 開始   : 2026-08-17 01:50:00 (UTC)
* 終了   : 2026-08-17 21:10:00 (UTC)
* 現象   : 2026-08-17 21:10:00 (UTC)を境に水準が 11.88から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.317, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.324, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host13-002 active_connections の推移](charts/EVT-20260817-host13-002.svg)

# イベントID( EVT-20260817-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→13→…→14→13→14→13
* 開始   : 2026-08-17 02:55:00 (UTC)
* 終了   : 2026-08-17 20:45:00 (UTC)
* 現象   : 2026-08-17 20:45:00 (UTC)を境に水準が 11.85から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.183σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.696, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.187, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host13-003 active_connections の推移](charts/EVT-20260817-host13-003.svg)

# イベントID( EVT-20260817-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→13→16→13→…→13→14→13→12
* 開始   : 2026-08-17 02:55:00 (UTC)
* 終了   : 2026-08-17 19:50:00 (UTC)
* 現象   : 2026-08-17 19:50:00 (UTC)を境に水準が 11.75から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.897, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.754, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host13-004 active_connections の推移](charts/EVT-20260817-host13-004.svg)

# イベントID( EVT-20260817-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 16→15→16→15→…→14→15→13→12
* 開始   : 2026-08-17 04:15:00 (UTC)
* 終了   : 2026-08-17 20:35:00 (UTC)
* 現象   : 2026-08-17 20:35:00 (UTC)を境に水準が 11.99から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.747, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host13-005 active_connections の推移](charts/EVT-20260817-host13-005.svg)

# イベントID( EVT-20260818-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 18→20→17→18→…→15→18→15→18
* 開始   : 2026-08-18 15:30:00 (UTC)
* 終了   : 2026-08-18 16:45:00 (UTC)
* 現象   : 2026-08-18 16:45:00 (UTC)を境に水準が 15.03から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host13-007 active_connections の推移](charts/EVT-20260818-host13-007.svg)

# イベントID( EVT-20260824-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→15→19→14→…→13→12→11→13
* 開始   : 2026-08-24 02:30:00 (UTC)
* 終了   : 2026-08-24 21:50:00 (UTC)
* 現象   : 2026-08-24 21:50:00 (UTC)を境に水準が 11.83から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.056, 限界=2.707)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.343, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host13-003 active_connections の推移](charts/EVT-20260824-host13-003.svg)

# イベントID( EVT-20260824-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→14→16→13→…→16→14→16→14
* 開始   : 2026-08-24 02:35:00 (UTC)
* 終了   : 2026-08-24 19:15:00 (UTC)
* 現象   : 2026-08-24 19:15:00 (UTC)を境に水準が 11.87から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.073, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host13-004 active_connections の推移](charts/EVT-20260824-host13-004.svg)

# イベントID( EVT-20260824-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→13→17→15→…→15→17→15→16
* 開始   : 2026-08-24 02:40:00 (UTC)
* 終了   : 2026-08-24 21:40:00 (UTC)
* 現象   : 2026-08-24 21:40:00 (UTC)を境に水準が 11.82から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.433, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.92, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host13-005 active_connections の推移](charts/EVT-20260824-host13-005.svg)

# イベントID( EVT-20260824-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→18→20→18→…→12→13→14→11
* 開始   : 2026-08-24 03:00:00 (UTC)
* 終了   : 2026-08-24 21:15:00 (UTC)
* 現象   : 2026-08-24 21:15:00 (UTC)を境に水準が 11.96から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.546σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.114, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host13-007 active_connections の推移](charts/EVT-20260824-host13-007.svg)

# イベントID( EVT-20260801-host13-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 9→10→11→10→…→13→11→12→14
* 開始   : 2026-08-01 05:25:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.991, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260801-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260801-host13-001 active_connections の推移](charts/EVT-20260801-host13-001.svg)

# イベントID( EVT-20260801-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→12→8→10→…→14→13→16→14
* 開始   : 2026-08-01 05:40:00 (UTC)
* 終了   : 2026-08-01 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.215, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260801-host13-002 active_connections の推移](charts/EVT-20260801-host13-002.svg)

# イベントID( EVT-20260801-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→14→13→11→…→11→12→13→12
* 開始   : 2026-08-01 05:40:00 (UTC)
* 終了   : 2026-08-01 20:00:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.873, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260801-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260801-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260801-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 14.2 時間

![EVT-20260801-host13-003 active_connections の推移](charts/EVT-20260801-host13-003.svg)

# イベントID( EVT-20260801-host13-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→12→10→14→…→10→11→13→10
* 開始   : 2026-08-01 05:45:00 (UTC)
* 終了   : 2026-08-01 19:25:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.954, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260801-host13-004 active_connections の推移](charts/EVT-20260801-host13-004.svg)

# イベントID( EVT-20260801-host13-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→12→11→13→…→12→13→14→13
* 開始   : 2026-08-01 06:15:00 (UTC)
* 終了   : 2026-08-01 20:00:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.117, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260801-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.4 時間
  - EVT-20260801-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260801-host13-005 active_connections の推移](charts/EVT-20260801-host13-005.svg)

# イベントID( EVT-20260801-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→15→13→12→…→12→14→12→11
* 開始   : 2026-08-01 06:30:00 (UTC)
* 終了   : 2026-08-01 18:15:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.091, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.8 時間
  - EVT-20260801-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間

![EVT-20260801-host13-006 active_connections の推移](charts/EVT-20260801-host13-006.svg)

# イベントID( EVT-20260802-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→11→15→11→12
* 開始   : 2026-08-02 05:35:00 (UTC)
* 終了   : 2026-08-02 05:35:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260802-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→12→9→13→15
* 開始   : 2026-08-02 17:05:00 (UTC)
* 終了   : 2026-08-02 17:05:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 8→9→4→8→9
* 開始   : 2026-08-02 23:45:00 (UTC)
* 終了   : 2026-08-02 23:45:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.286σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host13-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→13→15→16→…→16→14→15→13
* 開始   : 2026-08-03 03:45:00 (UTC)
* 終了   : 2026-08-03 21:05:00 (UTC)
* 現象   : 2026-08-03 21:05:00 (UTC)を境に水準が 11.89から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.312, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.295, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host13-004 active_connections の推移](charts/EVT-20260803-host13-004.svg)

# イベントID( EVT-20260803-host13-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→17→15→14→…→12→14→13→12
* 開始   : 2026-08-03 03:50:00 (UTC)
* 終了   : 2026-08-03 20:05:00 (UTC)
* 現象   : 2026-08-03 20:05:00 (UTC)を境に水準が 11.87から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.7, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.363, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host13-005 active_connections の推移](charts/EVT-20260803-host13-005.svg)

# イベントID( EVT-20260803-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 9→12→8→6→…→8→6→10→9
* 開始   : 2026-08-03 21:15:00 (UTC)
* 終了   : 2026-08-03 21:20:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.054σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260803-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260803-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 18→19→22→18→20
* 開始   : 2026-08-04 08:05:00 (UTC)
* 終了   : 2026-08-04 08:05:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.145σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260804-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→12→8→11→12
* 開始   : 2026-08-04 20:00:00 (UTC)
* 終了   : 2026-08-04 20:00:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.6275(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260804-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 9→10→6→10→8
* 開始   : 2026-08-04 21:05:00 (UTC)
* 終了   : 2026-08-04 21:05:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 10→11→6→11→…→11→13→11→9
* 開始   : 2026-08-04 21:10:00 (UTC)
* 終了   : 2026-08-04 21:20:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.5538(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.404σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260804-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host13-008 active_connections の推移](charts/EVT-20260804-host13-008.svg)

# イベントID( EVT-20260805-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→12→10→11→11→13→12→14→15
* 開始   : 2026-08-05 03:20:00 (UTC)
* 終了   : 2026-08-05 05:00:00 (UTC)
* 現象   : 2026-08-05 05:00:00 (UTC)を境に水準が 14.9から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.033, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→18→22→18→17
* 開始   : 2026-08-05 08:10:00 (UTC)
* 終了   : 2026-08-05 08:10:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.263倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.203σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host13-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 22→24→17→21→19
* 開始   : 2026-08-05 14:15:00 (UTC)
* 終了   : 2026-08-05 14:15:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.7584(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.761σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260805-host13-007 active_connections の推移](charts/EVT-20260805-host13-007.svg)

# イベントID( EVT-20260805-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 17→20→14→16→17
* 開始   : 2026-08-05 16:30:00 (UTC)
* 終了   : 2026-08-05 16:30:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→13→9→12→12
* 開始   : 2026-08-05 19:10:00 (UTC)
* 終了   : 2026-08-05 19:10:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 10→10→6→8→8
* 開始   : 2026-08-05 21:05:00 (UTC)
* 終了   : 2026-08-05 21:05:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.5581(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.345σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260805-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 7→9→13→11→10
* 開始   : 2026-08-06 02:40:00 (UTC)
* 終了   : 2026-08-06 02:40:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 18→16→15→17→…→17→13→16→17
* 開始   : 2026-08-06 17:10:00 (UTC)
* 終了   : 2026-08-06 17:20:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host13-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→11→7→9→10
* 開始   : 2026-08-06 20:10:00 (UTC)
* 終了   : 2026-08-06 20:10:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.5753(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.606σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host13-010 active_connections の推移](charts/EVT-20260806-host13-010.svg)

# イベントID( EVT-20260807-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→17→19→15→17→19→15→16
* 開始   : 2026-08-07 06:25:00 (UTC)
* 終了   : 2026-08-07 06:30:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260807-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→8→5→8→10
* 開始   : 2026-08-07 22:25:00 (UTC)
* 終了   : 2026-08-07 22:25:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260807-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 8→9→12→6→6
* 開始   : 2026-08-08 00:50:00 (UTC)
* 終了   : 2026-08-08 00:50:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260808-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→13→12→13→…→9→12→13→12
* 開始   : 2026-08-08 05:00:00 (UTC)
* 終了   : 2026-08-08 18:30:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.896, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260808-host13-004 active_connections の推移](charts/EVT-20260808-host13-004.svg)

# イベントID( EVT-20260808-host13-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→12→13→12→…→13→12→13→11
* 開始   : 2026-08-08 05:15:00 (UTC)
* 終了   : 2026-08-08 18:15:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.163, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260808-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260808-host13-005 active_connections の推移](charts/EVT-20260808-host13-005.svg)

# イベントID( EVT-20260808-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→11→13→12→…→10→11→12→11
* 開始   : 2026-08-08 06:00:00 (UTC)
* 終了   : 2026-08-08 19:10:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.793, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260808-host13-006 active_connections の推移](charts/EVT-20260808-host13-006.svg)

# イベントID( EVT-20260808-host13-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→12→13→14→…→11→10→11→12
* 開始   : 2026-08-08 06:25:00 (UTC)
* 終了   : 2026-08-08 18:35:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.741, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260808-host13-007 active_connections の推移](charts/EVT-20260808-host13-007.svg)

# イベントID( EVT-20260808-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→12→10→12→…→12→13→14→12
* 開始   : 2026-08-08 06:25:00 (UTC)
* 終了   : 2026-08-08 19:05:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.152, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host13-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260808-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260808-host13-008 active_connections の推移](charts/EVT-20260808-host13-008.svg)

# イベントID( EVT-20260808-host13-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→15→13→12→…→12→10→12→10
* 開始   : 2026-08-08 06:50:00 (UTC)
* 終了   : 2026-08-08 18:50:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.828, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260808-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260808-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.0 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260808-host13-009 active_connections の推移](charts/EVT-20260808-host13-009.svg)

# イベントID( EVT-20260809-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→15→11→14→15
* 開始   : 2026-08-09 14:00:00 (UTC)
* 終了   : 2026-08-09 14:00:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.169σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-036 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260809-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→13→10→11→12
* 開始   : 2026-08-09 17:00:00 (UTC)
* 終了   : 2026-08-09 17:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260809-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host13-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→14→15→14→…→16→15→16→15
* 開始   : 2026-08-10 03:20:00 (UTC)
* 終了   : 2026-08-10 19:45:00 (UTC)
* 現象   : 2026-08-10 19:45:00 (UTC)を境に水準が 11.87から15.05へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.716, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.999, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host13-005 active_connections の推移](charts/EVT-20260810-host13-005.svg)

# イベントID( EVT-20260811-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→13→16→12→13
* 開始   : 2026-08-11 04:35:00 (UTC)
* 終了   : 2026-08-11 04:35:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 15→14→19→15→14
* 開始   : 2026-08-11 05:45:00 (UTC)
* 終了   : 2026-08-11 05:45:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.399倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.78σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host13-003 active_connections の推移](charts/EVT-20260811-host13-003.svg)

# イベントID( EVT-20260811-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→18→22→17→19
* 開始   : 2026-08-11 07:45:00 (UTC)
* 終了   : 2026-08-11 07:45:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.269倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.241σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 21→22→25→20→21
* 開始   : 2026-08-11 09:40:00 (UTC)
* 終了   : 2026-08-11 09:40:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.169σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 24→23→22→23→23→21→23→21→24
* 開始   : 2026-08-11 11:15:00 (UTC)
* 終了   : 2026-08-11 12:45:00 (UTC)
* 現象   : 2026-08-11 12:45:00 (UTC)を境に水準が 15.1から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 19→19→16→20→20
* 開始   : 2026-08-11 15:15:00 (UTC)
* 終了   : 2026-08-11 15:15:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 18→17→15→14→…→15→14→15→16
* 開始   : 2026-08-11 17:20:00 (UTC)
* 終了   : 2026-08-11 17:45:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260811-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260811-lsfhost01-048 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260811-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 9→9→13→7→8
* 開始   : 2026-08-12 01:30:00 (UTC)
* 終了   : 2026-08-12 01:30:00 (UTC)
* 現象   : 平常時(8.167)に対し 1.592倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260812-host13-001 active_connections の推移](charts/EVT-20260812-host13-001.svg)

# イベントID( EVT-20260812-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→9→14→12→8
* 開始   : 2026-08-12 02:55:00 (UTC)
* 終了   : 2026-08-12 02:55:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.5倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260812-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→13→16→11→13
* 開始   : 2026-08-12 04:35:00 (UTC)
* 終了   : 2026-08-12 04:35:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-013 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260812-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→15→20→16→14
* 開始   : 2026-08-12 06:00:00 (UTC)
* 終了   : 2026-08-12 06:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.395倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.961σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host13-008 active_connections の推移](charts/EVT-20260812-host13-008.svg)

# イベントID( EVT-20260812-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→17→20→16→15
* 開始   : 2026-08-12 06:55:00 (UTC)
* 終了   : 2026-08-12 06:55:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.341倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.547σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host13-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260812-host13-011 active_connections の推移](charts/EVT-20260812-host13-011.svg)

# イベントID( EVT-20260812-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 18→18→23→20→19
* 開始   : 2026-08-12 08:50:00 (UTC)
* 終了   : 2026-08-12 08:50:00 (UTC)
* 現象   : 平常時(18.17)に対し 1.266倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260812-host13-013 active_connections の推移](charts/EVT-20260812-host13-013.svg)

# イベントID( EVT-20260812-host13-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 17→15→13→16→17
* 開始   : 2026-08-12 17:30:00 (UTC)
* 終了   : 2026-08-12 17:30:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host13-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→14→9→13→11
* 開始   : 2026-08-12 19:15:00 (UTC)
* 終了   : 2026-08-12 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6279(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.756σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host13-019 active_connections の推移](charts/EVT-20260812-host13-019.svg)

# イベントID( EVT-20260812-host13-020 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→14→8→11→10
* 開始   : 2026-08-12 20:05:00 (UTC)
* 終了   : 2026-08-12 20:05:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.6316(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260812-host13-020 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→13→16→12→…→12→13→14→16
* 開始   : 2026-08-13 17:50:00 (UTC)
* 終了   : 2026-08-13 18:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.796σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host13-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260813-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260813-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→12→9→13→13
* 開始   : 2026-08-13 19:25:00 (UTC)
* 終了   : 2026-08-13 19:25:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.24σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→13→8→13→11
* 開始   : 2026-08-13 19:45:00 (UTC)
* 終了   : 2026-08-13 20:10:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.6115(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.548σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-053 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260813-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260813-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260813-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260813-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host13-010 active_connections の推移](charts/EVT-20260813-host13-010.svg)

# イベントID( EVT-20260814-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 22→20→16→18→19
* 開始   : 2026-08-14 15:10:00 (UTC)
* 終了   : 2026-08-14 15:10:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 9→11→14→9→9
* 開始   : 2026-08-15 03:55:00 (UTC)
* 終了   : 2026-08-15 03:55:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.169σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260815-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 10→11→13→11→…→11→13→10→11
* 開始   : 2026-08-15 04:30:00 (UTC)
* 終了   : 2026-08-15 18:55:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.746, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260815-host13-002 active_connections の推移](charts/EVT-20260815-host13-002.svg)

# イベントID( EVT-20260815-host13-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→12→13→12→…→10→12→14→12
* 開始   : 2026-08-15 05:10:00 (UTC)
* 終了   : 2026-08-15 19:25:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.627, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260815-host13-003 active_connections の推移](charts/EVT-20260815-host13-003.svg)

# イベントID( EVT-20260815-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→11→13→12→…→12→13→11→12
* 開始   : 2026-08-15 05:25:00 (UTC)
* 終了   : 2026-08-15 18:10:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.956, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260815-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260815-host13-004 active_connections の推移](charts/EVT-20260815-host13-004.svg)

# イベントID( EVT-20260815-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 12→10→12→10→…→10→13→12→10
* 開始   : 2026-08-15 05:30:00 (UTC)
* 終了   : 2026-08-15 18:40:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.984, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260815-host13-005 active_connections の推移](charts/EVT-20260815-host13-005.svg)

# イベントID( EVT-20260815-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→8→11→12→…→12→11→10→12
* 開始   : 2026-08-15 05:35:00 (UTC)
* 終了   : 2026-08-15 18:55:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.944, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260815-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260815-host13-006 active_connections の推移](charts/EVT-20260815-host13-006.svg)

# イベントID( EVT-20260815-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→9→16→10→…→11→12→13→11
* 開始   : 2026-08-15 06:30:00 (UTC)
* 終了   : 2026-08-15 19:00:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.289σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.235, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260815-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260815-host13-007 active_connections の推移](charts/EVT-20260815-host13-007.svg)

# イベントID( EVT-20260816-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→14→15
* 開始   : 2026-08-16 15:15:00 (UTC)
* 終了   : 2026-08-16 15:15:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→14→16→17→…→14→13→14→12
* 開始   : 2026-08-17 04:20:00 (UTC)
* 終了   : 2026-08-17 19:10:00 (UTC)
* 現象   : 2026-08-17 19:10:00 (UTC)を境に水準が 12.08から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.006, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.82, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host13-006 active_connections の推移](charts/EVT-20260817-host13-006.svg)

# イベントID( EVT-20260818-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 6→8→12→7→7
* 開始   : 2026-08-18 01:30:00 (UTC)
* 終了   : 2026-08-18 01:30:00 (UTC)
* 現象   : 平常時(7.333)に対し 1.636倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.241σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260818-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 17→15→13→16
* 開始   : 2026-08-18 05:10:00 (UTC)
* 終了   : 2026-08-18 05:25:00 (UTC)
* 現象   : 2026-08-18 05:25:00 (UTC)を境に水準が 15から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 16→20→22→21→20→22→21→20→21
* 開始   : 2026-08-18 08:25:00 (UTC)
* 終了   : 2026-08-18 08:30:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 21→21→25→20→20
* 開始   : 2026-08-18 09:55:00 (UTC)
* 終了   : 2026-08-18 09:55:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.23倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.286σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260818-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 19→18→14→17→17
* 開始   : 2026-08-18 16:40:00 (UTC)
* 終了   : 2026-08-18 16:40:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260818-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→11→14→12→11
* 開始   : 2026-08-19 03:25:00 (UTC)
* 終了   : 2026-08-19 03:25:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.169σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-007 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260819-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 21→21→17→22→20
* 開始   : 2026-08-19 13:20:00 (UTC)
* 終了   : 2026-08-19 13:20:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.067σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→15→12→16→14
* 開始   : 2026-08-19 17:45:00 (UTC)
* 終了   : 2026-08-19 17:45:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.169σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→15→10→15→13
* 開始   : 2026-08-19 18:45:00 (UTC)
* 終了   : 2026-08-19 18:45:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 16→15→21→16→16
* 開始   : 2026-08-20 07:00:00 (UTC)
* 終了   : 2026-08-20 07:00:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.306倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.432σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260820-host13-004 active_connections の推移](charts/EVT-20260820-host13-004.svg)

# イベントID( EVT-20260820-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→14→11→13→11→13→11→12→13
* 開始   : 2026-08-20 19:05:00 (UTC)
* 終了   : 2026-08-20 20:15:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260820-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260820-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260820-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260820-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-062 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260820-host13-010 active_connections の推移](charts/EVT-20260820-host13-010.svg)

# イベントID( EVT-20260820-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 8→9→5→10→7
* 開始   : 2026-08-20 22:20:00 (UTC)
* 終了   : 2026-08-20 22:20:00 (UTC)
* 現象   : 平常時(10)に対し 0.5(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260820-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→15→17→14→15
* 開始   : 2026-08-21 05:20:00 (UTC)
* 終了   : 2026-08-21 05:20:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host13-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 17→16→20→17→17
* 開始   : 2026-08-21 07:10:00 (UTC)
* 終了   : 2026-08-21 07:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→18→20→19→…→20→19→16→17
* 開始   : 2026-08-21 07:15:00 (UTC)
* 終了   : 2026-08-21 07:20:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.125σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→13→10→12→12
* 開始   : 2026-08-21 19:10:00 (UTC)
* 終了   : 2026-08-21 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→12→11→12→…→12→10→11→10
* 開始   : 2026-08-22 05:00:00 (UTC)
* 終了   : 2026-08-22 19:20:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.617σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.919, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260822-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260822-host13-001 active_connections の推移](charts/EVT-20260822-host13-001.svg)

# イベントID( EVT-20260822-host13-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→12→…→14→12→13→11
* 開始   : 2026-08-22 05:05:00 (UTC)
* 終了   : 2026-08-22 19:35:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.872, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260822-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260822-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260822-host13-002 active_connections の推移](charts/EVT-20260822-host13-002.svg)

# イベントID( EVT-20260822-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→12→9→13→…→11→9→13→11
* 開始   : 2026-08-22 05:10:00 (UTC)
* 終了   : 2026-08-22 19:00:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.953, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260822-host13-003 active_connections の推移](charts/EVT-20260822-host13-003.svg)

# イベントID( EVT-20260822-host13-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→14→11→13→…→13→11→14→13
* 開始   : 2026-08-22 05:20:00 (UTC)
* 終了   : 2026-08-22 19:00:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.983, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260822-host13-004 active_connections の推移](charts/EVT-20260822-host13-004.svg)

# イベントID( EVT-20260822-host13-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→10→12→11→…→10→11→10→11
* 開始   : 2026-08-22 05:25:00 (UTC)
* 終了   : 2026-08-22 19:20:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.698, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260822-host13-005 active_connections の推移](charts/EVT-20260822-host13-005.svg)

# イベントID( EVT-20260822-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→10→9→10→…→14→12→14→12
* 開始   : 2026-08-22 06:05:00 (UTC)
* 終了   : 2026-08-22 19:10:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.177, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host13-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260822-host13-006 active_connections の推移](charts/EVT-20260822-host13-006.svg)

# イベントID( EVT-20260823-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 10→10→14→10→10
* 開始   : 2026-08-23 03:50:00 (UTC)
* 終了   : 2026-08-23 03:50:00 (UTC)
* 現象   : 平常時(9)に対し 1.556倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260823-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 15→13→9→13→11
* 開始   : 2026-08-23 17:20:00 (UTC)
* 終了   : 2026-08-23 18:20:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260823-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260823-lsfhost01-039 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260823-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host13-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→15→16→15→…→11→13→11→14
* 開始   : 2026-08-24 02:20:00 (UTC)
* 終了   : 2026-08-24 20:05:00 (UTC)
* 現象   : 2026-08-24 20:05:00 (UTC)を境に水準が 11.72から14.98へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.671, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.816, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host13-002 active_connections の推移](charts/EVT-20260824-host13-002.svg)

# イベントID( EVT-20260824-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→15→18→16→…→11→12→11→12
* 開始   : 2026-08-24 02:45:00 (UTC)
* 終了   : 2026-08-24 21:40:00 (UTC)
* 現象   : 2026-08-24 21:40:00 (UTC)を境に水準が 11.76から14.93へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.879, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.444, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 8→10→13→10→9
* 開始   : 2026-08-25 02:35:00 (UTC)
* 終了   : 2026-08-25 02:35:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260825-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→12→9→11→10→12→13→16→14
* 開始   : 2026-08-25 03:20:00 (UTC)
* 終了   : 2026-08-25 04:50:00 (UTC)
* 現象   : 2026-08-25 04:50:00 (UTC)を境に水準が 14.93から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 15→18→20→15→…→18→20→15→16
* 開始   : 2026-08-25 06:35:00 (UTC)
* 終了   : 2026-08-25 06:45:00 (UTC)
* 現象   : 2026-08-25 06:45:00 (UTC)を境に水準が 15.04から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 20→18→22→18→20
* 開始   : 2026-08-25 07:50:00 (UTC)
* 終了   : 2026-08-25 07:50:00 (UTC)
* 現象   : 平常時(17.25)に対し 1.275倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260825-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 21→23→18→22→23
* 開始   : 2026-08-25 13:15:00 (UTC)
* 終了   : 2026-08-25 13:15:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.169σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260825-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 10→9→4→8→8
* 開始   : 2026-08-26 00:50:00 (UTC)
* 終了   : 2026-08-26 00:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260826-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 20→20→24→22→22
* 開始   : 2026-08-26 09:05:00 (UTC)
* 終了   : 2026-08-26 09:05:00 (UTC)
* 現象   : 平常時(19.25)に対し 1.247倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 21→20→15→19→20
* 開始   : 2026-08-26 15:00:00 (UTC)
* 終了   : 2026-08-26 15:00:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7317(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.838σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260826-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host13-004 active_connections の推移](charts/EVT-20260826-host13-004.svg)

# イベントID( EVT-20260826-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→16→12→13→…→12→13→19→14
* 開始   : 2026-08-26 17:55:00 (UTC)
* 終了   : 2026-08-26 18:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.24σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260826-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260826-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→13→10→13→13
* 開始   : 2026-08-26 18:40:00 (UTC)
* 終了   : 2026-08-26 18:40:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.678(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host13-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→11→7→10→10
* 開始   : 2026-08-26 20:45:00 (UTC)
* 終了   : 2026-08-26 20:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host13-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→15→19→15→19→15→19→15→16
* 開始   : 2026-08-27 06:30:00 (UTC)
* 終了   : 2026-08-27 06:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host13-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260827-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260827-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 17→19→21→17→…→17→23→20→18
* 開始   : 2026-08-27 08:10:00 (UTC)
* 終了   : 2026-08-27 08:20:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260827-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host13-004 active_connections の推移](charts/EVT-20260827-host13-004.svg)

# イベントID( EVT-20260827-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→18→13→18→15
* 開始   : 2026-08-27 16:35:00 (UTC)
* 終了   : 2026-08-27 16:35:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host13-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260827-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→8→14→9→10
* 開始   : 2026-08-28 03:05:00 (UTC)
* 終了   : 2026-08-28 03:05:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.009σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-012 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260828-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 22→21→16→21→21
* 開始   : 2026-08-28 14:15:00 (UTC)
* 終了   : 2026-08-28 14:15:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.7589(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.58σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260828-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 16→16→12→15→16
* 開始   : 2026-08-28 17:45:00 (UTC)
* 終了   : 2026-08-28 17:45:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.052σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→13→10→12→…→12→8→12→10
* 開始   : 2026-08-28 19:45:00 (UTC)
* 終了   : 2026-08-28 19:55:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260828-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260828-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260828-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host13-012 active_connections の推移](charts/EVT-20260828-host13-012.svg)

# イベントID( EVT-20260828-host13-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→10→7→9→8
* 開始   : 2026-08-28 21:15:00 (UTC)
* 終了   : 2026-08-28 21:15:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.6131(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-069 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260828-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host13-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→11→…→8→11→14→11
* 開始   : 2026-08-29 04:45:00 (UTC)
* 終了   : 2026-08-29 19:00:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.746, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260829-host13-003 active_connections の推移](charts/EVT-20260829-host13-003.svg)

# イベントID( EVT-20260829-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→9→11→12→…→11→10→13→11
* 開始   : 2026-08-29 05:00:00 (UTC)
* 終了   : 2026-08-29 18:40:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.115, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260829-host13-004 active_connections の推移](charts/EVT-20260829-host13-004.svg)

# イベントID( EVT-20260829-host13-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→10→11→10→…→10→11→10→11
* 開始   : 2026-08-29 05:25:00 (UTC)
* 終了   : 2026-08-29 19:05:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.905, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260829-host13-005 active_connections の推移](charts/EVT-20260829-host13-005.svg)

# イベントID( EVT-20260829-host13-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→11→14→12→…→11→10→13→11
* 開始   : 2026-08-29 05:30:00 (UTC)
* 終了   : 2026-08-29 18:50:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.921, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260829-host13-006 active_connections の推移](charts/EVT-20260829-host13-006.svg)

# イベントID( EVT-20260829-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→12→11→12→…→11→13→12→11
* 開始   : 2026-08-29 05:50:00 (UTC)
* 終了   : 2026-08-29 18:45:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.378σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.779, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260829-host13-007 active_connections の推移](charts/EVT-20260829-host13-007.svg)

# イベントID( EVT-20260829-host13-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 12→11→13→12→…→11→13→11→15
* 開始   : 2026-08-29 06:10:00 (UTC)
* 終了   : 2026-08-29 19:05:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.988, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host13-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host13-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260829-host13-008 active_connections の推移](charts/EVT-20260829-host13-008.svg)

# イベントID( EVT-20260802-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 10→13→11→10→13→11
* 開始   : 2026-08-02 04:55:00 (UTC)
* 終了   : 2026-08-02 05:00:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260802-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host13-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→12→14
* 開始   : 2026-08-02 05:40:00 (UTC)
* 終了   : 2026-08-02 05:50:00 (UTC)
* 現象   : 2026-08-02 05:50:00 (UTC)を境に水準が 11.89から12.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.562, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→15→16→16→15→13→16→15
* 開始   : 2026-08-02 08:05:00 (UTC)
* 終了   : 2026-08-02 08:40:00 (UTC)
* 現象   : 2026-08-02 08:40:00 (UTC)を境に水準が 11.89から12.56へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.726, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host13-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→17→17→17
* 開始   : 2026-08-02 14:15:00 (UTC)
* 終了   : 2026-08-02 14:30:00 (UTC)
* 現象   : 2026-08-02 14:30:00 (UTC)を境に水準が 11.84から14.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.75, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host13-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 16→15→16→15→17
* 開始   : 2026-08-02 15:15:00 (UTC)
* 終了   : 2026-08-02 15:35:00 (UTC)
* 現象   : 2026-08-02 15:35:00 (UTC)を境に水準が 11.94から14.19へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.324, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→11→9→9→12
* 開始   : 2026-08-02 22:20:00 (UTC)
* 終了   : 2026-08-02 22:50:00 (UTC)
* 現象   : 2026-08-02 22:50:00 (UTC)を境に水準が 11.93から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→12→14→11→12→14→11→9
* 開始   : 2026-08-04 03:55:00 (UTC)
* 終了   : 2026-08-04 04:00:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-011 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分

![EVT-20260804-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→15→12→14→15→13→13→15
* 開始   : 2026-08-04 04:15:00 (UTC)
* 終了   : 2026-08-04 04:55:00 (UTC)
* 現象   : 2026-08-04 04:55:00 (UTC)を境に水準が 14.9から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host13-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 14→15→14→15→15→15→18→17→15
* 開始   : 2026-08-04 05:30:00 (UTC)
* 終了   : 2026-08-04 06:45:00 (UTC)
* 現象   : 2026-08-04 06:45:00 (UTC)を境に水準が 14.88から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.238, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→17→16→14→17→19→18
* 開始   : 2026-08-04 05:50:00 (UTC)
* 終了   : 2026-08-04 06:20:00 (UTC)
* 現象   : 2026-08-04 06:20:00 (UTC)を境に水準が 15.05から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.51, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 7→12→6→8→7→12→6→8
* 開始   : 2026-08-04 22:10:00 (UTC)
* 終了   : 2026-08-04 22:15:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 7→9→4→11→…→4→11→10→7
* 開始   : 2026-08-04 23:10:00 (UTC)
* 終了   : 2026-08-04 23:15:00 (UTC)
* 現象   : 平常時(7.833)に対し 0.5106(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.675σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→8→6→12→8→6→12→11
* 開始   : 2026-08-05 03:30:00 (UTC)
* 終了   : 2026-08-05 03:35:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260805-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→14→13→8→14→13→8→13→12
* 開始   : 2026-08-05 03:50:00 (UTC)
* 終了   : 2026-08-05 04:00:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260805-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 16→17→20→17→20→17
* 開始   : 2026-08-05 07:20:00 (UTC)
* 終了   : 2026-08-05 07:25:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.523σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 18→19→21→18→…→20→21→19→20
* 開始   : 2026-08-05 08:05:00 (UTC)
* 終了   : 2026-08-05 08:25:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.796σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→21→15→16→15→16→15→16→19
* 開始   : 2026-08-05 16:50:00 (UTC)
* 終了   : 2026-08-05 17:00:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260805-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→9→12→9→11→11→12→12
* 開始   : 2026-08-06 02:30:00 (UTC)
* 終了   : 2026-08-06 03:05:00 (UTC)
* 現象   : 2026-08-06 03:05:00 (UTC)を境に水準が 14.97から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→9→14→11→…→11→15→12→14
* 開始   : 2026-08-06 04:30:00 (UTC)
* 終了   : 2026-08-06 04:40:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host13-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260806-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260806-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→13→15→14→13→15→14→13
* 開始   : 2026-08-06 04:40:00 (UTC)
* 終了   : 2026-08-06 04:45:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.395倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.966σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host13-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260806-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→17→15→16→17→15→16
* 開始   : 2026-08-06 05:45:00 (UTC)
* 終了   : 2026-08-06 05:50:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host13-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 23→23→21→21→23→21→21→23→25
* 開始   : 2026-08-06 11:25:00 (UTC)
* 終了   : 2026-08-06 12:05:00 (UTC)
* 現象   : 2026-08-06 12:05:00 (UTC)を境に水準が 14.9から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.942, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→19→14→15→14→15→14→16
* 開始   : 2026-08-06 17:15:00 (UTC)
* 終了   : 2026-08-06 17:25:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7814(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.72σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260806-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→11→10→13→…→13→11→10→13
* 開始   : 2026-08-06 19:10:00 (UTC)
* 終了   : 2026-08-06 19:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260806-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→14→15→16→…→13→16→13→14
* 開始   : 2026-08-07 05:10:00 (UTC)
* 終了   : 2026-08-07 05:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260807-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 18→22→17→19→…→19→23→20→22
* 開始   : 2026-08-07 09:35:00 (UTC)
* 終了   : 2026-08-07 09:45:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host13-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 24→23→23→22→22→21→22→24→22
* 開始   : 2026-08-07 13:00:00 (UTC)
* 終了   : 2026-08-07 14:05:00 (UTC)
* 現象   : 2026-08-07 14:05:00 (UTC)を境に水準が 14.94から12.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→11→10→14→11→10→14→13
* 開始   : 2026-08-07 18:40:00 (UTC)
* 終了   : 2026-08-07 18:45:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.488σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→13→12→13→13
* 開始   : 2026-08-07 19:50:00 (UTC)
* 終了   : 2026-08-07 21:15:00 (UTC)
* 現象   : 2026-08-07 21:15:00 (UTC)を境に水準が 14.85から11.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.083σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.937, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→11→13→9→6→13→9→6→9
* 開始   : 2026-08-08 03:25:00 (UTC)
* 終了   : 2026-08-08 03:35:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260808-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→9→13→11→9→13→11
* 開始   : 2026-08-08 04:20:00 (UTC)
* 終了   : 2026-08-08 04:25:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260808-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→12→13→12→14→14→14→13→15
* 開始   : 2026-08-09 06:30:00 (UTC)
* 終了   : 2026-08-09 07:10:00 (UTC)
* 現象   : 2026-08-09 07:10:00 (UTC)を境に水準が 11.91から12.42へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host13-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 17→18→17→16→17
* 開始   : 2026-08-09 11:00:00 (UTC)
* 終了   : 2026-08-09 11:20:00 (UTC)
* 現象   : 2026-08-09 11:20:00 (UTC)を境に水準が 11.97から13.29へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.324, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host13-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 17→16→18→16→18→18→18
* 開始   : 2026-08-09 11:10:00 (UTC)
* 終了   : 2026-08-09 11:40:00 (UTC)
* 現象   : 2026-08-09 11:40:00 (UTC)を境に水準が 11.86から13.33へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.636, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host13-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 14→14→15→15
* 開始   : 2026-08-09 16:35:00 (UTC)
* 終了   : 2026-08-09 16:50:00 (UTC)
* 現象   : 2026-08-09 16:50:00 (UTC)を境に水準が 11.84から14.67へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→12→10→12→10→12→14
* 開始   : 2026-08-09 17:25:00 (UTC)
* 終了   : 2026-08-09 17:30:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260809-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host13-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 10→9→11→11
* 開始   : 2026-08-09 22:40:00 (UTC)
* 終了   : 2026-08-09 22:55:00 (UTC)
* 現象   : 2026-08-09 22:55:00 (UTC)を境に水準が 11.9から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.64, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→11→16→13→11→16→13→15
* 開始   : 2026-08-11 05:15:00 (UTC)
* 終了   : 2026-08-11 05:20:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260811-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 22→21→19→21→…→18→24→21→22
* 開始   : 2026-08-11 13:15:00 (UTC)
* 終了   : 2026-08-11 13:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 19→18→15→17→15→17→15→16→18
* 開始   : 2026-08-11 16:50:00 (UTC)
* 終了   : 2026-08-11 17:00:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260811-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260811-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→9→10→9→10→12→10→11
* 開始   : 2026-08-12 01:40:00 (UTC)
* 終了   : 2026-08-12 02:15:00 (UTC)
* 現象   : 2026-08-12 02:15:00 (UTC)を境に水準が 14.98から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→9→7→14→…→7→14→10→11
* 開始   : 2026-08-12 03:50:00 (UTC)
* 終了   : 2026-08-12 03:55:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→12→15→16→…→15→16→15→13
* 開始   : 2026-08-12 05:05:00 (UTC)
* 終了   : 2026-08-12 05:10:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→12→16→12→16
* 開始   : 2026-08-12 05:15:00 (UTC)
* 終了   : 2026-08-12 05:20:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260812-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 15→12→18→16→12→18→16→14
* 開始   : 2026-08-12 06:30:00 (UTC)
* 終了   : 2026-08-12 06:35:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.604σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260812-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260812-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 16→19→18→20→19→18→20→17→19
* 開始   : 2026-08-12 06:50:00 (UTC)
* 終了   : 2026-08-12 07:25:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host13-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host13-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260812-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260812-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→18→19→18→…→18→20→19→17
* 開始   : 2026-08-12 07:15:00 (UTC)
* 終了   : 2026-08-12 07:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host13-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260812-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 22→21→18→19→24→18→19→24→21
* 開始   : 2026-08-12 10:10:00 (UTC)
* 終了   : 2026-08-12 10:20:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260812-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 24→22→19→20→22→19→20
* 開始   : 2026-08-12 14:05:00 (UTC)
* 終了   : 2026-08-12 14:10:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260812-host13-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 15→14→12→14→…→14→11→13→14
* 開始   : 2026-08-12 18:55:00 (UTC)
* 終了   : 2026-08-12 19:05:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host13-018 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260812-host13-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host13-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→11→13→11→13→11
* 開始   : 2026-08-12 19:05:00 (UTC)
* 終了   : 2026-08-12 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host13-017 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260812-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host13-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→12→11→13→12→14→14→14
* 開始   : 2026-08-13 03:40:00 (UTC)
* 終了   : 2026-08-13 04:15:00 (UTC)
* 現象   : 2026-08-13 04:15:00 (UTC)を境に水準が 14.96から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host13-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 13→14→13→14→13→15→15→12→14
* 開始   : 2026-08-13 04:20:00 (UTC)
* 終了   : 2026-08-13 05:00:00 (UTC)
* 現象   : 2026-08-13 05:00:00 (UTC)を境に水準が 14.96から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 21→20→23→20→23→20
* 開始   : 2026-08-13 09:50:00 (UTC)
* 終了   : 2026-08-13 09:55:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 21→19→17→21→17→21→17→20→21
* 開始   : 2026-08-13 15:20:00 (UTC)
* 終了   : 2026-08-13 15:30:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.8361(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-035 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 17→19→22→19→…→19→16→17→19
* 開始   : 2026-08-13 15:45:00 (UTC)
* 終了   : 2026-08-13 15:55:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 16→17→13→15→…→15→12→16→13
* 開始   : 2026-08-13 18:00:00 (UTC)
* 終了   : 2026-08-13 18:10:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host13-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host13-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→16→12→15→16→12→15
* 開始   : 2026-08-13 18:10:00 (UTC)
* 終了   : 2026-08-13 18:15:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host13-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260813-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→8→5→10→5→10→5→7→8
* 開始   : 2026-08-14 00:30:00 (UTC)
* 終了   : 2026-08-14 00:40:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-003 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260814-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 11→14→12→14→12→14→9→11
* 開始   : 2026-08-14 03:45:00 (UTC)
* 終了   : 2026-08-14 03:55:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→14→17→18→17→18→15
* 開始   : 2026-08-14 06:05:00 (UTC)
* 終了   : 2026-08-14 06:15:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260814-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260814-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 13→16→18→16→18→16→18→16→15
* 開始   : 2026-08-14 06:25:00 (UTC)
* 終了   : 2026-08-14 06:35:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.278倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.758σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 18→16→21→18→16→21→18
* 開始   : 2026-08-14 08:05:00 (UTC)
* 終了   : 2026-08-14 08:10:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.241倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.875σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-036 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 17→18→21→19→18→21→19
* 開始   : 2026-08-14 08:30:00 (UTC)
* 終了   : 2026-08-14 08:35:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-039 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260814-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 22→20→24→19→20→24→19→21
* 開始   : 2026-08-14 09:35:00 (UTC)
* 終了   : 2026-08-14 09:40:00 (UTC)
* 現象   : 平常時(20)に対し 1.2倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.796σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-042 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-041 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260814-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host13-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 23→24→21→24
* 開始   : 2026-08-14 13:30:00 (UTC)
* 終了   : 2026-08-14 13:45:00 (UTC)
* 現象   : 2026-08-14 13:45:00 (UTC)を境に水準が 15.06から13.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host13-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 21→21→21→18→17→21
* 開始   : 2026-08-14 15:35:00 (UTC)
* 終了   : 2026-08-14 16:00:00 (UTC)
* 現象   : 2026-08-14 16:00:00 (UTC)を境に水準が 14.99から12.47へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.96, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 17→18→22→16→…→22→16→17→18
* 開始   : 2026-08-14 16:00:00 (UTC)
* 終了   : 2026-08-14 16:05:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260814-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 18→17→20→15→17→15→15→15→16
* 開始   : 2026-08-14 17:00:00 (UTC)
* 終了   : 2026-08-14 18:40:00 (UTC)
* 現象   : 2026-08-14 18:40:00 (UTC)を境に水準が 14.92から11.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.532, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 18→17→15→17→14→15→17→14→16
* 開始   : 2026-08-14 17:10:00 (UTC)
* 終了   : 2026-08-14 17:20:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260814-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260814-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host13-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→12→11→10→11→10→12→13
* 開始   : 2026-08-14 19:30:00 (UTC)
* 終了   : 2026-08-14 19:40:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260814-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→7→10→7→10→7→9→10
* 開始   : 2026-08-15 20:35:00 (UTC)
* 終了   : 2026-08-15 20:45:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-lsfhost01-058 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260815-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260815-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260815-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 8→6→9→6→9→6→9→10
* 開始   : 2026-08-15 21:50:00 (UTC)
* 終了   : 2026-08-15 22:00:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260815-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260815-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→10→8→8→8→10→10→7→9
* 開始   : 2026-08-15 23:25:00 (UTC)
* 終了   : 2026-08-16 01:15:00 (UTC)
* 現象   : 2026-08-16 01:15:00 (UTC)を境に水準が 11.84から11.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.88, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260815-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 11→12→15→11→12→15→11→12
* 開始   : 2026-08-16 06:35:00 (UTC)
* 終了   : 2026-08-16 06:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 16→13→17→11→15→13→17→11→15
* 開始   : 2026-08-16 09:10:00 (UTC)
* 終了   : 2026-08-16 09:15:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 15→12→18→16→15→12→18→16→14
* 開始   : 2026-08-16 09:50:00 (UTC)
* 終了   : 2026-08-16 09:55:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260816-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260816-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 7→5→11→8→7→5→11→8→7
* 開始   : 2026-08-16 23:30:00 (UTC)
* 終了   : 2026-08-16 23:35:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260816-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host13-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 10→12→8→8→9→9→8→9→10
* 開始   : 2026-08-17 22:05:00 (UTC)
* 終了   : 2026-08-17 22:50:00 (UTC)
* 現象   : 2026-08-17 22:50:00 (UTC)を境に水準が 15.04から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.16, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 18→17→20→16→…→16→21→16→17
* 開始   : 2026-08-18 07:40:00 (UTC)
* 終了   : 2026-08-18 07:50:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.206倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260818-host02-006 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260818-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 21→23→20→23→20→23→19→18
* 開始   : 2026-08-18 09:15:00 (UTC)
* 終了   : 2026-08-18 09:25:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.546σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260818-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260818-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→14→11→13→14→11→13→12
* 開始   : 2026-08-18 19:00:00 (UTC)
* 終了   : 2026-08-18 19:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分

![EVT-20260818-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 13→12→9→12→9→12→11
* 開始   : 2026-08-18 20:05:00 (UTC)
* 終了   : 2026-08-18 20:10:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260818-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→11→9→10→…→10→8→11→10
* 開始   : 2026-08-18 20:15:00 (UTC)
* 終了   : 2026-08-18 20:25:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260818-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 9→11→14→15→10→11→14→15→10
* 開始   : 2026-08-19 04:20:00 (UTC)
* 終了   : 2026-08-19 04:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260819-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host13-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→15→15→17→18→17→18
* 開始   : 2026-08-19 05:35:00 (UTC)
* 終了   : 2026-08-19 06:55:00 (UTC)
* 現象   : 2026-08-19 06:55:00 (UTC)を境に水準が 15.08から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.187, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 15→16→17→13→15→16→17→13→14
* 開始   : 2026-08-19 05:35:00 (UTC)
* 終了   : 2026-08-19 05:40:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260819-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260819-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→19→18→16→19→18
* 開始   : 2026-08-19 07:10:00 (UTC)
* 終了   : 2026-08-19 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260819-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 19→17→15→16→15→16→15→16→15
* 開始   : 2026-08-19 16:55:00 (UTC)
* 終了   : 2026-08-19 17:05:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260819-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→8→10→11→8→10→9
* 開始   : 2026-08-19 20:40:00 (UTC)
* 終了   : 2026-08-19 20:45:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260819-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→8→9→8→9→8→9→11
* 開始   : 2026-08-19 20:50:00 (UTC)
* 終了   : 2026-08-19 21:00:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.523σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-lsfhost01-069 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260819-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 10→11→15→14→11→15→14→12
* 開始   : 2026-08-20 04:45:00 (UTC)
* 終了   : 2026-08-20 04:50:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.343倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.699σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260820-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 16→13→17→14→…→14→18→13→16
* 開始   : 2026-08-20 05:05:00 (UTC)
* 終了   : 2026-08-20 05:50:00 (UTC)
* 現象   : 45分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260820-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260820-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 16→15→17→15→17→15
* 開始   : 2026-08-20 05:55:00 (UTC)
* 終了   : 2026-08-20 06:00:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260820-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 18→17→21→18→21→18→21→18→19
* 開始   : 2026-08-20 08:10:00 (UTC)
* 終了   : 2026-08-20 08:20:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260820-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 21→19→17→19→…→19→17→20→18
* 開始   : 2026-08-20 15:35:00 (UTC)
* 終了   : 2026-08-20 15:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260820-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 18→17→16→20→16→20→16→18
* 開始   : 2026-08-20 16:05:00 (UTC)
* 終了   : 2026-08-20 16:15:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host13-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260820-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 18→16→15→17→18→16→15→17→18
* 開始   : 2026-08-20 16:15:00 (UTC)
* 終了   : 2026-08-20 16:20:00 (UTC)
* 現象   : 平常時(19)に対し 0.8421(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.113σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host13-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260820-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 18→19→15→16→14→15→16→14→16
* 開始   : 2026-08-20 17:15:00 (UTC)
* 終了   : 2026-08-20 17:25:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-lsfhost01-048 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 9→7→6→5→8→7→6→5→8
* 開始   : 2026-08-20 22:05:00 (UTC)
* 終了   : 2026-08-20 22:10:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.384σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host13-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 9→12→8→10→10
* 開始   : 2026-08-20 22:40:00 (UTC)
* 終了   : 2026-08-20 23:00:00 (UTC)
* 現象   : 2026-08-20 23:00:00 (UTC)を境に水準が 14.81から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.079, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host13-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 12→13→14→12→…→14→9→13→11
* 開始   : 2026-08-21 04:05:00 (UTC)
* 終了   : 2026-08-21 05:25:00 (UTC)
* 現象   : 1.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host13-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host13-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260821-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 25 分
  - EVT-20260821-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 45 分
  - EVT-20260821-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分

![EVT-20260821-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 13→11→8→15→…→8→15→13→12
* 開始   : 2026-08-21 04:25:00 (UTC)
* 終了   : 2026-08-21 04:30:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host13-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260821-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 18→21→19→18→21→19→20
* 開始   : 2026-08-21 08:25:00 (UTC)
* 終了   : 2026-08-21 08:30:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 21→20→22→20→…→20→23→21→19
* 開始   : 2026-08-21 09:05:00 (UTC)
* 終了   : 2026-08-21 09:15:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 21→20→17→19→…→19→16→20→21
* 開始   : 2026-08-21 15:45:00 (UTC)
* 終了   : 2026-08-21 15:55:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260821-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→16→14→15→16→14→15→16
* 開始   : 2026-08-21 17:30:00 (UTC)
* 終了   : 2026-08-21 17:35:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.372σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260821-lsfhost01-053 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260821-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 14→13→10→12→13→10→12→10
* 開始   : 2026-08-21 19:35:00 (UTC)
* 終了   : 2026-08-21 19:40:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.7362(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.505σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host05-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→11→8→12→11→8→12→10
* 開始   : 2026-08-21 21:10:00 (UTC)
* 終了   : 2026-08-21 21:15:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→10→11→8→10→7→9→7→9
* 開始   : 2026-08-23 00:05:00 (UTC)
* 終了   : 2026-08-23 00:45:00 (UTC)
* 現象   : 2026-08-23 00:45:00 (UTC)を境に水準が 11.89から11.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host13-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 9→7→10→10→10→10→10→8→8
* 開始   : 2026-08-23 00:55:00 (UTC)
* 終了   : 2026-08-23 02:00:00 (UTC)
* 現象   : 2026-08-23 02:00:00 (UTC)を境に水準が 11.8から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.021, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 11→15→16→14→11→15→16→14→12
* 開始   : 2026-08-23 06:55:00 (UTC)
* 終了   : 2026-08-23 07:00:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260823-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260823-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host13-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→9→11→9→12→10→11→11→10
* 開始   : 2026-08-23 20:00:00 (UTC)
* 終了   : 2026-08-23 20:45:00 (UTC)
* 現象   : 2026-08-23 20:45:00 (UTC)を境に水準が 11.82から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.158, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 8→9→12→8→…→8→5→6→10
* 開始   : 2026-08-23 23:00:00 (UTC)
* 終了   : 2026-08-23 23:10:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.485倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.737σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260823-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260823-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260823-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host13-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 9→10→9
* 開始   : 2026-08-23 23:55:00 (UTC)
* 終了   : 2026-08-24 00:05:00 (UTC)
* 現象   : 2026-08-24 00:05:00 (UTC)を境に水準が 11.77から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.795, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 9→9→9→9→11→10→9→9
* 開始   : 2026-08-24 00:55:00 (UTC)
* 終了   : 2026-08-24 01:30:00 (UTC)
* 現象   : 2026-08-24 01:30:00 (UTC)を境に水準が 11.92から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→10→11→8→10→9→10→9→10
* 開始   : 2026-08-25 01:45:00 (UTC)
* 終了   : 2026-08-25 02:30:00 (UTC)
* 現象   : 2026-08-25 02:30:00 (UTC)を境に水準が 15.04から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.875, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→10→13→9→10→13→9→12
* 開始   : 2026-08-25 02:55:00 (UTC)
* 終了   : 2026-08-25 03:00:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260825-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 15→11→17→15→11→17→15
* 開始   : 2026-08-25 05:45:00 (UTC)
* 終了   : 2026-08-25 05:50:00 (UTC)
* 現象   : 平常時(13)に対し 1.308倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.817σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260825-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260825-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 20→17→21→22→21→22→19→18
* 開始   : 2026-08-25 08:40:00 (UTC)
* 終了   : 2026-08-25 09:30:00 (UTC)
* 現象   : 平常時(18)に対し 1.167倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260825-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260825-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260825-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260825-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 21→20→20→21→19→21→22→22→22
* 開始   : 2026-08-25 14:15:00 (UTC)
* 終了   : 2026-08-25 15:00:00 (UTC)
* 現象   : 2026-08-25 15:00:00 (UTC)を境に水準が 14.89から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.649, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 21→17→16→20→21→17→16→20→18
* 開始   : 2026-08-25 16:05:00 (UTC)
* 終了   : 2026-08-25 16:10:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260825-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 16→17→12→11→15→17→12→11→15
* 開始   : 2026-08-25 18:25:00 (UTC)
* 終了   : 2026-08-25 18:30:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.523σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 11→12→9→10→…→10→8→11→13
* 開始   : 2026-08-25 20:25:00 (UTC)
* 終了   : 2026-08-25 20:35:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-074 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260825-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 12→9→9→8→8→9→8→10→10
* 開始   : 2026-08-25 21:30:00 (UTC)
* 終了   : 2026-08-25 22:40:00 (UTC)
* 現象   : 2026-08-25 22:40:00 (UTC)を境に水準が 14.98から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host13-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host13-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 13→10→9→11→10→9→9→10
* 開始   : 2026-08-25 21:35:00 (UTC)
* 終了   : 2026-08-25 22:10:00 (UTC)
* 現象   : 2026-08-25 22:10:00 (UTC)を境に水準が 15.09から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host13-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 21→23→25→22→…→22→19→21→24
* 開始   : 2026-08-26 12:45:00 (UTC)
* 終了   : 2026-08-26 12:55:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260826-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→16→12→16→12→14
* 開始   : 2026-08-26 18:35:00 (UTC)
* 終了   : 2026-08-26 18:40:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host13-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260826-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host13-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→15→11→10→…→14→9→15→13
* 開始   : 2026-08-26 19:05:00 (UTC)
* 終了   : 2026-08-26 19:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-068 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260826-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 12→13→9→10→…→10→8→11→10
* 開始   : 2026-08-26 20:35:00 (UTC)
* 終了   : 2026-08-26 20:45:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host13-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 11→8→12→9→6→12→9→6→9
* 開始   : 2026-08-26 22:25:00 (UTC)
* 終了   : 2026-08-26 22:35:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.23σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 14→15→18→16→…→16→19→16→17
* 開始   : 2026-08-27 06:30:00 (UTC)
* 終了   : 2026-08-27 06:40:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.373σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host13-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260827-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260827-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260827-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 17→18→20→18→20→18
* 開始   : 2026-08-27 07:40:00 (UTC)
* 終了   : 2026-08-27 07:45:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.206倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.406σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host13-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 20→19→23→18→23→18→23→20→22
* 開始   : 2026-08-27 09:35:00 (UTC)
* 終了   : 2026-08-27 09:45:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.406σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host13-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 23→22→19→18→20→22→19→18→20
* 開始   : 2026-08-27 13:45:00 (UTC)
* 終了   : 2026-08-27 13:50:00 (UTC)
* 現象   : 平常時(22.25)に対し 0.8539(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.289σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260827-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260827-host13-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host13-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 21→22→25→23→19→25→23→19→20
* 開始   : 2026-08-27 14:05:00 (UTC)
* 終了   : 2026-08-27 14:15:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260827-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260827-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 17→18→15→18→15→18→17
* 開始   : 2026-08-27 16:35:00 (UTC)
* 終了   : 2026-08-27 16:40:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.43σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host13-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260827-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 18→19→15→17→…→16→14→16→17
* 開始   : 2026-08-27 16:50:00 (UTC)
* 終了   : 2026-08-27 17:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260827-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 15→13→11→10→12→13→11→10→12
* 開始   : 2026-08-27 19:10:00 (UTC)
* 終了   : 2026-08-27 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host13-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_3
* 値     : 9→7→6→9→7→6→9→10
* 開始   : 2026-08-27 21:55:00 (UTC)
* 終了   : 2026-08-27 22:00:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.054σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host13-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 8→7→6→9→6→9→6→8
* 開始   : 2026-08-27 22:10:00 (UTC)
* 終了   : 2026-08-27 22:20:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 10→9→13→14→12→9→13→14→12
* 開始   : 2026-08-28 03:25:00 (UTC)
* 終了   : 2026-08-28 03:30:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260828-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host13-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 12→11→15→14→11→15→14→13
* 開始   : 2026-08-28 05:00:00 (UTC)
* 終了   : 2026-08-28 05:05:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260828-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host13-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host13-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 18→19→13→17→18→19→13→17
* 開始   : 2026-08-28 07:00:00 (UTC)
* 終了   : 2026-08-28 07:05:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260828-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260828-host13-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host13-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 21→22→22→22→20→22→20→20→23
* 開始   : 2026-08-28 08:55:00 (UTC)
* 終了   : 2026-08-28 09:35:00 (UTC)
* 現象   : 2026-08-28 09:35:00 (UTC)を境に水準が 14.87から14.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host13-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host13-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 21→21→20→21→23→20→20→19→21
* 開始   : 2026-08-28 14:30:00 (UTC)
* 終了   : 2026-08-28 15:40:00 (UTC)
* 現象   : 2026-08-28 15:40:00 (UTC)を境に水準が 14.92から12.58へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.973, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host13-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host13-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_1
* 値     : 20→21→18→20→20→20→20→18→20
* 開始   : 2026-08-28 15:30:00 (UTC)
* 終了   : 2026-08-28 16:35:00 (UTC)
* 現象   : 2026-08-28 16:35:00 (UTC)を境に水準が 14.88から12.4へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host13-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host13-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 18→16→19→16→…→16→15→17→18
* 開始   : 2026-08-28 16:25:00 (UTC)
* 終了   : 2026-08-28 16:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 13→16→11→16→…→12→16→11→12
* 開始   : 2026-08-28 19:00:00 (UTC)
* 終了   : 2026-08-28 19:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.854σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260828-host14-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host03-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host13-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host13-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 11→9→14→9→14→9→11→10
* 開始   : 2026-08-28 20:05:00 (UTC)
* 終了   : 2026-08-28 20:15:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.7297(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host13-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host13-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 10→9→10→9→9→10→7→10
* 開始   : 2026-08-28 22:05:00 (UTC)
* 終了   : 2026-08-28 22:40:00 (UTC)
* 現象   : 2026-08-28 22:40:00 (UTC)を境に水準が 14.97から11.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host13-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host13-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_2
* 値     : 10→11→8→9→9→9→9→10→9
* 開始   : 2026-08-29 00:50:00 (UTC)
* 終了   : 2026-08-29 01:30:00 (UTC)
* 現象   : 2026-08-29 01:30:00 (UTC)を境に水準が 14.83から12.17へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260829-host13-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host13-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_4
* 値     : 9→12→10→6→12→10→6→8→7
* 開始   : 2026-08-29 02:45:00 (UTC)
* 終了   : 2026-08-29 02:55:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-lsfhost01-006 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260829-lsfhost01-007 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260829-host13-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host13-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 9→6→9→10→9→6→9→10→8
* 開始   : 2026-08-29 20:45:00 (UTC)
* 終了   : 2026-08-29 20:50:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(6)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.952, 限界=2.707)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-lsfhost01-078 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260829-host13-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host13-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_6
* 値     : 9→6→5→10→9→6→5→10→6
* 開始   : 2026-08-29 21:55:00 (UTC)
* 終了   : 2026-08-29 22:00:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260829-host13-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host13-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host13, port=7003, datasource=OraclePool_5
* 値     : 9→10→12→5→10→12→5→10→6
* 開始   : 2026-08-29 23:05:00 (UTC)
* 終了   : 2026-08-29 23:10:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.455倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.617σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-lsfhost01-085 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260829-host13-011 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
