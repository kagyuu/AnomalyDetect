# host14 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host14 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 288 (SEVERE: 17, FATAL: 121, WARN: 150, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 17 | 121 | 150 | 288 | ALG-A1, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260803-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→16→17→15→…→15→16→13→17
* 開始   : 2026-08-03 01:10:00 (UTC)
* 終了   : 2026-08-03 20:05:00 (UTC)
* 現象   : 2026-08-03 20:05:00 (UTC)を境に水準が 11.8から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.458, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host14-001 active_connections の推移](charts/EVT-20260803-host14-001.svg)

# イベントID( EVT-20260803-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 13→15→16→15→…→13→15→14→13
* 開始   : 2026-08-03 02:05:00 (UTC)
* 終了   : 2026-08-03 20:20:00 (UTC)
* 現象   : 2026-08-03 20:20:00 (UTC)を境に水準が 11.8から14.82へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.817, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host14-002 active_connections の推移](charts/EVT-20260803-host14-002.svg)

# イベントID( EVT-20260803-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→15→14→16→…→12→13→12→13
* 開始   : 2026-08-03 03:40:00 (UTC)
* 終了   : 2026-08-03 19:50:00 (UTC)
* 現象   : 2026-08-03 19:50:00 (UTC)を境に水準が 11.86から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.893, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host14-006 active_connections の推移](charts/EVT-20260803-host14-006.svg)

# イベントID( EVT-20260810-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→14→17→15→…→13→14→11→14
* 開始   : 2026-08-10 01:50:00 (UTC)
* 終了   : 2026-08-11 00:25:00 (UTC)
* 現象   : 2026-08-11 00:25:00 (UTC)を境に水準が 11.74から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.468σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.477, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.917, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host14-002 active_connections の推移](charts/EVT-20260810-host14-002.svg)

# イベントID( EVT-20260810-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→17→16→17→…→14→15→13→14
* 開始   : 2026-08-10 03:40:00 (UTC)
* 終了   : 2026-08-10 20:55:00 (UTC)
* 現象   : 2026-08-10 20:55:00 (UTC)を境に水準が 11.83から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.172, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host14-006 active_connections の推移](charts/EVT-20260810-host14-006.svg)

# イベントID( EVT-20260810-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→16→14→16→…→14→13→14→12
* 開始   : 2026-08-10 03:50:00 (UTC)
* 終了   : 2026-08-10 18:45:00 (UTC)
* 現象   : 2026-08-10 18:45:00 (UTC)を境に水準が 11.91から14.82へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.908, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.463, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host14-007 active_connections の推移](charts/EVT-20260810-host14-007.svg)

# イベントID( EVT-20260817-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→18→15→14→…→17→14→12→14
* 開始   : 2026-08-17 01:25:00 (UTC)
* 終了   : 2026-08-17 20:40:00 (UTC)
* 現象   : 2026-08-17 20:40:00 (UTC)を境に水準が 11.82から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.259σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.92, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.337, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host14-001 active_connections の推移](charts/EVT-20260817-host14-001.svg)

# イベントID( EVT-20260817-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 18→17→18→19→…→13→15→13→15
* 開始   : 2026-08-17 01:40:00 (UTC)
* 終了   : 2026-08-17 21:25:00 (UTC)
* 現象   : 2026-08-17 21:25:00 (UTC)を境に水準が 11.77から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.73, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.537, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host14-002 active_connections の推移](charts/EVT-20260817-host14-002.svg)

# イベントID( EVT-20260817-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→14→18→17→…→12→14→12→13
* 開始   : 2026-08-17 02:45:00 (UTC)
* 終了   : 2026-08-17 19:55:00 (UTC)
* 現象   : 2026-08-17 19:55:00 (UTC)を境に水準が 11.88から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.143, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.945, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host14-003 active_connections の推移](charts/EVT-20260817-host14-003.svg)

# イベントID( EVT-20260817-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→12→16→15→…→13→15→11→13
* 開始   : 2026-08-17 02:45:00 (UTC)
* 終了   : 2026-08-17 21:50:00 (UTC)
* 現象   : 2026-08-17 21:50:00 (UTC)を境に水準が 11.85から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.848, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host14-004 active_connections の推移](charts/EVT-20260817-host14-004.svg)

# イベントID( EVT-20260817-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→16→13→15→…→14→13→12→14
* 開始   : 2026-08-17 03:00:00 (UTC)
* 終了   : 2026-08-17 19:55:00 (UTC)
* 現象   : 2026-08-17 19:55:00 (UTC)を境に水準が 11.92から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.811, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.912, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host14-006 active_connections の推移](charts/EVT-20260817-host14-006.svg)

# イベントID( EVT-20260817-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→18→15→17→…→14→15→13→14
* 開始   : 2026-08-17 04:50:00 (UTC)
* 終了   : 2026-08-17 19:45:00 (UTC)
* 現象   : 2026-08-17 19:45:00 (UTC)を境に水準が 11.87から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.47σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.916, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=15.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host14-007 active_connections の推移](charts/EVT-20260817-host14-007.svg)

# イベントID( EVT-20260824-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→16→14→15→…→12→13→12→13
* 開始   : 2026-08-24 02:50:00 (UTC)
* 終了   : 2026-08-24 20:25:00 (UTC)
* 現象   : 2026-08-24 20:25:00 (UTC)を境に水準が 11.91から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.313σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.665, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host14-002 active_connections の推移](charts/EVT-20260824-host14-002.svg)

# イベントID( EVT-20260824-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→11→15→14→…→16→15→14→13
* 開始   : 2026-08-24 03:10:00 (UTC)
* 終了   : 2026-08-24 22:10:00 (UTC)
* 現象   : 2026-08-24 22:10:00 (UTC)を境に水準が 11.86から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.237σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.963, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host14-003 active_connections の推移](charts/EVT-20260824-host14-003.svg)

# イベントID( EVT-20260824-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→14→16→17→…→16→14→11→13
* 開始   : 2026-08-24 03:20:00 (UTC)
* 終了   : 2026-08-24 19:00:00 (UTC)
* 現象   : 2026-08-24 19:00:00 (UTC)を境に水準が 11.73から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.799, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host14-004 active_connections の推移](charts/EVT-20260824-host14-004.svg)

# イベントID( EVT-20260824-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→13→17→13→…→16→14→12→13
* 開始   : 2026-08-24 03:30:00 (UTC)
* 終了   : 2026-08-24 19:45:00 (UTC)
* 現象   : 2026-08-24 19:45:00 (UTC)を境に水準が 11.9から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.69, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.922, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host14-005 active_connections の推移](charts/EVT-20260824-host14-005.svg)

# イベントID( EVT-20260824-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→12→17→15→…→15→16→13→16
* 開始   : 2026-08-24 04:05:00 (UTC)
* 終了   : 2026-08-24 20:25:00 (UTC)
* 現象   : 2026-08-24 20:25:00 (UTC)を境に水準が 12から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.155, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.93, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host14-006 active_connections の推移](charts/EVT-20260824-host14-006.svg)

# イベントID( EVT-20260801-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 12→13→11→13→…→11→13→14→12
* 開始   : 2026-08-01 04:40:00 (UTC)
* 終了   : 2026-08-01 18:30:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.886, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260801-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260801-host14-001 active_connections の推移](charts/EVT-20260801-host14-001.svg)

# イベントID( EVT-20260801-host14-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→13→10→12→…→11→10→12→11
* 開始   : 2026-08-01 05:20:00 (UTC)
* 終了   : 2026-08-01 18:55:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.091, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260801-host14-002 active_connections の推移](charts/EVT-20260801-host14-002.svg)

# イベントID( EVT-20260801-host14-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→12→…→14→13→14→13
* 開始   : 2026-08-01 05:20:00 (UTC)
* 終了   : 2026-08-01 19:00:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.157, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260801-host14-003 active_connections の推移](charts/EVT-20260801-host14-003.svg)

# イベントID( EVT-20260801-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 13→10→12→11→…→11→12→11→12
* 開始   : 2026-08-01 05:25:00 (UTC)
* 終了   : 2026-08-01 19:05:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.169, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260801-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260801-host14-004 active_connections の推移](charts/EVT-20260801-host14-004.svg)

# イベントID( EVT-20260801-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→12→11→13→…→12→11→15→12
* 開始   : 2026-08-01 05:45:00 (UTC)
* 終了   : 2026-08-01 19:15:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.902, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260801-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260801-host14-005 active_connections の推移](charts/EVT-20260801-host14-005.svg)

# イベントID( EVT-20260801-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→13→11→13→…→11→12→11→12
* 開始   : 2026-08-01 05:50:00 (UTC)
* 終了   : 2026-08-01 18:45:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.55σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.869, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260801-host14-006 active_connections の推移](charts/EVT-20260801-host14-006.svg)

# イベントID( EVT-20260801-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 10→9→6→10→11
* 開始   : 2026-08-01 20:10:00 (UTC)
* 終了   : 2026-08-01 20:10:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260801-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260801-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260801-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260801-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→10→5→8→10
* 開始   : 2026-08-01 21:50:00 (UTC)
* 終了   : 2026-08-01 21:50:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260801-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 8→8→12→8→7
* 開始   : 2026-08-02 01:30:00 (UTC)
* 終了   : 2026-08-02 01:30:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260802-lsfhost01-004 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260802-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 10→9→13→8→12→13→8→12→9
* 開始   : 2026-08-02 03:25:00 (UTC)
* 終了   : 2026-08-02 03:35:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.007σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260802-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260802-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260802-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→12→12→15
* 開始   : 2026-08-02 04:35:00 (UTC)
* 終了   : 2026-08-02 04:50:00 (UTC)
* 現象   : 2026-08-02 04:50:00 (UTC)を境に水準が 11.75から12.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.961, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 17→14→20→14→14
* 開始   : 2026-08-02 14:20:00 (UTC)
* 終了   : 2026-08-02 14:20:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.311倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.296σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260802-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host14-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→16→17→16→…→15→14→13→14
* 開始   : 2026-08-03 02:35:00 (UTC)
* 終了   : 2026-08-03 19:30:00 (UTC)
* 現象   : 2026-08-03 19:30:00 (UTC)を境に水準が 11.96から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.848, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 16→19→18→15→…→14→13→12→13
* 開始   : 2026-08-03 02:45:00 (UTC)
* 終了   : 2026-08-03 20:20:00 (UTC)
* 現象   : 2026-08-03 20:20:00 (UTC)を境に水準が 11.78から14.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.702, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→16→15→16→…→16→14→16→14
* 開始   : 2026-08-03 02:50:00 (UTC)
* 終了   : 2026-08-03 19:55:00 (UTC)
* 現象   : 2026-08-03 19:55:00 (UTC)を境に水準が 11.91から15へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.792, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.893, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→13→17→13→13
* 開始   : 2026-08-04 05:10:00 (UTC)
* 終了   : 2026-08-04 05:10:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.388倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 17→19→16→18→15→16→18→15→18
* 開始   : 2026-08-04 15:55:00 (UTC)
* 終了   : 2026-08-04 16:30:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.7773(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-040 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260804-lsfhost01-041 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260804-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 18→20→15→18→17
* 開始   : 2026-08-04 16:05:00 (UTC)
* 終了   : 2026-08-04 16:05:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-040 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260804-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→12→10→13→14
* 開始   : 2026-08-04 18:45:00 (UTC)
* 終了   : 2026-08-04 18:45:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.021σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260804-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 13→10→7→10→11
* 開始   : 2026-08-04 20:05:00 (UTC)
* 終了   : 2026-08-04 20:05:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.5676(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.742σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host14-011 active_connections の推移](charts/EVT-20260804-host14-011.svg)

# イベントID( EVT-20260805-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 9→14→13→11→9→14→13→11
* 開始   : 2026-08-05 03:40:00 (UTC)
* 終了   : 2026-08-05 03:45:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260805-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260805-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→11→15→17→…→15→17→13→12
* 開始   : 2026-08-05 05:00:00 (UTC)
* 終了   : 2026-08-05 05:05:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.198σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-015 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260805-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 13→15→16→15→…→15→17→15→16
* 開始   : 2026-08-05 05:55:00 (UTC)
* 終了   : 2026-08-05 06:20:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host14-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260805-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260805-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 17→18→14→18→…→16→13→15→14
* 開始   : 2026-08-05 17:25:00 (UTC)
* 終了   : 2026-08-05 18:45:00 (UTC)
* 現象   : 1.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-051 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260805-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 50 分
  - EVT-20260805-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host12-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260805-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host14-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→11→5→10→9
* 開始   : 2026-08-05 22:30:00 (UTC)
* 終了   : 2026-08-05 22:30:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.5128(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260805-host14-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 22→21→25→21→21
* 開始   : 2026-08-06 10:10:00 (UTC)
* 終了   : 2026-08-06 10:10:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.065σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-035 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260806-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 23→22→17→22→22
* 開始   : 2026-08-06 13:20:00 (UTC)
* 終了   : 2026-08-06 13:20:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.7698(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.567σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260806-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 18→19→21→13→…→21→13→15→16
* 開始   : 2026-08-06 16:40:00 (UTC)
* 終了   : 2026-08-06 16:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260806-host14-008 active_connections の推移](charts/EVT-20260806-host14-008.svg)

# イベントID( EVT-20260806-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→13→7→10→9
* 開始   : 2026-08-06 20:50:00 (UTC)
* 終了   : 2026-08-06 20:50:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6043(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host02-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 8→10→14→10→11
* 開始   : 2026-08-07 03:30:00 (UTC)
* 終了   : 2026-08-07 03:30:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.065σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260807-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 16→16→12→17→15
* 開始   : 2026-08-07 17:00:00 (UTC)
* 終了   : 2026-08-07 17:00:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.689(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.794σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host14-009 active_connections の推移](charts/EVT-20260807-host14-009.svg)

# イベントID( EVT-20260807-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 17→13→11→13→15
* 開始   : 2026-08-07 18:30:00 (UTC)
* 終了   : 2026-08-07 18:30:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host14-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 7→7→12→8→9
* 開始   : 2026-08-08 01:25:00 (UTC)
* 終了   : 2026-08-08 01:25:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260808-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→9→4→10→9
* 開始   : 2026-08-08 02:35:00 (UTC)
* 終了   : 2026-08-08 02:35:00 (UTC)
* 現象   : 平常時(8.833)に対し 0.4528(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.352σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260808-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host14-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→14→13→12→…→11→14→13→12
* 開始   : 2026-08-08 04:50:00 (UTC)
* 終了   : 2026-08-08 19:10:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.975, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260808-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260808-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260808-host14-003 active_connections の推移](charts/EVT-20260808-host14-003.svg)

# イベントID( EVT-20260808-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→11→10→11→…→12→10→12→14
* 開始   : 2026-08-08 05:40:00 (UTC)
* 終了   : 2026-08-08 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.222, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260808-host14-004 active_connections の推移](charts/EVT-20260808-host14-004.svg)

# イベントID( EVT-20260808-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 15→13→15→14→…→13→12→11→13
* 開始   : 2026-08-08 05:50:00 (UTC)
* 終了   : 2026-08-08 19:00:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.065σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.917, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260808-host14-005 active_connections の推移](charts/EVT-20260808-host14-005.svg)

# イベントID( EVT-20260808-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→11→12→13→…→13→11→13→12
* 開始   : 2026-08-08 05:55:00 (UTC)
* 終了   : 2026-08-08 18:10:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.583, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.8 時間
  - EVT-20260808-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260808-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260808-host14-006 active_connections の推移](charts/EVT-20260808-host14-006.svg)

# イベントID( EVT-20260808-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 12→11→13→10→…→12→13→16→12
* 開始   : 2026-08-08 05:55:00 (UTC)
* 終了   : 2026-08-08 18:25:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.767, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host14-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.0 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260808-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260808-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260808-host14-007 active_connections の推移](charts/EVT-20260808-host14-007.svg)

# イベントID( EVT-20260808-host14-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 16→13→12→14→…→10→11→12→13
* 開始   : 2026-08-08 07:25:00 (UTC)
* 終了   : 2026-08-08 18:55:00 (UTC)
* 現象   : 11.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.812, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260808-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260808-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260808-host14-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.0 時間
  - EVT-20260808-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.8 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.5 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.5 時間

![EVT-20260808-host14-008 active_connections の推移](charts/EVT-20260808-host14-008.svg)

# イベントID( EVT-20260808-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→13→7→12→10
* 開始   : 2026-08-08 19:55:00 (UTC)
* 終了   : 2026-08-08 19:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260808-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260808-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260808-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 9→10→4→7→10
* 開始   : 2026-08-08 22:25:00 (UTC)
* 終了   : 2026-08-08 22:25:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.4404(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.551σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260808-host14-011 active_connections の推移](charts/EVT-20260808-host14-011.svg)

# イベントID( EVT-20260809-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→17→11→17→15
* 開始   : 2026-08-09 10:45:00 (UTC)
* 終了   : 2026-08-09 10:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-029 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260809-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 10→12→5→10→9
* 開始   : 2026-08-09 22:15:00 (UTC)
* 終了   : 2026-08-09 22:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.064σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host14-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 13→15→14→16→…→16→12→13→12
* 開始   : 2026-08-10 02:05:00 (UTC)
* 終了   : 2026-08-10 19:35:00 (UTC)
* 現象   : 2026-08-10 19:35:00 (UTC)を境に水準が 11.79から15.06へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.715, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host14-003 active_connections の推移](charts/EVT-20260810-host14-003.svg)

# イベントID( EVT-20260810-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→15→…→14→16→12→14
* 開始   : 2026-08-10 03:00:00 (UTC)
* 終了   : 2026-08-10 19:15:00 (UTC)
* 現象   : 2026-08-10 19:15:00 (UTC)を境に水準が 11.93から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.784, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host14-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→16→15→16→…→13→15→13→12
* 開始   : 2026-08-10 03:20:00 (UTC)
* 終了   : 2026-08-10 19:35:00 (UTC)
* 現象   : 2026-08-10 19:35:00 (UTC)を境に水準が 11.86から14.9へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.68, 限界=2.699)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.893, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 19→17→23→20→20
* 開始   : 2026-08-11 09:15:00 (UTC)
* 終了   : 2026-08-11 09:15:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260811-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→18→13→15→15
* 開始   : 2026-08-11 17:25:00 (UTC)
* 終了   : 2026-08-11 17:25:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7393(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.179σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-048 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260811-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 13→15→10→12→13
* 開始   : 2026-08-11 19:05:00 (UTC)
* 終了   : 2026-08-11 19:05:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6857(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host14-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→13→8→10→12
* 開始   : 2026-08-11 20:10:00 (UTC)
* 終了   : 2026-08-11 20:10:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.18σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→9→13→10→8
* 開始   : 2026-08-12 02:20:00 (UTC)
* 終了   : 2026-08-12 02:20:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.123σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-005 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 18→17→22→19→21→22→19→21→17
* 開始   : 2026-08-12 06:50:00 (UTC)
* 終了   : 2026-08-12 07:35:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260812-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 35 分
  - EVT-20260812-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260812-host14-005 active_connections の推移](charts/EVT-20260812-host14-005.svg)

# イベントID( EVT-20260812-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 21→21→17→22→19
* 開始   : 2026-08-12 14:05:00 (UTC)
* 終了   : 2026-08-12 14:05:00 (UTC)
* 現象   : 平常時(22)に対し 0.7727(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.486σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260812-host14-007 active_connections の推移](charts/EVT-20260812-host14-007.svg)

# イベントID( EVT-20260812-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 18→18→15→18→19
* 開始   : 2026-08-12 16:15:00 (UTC)
* 終了   : 2026-08-12 16:15:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.021σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host14-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260812-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→16→12→13→…→12→13→14→16
* 開始   : 2026-08-12 17:35:00 (UTC)
* 終了   : 2026-08-12 17:40:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7164(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260812-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→13→18→14→15
* 開始   : 2026-08-13 04:45:00 (UTC)
* 終了   : 2026-08-13 04:45:00 (UTC)
* 現象   : 平常時(12)に対し 1.5倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260813-host14-002 active_connections の推移](charts/EVT-20260813-host14-002.svg)

# イベントID( EVT-20260813-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 18→16→21→18→19
* 開始   : 2026-08-13 07:50:00 (UTC)
* 終了   : 2026-08-13 07:50:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 22→22→17→22→21
* 開始   : 2026-08-13 10:30:00 (UTC)
* 終了   : 2026-08-13 10:30:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.237σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→17→11→15→16
* 開始   : 2026-08-13 17:35:00 (UTC)
* 終了   : 2026-08-13 17:35:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.6701(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.757σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host14-007 active_connections の推移](charts/EVT-20260813-host14-007.svg)

# イベントID( EVT-20260814-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→14→19→17→…→17→18→15→17
* 開始   : 2026-08-14 06:25:00 (UTC)
* 終了   : 2026-08-14 06:35:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.341倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 22→22→18→21→20
* 開始   : 2026-08-14 13:20:00 (UTC)
* 終了   : 2026-08-14 13:20:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260814-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 20→23→17→21→19
* 開始   : 2026-08-14 14:30:00 (UTC)
* 終了   : 2026-08-14 14:30:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260814-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 19→17→14→16→16
* 開始   : 2026-08-14 16:30:00 (UTC)
* 終了   : 2026-08-14 16:30:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→14→18→13→…→13→12→16→14
* 開始   : 2026-08-14 17:30:00 (UTC)
* 終了   : 2026-08-14 17:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260814-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260814-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260814-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260814-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→12→9→7→…→9→7→11→9
* 開始   : 2026-08-14 20:25:00 (UTC)
* 終了   : 2026-08-14 20:30:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260814-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host16-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260814-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-075 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host14-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→11→14→11→…→10→11→13→10
* 開始   : 2026-08-15 04:20:00 (UTC)
* 終了   : 2026-08-15 19:00:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.747, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260815-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260815-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260815-host14-001 active_connections の推移](charts/EVT-20260815-host14-001.svg)

# イベントID( EVT-20260815-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→15→12→13→…→12→13→12→14
* 開始   : 2026-08-15 04:20:00 (UTC)
* 終了   : 2026-08-15 19:20:00 (UTC)
* 現象   : 15.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.161, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260815-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260815-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260815-host14-002 active_connections の推移](charts/EVT-20260815-host14-002.svg)

# イベントID( EVT-20260815-host14-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→11→12→11→…→13→10→14→13
* 開始   : 2026-08-15 04:25:00 (UTC)
* 終了   : 2026-08-15 19:00:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.801, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260815-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260815-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260815-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260815-host14-003 active_connections の推移](charts/EVT-20260815-host14-003.svg)

# イベントID( EVT-20260815-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 11→12→9→10→…→11→12→11→10
* 開始   : 2026-08-15 05:10:00 (UTC)
* 終了   : 2026-08-15 18:55:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.684σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.817, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260815-host14-004 active_connections の推移](charts/EVT-20260815-host14-004.svg)

# イベントID( EVT-20260815-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 10→12→8→12→…→10→11→10→12
* 開始   : 2026-08-15 05:30:00 (UTC)
* 終了   : 2026-08-15 18:55:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.602σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.518, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260815-host14-005 active_connections の推移](charts/EVT-20260815-host14-005.svg)

# イベントID( EVT-20260815-host14-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→10→12→15→…→11→10→13→11
* 開始   : 2026-08-15 05:40:00 (UTC)
* 終了   : 2026-08-15 19:05:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.26, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260815-host14-006 active_connections の推移](charts/EVT-20260815-host14-006.svg)

# イベントID( EVT-20260819-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→12→14→11→10
* 開始   : 2026-08-19 03:30:00 (UTC)
* 終了   : 2026-08-19 03:30:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.179σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260819-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 19→21→18→25→…→18→25→22→20
* 開始   : 2026-08-19 14:10:00 (UTC)
* 終了   : 2026-08-19 14:15:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 15→17→12→17→15
* 開始   : 2026-08-19 17:50:00 (UTC)
* 終了   : 2026-08-19 17:50:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.699(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.585σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host14-005 active_connections の推移](charts/EVT-20260819-host14-005.svg)

# イベントID( EVT-20260819-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→13→8→15→…→8→15→11→13
* 開始   : 2026-08-19 19:55:00 (UTC)
* 終了   : 2026-08-19 20:00:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.122σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260819-host02-014 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260819-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-063 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260819-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→12→17→11→16→17→11→16→14
* 開始   : 2026-08-20 05:05:00 (UTC)
* 終了   : 2026-08-20 05:15:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 20→21→17→21→21
* 開始   : 2026-08-20 14:00:00 (UTC)
* 終了   : 2026-08-20 14:00:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.122σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260820-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 20→20→15→18→18
* 開始   : 2026-08-20 15:40:00 (UTC)
* 終了   : 2026-08-20 15:40:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.7563(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 12→13→9→13→12
* 開始   : 2026-08-20 19:05:00 (UTC)
* 終了   : 2026-08-20 19:05:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.6391(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.544σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host14-010 active_connections の推移](charts/EVT-20260820-host14-010.svg)

# イベントID( EVT-20260821-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→10→14→10→14→10→14→11→12
* 開始   : 2026-08-21 04:00:00 (UTC)
* 終了   : 2026-08-21 04:40:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260821-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 40 分
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 35 分
  - EVT-20260821-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260821-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 15 分
  - EVT-20260821-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 17→14→20→16→16
* 開始   : 2026-08-21 06:10:00 (UTC)
* 終了   : 2026-08-21 06:10:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.364倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.719σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host14-003 active_connections の推移](charts/EVT-20260821-host14-003.svg)

# イベントID( EVT-20260821-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 23→22→25→22→23→24→21→23→22
* 開始   : 2026-08-21 12:30:00 (UTC)
* 終了   : 2026-08-21 13:25:00 (UTC)
* 現象   : 2026-08-21 13:25:00 (UTC)を境に水準が 15.11から13.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.179σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.843, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host14-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→13→11→13→…→12→10→12→13
* 開始   : 2026-08-22 05:05:00 (UTC)
* 終了   : 2026-08-22 18:50:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.193, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260822-host14-001 active_connections の推移](charts/EVT-20260822-host14-001.svg)

# イベントID( EVT-20260822-host14-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 12→11→14→12→…→9→12→10→12
* 開始   : 2026-08-22 05:25:00 (UTC)
* 終了   : 2026-08-22 18:45:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.801, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260822-host14-002 active_connections の推移](charts/EVT-20260822-host14-002.svg)

# イベントID( EVT-20260822-host14-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→12→11→13→…→11→13→12→11
* 開始   : 2026-08-22 05:45:00 (UTC)
* 終了   : 2026-08-22 18:45:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.297, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260822-host14-003 active_connections の推移](charts/EVT-20260822-host14-003.svg)

# イベントID( EVT-20260822-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→13→11→13→…→11→8→11→13
* 開始   : 2026-08-22 05:50:00 (UTC)
* 終了   : 2026-08-22 19:00:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.858, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260822-host14-004 active_connections の推移](charts/EVT-20260822-host14-004.svg)

# イベントID( EVT-20260822-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→11→15→12→…→13→11→12→13
* 開始   : 2026-08-22 06:00:00 (UTC)
* 終了   : 2026-08-22 20:35:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.929, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host14-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260822-host14-005 active_connections の推移](charts/EVT-20260822-host14-005.svg)

# イベントID( EVT-20260822-host14-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 10→12→10→12→…→10→13→12→11
* 開始   : 2026-08-22 06:10:00 (UTC)
* 終了   : 2026-08-22 19:45:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.888, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260822-host14-006 active_connections の推移](charts/EVT-20260822-host14-006.svg)

# イベントID( EVT-20260823-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→15→19→16→16
* 開始   : 2026-08-23 12:55:00 (UTC)
* 終了   : 2026-08-23 12:55:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260823-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 15→14→19→14→12→19→14→12→14
* 開始   : 2026-08-23 15:40:00 (UTC)
* 終了   : 2026-08-23 15:50:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.065σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260823-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host14-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→13→12→13→…→11→12→11→10
* 開始   : 2026-08-24 02:20:00 (UTC)
* 終了   : 2026-08-24 20:55:00 (UTC)
* 現象   : 2026-08-24 20:55:00 (UTC)を境に水準が 11.82から15.09へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.769, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→6→13→9→…→9→12→10→9
* 開始   : 2026-08-25 02:25:00 (UTC)
* 終了   : 2026-08-25 02:35:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260825-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→12→18→13→15
* 開始   : 2026-08-25 05:25:00 (UTC)
* 終了   : 2026-08-25 05:25:00 (UTC)
* 現象   : 平常時(13)に対し 1.385倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.47σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260825-host14-002 active_connections の推移](charts/EVT-20260825-host14-002.svg)

# イベントID( EVT-20260825-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 21→22→21→21→20→21→16→22→21
* 開始   : 2026-08-25 14:10:00 (UTC)
* 終了   : 2026-08-25 15:10:00 (UTC)
* 現象   : 2026-08-25 15:10:00 (UTC)を境に水準が 15.01から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.583σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.996, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 17→19→15→19→15→16
* 開始   : 2026-08-25 16:55:00 (UTC)
* 終了   : 2026-08-25 17:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host14-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260825-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260825-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 7→7→4→8→10
* 開始   : 2026-08-25 23:15:00 (UTC)
* 終了   : 2026-08-25 23:15:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260825-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 18→17→22→16→15
* 開始   : 2026-08-26 07:40:00 (UTC)
* 終了   : 2026-08-26 07:40:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.307倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 23→22→18→21→20
* 開始   : 2026-08-26 12:55:00 (UTC)
* 終了   : 2026-08-26 12:55:00 (UTC)
* 現象   : 平常時(22.58)に対し 0.797(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→18→12→16→14
* 開始   : 2026-08-26 17:50:00 (UTC)
* 終了   : 2026-08-26 17:50:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7164(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260826-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→12→10→13→15→12→10→13→15
* 開始   : 2026-08-26 18:45:00 (UTC)
* 終了   : 2026-08-26 18:50:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.427σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host14-011 active_connections の推移](charts/EVT-20260826-host14-011.svg)

# イベントID( EVT-20260826-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 9→7→4→8→8
* 開始   : 2026-08-26 23:30:00 (UTC)
* 終了   : 2026-08-26 23:30:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→11→16→13→14
* 開始   : 2026-08-27 04:50:00 (UTC)
* 終了   : 2026-08-27 04:50:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→9→8→6→7→9→9→10→10
* 開始   : 2026-08-27 23:20:00 (UTC)
* 終了   : 2026-08-28 01:55:00 (UTC)
* 現象   : 2026-08-28 01:55:00 (UTC)を境に水準が 14.96から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.686, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 9→8→8→10→8→9→11
* 開始   : 2026-08-28 00:20:00 (UTC)
* 終了   : 2026-08-28 01:50:00 (UTC)
* 現象   : 2026-08-28 01:50:00 (UTC)を境に水準が 15.03から15.17へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 18→19→16→17
* 開始   : 2026-08-28 06:00:00 (UTC)
* 終了   : 2026-08-28 06:15:00 (UTC)
* 現象   : 2026-08-28 06:15:00 (UTC)を境に水準が 14.94から14.71へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.802σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.961, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 17→17→21→18→17
* 開始   : 2026-08-28 07:25:00 (UTC)
* 終了   : 2026-08-28 07:25:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.123σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260828-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 17→18→21→18→16
* 開始   : 2026-08-28 07:30:00 (UTC)
* 終了   : 2026-08-28 07:30:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260828-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 19→16→14→21→…→14→21→22→19
* 開始   : 2026-08-28 07:55:00 (UTC)
* 終了   : 2026-08-28 08:05:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 18→18→23→20→21
* 開始   : 2026-08-28 08:35:00 (UTC)
* 終了   : 2026-08-28 08:35:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.272倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.428σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host14-009 active_connections の推移](charts/EVT-20260828-host14-009.svg)

# イベントID( EVT-20260828-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 20→23→26→19→20→23→26→19→22
* 開始   : 2026-08-28 09:25:00 (UTC)
* 終了   : 2026-08-28 09:30:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.198σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host14-010 active_connections の推移](charts/EVT-20260828-host14-010.svg)

# イベントID( EVT-20260828-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 20→18→17→21→20→18→17→21→19
* 開始   : 2026-08-28 14:50:00 (UTC)
* 終了   : 2026-08-28 15:15:00 (UTC)
* 現象   : 平常時(21.17)に対し 1.228倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→18→11→14→16
* 開始   : 2026-08-28 18:25:00 (UTC)
* 終了   : 2026-08-28 19:00:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.6839(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260828-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host03-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-host03-017 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260828-host14-016 active_connections の推移](charts/EVT-20260828-host14-016.svg)

# イベントID( EVT-20260828-host14-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→10→5→8→…→8→6→10→8
* 開始   : 2026-08-28 21:45:00 (UTC)
* 終了   : 2026-08-28 22:25:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217倍(5)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.18σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260828-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host14-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host14-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 13→12→9→10→…→12→11→12→9
* 開始   : 2026-08-29 04:30:00 (UTC)
* 終了   : 2026-08-29 19:20:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.947, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260829-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260829-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.6 時間
  - EVT-20260829-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260829-host14-001 active_connections の推移](charts/EVT-20260829-host14-001.svg)

# イベントID( EVT-20260829-host14-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 10→8→10→8→…→13→14→13→12
* 開始   : 2026-08-29 04:40:00 (UTC)
* 終了   : 2026-08-29 19:15:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.213, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260829-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260829-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260829-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260829-host14-002 active_connections の推移](charts/EVT-20260829-host14-002.svg)

# イベントID( EVT-20260829-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 11→9→11→10→…→11→12→13→12
* 開始   : 2026-08-29 05:05:00 (UTC)
* 終了   : 2026-08-29 18:50:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.752, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260829-host14-003 active_connections の推移](charts/EVT-20260829-host14-003.svg)

# イベントID( EVT-20260829-host14-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→10→12→11→…→12→10→14→11
* 開始   : 2026-08-29 05:45:00 (UTC)
* 終了   : 2026-08-29 18:50:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.863, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260829-host14-004 active_connections の推移](charts/EVT-20260829-host14-004.svg)

# イベントID( EVT-20260829-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→11→12→14→…→11→9→13→12
* 開始   : 2026-08-29 05:50:00 (UTC)
* 終了   : 2026-08-29 19:15:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.14σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.115, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260829-host14-005 active_connections の推移](charts/EVT-20260829-host14-005.svg)

# イベントID( EVT-20260829-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→12→11→12→…→14→11→12→14
* 開始   : 2026-08-29 05:55:00 (UTC)
* 終了   : 2026-08-29 19:40:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.781, 限界=2.699)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host14-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host14-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host14-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host14-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260829-host14-006 active_connections の推移](charts/EVT-20260829-host14-006.svg)

# イベントID( EVT-20260829-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 9→10→13→5→…→13→5→8→9
* 開始   : 2026-08-29 21:00:00 (UTC)
* 終了   : 2026-08-29 21:55:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263倍(5)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260829-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260829-lsfhost01-079 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260829-lsfhost01-080 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260829-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260829-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 9→10→13→10→…→10→13→12→10
* 開始   : 2026-08-02 04:55:00 (UTC)
* 終了   : 2026-08-02 05:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260802-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260802-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→17→18→16→17→18→16→17
* 開始   : 2026-08-02 12:05:00 (UTC)
* 終了   : 2026-08-02 12:10:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260802-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 12→13→17→15→…→15→11→14→13
* 開始   : 2026-08-02 16:00:00 (UTC)
* 終了   : 2026-08-02 16:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260802-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260802-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host14-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→10→10→8→10→9→11→11→9
* 開始   : 2026-08-03 20:40:00 (UTC)
* 終了   : 2026-08-03 21:40:00 (UTC)
* 現象   : 2026-08-03 21:40:00 (UTC)を境に水準が 14.89から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 10→11→12→10→11→9→11→11→12
* 開始   : 2026-08-03 20:55:00 (UTC)
* 終了   : 2026-08-03 22:10:00 (UTC)
* 現象   : 2026-08-03 22:10:00 (UTC)を境に水準が 14.85から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.85, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 8→10→12→10→…→10→6→9→8
* 開始   : 2026-08-03 22:50:00 (UTC)
* 終了   : 2026-08-03 23:00:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260803-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260803-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 8→5→9→5→9→5→9→7
* 開始   : 2026-08-04 00:35:00 (UTC)
* 終了   : 2026-08-04 00:45:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→12→14→10→14→10→14→11→12
* 開始   : 2026-08-04 03:40:00 (UTC)
* 終了   : 2026-08-04 03:50:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.487σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260804-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→12→15→12→15→12→15→12→14
* 開始   : 2026-08-04 04:55:00 (UTC)
* 終了   : 2026-08-04 05:05:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host14-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 22→23→22→22→21→21→23→21→21
* 開始   : 2026-08-04 14:20:00 (UTC)
* 終了   : 2026-08-04 15:10:00 (UTC)
* 現象   : 2026-08-04 15:10:00 (UTC)を境に水準が 14.95から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 20→23→18→21→18→21→18→20
* 開始   : 2026-08-04 14:30:00 (UTC)
* 終了   : 2026-08-04 14:40:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.313σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-035 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260804-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 17→14→12→14→12→13
* 開始   : 2026-08-04 18:20:00 (UTC)
* 終了   : 2026-08-04 18:25:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260804-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260804-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 12→11→7→11→7→11→7→11→8
* 開始   : 2026-08-04 21:30:00 (UTC)
* 終了   : 2026-08-04 21:40:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.6667(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host14-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 8→11→8→11→11→9→9→11→10
* 開始   : 2026-08-05 01:45:00 (UTC)
* 終了   : 2026-08-05 03:10:00 (UTC)
* 現象   : 2026-08-05 03:10:00 (UTC)を境に水準が 14.82から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.917, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 16→13→17→13→…→16→17→14→13
* 開始   : 2026-08-05 05:45:00 (UTC)
* 終了   : 2026-08-05 06:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260805-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 15→18→16→18→16→18→15
* 開始   : 2026-08-05 06:15:00 (UTC)
* 終了   : 2026-08-05 06:25:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.602σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260805-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 18→19→22→19→22→19→22→21→20
* 開始   : 2026-08-05 08:50:00 (UTC)
* 終了   : 2026-08-05 09:00:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 20→21→23→21→23→22
* 開始   : 2026-08-05 09:50:00 (UTC)
* 終了   : 2026-08-05 09:55:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260805-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host14-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 22→19→24→21
* 開始   : 2026-08-05 14:25:00 (UTC)
* 終了   : 2026-08-05 14:40:00 (UTC)
* 現象   : 2026-08-05 14:40:00 (UTC)を境に水準が 14.99から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.961, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host14-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 17→15→13→15→14→14→15
* 開始   : 2026-08-05 18:15:00 (UTC)
* 終了   : 2026-08-05 18:45:00 (UTC)
* 現象   : 2026-08-05 18:45:00 (UTC)を境に水準が 14.99から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→10→8→7→…→8→7→11→12
* 開始   : 2026-08-05 20:35:00 (UTC)
* 終了   : 2026-08-05 20:40:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-063 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260805-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 12→13→7→9→7→9→7→11→9
* 開始   : 2026-08-05 20:55:00 (UTC)
* 終了   : 2026-08-05 21:05:00 (UTC)
* 現象   : 平常時(11)に対し 0.6364(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.789σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260805-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260805-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host14-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 12→10→8→10→8→10→8
* 開始   : 2026-08-05 21:00:00 (UTC)
* 終了   : 2026-08-05 21:05:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260805-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 9→10→13→9→10→13→9→11
* 開始   : 2026-08-06 03:10:00 (UTC)
* 終了   : 2026-08-06 03:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→10→14→10→14→10→14→11→12
* 開始   : 2026-08-06 03:50:00 (UTC)
* 終了   : 2026-08-06 04:00:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.371σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260806-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260806-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 14→12→16→13→16→13→16→15→14
* 開始   : 2026-08-06 05:30:00 (UTC)
* 終了   : 2026-08-06 05:40:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260806-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host14-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 23→21→20
* 開始   : 2026-08-06 09:15:00 (UTC)
* 終了   : 2026-08-06 09:25:00 (UTC)
* 現象   : 2026-08-06 09:25:00 (UTC)を境に水準が 15.11から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.153, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 24→22→25→22→…→22→19→20→22
* 開始   : 2026-08-06 11:05:00 (UTC)
* 終了   : 2026-08-06 11:15:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-037 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-036 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260806-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host14-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 16→13→13→14→14→13→12→12→15
* 開始   : 2026-08-06 18:55:00 (UTC)
* 終了   : 2026-08-06 19:50:00 (UTC)
* 現象   : 2026-08-06 19:50:00 (UTC)を境に水準が 14.99から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→10→15→16→10→15→16→13
* 開始   : 2026-08-07 05:25:00 (UTC)
* 終了   : 2026-08-07 06:15:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742倍(10)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260807-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260807-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260807-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→17→14→17→14→15
* 開始   : 2026-08-07 05:35:00 (UTC)
* 終了   : 2026-08-07 05:40:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.291倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.659σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host14-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260807-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260807-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 17→20→18→17→20→18→15
* 開始   : 2026-08-07 07:25:00 (UTC)
* 終了   : 2026-08-07 07:30:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.257倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.847σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260807-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 19→20→23→21→…→21→24→18→21
* 開始   : 2026-08-07 09:45:00 (UTC)
* 終了   : 2026-08-07 09:55:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host14-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 22→20→17→24→23→20→17→24→23
* 開始   : 2026-08-07 09:55:00 (UTC)
* 終了   : 2026-08-07 10:00:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.8193(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.602σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host14-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260807-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 21→19→17→20→17→20→17→20→19
* 開始   : 2026-08-07 15:15:00 (UTC)
* 終了   : 2026-08-07 15:25:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host14-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 22→18→17→19→16→17→19→16→18
* 開始   : 2026-08-07 15:20:00 (UTC)
* 終了   : 2026-08-07 15:30:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host14-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 17→15→13→15→…→15→12→15→14
* 開始   : 2026-08-07 18:20:00 (UTC)
* 終了   : 2026-08-07 18:30:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host14-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260807-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→10→13→10→13→11
* 開始   : 2026-08-07 19:50:00 (UTC)
* 終了   : 2026-08-07 19:55:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-077 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 11→12→9→8→…→9→8→10→13
* 開始   : 2026-08-07 20:20:00 (UTC)
* 終了   : 2026-08-07 20:25:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-079 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-080 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host14-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 10→11→9→10→…→9→10→12→11
* 開始   : 2026-08-08 19:45:00 (UTC)
* 終了   : 2026-08-08 19:50:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.758, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分

![EVT-20260808-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host14-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 11→9→9→9→9→8→10
* 開始   : 2026-08-09 00:35:00 (UTC)
* 終了   : 2026-08-09 01:05:00 (UTC)
* 現象   : 2026-08-09 01:05:00 (UTC)を境に水準が 11.96から11.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host14-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→14→15→16→13→18
* 開始   : 2026-08-09 08:10:00 (UTC)
* 終了   : 2026-08-09 08:35:00 (UTC)
* 現象   : 2026-08-09 08:35:00 (UTC)を境に水準が 11.83から12.49へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→13→17→11→…→17→11→15→13
* 開始   : 2026-08-09 09:15:00 (UTC)
* 終了   : 2026-08-09 09:20:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260809-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 18→15→12→15→18→12→15→18→13
* 開始   : 2026-08-09 11:35:00 (UTC)
* 終了   : 2026-08-09 11:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260809-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→16→10→14→10→14→10→15→12
* 開始   : 2026-08-09 16:45:00 (UTC)
* 終了   : 2026-08-09 16:55:00 (UTC)
* 現象   : 平常時(14)に対し 0.7143(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.794σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260809-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260809-lsfhost01-041 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260809-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260809-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260809-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 9→11→14→10→14→10→14→9→8
* 開始   : 2026-08-09 20:05:00 (UTC)
* 終了   : 2026-08-09 20:15:00 (UTC)
* 現象   : 日曜20時台の平常値(9.49)に対し 14であった
* 説明   : ALG-A1: 移動平均からの残差が 2.685σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.273σ 外れた (平常値=9.49)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260809-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260809-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260809-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260809-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260809-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 6→8→11→5→…→11→5→6→8
* 開始   : 2026-08-10 00:00:00 (UTC)
* 終了   : 2026-08-10 00:05:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260810-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host14-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 9→12→11→9→8→11→10→8→10
* 開始   : 2026-08-10 20:55:00 (UTC)
* 終了   : 2026-08-10 22:20:00 (UTC)
* 現象   : 2026-08-10 22:20:00 (UTC)を境に水準が 14.71から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 8→7→11→8→…→8→5→9→8
* 開始   : 2026-08-11 00:00:00 (UTC)
* 終了   : 2026-08-11 00:10:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260810-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260811-lsfhost01-001 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260810-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 8→5→10→11→5→10→11→8
* 開始   : 2026-08-11 02:10:00 (UTC)
* 終了   : 2026-08-11 02:20:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-009 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260811-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→13→16→13→16→15
* 開始   : 2026-08-11 05:25:00 (UTC)
* 終了   : 2026-08-11 05:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260811-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260811-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→18→19→18→19→18→15
* 開始   : 2026-08-11 07:05:00 (UTC)
* 終了   : 2026-08-11 07:10:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260811-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host14-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 22→22→22→23→24→21→23
* 開始   : 2026-08-11 12:25:00 (UTC)
* 終了   : 2026-08-11 12:55:00 (UTC)
* 現象   : 2026-08-11 12:55:00 (UTC)を境に水準が 15.06から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 21→23→17→19→23→17→19→18
* 開始   : 2026-08-11 15:45:00 (UTC)
* 終了   : 2026-08-11 15:50:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.8361(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→16→12→14→…→14→11→12→13
* 開始   : 2026-08-11 18:55:00 (UTC)
* 終了   : 2026-08-11 19:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host14-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260811-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260811-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→12→13→14→14→12→13→13→13
* 開始   : 2026-08-11 19:00:00 (UTC)
* 終了   : 2026-08-11 20:00:00 (UTC)
* 現象   : 2026-08-11 20:00:00 (UTC)を境に水準が 15.06から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.169, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 8→7→11→5→7→11→5→7→9
* 開始   : 2026-08-11 23:20:00 (UTC)
* 終了   : 2026-08-11 23:25:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.14σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 10→7→4→8→…→8→11→9→8
* 開始   : 2026-08-12 00:45:00 (UTC)
* 終了   : 2026-08-12 00:55:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.4948(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.847σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-003 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260811-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分

![EVT-20260812-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host14-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 10→10→9→10→9→10→7→12→10
* 開始   : 2026-08-12 01:00:00 (UTC)
* 終了   : 2026-08-12 02:10:00 (UTC)
* 現象   : 2026-08-12 02:10:00 (UTC)を境に水準が 14.89から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.912, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→14→15→11→15→11→15→14
* 開始   : 2026-08-12 04:35:00 (UTC)
* 終了   : 2026-08-12 04:45:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-013 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260812-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host14-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 20→20→21→20→18→20→22
* 開始   : 2026-08-12 07:50:00 (UTC)
* 終了   : 2026-08-12 08:20:00 (UTC)
* 現象   : 2026-08-12 08:20:00 (UTC)を境に水準が 15.03から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 19→16→20→16→20→16→19→18
* 開始   : 2026-08-12 16:10:00 (UTC)
* 終了   : 2026-08-12 16:20:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host14-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260812-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260812-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 15→17→13→16→17→13→16→18
* 開始   : 2026-08-12 17:50:00 (UTC)
* 終了   : 2026-08-12 17:55:00 (UTC)
* 現象   : 平常時(17)に対し 0.7647(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.789σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 17→15→13→12→15→13→12→15→14
* 開始   : 2026-08-12 18:10:00 (UTC)
* 終了   : 2026-08-12 18:15:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260812-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 8→5→11→9→8→5→11→9→10
* 開始   : 2026-08-13 00:25:00 (UTC)
* 終了   : 2026-08-13 00:30:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260813-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 14→17→19→20→…→19→20→18→16
* 開始   : 2026-08-13 07:05:00 (UTC)
* 終了   : 2026-08-13 07:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260813-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 16→17→15→16→…→16→14→17→18
* 開始   : 2026-08-13 17:10:00 (UTC)
* 終了   : 2026-08-13 17:20:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host14-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 10→9→10→11→8→10→10→13→12
* 開始   : 2026-08-14 02:15:00 (UTC)
* 終了   : 2026-08-14 03:25:00 (UTC)
* 現象   : 2026-08-14 03:25:00 (UTC)を境に水準が 14.9から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.764, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 10→6→12→11→10→6→12→11→12
* 開始   : 2026-08-14 02:45:00 (UTC)
* 終了   : 2026-08-14 02:50:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260814-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 13→14→16→12→16→12→16→13
* 開始   : 2026-08-14 04:30:00 (UTC)
* 終了   : 2026-08-14 05:15:00 (UTC)
* 現象   : 平常時(12)に対し 0.75倍(9)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host14-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260814-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260814-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260814-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→13→15→14→…→14→16→14→12
* 開始   : 2026-08-14 04:45:00 (UTC)
* 終了   : 2026-08-14 04:55:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host14-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260814-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 18→18→18→18→20→21→18
* 開始   : 2026-08-14 07:15:00 (UTC)
* 終了   : 2026-08-14 07:45:00 (UTC)
* 現象   : 2026-08-14 07:45:00 (UTC)を境に水準が 15から14.55へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 19→20→22→23→…→19→22→23→19
* 開始   : 2026-08-14 09:00:00 (UTC)
* 終了   : 2026-08-14 09:10:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260814-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host14-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 24→21→22→21→23→21→23→24→24
* 開始   : 2026-08-14 13:00:00 (UTC)
* 終了   : 2026-08-14 13:45:00 (UTC)
* 現象   : 2026-08-14 13:45:00 (UTC)を境に水準が 15.1から13.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.881, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host14-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 17→19→16→19→15→14→16→17→18
* 開始   : 2026-08-14 17:00:00 (UTC)
* 終了   : 2026-08-14 17:45:00 (UTC)
* 現象   : 2026-08-14 17:45:00 (UTC)を境に水準が 15.02から12.24へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.843, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host14-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 10→12→10→10→12
* 開始   : 2026-08-14 21:30:00 (UTC)
* 終了   : 2026-08-14 21:50:00 (UTC)
* 現象   : 2026-08-14 21:50:00 (UTC)を境に水準が 15.07から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host14-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host14-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 9→6→8→11→9→6→8→11→10
* 開始   : 2026-08-15 20:35:00 (UTC)
* 終了   : 2026-08-15 20:40:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(6)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.095, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-lsfhost01-058 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260815-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260815-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260815-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 7→8→5→9→…→9→11→10→6
* 開始   : 2026-08-15 23:45:00 (UTC)
* 終了   : 2026-08-15 23:55:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260815-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 8→7→5→11→…→5→11→8→9
* 開始   : 2026-08-16 01:35:00 (UTC)
* 終了   : 2026-08-16 01:40:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→7→5→11→…→5→11→8→10
* 開始   : 2026-08-16 01:55:00 (UTC)
* 終了   : 2026-08-16 02:00:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 10→8→13→11→8→13→11
* 開始   : 2026-08-16 04:25:00 (UTC)
* 終了   : 2026-08-16 04:30:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 14→18→15→12→18→15→12→17→15
* 開始   : 2026-08-16 11:10:00 (UTC)
* 終了   : 2026-08-16 11:20:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260816-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→12→10→13→10→13→10→13
* 開始   : 2026-08-16 16:50:00 (UTC)
* 終了   : 2026-08-16 17:00:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.7273(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host14-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→11→10→11→10→10→10→10→14
* 開始   : 2026-08-17 02:55:00 (UTC)
* 終了   : 2026-08-17 03:35:00 (UTC)
* 現象   : 2026-08-17 03:35:00 (UTC)を境に水準が 11.76から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host14-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 18→18→18→17→20
* 開始   : 2026-08-18 06:50:00 (UTC)
* 終了   : 2026-08-18 07:10:00 (UTC)
* 現象   : 2026-08-18 07:10:00 (UTC)を境に水準が 14.93から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.921, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 18→17→21→15→…→16→21→18→17
* 開始   : 2026-08-18 07:25:00 (UTC)
* 終了   : 2026-08-18 07:45:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.891σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260818-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 19→15→20→18→…→18→21→20→18
* 開始   : 2026-08-18 07:50:00 (UTC)
* 終了   : 2026-08-18 08:00:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260818-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host02-006 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260818-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 21→24→20→24→20→24→21→20
* 開始   : 2026-08-18 09:40:00 (UTC)
* 終了   : 2026-08-18 09:50:00 (UTC)
* 現象   : 平常時(20.25)に対し 1.185倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.627σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260818-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260818-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 22→21→24→23→…→23→18→22→23
* 開始   : 2026-08-18 10:30:00 (UTC)
* 終了   : 2026-08-18 10:40:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.18倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260818-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→16→13→18→16→13→18→14
* 開始   : 2026-08-18 18:00:00 (UTC)
* 終了   : 2026-08-18 18:05:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 17→15→17→16
* 開始   : 2026-08-18 18:00:00 (UTC)
* 終了   : 2026-08-18 19:10:00 (UTC)
* 現象   : 2026-08-18 19:10:00 (UTC)を境に水準が 14.98から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 15→12→9→11→12→9→11
* 開始   : 2026-08-18 20:20:00 (UTC)
* 終了   : 2026-08-18 20:25:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.7297(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260818-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→8→6→10→6→10→6→7→9
* 開始   : 2026-08-18 22:20:00 (UTC)
* 終了   : 2026-08-18 22:30:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.6154(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.601σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host14-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260818-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host14-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 9→8→6→7→8→6→7
* 開始   : 2026-08-18 22:30:00 (UTC)
* 終了   : 2026-08-18 22:35:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.313σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host14-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host14-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host14-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 9→7→9→9→10→9→8→9→12
* 開始   : 2026-08-18 22:55:00 (UTC)
* 終了   : 2026-08-18 23:40:00 (UTC)
* 現象   : 2026-08-18 23:40:00 (UTC)を境に水準が 15.05から14.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.881, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 11→10→12→6→…→12→6→8→7
* 開始   : 2026-08-18 23:10:00 (UTC)
* 終了   : 2026-08-18 23:15:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 11→12→14→11→…→11→15→11→12
* 開始   : 2026-08-19 04:20:00 (UTC)
* 終了   : 2026-08-19 04:30:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260819-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 19→16→19→16→19
* 開始   : 2026-08-19 16:00:00 (UTC)
* 終了   : 2026-08-19 16:05:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 8→10→6→7→6→7→6→7→10
* 開始   : 2026-08-19 22:05:00 (UTC)
* 終了   : 2026-08-19 22:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host03-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-077 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260819-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 8→9→12→10→9→12→10→9
* 開始   : 2026-08-20 02:45:00 (UTC)
* 終了   : 2026-08-20 02:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.487σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 15→14→17→14→17→14→15
* 開始   : 2026-08-20 06:00:00 (UTC)
* 終了   : 2026-08-20 06:55:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260820-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 20 分
  - EVT-20260820-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host02-005 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260820-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 18→21→18→21→18→21→17→21
* 開始   : 2026-08-20 08:20:00 (UTC)
* 終了   : 2026-08-20 08:30:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 21→22→25→19→…→25→19→20→21
* 開始   : 2026-08-20 11:15:00 (UTC)
* 終了   : 2026-08-20 11:20:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.158倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.371σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260820-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host14-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 23→22→22→21→21→20→22→22→23
* 開始   : 2026-08-20 13:25:00 (UTC)
* 終了   : 2026-08-20 14:10:00 (UTC)
* 現象   : 2026-08-20 14:10:00 (UTC)を境に水準が 15.02から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.843, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 18→14→17→14→17→14→15→16
* 開始   : 2026-08-20 17:10:00 (UTC)
* 終了   : 2026-08-20 17:20:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.785(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.69σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-047 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-048 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host14-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 12→14→10→11→14→10→11→13
* 開始   : 2026-08-20 19:45:00 (UTC)
* 終了   : 2026-08-20 19:50:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host14-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 11→13→9→10→13→9→10
* 開始   : 2026-08-20 20:05:00 (UTC)
* 終了   : 2026-08-20 20:10:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host14-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 10→8→9→10→8→9
* 開始   : 2026-08-20 20:45:00 (UTC)
* 終了   : 2026-08-20 20:50:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host14-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 14→15→18→17→…→18→17→13→14
* 開始   : 2026-08-21 05:50:00 (UTC)
* 終了   : 2026-08-21 05:55:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.309倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.948σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260821-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 16→15→19→16→15→19→16→17
* 開始   : 2026-08-21 07:15:00 (UTC)
* 終了   : 2026-08-21 07:20:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 18→20→23→19→23→19→23→22→21
* 開始   : 2026-08-21 08:00:00 (UTC)
* 終了   : 2026-08-21 09:15:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-032 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260821-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260821-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 18→19→16→21→19→16→21→19
* 開始   : 2026-08-21 15:35:00 (UTC)
* 終了   : 2026-08-21 15:40:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.8136(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.543σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260821-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 14→14→15→15→13→13
* 開始   : 2026-08-21 19:00:00 (UTC)
* 終了   : 2026-08-21 19:45:00 (UTC)
* 現象   : 2026-08-21 19:45:00 (UTC)を境に水準が 14.96から11.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.744σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.941, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 14→10→9→11→14→10→9→11→13
* 開始   : 2026-08-21 19:45:00 (UTC)
* 終了   : 2026-08-21 19:50:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260821-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 12→9→8→10→7→8→10→7→12
* 開始   : 2026-08-22 20:05:00 (UTC)
* 終了   : 2026-08-22 20:15:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host14-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260822-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260822-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260822-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 9→7→11→6→7→11→6→7
* 開始   : 2026-08-22 20:50:00 (UTC)
* 終了   : 2026-08-22 21:00:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260822-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260822-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260822-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 7→11→10→12→11→10→12→10→8
* 開始   : 2026-08-23 02:15:00 (UTC)
* 終了   : 2026-08-23 02:25:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.198σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260823-lsfhost01-006 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260823-lsfhost01-007 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260823-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 16→18→13→16→…→16→19→16→17
* 開始   : 2026-08-23 12:20:00 (UTC)
* 終了   : 2026-08-23 12:30:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260823-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260823-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host14-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→16→16→15→15→15
* 開始   : 2026-08-23 14:20:00 (UTC)
* 終了   : 2026-08-23 14:45:00 (UTC)
* 現象   : 2026-08-23 14:45:00 (UTC)を境に水準が 11.72から14.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.306, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host14-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 9→9→8→11→10→7→10→10→9
* 開始   : 2026-08-23 21:00:00 (UTC)
* 終了   : 2026-08-23 21:50:00 (UTC)
* 現象   : 2026-08-23 21:50:00 (UTC)を境に水準が 11.75から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 8→9→6→9→6→9→6→8
* 開始   : 2026-08-23 21:15:00 (UTC)
* 終了   : 2026-08-23 21:25:00 (UTC)
* 現象   : 平常時(10)に対し 0.6(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.807σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260823-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260823-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 9→11→5→8→…→8→12→9→6
* 開始   : 2026-08-23 22:05:00 (UTC)
* 終了   : 2026-08-23 22:15:00 (UTC)
* 現象   : 平常時(9)に対し 0.5556(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.774σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260823-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260823-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 11→11→10→9→7→8→9→8→10
* 開始   : 2026-08-24 21:10:00 (UTC)
* 終了   : 2026-08-24 23:40:00 (UTC)
* 現象   : 2026-08-24 23:40:00 (UTC)を境に水準が 14.73から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.544, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 13→18→16→18→…→15→19→16→18
* 開始   : 2026-08-25 06:35:00 (UTC)
* 終了   : 2026-08-25 06:55:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.602σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260825-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260825-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260825-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 17→19→17→19→17→19
* 開始   : 2026-08-25 07:05:00 (UTC)
* 終了   : 2026-08-25 07:10:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.428σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 17→18→15→14→…→15→14→16→14
* 開始   : 2026-08-25 17:20:00 (UTC)
* 終了   : 2026-08-25 17:25:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host14-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260825-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 17→16→13→15→13→15→13→15→13
* 開始   : 2026-08-25 18:05:00 (UTC)
* 終了   : 2026-08-25 18:15:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7879(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.428σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260825-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host14-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 9→10→12→9→6→12→9→6→10
* 開始   : 2026-08-26 02:10:00 (UTC)
* 終了   : 2026-08-26 02:20:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260826-host14-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 10→8→12→10→8→12→10
* 開始   : 2026-08-26 02:25:00 (UTC)
* 終了   : 2026-08-26 02:30:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→14→13→12→14→13
* 開始   : 2026-08-26 04:05:00 (UTC)
* 終了   : 2026-08-26 04:10:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.313σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260826-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 15→15→13→15→14→15→16→17→18
* 開始   : 2026-08-26 05:05:00 (UTC)
* 終了   : 2026-08-26 06:55:00 (UTC)
* 現象   : 2026-08-26 06:55:00 (UTC)を境に水準が 15.06から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.89σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.839, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 21→22→23→21→24→23→21→24→19
* 開始   : 2026-08-26 09:55:00 (UTC)
* 終了   : 2026-08-26 10:05:00 (UTC)
* 現象   : 平常時(20)に対し 1.15倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.082σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host14-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 24→20→18→21→18→21→18→21→22
* 開始   : 2026-08-26 14:30:00 (UTC)
* 終了   : 2026-08-26 14:40:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8213(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.717σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 19→17→19→18
* 開始   : 2026-08-26 16:55:00 (UTC)
* 終了   : 2026-08-26 17:40:00 (UTC)
* 現象   : 2026-08-26 17:40:00 (UTC)を境に水準が 15.02から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.152, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 15→17→19→17→19→17→18
* 開始   : 2026-08-27 07:00:00 (UTC)
* 終了   : 2026-08-27 07:05:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.198σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host14-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 20→21→20→21→19
* 開始   : 2026-08-27 08:15:00 (UTC)
* 終了   : 2026-08-27 08:20:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260827-host14-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_1
* 値     : 20→23→20→23→20→21
* 開始   : 2026-08-27 09:55:00 (UTC)
* 終了   : 2026-08-27 10:00:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260827-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_3
* 値     : 22→23→24→25→…→24→25→21→22
* 開始   : 2026-08-27 10:25:00 (UTC)
* 終了   : 2026-08-27 10:30:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260827-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host14-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 19→16→15→19→…→16→15→18→16
* 開始   : 2026-08-27 16:20:00 (UTC)
* 終了   : 2026-08-27 16:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host14-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host14-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 16→19→15→17→19→15→17→19
* 開始   : 2026-08-27 16:35:00 (UTC)
* 終了   : 2026-08-27 16:40:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260827-host14-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host14-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 17→14→17→15→14→15→13→14→13
* 開始   : 2026-08-27 17:30:00 (UTC)
* 終了   : 2026-08-27 19:15:00 (UTC)
* 現象   : 2026-08-27 19:15:00 (UTC)を境に水準が 14.93から15.26へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.337, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host14-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host14-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 13→14→11→14→11→14→13
* 開始   : 2026-08-27 19:10:00 (UTC)
* 終了   : 2026-08-27 19:15:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.7416(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.659σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host14-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_6
* 値     : 8→9→12→13→…→12→13→8→10
* 開始   : 2026-08-28 03:10:00 (UTC)
* 終了   : 2026-08-28 03:15:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260828-host14-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 15→17→15→18→17→15→18→16→15
* 開始   : 2026-08-28 06:05:00 (UTC)
* 終了   : 2026-08-28 06:15:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260828-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host14-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 19→18→19→18→18→20→17→17→19
* 開始   : 2026-08-28 06:50:00 (UTC)
* 終了   : 2026-08-28 07:30:00 (UTC)
* 現象   : 2026-08-28 07:30:00 (UTC)を境に水準が 15.03から14.49へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.543σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.459, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host14-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_2
* 値     : 21→24→24→24→22
* 開始   : 2026-08-28 11:35:00 (UTC)
* 終了   : 2026-08-28 11:55:00 (UTC)
* 現象   : 2026-08-28 11:55:00 (UTC)を境に水準が 15.04から13.53へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.921, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host14-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 25→24→24→23→23→22→22→24→22
* 開始   : 2026-08-28 12:05:00 (UTC)
* 終了   : 2026-08-28 13:15:00 (UTC)
* 現象   : 2026-08-28 13:15:00 (UTC)を境に水準が 15.22から13.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.321, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host14-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_5
* 値     : 21→23→21→20→22
* 開始   : 2026-08-28 15:10:00 (UTC)
* 終了   : 2026-08-28 15:30:00 (UTC)
* 現象   : 2026-08-28 15:30:00 (UTC)を境に水準が 15.26から12.46へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host14-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 17→15→17→15→17
* 開始   : 2026-08-28 16:45:00 (UTC)
* 終了   : 2026-08-28 16:50:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.8(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.602σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host14-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host14-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host14, port=7003, datasource=OraclePool_4
* 値     : 12→13→11→14→…→14→10→12→13
* 開始   : 2026-08-28 19:25:00 (UTC)
* 終了   : 2026-08-28 19:35:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host14-017 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
