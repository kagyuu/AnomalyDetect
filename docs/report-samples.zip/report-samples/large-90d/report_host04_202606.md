# host04 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host04 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 311 (SEVERE: 19, FATAL: 129, WARN: 163, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 19 | 129 | 163 | 311 | ALG-A1, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→13→17→15→…→16→14→13→12
* 開始   : 2026-06-08 02:00:00 (UTC)
* 終了   : 2026-06-08 21:00:00 (UTC)
* 現象   : 2026-06-08 21:00:00 (UTC)を境に水準が 11.92から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.672, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.467, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host04-001 active_connections の推移](charts/EVT-20260608-host04-001.svg)

# イベントID( EVT-20260608-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 16→15→16→14→…→13→12→14→13
* 開始   : 2026-06-08 02:10:00 (UTC)
* 終了   : 2026-06-08 20:00:00 (UTC)
* 現象   : 2026-06-08 20:00:00 (UTC)を境に水準が 11.68から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.322, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host04-002 active_connections の推移](charts/EVT-20260608-host04-002.svg)

# イベントID( EVT-20260608-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→15→…→17→13→12→14
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 20:20:00 (UTC)
* 現象   : 2026-06-08 20:20:00 (UTC)を境に水準が 11.85から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.742σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.299, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.265, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host04-003 active_connections の推移](charts/EVT-20260608-host04-003.svg)

# イベントID( EVT-20260608-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→17→14→13→…→12→14→12→13
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 21:15:00 (UTC)
* 現象   : 2026-06-08 21:15:00 (UTC)を境に水準が 11.83から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.932, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.493, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host04-004 active_connections の推移](charts/EVT-20260608-host04-004.svg)

# イベントID( EVT-20260608-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→16→14→16→…→15→13→15→13
* 開始   : 2026-06-08 02:40:00 (UTC)
* 終了   : 2026-06-08 20:10:00 (UTC)
* 現象   : 2026-06-08 20:10:00 (UTC)を境に水準が 11.89から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.878, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.196, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host04-005 active_connections の推移](charts/EVT-20260608-host04-005.svg)

# イベントID( EVT-20260608-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→13→16→14→…→15→12→14→13
* 開始   : 2026-06-08 03:55:00 (UTC)
* 終了   : 2026-06-08 19:45:00 (UTC)
* 現象   : 2026-06-08 19:45:00 (UTC)を境に水準が 11.98から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.702, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host04-006 active_connections の推移](charts/EVT-20260608-host04-006.svg)

# イベントID( EVT-20260615-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→13→16→13→…→13→15→13→15
* 開始   : 2026-06-15 02:15:00 (UTC)
* 終了   : 2026-06-15 21:05:00 (UTC)
* 現象   : 2026-06-15 21:05:00 (UTC)を境に水準が 11.85から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.833, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host04-002 active_connections の推移](charts/EVT-20260615-host04-002.svg)

# イベントID( EVT-20260615-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→16→17→16→…→13→15→11→14
* 開始   : 2026-06-15 02:20:00 (UTC)
* 終了   : 2026-06-15 20:30:00 (UTC)
* 現象   : 2026-06-15 20:30:00 (UTC)を境に水準が 11.93から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.248, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host04-003 active_connections の推移](charts/EVT-20260615-host04-003.svg)

# イベントID( EVT-20260615-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 15→14→16→15→…→12→14→12→14
* 開始   : 2026-06-15 02:55:00 (UTC)
* 終了   : 2026-06-15 22:05:00 (UTC)
* 現象   : 2026-06-15 22:05:00 (UTC)を境に水準が 11.78から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.012, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.532, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host04-005 active_connections の推移](charts/EVT-20260615-host04-005.svg)

# イベントID( EVT-20260615-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→17→14→15→…→11→14→13→12
* 開始   : 2026-06-15 04:20:00 (UTC)
* 終了   : 2026-06-15 19:20:00 (UTC)
* 現象   : 2026-06-15 19:20:00 (UTC)を境に水準が 11.94から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.8, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.761, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host04-007 active_connections の推移](charts/EVT-20260615-host04-007.svg)

# イベントID( EVT-20260622-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→15→14→15→…→13→11→12→10
* 開始   : 2026-06-22 02:05:00 (UTC)
* 終了   : 2026-06-22 19:25:00 (UTC)
* 現象   : 2026-06-22 19:25:00 (UTC)を境に水準が 11.84から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.625σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.814, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.992, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host04-001 active_connections の推移](charts/EVT-20260622-host04-001.svg)

# イベントID( EVT-20260622-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→17→15→18→…→15→14→13→14
* 開始   : 2026-06-22 02:30:00 (UTC)
* 終了   : 2026-06-22 20:50:00 (UTC)
* 現象   : 2026-06-22 20:50:00 (UTC)を境に水準が 11.91から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.812, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.931, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host04-002 active_connections の推移](charts/EVT-20260622-host04-002.svg)

# イベントID( EVT-20260622-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→16→15→16→…→13→14→12→11
* 開始   : 2026-06-22 02:50:00 (UTC)
* 終了   : 2026-06-22 20:00:00 (UTC)
* 現象   : 2026-06-22 20:00:00 (UTC)を境に水準が 11.95から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.707, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host04-003 active_connections の推移](charts/EVT-20260622-host04-003.svg)

# イベントID( EVT-20260622-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→17→12→16→…→13→14→13→12
* 開始   : 2026-06-22 03:20:00 (UTC)
* 終了   : 2026-06-22 20:40:00 (UTC)
* 現象   : 2026-06-22 20:40:00 (UTC)を境に水準が 11.86から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.719, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.943, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host04-005 active_connections の推移](charts/EVT-20260622-host04-005.svg)

# イベントID( EVT-20260622-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 16→18→17→18→…→12→13→12→13
* 開始   : 2026-06-22 03:45:00 (UTC)
* 終了   : 2026-06-22 20:50:00 (UTC)
* 現象   : 2026-06-22 20:50:00 (UTC)を境に水準が 12から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.707σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.679, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.489, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host04-006 active_connections の推移](charts/EVT-20260622-host04-006.svg)

# イベントID( EVT-20260629-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 16→15→17→14→…→17→16→13→14
* 開始   : 2026-06-29 02:40:00 (UTC)
* 終了   : 2026-06-29 21:40:00 (UTC)
* 現象   : 2026-06-29 21:40:00 (UTC)を境に水準が 11.91から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.998, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-003 active_connections の推移](charts/EVT-20260629-host04-003.svg)

# イベントID( EVT-20260629-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→15→14→15→…→14→12→14→11
* 開始   : 2026-06-29 03:00:00 (UTC)
* 終了   : 2026-06-29 20:25:00 (UTC)
* 現象   : 2026-06-29 20:25:00 (UTC)を境に水準が 11.94から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.442σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.93, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.816, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-004 active_connections の推移](charts/EVT-20260629-host04-004.svg)

# イベントID( EVT-20260629-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→14→17→15→…→14→13→12→15
* 開始   : 2026-06-29 03:20:00 (UTC)
* 終了   : 2026-06-29 20:50:00 (UTC)
* 現象   : 2026-06-29 20:50:00 (UTC)を境に水準が 11.75から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.851, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.747, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-005 active_connections の推移](charts/EVT-20260629-host04-005.svg)

# イベントID( EVT-20260629-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→14→17→15→…→13→12→10→12
* 開始   : 2026-06-29 03:35:00 (UTC)
* 終了   : 2026-06-29 21:10:00 (UTC)
* 現象   : 2026-06-29 21:10:00 (UTC)を境に水準が 12.01から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.362σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.755, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-006 active_connections の推移](charts/EVT-20260629-host04-006.svg)

# イベントID( EVT-20260601-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 7→10→14→8→9
* 開始   : 2026-06-01 00:40:00 (UTC)
* 終了   : 2026-06-01 00:40:00 (UTC)
* 現象   : 平常時(8.375)に対し 1.672倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.946σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host04-001 active_connections の推移](charts/EVT-20260601-host04-001.svg)

# イベントID( EVT-20260601-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→12→16→12→12
* 開始   : 2026-06-01 04:30:00 (UTC)
* 終了   : 2026-06-01 04:30:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→13→18→15→15
* 開始   : 2026-06-01 05:35:00 (UTC)
* 終了   : 2026-06-01 05:35:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.412倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.68σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→15→19→15→16
* 開始   : 2026-06-01 06:00:00 (UTC)
* 終了   : 2026-06-01 06:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→17→21→16→16
* 開始   : 2026-06-01 06:50:00 (UTC)
* 終了   : 2026-06-01 06:50:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.362倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.913σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host04-006 active_connections の推移](charts/EVT-20260601-host04-006.svg)

# イベントID( EVT-20260601-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 16→18→22→18→16
* 開始   : 2026-06-01 07:40:00 (UTC)
* 終了   : 2026-06-01 07:40:00 (UTC)
* 現象   : 平常時(17.25)に対し 1.275倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 23→18→25→22→21
* 開始   : 2026-06-01 10:30:00 (UTC)
* 終了   : 2026-06-01 10:30:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 22→23→26→21→22
* 開始   : 2026-06-01 11:20:00 (UTC)
* 終了   : 2026-06-01 11:20:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.13σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 17→16→13→17→…→11→15→12→13
* 開始   : 2026-06-01 18:10:00 (UTC)
* 終了   : 2026-06-01 18:30:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260601-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260601-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→13→10→12→12
* 開始   : 2026-06-01 18:50:00 (UTC)
* 終了   : 2026-06-01 18:50:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→9→11→9→11→9
* 開始   : 2026-06-01 19:25:00 (UTC)
* 終了   : 2026-06-01 20:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-016 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 45 分
  - EVT-20260601-lsfhost01-064 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260601-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260601-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host04-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→12→8→10→11
* 開始   : 2026-06-01 19:50:00 (UTC)
* 終了   : 2026-06-01 19:50:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host04-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→12→16→13→13
* 開始   : 2026-06-02 04:40:00 (UTC)
* 終了   : 2026-06-02 04:40:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→13→16→13→14
* 開始   : 2026-06-02 05:15:00 (UTC)
* 終了   : 2026-06-02 05:15:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260602-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→13→17→15→15
* 開始   : 2026-06-03 05:15:00 (UTC)
* 終了   : 2026-06-03 05:15:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→12→7→11→10
* 開始   : 2026-06-03 20:25:00 (UTC)
* 終了   : 2026-06-03 20:25:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.5676(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.733σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host04-010 active_connections の推移](charts/EVT-20260603-host04-010.svg)

# イベントID( EVT-20260603-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→9→5→9→7
* 開始   : 2026-06-03 22:00:00 (UTC)
* 終了   : 2026-06-03 22:00:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.5085(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.36σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 10→10→14→11→12
* 開始   : 2026-06-04 03:15:00 (UTC)
* 終了   : 2026-06-04 03:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.474倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→12→16→13→13
* 開始   : 2026-06-04 04:30:00 (UTC)
* 終了   : 2026-06-04 04:30:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260604-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 18→18→21→19→19
* 開始   : 2026-06-04 07:25:00 (UTC)
* 終了   : 2026-06-04 07:25:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260604-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 17→14→17→14→17→14→17→16
* 開始   : 2026-06-04 17:00:00 (UTC)
* 終了   : 2026-06-04 17:10:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-049 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 19→17→15→13→…→15→13→16→17
* 開始   : 2026-06-04 17:10:00 (UTC)
* 終了   : 2026-06-04 17:15:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host04-007 active_connections の推移](charts/EVT-20260604-host04-007.svg)

# イベントID( EVT-20260604-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→8→13→9
* 開始   : 2026-06-04 22:20:00 (UTC)
* 終了   : 2026-06-04 22:35:00 (UTC)
* 現象   : 2026-06-04 22:35:00 (UTC)を境に水準が 15.02から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 7→10→14→8→11
* 開始   : 2026-06-05 02:05:00 (UTC)
* 終了   : 2026-06-05 02:05:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.615倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.709σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host04-001 active_connections の推移](charts/EVT-20260605-host04-001.svg)

# イベントID( EVT-20260605-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→13→6→11→11
* 開始   : 2026-06-05 03:40:00 (UTC)
* 終了   : 2026-06-05 03:40:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 21→20→25→22→22
* 開始   : 2026-06-05 09:40:00 (UTC)
* 終了   : 2026-06-05 09:40:00 (UTC)
* 現象   : 平常時(19.92)に対し 1.255倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.533σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→20→15→20→19
* 開始   : 2026-06-05 16:00:00 (UTC)
* 終了   : 2026-06-05 16:00:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.7563(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 15→14→9→11→11
* 開始   : 2026-06-05 19:20:00 (UTC)
* 終了   : 2026-06-05 19:20:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6279(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.742σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host04-014 active_connections の推移](charts/EVT-20260605-host04-014.svg)

# イベントID( EVT-20260606-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 9→10→13→9→9
* 開始   : 2026-06-06 03:35:00 (UTC)
* 終了   : 2026-06-06 03:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host04-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→14→12→14→…→13→14→13→14
* 開始   : 2026-06-06 05:00:00 (UTC)
* 終了   : 2026-06-06 19:15:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.845, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260606-host04-002 active_connections の推移](charts/EVT-20260606-host04-002.svg)

# イベントID( EVT-20260606-host04-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→11→12→14→…→12→13→12→13
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 19:15:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.081, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host04-003 active_connections の推移](charts/EVT-20260606-host04-003.svg)

# イベントID( EVT-20260606-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→11→14→12→…→12→11→13→10
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 18:55:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.811, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260606-host04-004 active_connections の推移](charts/EVT-20260606-host04-004.svg)

# イベントID( EVT-20260606-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→11→…→10→13→11→12
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 18:55:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.318σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.818, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260606-host04-005 active_connections の推移](charts/EVT-20260606-host04-005.svg)

# イベントID( EVT-20260606-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→10→14→9→…→14→11→14→11
* 開始   : 2026-06-06 05:40:00 (UTC)
* 終了   : 2026-06-06 19:10:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.747, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260606-host04-006 active_connections の推移](charts/EVT-20260606-host04-006.svg)

# イベントID( EVT-20260606-host04-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→9→11→12→…→12→9→12→11
* 開始   : 2026-06-06 06:00:00 (UTC)
* 終了   : 2026-06-06 19:30:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.71, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260606-host04-007 active_connections の推移](charts/EVT-20260606-host04-007.svg)

# イベントID( EVT-20260606-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→9→6→10→9
* 開始   : 2026-06-06 20:30:00 (UTC)
* 終了   : 2026-06-06 20:30:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260606-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260606-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260606-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 11→13→17→15→11
* 開始   : 2026-06-07 07:20:00 (UTC)
* 終了   : 2026-06-07 07:20:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.407倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.42σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→11→14→9→11
* 開始   : 2026-06-09 03:30:00 (UTC)
* 終了   : 2026-06-09 03:30:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 20→19→24→22→23
* 開始   : 2026-06-09 09:45:00 (UTC)
* 終了   : 2026-06-09 09:45:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.13σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 21→21→25→20→23
* 開始   : 2026-06-09 10:50:00 (UTC)
* 終了   : 2026-06-09 10:50:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 19→20→17→20→22
* 開始   : 2026-06-09 14:20:00 (UTC)
* 終了   : 2026-06-09 14:20:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7846(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 18→20→15→20→18
* 開始   : 2026-06-09 16:05:00 (UTC)
* 終了   : 2026-06-09 16:05:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→11→9→12→14→11→9→12
* 開始   : 2026-06-09 19:05:00 (UTC)
* 終了   : 2026-06-09 19:10:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host04-011 active_connections の推移](charts/EVT-20260609-host04-011.svg)

# イベントID( EVT-20260609-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→11→7→11→12
* 開始   : 2026-06-09 20:25:00 (UTC)
* 終了   : 2026-06-09 20:25:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.5915(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.36σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 8→11→6→10→11
* 開始   : 2026-06-09 21:25:00 (UTC)
* 終了   : 2026-06-09 21:25:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 14→12→18→14→16
* 開始   : 2026-06-10 05:45:00 (UTC)
* 終了   : 2026-06-10 05:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.376倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host04-005 active_connections の推移](charts/EVT-20260610-host04-005.svg)

# イベントID( EVT-20260610-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→18→17→14→18→17→14→15
* 開始   : 2026-06-10 06:05:00 (UTC)
* 終了   : 2026-06-10 06:30:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260610-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260610-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260610-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→14→19→16→14
* 開始   : 2026-06-10 06:05:00 (UTC)
* 終了   : 2026-06-10 06:05:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.416倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.881σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host04-007 active_connections の推移](charts/EVT-20260610-host04-007.svg)

# イベントID( EVT-20260610-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 17→18→21→16→17
* 開始   : 2026-06-10 07:45:00 (UTC)
* 終了   : 2026-06-10 07:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 19→19→23→18→21
* 開始   : 2026-06-10 08:55:00 (UTC)
* 終了   : 2026-06-10 08:55:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-035 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→11→5→7→8
* 開始   : 2026-06-10 23:00:00 (UTC)
* 終了   : 2026-06-10 23:00:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host04-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→15→18→15→15
* 開始   : 2026-06-11 05:35:00 (UTC)
* 終了   : 2026-06-11 05:35:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.376倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.428σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host04-003 active_connections の推移](charts/EVT-20260611-host04-003.svg)

# イベントID( EVT-20260611-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→15→20→18→14
* 開始   : 2026-06-11 07:00:00 (UTC)
* 終了   : 2026-06-11 07:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 22→21→19→21→…→21→17→22→23
* 開始   : 2026-06-11 13:25:00 (UTC)
* 終了   : 2026-06-11 13:35:00 (UTC)
* 現象   : 平常時(22)に対し 0.8636(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 22→21→17→20→21→17→20→21
* 開始   : 2026-06-11 15:35:00 (UTC)
* 終了   : 2026-06-11 16:35:00 (UTC)
* 現象   : 平常時(20.83)に対し 0.816(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260611-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→13→19→15→16
* 開始   : 2026-06-12 05:35:00 (UTC)
* 終了   : 2026-06-12 05:35:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.471倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.231σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host04-002 active_connections の推移](charts/EVT-20260612-host04-002.svg)

# イベントID( EVT-20260612-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 16→18→21→18→19
* 開始   : 2026-06-12 07:30:00 (UTC)
* 終了   : 2026-06-12 07:30:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.279倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 19→19→23→18→19
* 開始   : 2026-06-12 08:10:00 (UTC)
* 終了   : 2026-06-12 08:10:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.308倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.777σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host04-004 active_connections の推移](charts/EVT-20260612-host04-004.svg)

# イベントID( EVT-20260612-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 22→21→27→22→22
* 開始   : 2026-06-12 12:55:00 (UTC)
* 終了   : 2026-06-12 12:55:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.237倍(27)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.591σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host04-006 active_connections の推移](charts/EVT-20260612-host04-006.svg)

# イベントID( EVT-20260612-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→18→16→16→15→16→16→15→18
* 開始   : 2026-06-12 17:30:00 (UTC)
* 終了   : 2026-06-12 18:45:00 (UTC)
* 現象   : 2026-06-12 18:45:00 (UTC)を境に水準が 14.94から12.16へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.608σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.196, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 9→10→12→10→…→12→11→13→11
* 開始   : 2026-06-13 05:10:00 (UTC)
* 終了   : 2026-06-13 20:30:00 (UTC)
* 現象   : 15.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.961, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260613-host04-001 active_connections の推移](charts/EVT-20260613-host04-001.svg)

# イベントID( EVT-20260613-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→12→11→13→…→11→10→12→11
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 20:15:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.845, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260613-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260613-host04-002 active_connections の推移](charts/EVT-20260613-host04-002.svg)

# イベントID( EVT-20260613-host04-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→11→10→13→…→11→12→14→12
* 開始   : 2026-06-13 05:30:00 (UTC)
* 終了   : 2026-06-13 18:10:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.064, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260613-host04-003 active_connections の推移](charts/EVT-20260613-host04-003.svg)

# イベントID( EVT-20260613-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 11→14→12→11→…→13→14→15→11
* 開始   : 2026-06-13 05:35:00 (UTC)
* 終了   : 2026-06-13 19:40:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.304σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.913, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260613-host04-004 active_connections の推移](charts/EVT-20260613-host04-004.svg)

# イベントID( EVT-20260613-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→10→13→10→…→9→11→13→11
* 開始   : 2026-06-13 06:00:00 (UTC)
* 終了   : 2026-06-13 18:45:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.912, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260613-host04-005 active_connections の推移](charts/EVT-20260613-host04-005.svg)

# イベントID( EVT-20260613-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→12→13→12→…→9→12→13→9
* 開始   : 2026-06-13 06:10:00 (UTC)
* 終了   : 2026-06-13 18:50:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.931, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260613-host04-006 active_connections の推移](charts/EVT-20260613-host04-006.svg)

# イベントID( EVT-20260614-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→12→16→12→13
* 開始   : 2026-06-14 06:45:00 (UTC)
* 終了   : 2026-06-14 06:45:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→11→17→13→14
* 開始   : 2026-06-14 07:15:00 (UTC)
* 終了   : 2026-06-14 07:15:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.378倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→8→4→7→8
* 開始   : 2026-06-15 00:35:00 (UTC)
* 終了   : 2026-06-15 00:35:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260615-lsfhost01-001 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260615-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host04-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→14→16→14→…→12→15→12→13
* 開始   : 2026-06-15 02:25:00 (UTC)
* 終了   : 2026-06-15 19:25:00 (UTC)
* 現象   : 2026-06-15 19:25:00 (UTC)を境に水準が 11.89から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.878, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.7, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→17→16→15→…→13→12→14→13
* 開始   : 2026-06-15 03:00:00 (UTC)
* 終了   : 2026-06-15 20:40:00 (UTC)
* 現象   : 2026-06-15 20:40:00 (UTC)を境に水準が 11.91から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.022, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→11→16→14→16→14→16→13
* 開始   : 2026-06-16 05:05:00 (UTC)
* 終了   : 2026-06-16 05:15:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260616-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→15→17→13→15
* 開始   : 2026-06-16 05:40:00 (UTC)
* 終了   : 2026-06-16 05:40:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 21→19→25→20→21
* 開始   : 2026-06-16 09:30:00 (UTC)
* 終了   : 2026-06-16 09:30:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.261倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.593σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 8→9→12→5→9
* 開始   : 2026-06-17 00:35:00 (UTC)
* 終了   : 2026-06-17 00:35:00 (UTC)
* 現象   : 平常時(7.167)に対し 1.674倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→12→14→10→10
* 開始   : 2026-06-17 03:30:00 (UTC)
* 終了   : 2026-06-17 03:30:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 17→15→20→16→16
* 開始   : 2026-06-17 06:50:00 (UTC)
* 終了   : 2026-06-17 06:50:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.326倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host04-006 active_connections の推移](charts/EVT-20260617-host04-006.svg)

# イベントID( EVT-20260617-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→13→11→14→17
* 開始   : 2026-06-17 17:55:00 (UTC)
* 終了   : 2026-06-17 17:55:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→15→12→13→…→13→10→15→14
* 開始   : 2026-06-17 18:40:00 (UTC)
* 終了   : 2026-06-17 18:50:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→11→7→12→11
* 開始   : 2026-06-17 20:20:00 (UTC)
* 終了   : 2026-06-17 20:20:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.56(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.855σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-077 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host04-013 active_connections の推移](charts/EVT-20260617-host04-013.svg)

# イベントID( EVT-20260617-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 9→12→4→9→9
* 開始   : 2026-06-17 21:45:00 (UTC)
* 終了   : 2026-06-17 21:45:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.3967(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host04-014 active_connections の推移](charts/EVT-20260617-host04-014.svg)

# イベントID( EVT-20260618-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→12→11→11→9→15
* 開始   : 2026-06-18 02:50:00 (UTC)
* 終了   : 2026-06-18 03:15:00 (UTC)
* 現象   : 2026-06-18 03:15:00 (UTC)を境に水準が 14.97から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.591σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.98, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→15→21→15→17
* 開始   : 2026-06-18 06:30:00 (UTC)
* 終了   : 2026-06-18 06:30:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.44倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host04-006 active_connections の推移](charts/EVT-20260618-host04-006.svg)

# イベントID( EVT-20260618-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 20→20→25→19→21
* 開始   : 2026-06-18 09:50:00 (UTC)
* 終了   : 2026-06-18 09:50:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 20→21→26→18→…→26→18→23→20
* 開始   : 2026-06-18 13:50:00 (UTC)
* 終了   : 2026-06-18 13:55:00 (UTC)
* 現象   : 平常時(21.25)に対し 1.224倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260618-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→11→13→15→…→10→14→11→12
* 開始   : 2026-06-19 04:20:00 (UTC)
* 終了   : 2026-06-19 05:40:00 (UTC)
* 現象   : 1.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260619-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260619-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分

![EVT-20260619-host04-001 active_connections の推移](charts/EVT-20260619-host04-001.svg)

# イベントID( EVT-20260619-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→16→18→17→13
* 開始   : 2026-06-19 06:05:00 (UTC)
* 終了   : 2026-06-19 06:05:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 18→18→22→19→18
* 開始   : 2026-06-19 07:35:00 (UTC)
* 終了   : 2026-06-19 07:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.32倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.709σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host04-005 active_connections の推移](charts/EVT-20260619-host04-005.svg)

# イベントID( EVT-20260620-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 9→9→13→11→9
* 開始   : 2026-06-20 03:00:00 (UTC)
* 終了   : 2026-06-20 03:00:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host04-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 14→11→12→14→…→11→12→13→12
* 開始   : 2026-06-20 05:10:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.128, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.9 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260620-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260620-host04-002 active_connections の推移](charts/EVT-20260620-host04-002.svg)

# イベントID( EVT-20260620-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 16→13→14→11→…→11→12→14→11
* 開始   : 2026-06-20 05:15:00 (UTC)
* 終了   : 2026-06-20 19:00:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.072σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.99, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host04-003 active_connections の推移](charts/EVT-20260620-host04-003.svg)

# イベントID( EVT-20260620-host04-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→10→12→10→…→12→11→12→11
* 開始   : 2026-06-20 05:35:00 (UTC)
* 終了   : 2026-06-20 18:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.914, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260620-host04-004 active_connections の推移](charts/EVT-20260620-host04-004.svg)

# イベントID( EVT-20260620-host04-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→11→13→11→…→11→13→12→11
* 開始   : 2026-06-20 05:35:00 (UTC)
* 終了   : 2026-06-20 19:15:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.9, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260620-host04-005 active_connections の推移](charts/EVT-20260620-host04-005.svg)

# イベントID( EVT-20260620-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→11→14→11→…→14→12→13→12
* 開始   : 2026-06-20 05:40:00 (UTC)
* 終了   : 2026-06-20 18:00:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.906, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260620-host04-006 active_connections の推移](charts/EVT-20260620-host04-006.svg)

# イベントID( EVT-20260620-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→12→14→12→…→12→11→12→11
* 開始   : 2026-06-20 06:25:00 (UTC)
* 終了   : 2026-06-20 18:35:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.428σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.171, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260620-host04-007 active_connections の推移](charts/EVT-20260620-host04-007.svg)

# イベントID( EVT-20260621-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→12→17→14→13
* 開始   : 2026-06-21 07:35:00 (UTC)
* 終了   : 2026-06-21 07:35:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 14→16→10→15→15
* 開始   : 2026-06-21 15:35:00 (UTC)
* 終了   : 2026-06-21 15:35:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host11-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host04-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→14→17→14→…→14→10→13→11
* 開始   : 2026-06-22 02:55:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 11.83から14.94へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.819, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.992, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 8→9→13→12→11
* 開始   : 2026-06-23 02:15:00 (UTC)
* 終了   : 2026-06-23 02:15:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 9→8→13→11→7
* 開始   : 2026-06-23 02:40:00 (UTC)
* 終了   : 2026-06-23 02:40:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 14→15→19→15→12
* 開始   : 2026-06-23 05:55:00 (UTC)
* 終了   : 2026-06-23 05:55:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.382倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host04-003 active_connections の推移](charts/EVT-20260623-host04-003.svg)

# イベントID( EVT-20260623-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 23→24→18→22→20
* 開始   : 2026-06-23 12:15:00 (UTC)
* 終了   : 2026-06-23 12:15:00 (UTC)
* 現象   : 平常時(22.67)に対し 0.7941(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.246σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→12→9→13→13
* 開始   : 2026-06-23 19:35:00 (UTC)
* 終了   : 2026-06-23 19:35:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 22→23→26→24→23
* 開始   : 2026-06-24 12:30:00 (UTC)
* 終了   : 2026-06-24 12:30:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-041 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260624-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 17→16→12→15→15
* 開始   : 2026-06-24 17:35:00 (UTC)
* 終了   : 2026-06-24 17:35:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7129(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host04-009 active_connections の推移](charts/EVT-20260624-host04-009.svg)

# イベントID( EVT-20260625-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 19→21→26→21→22
* 開始   : 2026-06-25 10:15:00 (UTC)
* 終了   : 2026-06-25 10:15:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.258倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.707σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260625-host04-007 active_connections の推移](charts/EVT-20260625-host04-007.svg)

# イベントID( EVT-20260626-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 9→9→4→9→9
* 開始   : 2026-06-26 01:15:00 (UTC)
* 終了   : 2026-06-26 01:15:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→7→13→10→8
* 開始   : 2026-06-26 02:45:00 (UTC)
* 終了   : 2026-06-26 02:45:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→12→15→12→12
* 開始   : 2026-06-26 04:05:00 (UTC)
* 終了   : 2026-06-26 04:05:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→12→9→12→11
* 開始   : 2026-06-26 19:20:00 (UTC)
* 終了   : 2026-06-26 19:20:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→14→8→13→11
* 開始   : 2026-06-26 19:40:00 (UTC)
* 終了   : 2026-06-26 19:40:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.5926(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.835σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host04-013 active_connections の推移](charts/EVT-20260626-host04-013.svg)

# イベントID( EVT-20260627-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→12→9→15→…→13→12→13→12
* 開始   : 2026-06-27 05:20:00 (UTC)
* 終了   : 2026-06-27 18:35:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.218, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host04-002 active_connections の推移](charts/EVT-20260627-host04-002.svg)

# イベントID( EVT-20260627-host04-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→12→11→12→…→11→10→11→13
* 開始   : 2026-06-27 05:25:00 (UTC)
* 終了   : 2026-06-27 19:05:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.007, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260627-host04-003 active_connections の推移](charts/EVT-20260627-host04-003.svg)

# イベントID( EVT-20260627-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→12→13→12→…→13→11→13→10
* 開始   : 2026-06-27 05:35:00 (UTC)
* 終了   : 2026-06-27 18:15:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.943, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260627-host04-004 active_connections の推移](charts/EVT-20260627-host04-004.svg)

# イベントID( EVT-20260627-host04-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→11→12→11→…→12→10→13→12
* 開始   : 2026-06-27 05:45:00 (UTC)
* 終了   : 2026-06-27 18:35:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.933, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host04-005 active_connections の推移](charts/EVT-20260627-host04-005.svg)

# イベントID( EVT-20260627-host04-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→14→10→12→…→9→15→14→11
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 19:20:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.375, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host04-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host04-006 active_connections の推移](charts/EVT-20260627-host04-006.svg)

# イベントID( EVT-20260627-host04-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→11→12→13→…→10→9→12→10
* 開始   : 2026-06-27 06:25:00 (UTC)
* 終了   : 2026-06-27 19:15:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.886, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host04-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host04-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host04-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host04-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host04-007 active_connections の推移](charts/EVT-20260627-host04-007.svg)

# イベントID( EVT-20260627-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→8→5→10→8
* 開始   : 2026-06-27 20:55:00 (UTC)
* 終了   : 2026-06-27 20:55:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→11→19→15→11→19→15→14
* 開始   : 2026-06-28 15:00:00 (UTC)
* 終了   : 2026-06-28 15:05:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260628-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 14→15→12→10→12→10→11→13
* 開始   : 2026-06-28 16:20:00 (UTC)
* 終了   : 2026-06-28 16:30:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260628-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 7→6→12→6→10
* 開始   : 2026-06-28 23:10:00 (UTC)
* 終了   : 2026-06-28 23:10:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host04-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→14→15→14→…→15→13→14→15
* 開始   : 2026-06-29 04:05:00 (UTC)
* 終了   : 2026-06-29 21:10:00 (UTC)
* 現象   : 2026-06-29 21:10:00 (UTC)を境に水準が 11.98から15.13へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.089, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host04-008 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 14→13→16→13→…→13→12→13→11
* 開始   : 2026-06-29 04:20:00 (UTC)
* 終了   : 2026-06-29 19:30:00 (UTC)
* 現象   : 2026-06-29 19:30:00 (UTC)を境に水準が 12.05から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.04, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-008 active_connections の推移](charts/EVT-20260629-host04-008.svg)

# イベントID( EVT-20260630-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→14→17→11→15
* 開始   : 2026-06-30 05:15:00 (UTC)
* 終了   : 2026-06-30 05:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→14→17→16→…→17→16→15→16
* 開始   : 2026-06-30 05:35:00 (UTC)
* 終了   : 2026-06-30 05:40:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260630-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 17→17→21→17→17
* 開始   : 2026-06-30 07:15:00 (UTC)
* 終了   : 2026-06-30 07:15:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.292倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 18→16→20→22→18→16→20→22→18
* 開始   : 2026-06-30 07:45:00 (UTC)
* 終了   : 2026-06-30 07:50:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 20→16→14→16→17
* 開始   : 2026-06-30 16:35:00 (UTC)
* 終了   : 2026-06-30 16:35:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 17→16→13→14→…→13→14→17→15
* 開始   : 2026-06-30 17:25:00 (UTC)
* 終了   : 2026-06-30 17:30:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260630-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 7→8→12→7→…→12→7→6→10
* 開始   : 2026-06-01 02:05:00 (UTC)
* 終了   : 2026-06-01 02:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260601-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→14→19→18→19→18→19→18
* 開始   : 2026-06-01 06:55:00 (UTC)
* 終了   : 2026-06-01 07:05:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260601-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260601-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 15→16→19→20→16→19→20→16→17
* 開始   : 2026-06-01 07:15:00 (UTC)
* 終了   : 2026-06-01 07:20:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 19→22→24→23→24→23→24→21
* 開始   : 2026-06-01 10:05:00 (UTC)
* 終了   : 2026-06-01 10:15:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.171倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260601-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 19→20→16→17→19→20→16→17→19
* 開始   : 2026-06-02 15:40:00 (UTC)
* 終了   : 2026-06-02 15:45:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.7934(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.905σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host04-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 20→20→18→20→19→18→18→16→20
* 開始   : 2026-06-02 15:50:00 (UTC)
* 終了   : 2026-06-02 16:55:00 (UTC)
* 現象   : 2026-06-02 16:55:00 (UTC)を境に水準が 15.09から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.06, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 13→12→13→12→13→11→12→14→10
* 開始   : 2026-06-02 19:10:00 (UTC)
* 終了   : 2026-06-02 20:35:00 (UTC)
* 現象   : 2026-06-02 20:35:00 (UTC)を境に水準が 14.99から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.87, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 10→9→5→8→…→8→11→8→10
* 開始   : 2026-06-02 23:50:00 (UTC)
* 終了   : 2026-06-03 00:00:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 10→13→12→11→11→13→12
* 開始   : 2026-06-03 03:10:00 (UTC)
* 終了   : 2026-06-03 03:40:00 (UTC)
* 現象   : 2026-06-03 03:40:00 (UTC)を境に水準が 14.9から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.747, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→15→15→17→16→16→17→17→18
* 開始   : 2026-06-03 05:35:00 (UTC)
* 終了   : 2026-06-03 06:30:00 (UTC)
* 現象   : 2026-06-03 06:30:00 (UTC)を境に水準が 14.99から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.112, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→17→16→13→17→16→17
* 開始   : 2026-06-03 06:05:00 (UTC)
* 終了   : 2026-06-03 06:10:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260603-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 18→17→20→15→20→15→20→18→17
* 開始   : 2026-06-03 07:25:00 (UTC)
* 終了   : 2026-06-03 07:35:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260603-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 19→17→20→21→17→20→21→17
* 開始   : 2026-06-03 07:55:00 (UTC)
* 終了   : 2026-06-03 08:00:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260603-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 25→22→22→24→24→23→23→22→23
* 開始   : 2026-06-03 12:10:00 (UTC)
* 終了   : 2026-06-03 12:55:00 (UTC)
* 現象   : 2026-06-03 12:55:00 (UTC)を境に水準が 15.15から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.332, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 21→20→24→18→…→24→18→21→19
* 開始   : 2026-06-03 14:40:00 (UTC)
* 終了   : 2026-06-03 14:45:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→16→13→16→13→16→15
* 開始   : 2026-06-03 18:05:00 (UTC)
* 終了   : 2026-06-03 18:10:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→11→8→9→11→8→9→8
* 開始   : 2026-06-03 21:10:00 (UTC)
* 終了   : 2026-06-03 21:15:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-078 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260603-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 9→6→12→9→6→12→9→7
* 開始   : 2026-06-03 22:25:00 (UTC)
* 終了   : 2026-06-03 22:30:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-082 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→6→8→9→6→8→7
* 開始   : 2026-06-03 22:30:00 (UTC)
* 終了   : 2026-06-03 22:35:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host04-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→17→19→17→19→17→19→17→18
* 開始   : 2026-06-04 06:55:00 (UTC)
* 終了   : 2026-06-04 07:05:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 24→21→22→22→24→24→24→21→22
* 開始   : 2026-06-04 12:20:00 (UTC)
* 終了   : 2026-06-04 13:20:00 (UTC)
* 現象   : 2026-06-04 13:20:00 (UTC)を境に水準が 14.98から15.17へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→10→11→13→10→11→12
* 開始   : 2026-06-04 19:45:00 (UTC)
* 終了   : 2026-06-04 19:50:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260604-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host04-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 13→14→12→10→12→11→12→11
* 開始   : 2026-06-04 19:55:00 (UTC)
* 終了   : 2026-06-04 20:30:00 (UTC)
* 現象   : 2026-06-04 20:30:00 (UTC)を境に水準が 14.96から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.87, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 9→10→12→13→12→10→12→13→12
* 開始   : 2026-06-05 03:10:00 (UTC)
* 終了   : 2026-06-05 03:15:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→10→14→12→10→14→12
* 開始   : 2026-06-05 04:10:00 (UTC)
* 終了   : 2026-06-05 04:15:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 13→11→15→13→15→13→15→14→11
* 開始   : 2026-06-05 04:30:00 (UTC)
* 終了   : 2026-06-05 04:40:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.385倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.896σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→14→15→12→11→14→15→12→13
* 開始   : 2026-06-05 04:30:00 (UTC)
* 終了   : 2026-06-05 04:35:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→16→18→16→18→16
* 開始   : 2026-06-05 06:20:00 (UTC)
* 終了   : 2026-06-05 06:25:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260605-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 20→21→24→22→21→24→22→21
* 開始   : 2026-06-05 11:25:00 (UTC)
* 終了   : 2026-06-05 11:30:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-042 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260605-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 20→19→17→16→…→17→16→18→21
* 開始   : 2026-06-05 15:45:00 (UTC)
* 終了   : 2026-06-05 15:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 18→15→18→18→15→16→18→17
* 開始   : 2026-06-05 17:35:00 (UTC)
* 終了   : 2026-06-05 18:10:00 (UTC)
* 現象   : 2026-06-05 18:10:00 (UTC)を境に水準が 15.11から12.17へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.304, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→17→14→13→…→14→13→15→16
* 開始   : 2026-06-05 17:50:00 (UTC)
* 終了   : 2026-06-05 17:55:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host04-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 14→12→10→11→10→11→10→11→12
* 開始   : 2026-06-05 19:25:00 (UTC)
* 終了   : 2026-06-05 19:35:00 (UTC)
* 現象   : 平常時(14)に対し 0.7143(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.803σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host04-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 11→11→10→9→9→9→9→10→12
* 開始   : 2026-06-07 01:50:00 (UTC)
* 終了   : 2026-06-07 03:50:00 (UTC)
* 現象   : 2026-06-07 03:50:00 (UTC)を境に水準が 11.75から11.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.401, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 9→10→12→13→…→12→13→11→9
* 開始   : 2026-06-07 03:50:00 (UTC)
* 終了   : 2026-06-07 03:55:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host04-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260607-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 7→9→12→8→9→12→8→11
* 開始   : 2026-06-07 03:55:00 (UTC)
* 終了   : 2026-06-07 04:00:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.15σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host04-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260607-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→16→11→16→11→16→13
* 開始   : 2026-06-07 07:30:00 (UTC)
* 終了   : 2026-06-07 07:40:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260607-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host04-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 17→15→18→17→18→17
* 開始   : 2026-06-07 10:15:00 (UTC)
* 終了   : 2026-06-07 10:40:00 (UTC)
* 現象   : 2026-06-07 10:40:00 (UTC)を境に水準が 11.86から13.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host04-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→16→17→17→17→18
* 開始   : 2026-06-07 13:20:00 (UTC)
* 終了   : 2026-06-07 13:45:00 (UTC)
* 現象   : 2026-06-07 13:45:00 (UTC)を境に水準が 11.92から13.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.056, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→11→15→10→…→10→9→11→10
* 開始   : 2026-06-07 18:35:00 (UTC)
* 終了   : 2026-06-07 18:45:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260607-lsfhost01-038 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260607-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→12→8→10→…→10→7→11→9
* 開始   : 2026-06-08 21:10:00 (UTC)
* 終了   : 2026-06-08 21:20:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260608-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260608-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 6→8→12→11→8→12→11→9
* 開始   : 2026-06-09 01:20:00 (UTC)
* 終了   : 2026-06-09 01:25:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.532倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.898σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-003 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260609-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→17→18→15→17→18→15→16
* 開始   : 2026-06-09 06:05:00 (UTC)
* 終了   : 2026-06-09 06:10:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260609-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 15→18→15→18→…→15→18→17→14
* 開始   : 2026-06-09 06:10:00 (UTC)
* 終了   : 2026-06-09 06:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260609-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260609-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 19→20→16→18→20→16→18
* 開始   : 2026-06-09 15:40:00 (UTC)
* 終了   : 2026-06-09 15:45:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.8101(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.607σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 19→20→16→19→20→16→19→18
* 開始   : 2026-06-09 15:45:00 (UTC)
* 終了   : 2026-06-09 15:50:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.8101(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.631σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 6→8→11→7→11→7→11→9
* 開始   : 2026-06-10 01:25:00 (UTC)
* 終了   : 2026-06-10 01:35:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.483倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→11→12→11→12→11→9
* 開始   : 2026-06-10 03:15:00 (UTC)
* 終了   : 2026-06-10 03:20:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 11→10→13→10→13→10→11
* 開始   : 2026-06-10 03:20:00 (UTC)
* 終了   : 2026-06-10 03:25:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260610-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→11→15→13→…→15→16→15→12
* 開始   : 2026-06-10 05:00:00 (UTC)
* 終了   : 2026-06-10 05:20:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 20 分
  - EVT-20260610-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260610-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260610-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 17→15→19→16→15→19→16→17
* 開始   : 2026-06-10 06:55:00 (UTC)
* 終了   : 2026-06-10 07:00:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.511σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260610-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 16→17→19→17→19→17→19→18→16
* 開始   : 2026-06-10 07:00:00 (UTC)
* 終了   : 2026-06-10 07:10:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.246倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.631σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260610-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 22→23→19→24→19→24→19→22
* 開始   : 2026-06-10 11:50:00 (UTC)
* 終了   : 2026-06-10 12:00:00 (UTC)
* 現象   : 平常時(22)に対し 0.8636(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 21→20→19→19→19→21→20
* 開始   : 2026-06-10 15:35:00 (UTC)
* 終了   : 2026-06-10 16:05:00 (UTC)
* 現象   : 2026-06-10 16:05:00 (UTC)を境に水準が 14.99から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 17→21→16→19→16→19→16→21→18
* 開始   : 2026-06-10 15:55:00 (UTC)
* 終了   : 2026-06-10 16:05:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 17→19→16→20→…→20→15→17→18
* 開始   : 2026-06-10 16:30:00 (UTC)
* 終了   : 2026-06-10 16:40:00 (UTC)
* 現象   : 平常時(19)に対し 0.8421(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260610-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host04-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 11→13→9→12→13→9→12→13
* 開始   : 2026-06-10 20:10:00 (UTC)
* 終了   : 2026-06-10 20:15:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host04-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host04-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 12→13→8→11→8→11→8→11→10
* 開始   : 2026-06-10 20:35:00 (UTC)
* 終了   : 2026-06-10 20:45:00 (UTC)
* 現象   : 平常時(12)に対し 0.6667(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.8σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host04-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→8→10→9→10→8→9→9→10
* 開始   : 2026-06-11 00:50:00 (UTC)
* 終了   : 2026-06-11 01:35:00 (UTC)
* 現象   : 2026-06-11 01:35:00 (UTC)を境に水準が 14.94から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.495, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→16→12→17→16→12→17→12→14
* 開始   : 2026-06-11 05:20:00 (UTC)
* 終了   : 2026-06-11 05:30:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260611-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 19→18→20→21→…→19→20→21→19
* 開始   : 2026-06-11 08:10:00 (UTC)
* 終了   : 2026-06-11 08:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260611-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 23→21→23→21→23→23→21→23→24
* 開始   : 2026-06-11 10:15:00 (UTC)
* 終了   : 2026-06-11 11:00:00 (UTC)
* 現象   : 2026-06-11 11:00:00 (UTC)を境に水準が 15.04から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.495, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 22→20→25→21→18→25→21→18→21
* 開始   : 2026-06-11 14:30:00 (UTC)
* 終了   : 2026-06-11 14:40:00 (UTC)
* 現象   : 平常時(21.75)に対し 1.149倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 17→14→15→17→14→15
* 開始   : 2026-06-11 17:30:00 (UTC)
* 終了   : 2026-06-11 17:35:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260611-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 16→13→14→16→13→14
* 開始   : 2026-06-11 17:45:00 (UTC)
* 終了   : 2026-06-11 17:50:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.78(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260611-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 16→13→17→15→14→16→16
* 開始   : 2026-06-11 18:25:00 (UTC)
* 終了   : 2026-06-11 19:10:00 (UTC)
* 現象   : 2026-06-11 19:10:00 (UTC)を境に水準が 14.96から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.839σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 17→15→12→13→12→13→12→15→14
* 開始   : 2026-06-11 18:40:00 (UTC)
* 終了   : 2026-06-11 18:50:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.511σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260611-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→12→11→12→11→12→15
* 開始   : 2026-06-11 19:05:00 (UTC)
* 終了   : 2026-06-11 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 9→8→11→8→11→8→11→8→9
* 開始   : 2026-06-12 01:55:00 (UTC)
* 終了   : 2026-06-12 02:05:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-006 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260612-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 20→22→23→24→…→23→24→20→22
* 開始   : 2026-06-12 09:30:00 (UTC)
* 終了   : 2026-06-12 09:35:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→14→12→11→14→12→11→14
* 開始   : 2026-06-12 18:55:00 (UTC)
* 終了   : 2026-06-12 19:00:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-082 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 13→15→10→9→…→10→9→11→12
* 開始   : 2026-06-12 19:55:00 (UTC)
* 終了   : 2026-06-12 20:00:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.222σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 9→8→6→9→…→9→12→8→10
* 開始   : 2026-06-13 22:30:00 (UTC)
* 終了   : 2026-06-13 22:40:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260613-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260613-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host04-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→12→10→11→12→12→12→11→13
* 開始   : 2026-06-14 19:20:00 (UTC)
* 終了   : 2026-06-14 20:00:00 (UTC)
* 現象   : 2026-06-14 20:00:00 (UTC)を境に水準が 11.87から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.58, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→9→6→8→6→8→6→8→10
* 開始   : 2026-06-14 20:45:00 (UTC)
* 終了   : 2026-06-14 20:55:00 (UTC)
* 現象   : 平常時(9.667)に対し 0.6207(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260614-lsfhost01-042 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260614-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→10→9→9→10→8→10→10→10
* 開始   : 2026-06-15 21:30:00 (UTC)
* 終了   : 2026-06-15 23:20:00 (UTC)
* 現象   : 2026-06-15 23:20:00 (UTC)を境に水準が 14.74から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 11→10→6→12→10→6→12→10→12
* 開始   : 2026-06-16 02:20:00 (UTC)
* 終了   : 2026-06-16 02:25:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 16→15→19→17→20→19→17→20→17
* 開始   : 2026-06-16 07:20:00 (UTC)
* 終了   : 2026-06-16 07:30:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260616-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 16→18→15→16→18→15→16→17
* 開始   : 2026-06-16 16:40:00 (UTC)
* 終了   : 2026-06-16 16:45:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 17→15→13→12→13→15→13→12→13
* 開始   : 2026-06-16 18:10:00 (UTC)
* 終了   : 2026-06-16 18:15:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260616-host12-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→13→9→11→…→11→15→11→10
* 開始   : 2026-06-16 20:10:00 (UTC)
* 終了   : 2026-06-16 20:20:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.7297(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260616-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host04-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 8→10→7→11→9→8→9→10
* 開始   : 2026-06-16 23:50:00 (UTC)
* 終了   : 2026-06-17 00:25:00 (UTC)
* 現象   : 2026-06-17 00:25:00 (UTC)を境に水準が 14.95から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.87, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 7→9→11→8→9→11→8
* 開始   : 2026-06-17 00:50:00 (UTC)
* 終了   : 2026-06-17 00:55:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.483倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 14→14→15→13→13→14→14→15→16
* 開始   : 2026-06-17 04:45:00 (UTC)
* 終了   : 2026-06-17 05:30:00 (UTC)
* 現象   : 2026-06-17 05:30:00 (UTC)を境に水準が 14.98から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 12→17→14→17→14→17→16
* 開始   : 2026-06-17 05:50:00 (UTC)
* 終了   : 2026-06-17 06:00:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.316倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.862σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 20→20→22→19→21→20→22→21→23
* 開始   : 2026-06-17 08:30:00 (UTC)
* 終了   : 2026-06-17 09:35:00 (UTC)
* 現象   : 2026-06-17 09:35:00 (UTC)を境に水準が 14.93から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.493, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→20→15→16→20→15→16→18
* 開始   : 2026-06-17 16:50:00 (UTC)
* 終了   : 2026-06-17 16:55:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.8036(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-012 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260617-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 16→17→14→17→13→14→17→13→15
* 開始   : 2026-06-17 17:30:00 (UTC)
* 終了   : 2026-06-17 17:40:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host04-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 16→14→14→14→17→15
* 開始   : 2026-06-17 18:10:00 (UTC)
* 終了   : 2026-06-17 18:35:00 (UTC)
* 現象   : 2026-06-17 18:35:00 (UTC)を境に水準が 15.09から15.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.056, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 10→13→9→13→9→13→12
* 開始   : 2026-06-18 03:25:00 (UTC)
* 終了   : 2026-06-18 03:35:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.393倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260618-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host04-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 13→13→15→13→14→15
* 開始   : 2026-06-18 04:35:00 (UTC)
* 終了   : 2026-06-18 05:00:00 (UTC)
* 現象   : 2026-06-18 05:00:00 (UTC)を境に水準が 15.06から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→16→16→15→18→19→16→17→20
* 開始   : 2026-06-18 05:50:00 (UTC)
* 終了   : 2026-06-18 07:40:00 (UTC)
* 現象   : 2026-06-18 07:40:00 (UTC)を境に水準が 15.02から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.749, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 16→18→17→19→18→17→19→17→15
* 開始   : 2026-06-18 06:30:00 (UTC)
* 終了   : 2026-06-18 06:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→16→19→15→19→15→19→18→19
* 開始   : 2026-06-18 06:55:00 (UTC)
* 終了   : 2026-06-18 07:05:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 18→20→22→20→22→20→22→19→22
* 開始   : 2026-06-18 08:50:00 (UTC)
* 終了   : 2026-06-18 09:00:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260618-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 18→20→22→18→…→18→23→20→19
* 開始   : 2026-06-18 08:55:00 (UTC)
* 終了   : 2026-06-18 09:30:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host04-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 23→22→24→21→21→24→21→22→24
* 開始   : 2026-06-18 11:05:00 (UTC)
* 終了   : 2026-06-18 12:00:00 (UTC)
* 現象   : 2026-06-18 12:00:00 (UTC)を境に水準が 15.02から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.994, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 19→20→16→17→20→16→17→18
* 開始   : 2026-06-18 16:15:00 (UTC)
* 終了   : 2026-06-18 16:20:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.8101(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.607σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 8→7→5→11→8→7→5→11→8
* 開始   : 2026-06-18 23:10:00 (UTC)
* 終了   : 2026-06-18 23:15:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 12→13→15→11→…→16→14→16→14
* 開始   : 2026-06-19 04:55:00 (UTC)
* 終了   : 2026-06-19 05:15:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.029σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260619-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260619-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→18→16→18→16→18→17→16
* 開始   : 2026-06-19 06:25:00 (UTC)
* 終了   : 2026-06-19 06:35:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.615σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260619-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 22→23→24→22→24→22→24→23→22
* 開始   : 2026-06-19 10:05:00 (UTC)
* 終了   : 2026-06-19 10:15:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 22→23→22
* 開始   : 2026-06-19 14:45:00 (UTC)
* 終了   : 2026-06-19 14:55:00 (UTC)
* 現象   : 2026-06-19 14:55:00 (UTC)を境に水準が 14.96から12.71へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.749, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 19→14→17→14→…→17→14→15→18
* 開始   : 2026-06-19 17:10:00 (UTC)
* 終了   : 2026-06-19 17:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.789σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260619-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260619-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260619-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 14→15→11→13→…→13→10→12→13
* 開始   : 2026-06-19 19:25:00 (UTC)
* 終了   : 2026-06-19 20:05:00 (UTC)
* 現象   : 平常時(14)に対し 0.7857(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host15-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 9→11→12→11→11→11
* 開始   : 2026-06-21 03:30:00 (UTC)
* 終了   : 2026-06-21 03:55:00 (UTC)
* 現象   : 2026-06-21 03:55:00 (UTC)を境に水準が 11.76から11.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host04-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→11→12→13→14→13→14
* 開始   : 2026-06-21 05:10:00 (UTC)
* 終了   : 2026-06-21 05:40:00 (UTC)
* 現象   : 2026-06-21 05:40:00 (UTC)を境に水準が 11.94から12.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.141, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 16→15→18→15→…→15→19→15→18
* 開始   : 2026-06-21 10:10:00 (UTC)
* 終了   : 2026-06-21 10:20:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→10→12→14→10→12→14
* 開始   : 2026-06-21 17:05:00 (UTC)
* 終了   : 2026-06-21 17:10:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7186(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.731σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260621-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260621-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 8→11→6→10→…→10→13→10→8
* 開始   : 2026-06-21 21:05:00 (UTC)
* 終了   : 2026-06-21 21:15:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.492σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 22→23→22→21→23→25→20→23→23
* 開始   : 2026-06-23 10:45:00 (UTC)
* 終了   : 2026-06-23 11:30:00 (UTC)
* 現象   : 2026-06-23 11:30:00 (UTC)を境に水準が 14.87から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 19→20→17→23→…→17→23→19→21
* 開始   : 2026-06-23 15:15:00 (UTC)
* 終了   : 2026-06-23 15:20:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 18→16→20→18→16→20→19
* 開始   : 2026-06-23 16:10:00 (UTC)
* 終了   : 2026-06-23 16:15:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 16→17→21→14→17→21→14→17→18
* 開始   : 2026-06-23 16:55:00 (UTC)
* 終了   : 2026-06-23 17:00:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 17→16→14→16→14→16
* 開始   : 2026-06-23 17:40:00 (UTC)
* 終了   : 2026-06-23 18:05:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260623-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260623-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260623-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 12→12→11→13→11→13→13→14→14
* 開始   : 2026-06-24 03:55:00 (UTC)
* 終了   : 2026-06-24 04:55:00 (UTC)
* 現象   : 2026-06-24 04:55:00 (UTC)を境に水準が 15から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 12→13→16→17→14→13→16→17→14
* 開始   : 2026-06-24 05:15:00 (UTC)
* 終了   : 2026-06-24 05:20:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 13→14→16→15→…→15→17→15→11
* 開始   : 2026-06-24 05:25:00 (UTC)
* 終了   : 2026-06-24 05:35:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260624-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 17→16→21→20→21→20→21→20→17
* 開始   : 2026-06-24 08:05:00 (UTC)
* 終了   : 2026-06-24 08:15:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.376σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260624-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 22→18→21→24→18→21→24→22→20
* 開始   : 2026-06-24 09:50:00 (UTC)
* 終了   : 2026-06-24 10:00:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-038 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-040 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260624-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 25→23→24→23→24→23
* 開始   : 2026-06-24 12:40:00 (UTC)
* 終了   : 2026-06-24 13:55:00 (UTC)
* 現象   : 2026-06-24 13:55:00 (UTC)を境に水準が 14.93から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.91, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 21→20→24→18→…→24→18→19→20
* 開始   : 2026-06-24 14:15:00 (UTC)
* 終了   : 2026-06-24 14:20:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-046 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260624-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 16→15→12→15→12→15→12→13
* 開始   : 2026-06-24 18:20:00 (UTC)
* 終了   : 2026-06-24 18:30:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 14→13→11→12→13→11→12
* 開始   : 2026-06-24 19:20:00 (UTC)
* 終了   : 2026-06-24 19:25:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 12→11→8→10→8→10→8→11
* 開始   : 2026-06-24 20:20:00 (UTC)
* 終了   : 2026-06-24 20:30:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.6621(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.847σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260624-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→12→8→10→…→10→7→9→8
* 開始   : 2026-06-24 21:05:00 (UTC)
* 終了   : 2026-06-24 21:15:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260624-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260624-host10-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 10→7→5→7→5→9→5→9
* 開始   : 2026-06-24 22:55:00 (UTC)
* 終了   : 2026-06-24 23:05:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260624-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 8→9→5→11→…→5→11→6→9
* 開始   : 2026-06-25 00:40:00 (UTC)
* 終了   : 2026-06-25 00:45:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 9→8→5→7→12→5→7→12→9
* 開始   : 2026-06-25 01:05:00 (UTC)
* 終了   : 2026-06-25 01:15:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 9→7→12→9→…→9→6→9→11
* 開始   : 2026-06-25 02:35:00 (UTC)
* 終了   : 2026-06-25 02:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260625-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 11→13→10→13→10→13→11→10
* 開始   : 2026-06-25 03:30:00 (UTC)
* 終了   : 2026-06-25 03:40:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260625-host04-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 16→18→13→16→20→13→16→20→17
* 開始   : 2026-06-25 07:00:00 (UTC)
* 終了   : 2026-06-25 07:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host04-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 21→19→23→21→19→23→21→22
* 開始   : 2026-06-25 09:40:00 (UTC)
* 終了   : 2026-06-25 09:45:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260625-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 22→21→25→19→21→25→19→21→22
* 開始   : 2026-06-25 13:40:00 (UTC)
* 終了   : 2026-06-25 13:45:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260625-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260625-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 19→20→17→20→17→20
* 開始   : 2026-06-25 15:00:00 (UTC)
* 終了   : 2026-06-25 15:05:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.8193(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.625σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 17→14→16→13→14→16→13→14→15
* 開始   : 2026-06-25 17:40:00 (UTC)
* 終了   : 2026-06-25 17:50:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host04-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260625-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260625-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 16→13→17→13→17→13→14→16
* 開始   : 2026-06-25 17:45:00 (UTC)
* 終了   : 2026-06-25 17:55:00 (UTC)
* 現象   : 平常時(16.83)に対し 0.7723(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.666σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host04-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260625-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260625-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 11→9→13→9→13→9→10
* 開始   : 2026-06-25 20:05:00 (UTC)
* 終了   : 2026-06-25 20:15:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host01-012 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260625-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host04-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host04-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 11→10→10→10→8→10→11
* 開始   : 2026-06-25 21:45:00 (UTC)
* 終了   : 2026-06-25 22:15:00 (UTC)
* 現象   : 2026-06-25 22:15:00 (UTC)を境に水準が 14.89から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host04-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 8→7→11→9→…→9→5→8→6
* 開始   : 2026-06-26 00:35:00 (UTC)
* 終了   : 2026-06-26 00:45:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260626-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→12→9→10→11→11→11→10→9
* 開始   : 2026-06-26 01:50:00 (UTC)
* 終了   : 2026-06-26 02:50:00 (UTC)
* 現象   : 2026-06-26 02:50:00 (UTC)を境に水準が 14.96から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 15→17→16→16→17→17→18→17→18
* 開始   : 2026-06-26 06:00:00 (UTC)
* 終了   : 2026-06-26 07:00:00 (UTC)
* 現象   : 2026-06-26 07:00:00 (UTC)を境に水準が 15.03から14.54へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 15→17→18→17→18→15
* 開始   : 2026-06-26 06:45:00 (UTC)
* 終了   : 2026-06-26 06:50:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 20→21→24→21→…→21→25→21→20
* 開始   : 2026-06-26 10:05:00 (UTC)
* 終了   : 2026-06-26 10:15:00 (UTC)
* 現象   : 平常時(20.75)に対し 1.157倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260626-host04-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 23→19→24→23→19→24→21
* 開始   : 2026-06-26 12:15:00 (UTC)
* 終了   : 2026-06-26 12:20:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 23→24→23→24
* 開始   : 2026-06-26 13:45:00 (UTC)
* 終了   : 2026-06-26 14:00:00 (UTC)
* 現象   : 2026-06-26 14:00:00 (UTC)を境に水準が 15.01から12.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.998, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 15→12→14→15→12→14
* 開始   : 2026-06-26 18:25:00 (UTC)
* 終了   : 2026-06-26 18:30:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分

![EVT-20260626-host04-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 10→7→9→7→9→7→10→7
* 開始   : 2026-06-26 21:55:00 (UTC)
* 終了   : 2026-06-26 22:05:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260626-host04-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host04-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→9→5→8→9→5→8→9
* 開始   : 2026-06-26 23:00:00 (UTC)
* 終了   : 2026-06-26 23:05:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.5714(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.625σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host04-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 8→9→12→6→…→12→6→8→9
* 開始   : 2026-06-27 01:55:00 (UTC)
* 終了   : 2026-06-27 02:00:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 7→11→12→8→7→11→12→8→7
* 開始   : 2026-06-28 01:20:00 (UTC)
* 終了   : 2026-06-28 01:25:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-002 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260628-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host04-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→7→11→6→7→11→6→10
* 開始   : 2026-06-28 02:30:00 (UTC)
* 終了   : 2026-06-28 02:35:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host04-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 14→11→15→17→11→15→17→14
* 開始   : 2026-06-28 09:15:00 (UTC)
* 終了   : 2026-06-28 09:25:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260628-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260628-host04-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host04-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_2
* 値     : 14→14→11→13→12→14→14→10→15
* 開始   : 2026-06-28 16:35:00 (UTC)
* 終了   : 2026-06-28 18:00:00 (UTC)
* 現象   : 2026-06-28 18:00:00 (UTC)を境に水準が 11.87から14.65へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.743, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host04-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_1
* 値     : 10→8→7→10→8→7→10→13
* 開始   : 2026-06-28 19:20:00 (UTC)
* 終了   : 2026-06-28 19:25:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host04-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host04-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_5
* 値     : 10→10→8→10→10
* 開始   : 2026-06-29 01:55:00 (UTC)
* 終了   : 2026-06-29 02:15:00 (UTC)
* 現象   : 2026-06-29 02:15:00 (UTC)を境に水準が 11.89から15.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host04-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 11→9→9→11→10→10→10→11
* 開始   : 2026-06-29 02:00:00 (UTC)
* 終了   : 2026-06-29 02:35:00 (UTC)
* 現象   : 2026-06-29 02:35:00 (UTC)を境に水準が 11.96から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.466, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host04-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 8→6→10→6→10→6→7
* 開始   : 2026-06-29 22:10:00 (UTC)
* 終了   : 2026-06-29 22:20:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.453σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260629-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_4
* 値     : 6→9→11→6→11→6→11→8→6
* 開始   : 2026-06-30 00:30:00 (UTC)
* 終了   : 2026-06-30 00:40:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host04-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 23→25→23→21→22→24→23→23
* 開始   : 2026-06-30 12:05:00 (UTC)
* 終了   : 2026-06-30 12:40:00 (UTC)
* 現象   : 2026-06-30 12:40:00 (UTC)を境に水準が 14.93から15.18へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.996, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host04-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 15→14→16→14
* 開始   : 2026-06-30 18:55:00 (UTC)
* 終了   : 2026-06-30 19:35:00 (UTC)
* 現象   : 2026-06-30 19:35:00 (UTC)を境に水準が 15.06から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.336σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.998, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host04-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_3
* 値     : 11→13→10→9→…→10→9→11→13
* 開始   : 2026-06-30 19:50:00 (UTC)
* 終了   : 2026-06-30 19:55:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.087σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host04-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host04-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host04, port=7003, datasource=OraclePool_6
* 値     : 11→9→8→11→10→10
* 開始   : 2026-06-30 22:00:00 (UTC)
* 終了   : 2026-06-30 22:25:00 (UTC)
* 現象   : 2026-06-30 22:25:00 (UTC)を境に水準が 15.08から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host04-011 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
