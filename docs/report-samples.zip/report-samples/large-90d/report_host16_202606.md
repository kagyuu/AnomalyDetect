# host16 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host16 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 328 (SEVERE: 21, FATAL: 133, WARN: 174, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 21 | 133 | 174 | 328 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→13→15→14→…→16→14→10→15
* 開始   : 2026-06-08 01:55:00 (UTC)
* 終了   : 2026-06-08 19:45:00 (UTC)
* 現象   : 2026-06-08 19:45:00 (UTC)を境に水準が 11.92から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.234σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.97, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.95, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host16-002 active_connections の推移](charts/EVT-20260608-host16-002.svg)

# イベントID( EVT-20260608-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 16→15→16→15→…→13→12→13→12
* 開始   : 2026-06-08 02:45:00 (UTC)
* 終了   : 2026-06-08 19:45:00 (UTC)
* 現象   : 2026-06-08 19:45:00 (UTC)を境に水準が 11.88から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.864σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.751, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host16-003 active_connections の推移](charts/EVT-20260608-host16-003.svg)

# イベントID( EVT-20260608-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→15→17→15→…→13→15→13→12
* 開始   : 2026-06-08 02:45:00 (UTC)
* 終了   : 2026-06-08 18:45:00 (UTC)
* 現象   : 2026-06-08 18:45:00 (UTC)を境に水準が 11.94から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.011, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host16-004 active_connections の推移](charts/EVT-20260608-host16-004.svg)

# イベントID( EVT-20260608-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→15→16→17→…→15→14→12→15
* 開始   : 2026-06-08 02:45:00 (UTC)
* 終了   : 2026-06-08 20:00:00 (UTC)
* 現象   : 2026-06-08 20:00:00 (UTC)を境に水準が 11.9から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.68, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host16-005 active_connections の推移](charts/EVT-20260608-host16-005.svg)

# イベントID( EVT-20260608-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→16→14→16→…→12→13→12→15
* 開始   : 2026-06-08 03:40:00 (UTC)
* 終了   : 2026-06-08 21:20:00 (UTC)
* 現象   : 2026-06-08 21:20:00 (UTC)を境に水準が 12.03から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.655, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.595, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host16-006 active_connections の推移](charts/EVT-20260608-host16-006.svg)

# イベントID( EVT-20260608-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→16→15→16→…→11→12→11→9
* 開始   : 2026-06-08 04:10:00 (UTC)
* 終了   : 2026-06-08 20:05:00 (UTC)
* 現象   : 2026-06-08 20:05:00 (UTC)を境に水準が 11.86から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.007, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.96, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host16-007 active_connections の推移](charts/EVT-20260608-host16-007.svg)

# イベントID( EVT-20260615-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→15→14→16→…→16→15→13→14
* 開始   : 2026-06-15 01:50:00 (UTC)
* 終了   : 2026-06-15 22:05:00 (UTC)
* 現象   : 2026-06-15 22:05:00 (UTC)を境に水準が 11.83から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.499σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.994, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host16-001 active_connections の推移](charts/EVT-20260615-host16-001.svg)

# イベントID( EVT-20260615-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→16→17→16→…→14→17→15→14
* 開始   : 2026-06-15 02:20:00 (UTC)
* 終了   : 2026-06-15 20:40:00 (UTC)
* 現象   : 2026-06-15 20:40:00 (UTC)を境に水準が 11.82から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.866, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.845, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host16-002 active_connections の推移](charts/EVT-20260615-host16-002.svg)

# イベントID( EVT-20260615-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→16→17→16→…→14→16→14→15
* 開始   : 2026-06-15 02:35:00 (UTC)
* 終了   : 2026-06-15 21:05:00 (UTC)
* 現象   : 2026-06-15 21:05:00 (UTC)を境に水準が 11.92から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.293σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.759, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.93, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host16-004 active_connections の推移](charts/EVT-20260615-host16-004.svg)

# イベントID( EVT-20260615-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 16→17→16→17→…→13→15→11→13
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 21:15:00 (UTC)
* 現象   : 2026-06-15 21:15:00 (UTC)を境に水準が 11.87から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.513σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.692, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host16-005 active_connections の推移](charts/EVT-20260615-host16-005.svg)

# イベントID( EVT-20260615-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→14→13→17→…→14→15→14→13
* 開始   : 2026-06-15 03:30:00 (UTC)
* 終了   : 2026-06-15 20:25:00 (UTC)
* 現象   : 2026-06-15 20:25:00 (UTC)を境に水準が 11.91から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.159, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.812, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host16-006 active_connections の推移](charts/EVT-20260615-host16-006.svg)

# イベントID( EVT-20260622-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→17→15→17→…→14→13→10→13
* 開始   : 2026-06-22 02:30:00 (UTC)
* 終了   : 2026-06-22 20:45:00 (UTC)
* 現象   : 2026-06-22 20:45:00 (UTC)を境に水準が 11.85から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.782, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.61, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host16-004 active_connections の推移](charts/EVT-20260622-host16-004.svg)

# イベントID( EVT-20260622-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→15→14→15→…→11→15→14→13
* 開始   : 2026-06-22 02:45:00 (UTC)
* 終了   : 2026-06-22 19:45:00 (UTC)
* 現象   : 2026-06-22 19:45:00 (UTC)を境に水準が 11.92から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.911σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.953, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.028, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host16-005 active_connections の推移](charts/EVT-20260622-host16-005.svg)

# イベントID( EVT-20260622-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→16→17→16→…→15→14→15→12
* 開始   : 2026-06-22 03:10:00 (UTC)
* 終了   : 2026-06-22 21:25:00 (UTC)
* 現象   : 2026-06-22 21:25:00 (UTC)を境に水準が 11.78から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.028, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.187, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host16-006 active_connections の推移](charts/EVT-20260622-host16-006.svg)

# イベントID( EVT-20260622-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 16→17→20→19→…→14→13→14→11
* 開始   : 2026-06-22 03:55:00 (UTC)
* 終了   : 2026-06-22 20:45:00 (UTC)
* 現象   : 2026-06-22 20:45:00 (UTC)を境に水準が 11.91から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.977, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host16-008 active_connections の推移](charts/EVT-20260622-host16-008.svg)

# イベントID( EVT-20260629-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 13→16→17→14→…→13→16→12→13
* 開始   : 2026-06-29 00:15:00 (UTC)
* 終了   : 2026-06-29 22:20:00 (UTC)
* 現象   : 2026-06-29 22:20:00 (UTC)を境に水準が 11.73から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.885, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host16-001 active_connections の推移](charts/EVT-20260629-host16-001.svg)

# イベントID( EVT-20260629-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→15→14→15→…→15→13→14→13
* 開始   : 2026-06-29 01:20:00 (UTC)
* 終了   : 2026-06-29 21:45:00 (UTC)
* 現象   : 2026-06-29 21:45:00 (UTC)を境に水準が 11.78から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.679, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.081, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host16-002 active_connections の推移](charts/EVT-20260629-host16-002.svg)

# イベントID( EVT-20260629-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→17→14→13→…→13→14→15→13
* 開始   : 2026-06-29 01:25:00 (UTC)
* 終了   : 2026-06-29 20:00:00 (UTC)
* 現象   : 2026-06-29 20:00:00 (UTC)を境に水準が 11.83から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.089, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.483, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host16-003 active_connections の推移](charts/EVT-20260629-host16-003.svg)

# イベントID( EVT-20260629-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→17→…→16→17→14→16
* 開始   : 2026-06-29 02:45:00 (UTC)
* 終了   : 2026-06-29 21:05:00 (UTC)
* 現象   : 2026-06-29 21:05:00 (UTC)を境に水準が 11.84から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.004, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.91, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host16-006 active_connections の推移](charts/EVT-20260629-host16-006.svg)

# イベントID( EVT-20260629-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→15→17→18→…→10→13→12→11
* 開始   : 2026-06-29 03:25:00 (UTC)
* 終了   : 2026-06-29 20:00:00 (UTC)
* 現象   : 2026-06-29 20:00:00 (UTC)を境に水準が 11.88から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.763σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.782, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host16-007 active_connections の推移](charts/EVT-20260629-host16-007.svg)

# イベントID( EVT-20260629-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→13→17→15→…→14→16→14→13
* 開始   : 2026-06-29 04:25:00 (UTC)
* 終了   : 2026-06-29 21:25:00 (UTC)
* 現象   : 2026-06-29 21:25:00 (UTC)を境に水準が 11.88から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.131, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host16-008 active_connections の推移](charts/EVT-20260629-host16-008.svg)

# イベントID( EVT-20260601-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→8→4→10→9
* 開始   : 2026-06-01 02:20:00 (UTC)
* 終了   : 2026-06-01 02:20:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.4324(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.682σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host16-001 active_connections の推移](charts/EVT-20260601-host16-001.svg)

# イベントID( EVT-20260601-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 18→17→21→20→18→17→21→20→18
* 開始   : 2026-06-01 07:25:00 (UTC)
* 終了   : 2026-06-01 07:30:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 21→20→25→23→22
* 開始   : 2026-06-01 10:00:00 (UTC)
* 終了   : 2026-06-01 10:00:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.175σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 20→22→24→25→22→24→25→22→23
* 開始   : 2026-06-01 10:15:00 (UTC)
* 終了   : 2026-06-01 10:20:00 (UTC)
* 現象   : 平常時(20.17)に対し 1.19倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.689σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260601-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 22→22→17→21→22
* 開始   : 2026-06-01 14:35:00 (UTC)
* 終了   : 2026-06-01 14:35:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-042 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260601-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 18→17→14→18→16
* 開始   : 2026-06-01 17:10:00 (UTC)
* 終了   : 2026-06-01 17:10:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.057σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-047 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→13→7→12→14
* 開始   : 2026-06-01 19:20:00 (UTC)
* 終了   : 2026-06-01 19:20:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.5185(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.575σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host16-012 active_connections の推移](charts/EVT-20260601-host16-012.svg)

# イベントID( EVT-20260601-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 7→9→5→8→8
* 開始   : 2026-06-01 22:25:00 (UTC)
* 終了   : 2026-06-01 22:25:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 18→18→23→17→21
* 開始   : 2026-06-02 08:35:00 (UTC)
* 終了   : 2026-06-02 08:35:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 20→21→25→19→19
* 開始   : 2026-06-02 09:45:00 (UTC)
* 終了   : 2026-06-02 09:45:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.245倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-039 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260602-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host16-003 active_connections の推移](charts/EVT-20260602-host16-003.svg)

# イベントID( EVT-20260602-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 20→23→17→20→19
* 開始   : 2026-06-02 14:45:00 (UTC)
* 終了   : 2026-06-02 14:45:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→16→12→17→15
* 開始   : 2026-06-02 18:00:00 (UTC)
* 終了   : 2026-06-02 18:00:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7236(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 19→15→17→17→18→16→18→19→17
* 開始   : 2026-06-03 05:05:00 (UTC)
* 終了   : 2026-06-03 07:10:00 (UTC)
* 現象   : 2026-06-03 07:10:00 (UTC)を境に水準が 14.98から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.365, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 22→23→22→22→22→22→23→23→23
* 開始   : 2026-06-04 13:20:00 (UTC)
* 終了   : 2026-06-04 14:20:00 (UTC)
* 現象   : 2026-06-04 14:20:00 (UTC)を境に水準が 14.97から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.168σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→9→16→13→14
* 開始   : 2026-06-05 04:45:00 (UTC)
* 終了   : 2026-06-05 04:45:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.344σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→16→18→14→13→16→18→14
* 開始   : 2026-06-05 05:30:00 (UTC)
* 終了   : 2026-06-05 05:35:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260605-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 23→21→17→19→19
* 開始   : 2026-06-05 14:50:00 (UTC)
* 終了   : 2026-06-05 14:50:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 9→8→13→9→10
* 開始   : 2026-06-06 03:40:00 (UTC)
* 終了   : 2026-06-06 03:40:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260606-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host16-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 11→10→13→11→…→12→11→12→11
* 開始   : 2026-06-06 05:10:00 (UTC)
* 終了   : 2026-06-06 18:40:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.182, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260606-host16-003 active_connections の推移](charts/EVT-20260606-host16-003.svg)

# イベントID( EVT-20260606-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→13→12→10→…→12→13→14→12
* 開始   : 2026-06-06 05:25:00 (UTC)
* 終了   : 2026-06-06 18:35:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.41σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.463, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host16-004 active_connections の推移](charts/EVT-20260606-host16-004.svg)

# イベントID( EVT-20260606-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→14→13→14→…→11→10→13→12
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 20:00:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.037, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260606-host16-005 active_connections の推移](charts/EVT-20260606-host16-005.svg)

# イベントID( EVT-20260606-host16-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→12→11→12→…→13→12→13→12
* 開始   : 2026-06-06 05:50:00 (UTC)
* 終了   : 2026-06-06 19:05:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.867, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host16-006 active_connections の推移](charts/EVT-20260606-host16-006.svg)

# イベントID( EVT-20260606-host16-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→14→13→14→…→12→11→10→11
* 開始   : 2026-06-06 05:55:00 (UTC)
* 終了   : 2026-06-06 19:00:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.795, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260606-host16-007 active_connections の推移](charts/EVT-20260606-host16-007.svg)

# イベントID( EVT-20260606-host16-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→12→10→13→…→12→10→12→10
* 開始   : 2026-06-06 06:30:00 (UTC)
* 終了   : 2026-06-06 19:20:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.104, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260606-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 11.8 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260606-host16-008 active_connections の推移](charts/EVT-20260606-host16-008.svg)

# イベントID( EVT-20260607-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→10→16→15→…→16→15→12→13
* 開始   : 2026-06-07 06:30:00 (UTC)
* 終了   : 2026-06-07 06:35:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host05-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 5 分
  - EVT-20260607-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260607-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→16→18→14→16→15→19
* 開始   : 2026-06-07 08:40:00 (UTC)
* 終了   : 2026-06-07 09:10:00 (UTC)
* 現象   : 2026-06-07 09:10:00 (UTC)を境に水準が 11.88から12.78へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.51, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→15→17→20
* 開始   : 2026-06-07 11:00:00 (UTC)
* 終了   : 2026-06-07 11:15:00 (UTC)
* 現象   : 2026-06-07 11:15:00 (UTC)を境に水準が 11.9から13.33へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.61σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.865, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→9→7→11→12→9→7→11
* 開始   : 2026-06-07 18:45:00 (UTC)
* 終了   : 2026-06-07 18:50:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260607-lsfhost01-038 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260607-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→7→3→7→8
* 開始   : 2026-06-08 01:20:00 (UTC)
* 終了   : 2026-06-08 01:20:00 (UTC)
* 現象   : 平常時(7.667)に対し 0.3913(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260608-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 8→9→8→8→9→10→11
* 開始   : 2026-06-08 23:40:00 (UTC)
* 終了   : 2026-06-09 00:55:00 (UTC)
* 現象   : 2026-06-09 00:55:00 (UTC)を境に水準が 14.83から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.849σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host16-009 active_connections の推移](charts/EVT-20260608-host16-009.svg)

# イベントID( EVT-20260609-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 9→8→13→10→9
* 開始   : 2026-06-09 02:55:00 (UTC)
* 終了   : 2026-06-09 02:55:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 19→18→22→18→19
* 開始   : 2026-06-09 08:00:00 (UTC)
* 終了   : 2026-06-09 08:00:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.263倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 21→19→23→19→19
* 開始   : 2026-06-09 08:40:00 (UTC)
* 終了   : 2026-06-09 08:40:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-029 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 20→20→25→20→20
* 開始   : 2026-06-09 10:50:00 (UTC)
* 終了   : 2026-06-09 10:50:00 (UTC)
* 現象   : 平常時(19.92)に対し 1.255倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host16-008 active_connections の推移](charts/EVT-20260609-host16-008.svg)

# イベントID( EVT-20260609-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→14→10→12→12
* 開始   : 2026-06-09 18:55:00 (UTC)
* 終了   : 2026-06-09 18:55:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.6593(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.645σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host16-012 active_connections の推移](charts/EVT-20260609-host16-012.svg)

# イベントID( EVT-20260609-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→11→6→9→10
* 開始   : 2026-06-09 21:40:00 (UTC)
* 終了   : 2026-06-09 21:40:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.5538(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-078 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→14→16→15→13
* 開始   : 2026-06-10 05:00:00 (UTC)
* 終了   : 2026-06-10 05:00:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 16→14→19→15→16
* 開始   : 2026-06-10 06:20:00 (UTC)
* 終了   : 2026-06-10 06:20:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.057σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 17→16→12→15→17
* 開始   : 2026-06-10 17:15:00 (UTC)
* 終了   : 2026-06-10 17:15:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.689(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.79σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host16-008 active_connections の推移](charts/EVT-20260610-host16-008.svg)

# イベントID( EVT-20260610-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 15→16→12→17→16
* 開始   : 2026-06-10 17:25:00 (UTC)
* 終了   : 2026-06-10 17:25:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.699(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host16-009 active_connections の推移](charts/EVT-20260610-host16-009.svg)

# イベントID( EVT-20260610-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→15→…→13→11→12→14
* 開始   : 2026-06-10 18:40:00 (UTC)
* 終了   : 2026-06-10 19:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260610-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 9→9→9→10→8→9→9→8→9
* 開始   : 2026-06-11 00:00:00 (UTC)
* 終了   : 2026-06-11 01:40:00 (UTC)
* 現象   : 2026-06-11 01:40:00 (UTC)を境に水準が 14.88から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.096, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 19→18→23→22→20→18→23→22→20
* 開始   : 2026-06-11 08:35:00 (UTC)
* 終了   : 2026-06-11 08:40:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 16→15→11→15→16
* 開始   : 2026-06-11 17:45:00 (UTC)
* 終了   : 2026-06-11 17:45:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.6701(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.813σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host16-009 active_connections の推移](charts/EVT-20260611-host16-009.svg)

# イベントID( EVT-20260611-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 10→10→9→10→9→11→9→8→10
* 開始   : 2026-06-11 21:00:00 (UTC)
* 終了   : 2026-06-11 22:25:00 (UTC)
* 現象   : 2026-06-11 22:25:00 (UTC)を境に水準が 14.85から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→9→6→7→…→6→7→8→9
* 開始   : 2026-06-11 21:20:00 (UTC)
* 終了   : 2026-06-11 21:25:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.175σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→12→15→11→11
* 開始   : 2026-06-12 03:40:00 (UTC)
* 終了   : 2026-06-12 03:40:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→14→19→17→14
* 開始   : 2026-06-12 06:20:00 (UTC)
* 終了   : 2026-06-12 06:20:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.349倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host16-002 active_connections の推移](charts/EVT-20260612-host16-002.svg)

# イベントID( EVT-20260612-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 18→17→20→17→…→17→22→17→18
* 開始   : 2026-06-12 07:50:00 (UTC)
* 終了   : 2026-06-12 08:00:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-043 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 21→19→21→19→20→23
* 開始   : 2026-06-12 08:05:00 (UTC)
* 終了   : 2026-06-12 08:40:00 (UTC)
* 現象   : 2026-06-12 08:40:00 (UTC)を境に水準が 14.87から14.21へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 21→20→16→20→19
* 開始   : 2026-06-12 15:15:00 (UTC)
* 終了   : 2026-06-12 15:15:00 (UTC)
* 現象   : 平常時(20.83)に対し 0.768(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 18→16→13→18→16→13→18→16
* 開始   : 2026-06-12 17:05:00 (UTC)
* 終了   : 2026-06-12 17:10:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.7189(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.557σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host16-011 active_connections の推移](charts/EVT-20260612-host16-011.svg)

# イベントID( EVT-20260612-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→16→11→16→15
* 開始   : 2026-06-12 17:40:00 (UTC)
* 終了   : 2026-06-12 17:40:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.6804(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.615σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host16-012 active_connections の推移](charts/EVT-20260612-host16-012.svg)

# イベントID( EVT-20260612-host16-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→10→6→12→9
* 開始   : 2026-06-12 21:40:00 (UTC)
* 終了   : 2026-06-12 21:40:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host11-019 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host16-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→10→12→11→…→11→13→11→13
* 開始   : 2026-06-13 05:00:00 (UTC)
* 終了   : 2026-06-13 19:00:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.96, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260613-host16-002 active_connections の推移](charts/EVT-20260613-host16-002.svg)

# イベントID( EVT-20260613-host16-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→12→14→13→…→11→10→13→10
* 開始   : 2026-06-13 05:45:00 (UTC)
* 終了   : 2026-06-13 18:55:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.446, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260613-host16-003 active_connections の推移](charts/EVT-20260613-host16-003.svg)

# イベントID( EVT-20260613-host16-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→10→12→10→…→10→12→10→11
* 開始   : 2026-06-13 05:50:00 (UTC)
* 終了   : 2026-06-13 19:10:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.799, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260613-host16-004 active_connections の推移](charts/EVT-20260613-host16-004.svg)

# イベントID( EVT-20260613-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→11→10→11→…→11→9→11→10
* 開始   : 2026-06-13 05:55:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.921, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260613-host16-005 active_connections の推移](charts/EVT-20260613-host16-005.svg)

# イベントID( EVT-20260613-host16-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→12→13→12→…→12→13→10→12
* 開始   : 2026-06-13 06:20:00 (UTC)
* 終了   : 2026-06-13 18:55:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.907, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260613-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host16-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 11→13→10→12→…→11→10→9→8
* 開始   : 2026-06-13 06:30:00 (UTC)
* 終了   : 2026-06-13 20:10:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.063, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260613-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260613-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260613-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260613-host16-007 active_connections の推移](charts/EVT-20260613-host16-007.svg)

# イベントID( EVT-20260613-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 8→12→6→12→6→12→6→8→9
* 開始   : 2026-06-13 20:25:00 (UTC)
* 終了   : 2026-06-13 20:35:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260613-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260613-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 8→8→4→9→9
* 開始   : 2026-06-13 23:20:00 (UTC)
* 終了   : 2026-06-13 23:20:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.344σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260613-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→11→6→12→11→6→12→8
* 開始   : 2026-06-14 03:25:00 (UTC)
* 終了   : 2026-06-14 04:05:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260614-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260614-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host16-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→15→13→12→…→12→14→13→12
* 開始   : 2026-06-15 02:30:00 (UTC)
* 終了   : 2026-06-15 22:15:00 (UTC)
* 現象   : 2026-06-15 22:15:00 (UTC)を境に水準が 11.93から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.839, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→8→12→10→10
* 開始   : 2026-06-16 01:55:00 (UTC)
* 終了   : 2026-06-16 03:15:00 (UTC)
* 現象   : 2026-06-16 03:15:00 (UTC)を境に水準が 14.96から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 16→18→22→18→20
* 開始   : 2026-06-16 07:50:00 (UTC)
* 終了   : 2026-06-16 07:50:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.282倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260616-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 22→20→26→22→20
* 開始   : 2026-06-16 12:35:00 (UTC)
* 終了   : 2026-06-16 12:35:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 16→14→15→17→15→14→15→15→14
* 開始   : 2026-06-16 18:10:00 (UTC)
* 終了   : 2026-06-16 19:45:00 (UTC)
* 現象   : 2026-06-16 19:45:00 (UTC)を境に水準が 15から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.989, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→11→8→11→11
* 開始   : 2026-06-16 19:35:00 (UTC)
* 終了   : 2026-06-16 19:35:00 (UTC)
* 現象   : 平常時(13)に対し 0.6154(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.52σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260616-host16-010 active_connections の推移](charts/EVT-20260616-host16-010.svg)

# イベントID( EVT-20260616-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→12→8→11→10
* 開始   : 2026-06-16 20:15:00 (UTC)
* 終了   : 2026-06-16 20:15:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.6316(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 22→21→26→22→22
* 開始   : 2026-06-17 11:55:00 (UTC)
* 終了   : 2026-06-17 11:55:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.219倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.261σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 21→19→16→19→19
* 開始   : 2026-06-17 15:45:00 (UTC)
* 終了   : 2026-06-17 15:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 16→15→10→15→13
* 開始   : 2026-06-17 18:20:00 (UTC)
* 終了   : 2026-06-17 18:20:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.6486(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.799σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260617-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host16-009 active_connections の推移](charts/EVT-20260617-host16-009.svg)

# イベントID( EVT-20260617-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→13→9→13→9→13→9→13
* 開始   : 2026-06-17 18:55:00 (UTC)
* 終了   : 2026-06-17 19:50:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host16-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-071 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260617-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-018 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260617-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260617-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 13→14→16→13→13
* 開始   : 2026-06-18 04:40:00 (UTC)
* 終了   : 2026-06-18 04:40:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→13→17→13→14
* 開始   : 2026-06-18 05:15:00 (UTC)
* 終了   : 2026-06-18 05:15:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 17→17→20→16→18
* 開始   : 2026-06-18 07:15:00 (UTC)
* 終了   : 2026-06-18 07:15:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260618-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 20→21→17→21→25→17→21→25→21
* 開始   : 2026-06-18 09:55:00 (UTC)
* 終了   : 2026-06-18 10:05:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 20→24→16→22→20
* 開始   : 2026-06-18 14:30:00 (UTC)
* 終了   : 2026-06-18 14:30:00 (UTC)
* 現象   : 平常時(21.67)に対し 0.7385(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.998σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host16-009 active_connections の推移](charts/EVT-20260618-host16-009.svg)

# イベントID( EVT-20260618-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→14→9→10→…→9→10→13→12
* 開始   : 2026-06-18 19:40:00 (UTC)
* 終了   : 2026-06-18 19:45:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→13→16→13→11
* 開始   : 2026-06-19 04:30:00 (UTC)
* 終了   : 2026-06-19 04:30:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→11→16→12→14
* 開始   : 2026-06-19 04:40:00 (UTC)
* 終了   : 2026-06-19 04:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→11→16→11→11
* 開始   : 2026-06-19 04:40:00 (UTC)
* 終了   : 2026-06-19 04:40:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 21→20→25→21→22
* 開始   : 2026-06-19 10:00:00 (UTC)
* 終了   : 2026-06-19 10:00:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→14→9→12→11
* 開始   : 2026-06-19 19:50:00 (UTC)
* 終了   : 2026-06-19 19:50:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 11→12→7→11→8
* 開始   : 2026-06-19 20:55:00 (UTC)
* 終了   : 2026-06-19 20:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-076 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host16-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→13→10→14→…→14→13→14→13
* 開始   : 2026-06-20 05:05:00 (UTC)
* 終了   : 2026-06-20 20:05:00 (UTC)
* 現象   : 15.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.727, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host16-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間

![EVT-20260620-host16-001 active_connections の推移](charts/EVT-20260620-host16-001.svg)

# イベントID( EVT-20260620-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→13→11→10→…→11→12→11→13
* 開始   : 2026-06-20 05:10:00 (UTC)
* 終了   : 2026-06-20 18:30:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.578σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.828, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260620-host16-002 active_connections の推移](charts/EVT-20260620-host16-002.svg)

# イベントID( EVT-20260620-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→9→10→11→…→11→10→13→11
* 開始   : 2026-06-20 05:10:00 (UTC)
* 終了   : 2026-06-20 19:25:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.743, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-lsfhost01-008 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.2 時間

![EVT-20260620-host16-003 active_connections の推移](charts/EVT-20260620-host16-003.svg)

# イベントID( EVT-20260620-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→14→13→14→…→12→11→13→14
* 開始   : 2026-06-20 05:15:00 (UTC)
* 終了   : 2026-06-20 18:35:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.963, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260620-host16-004 active_connections の推移](charts/EVT-20260620-host16-004.svg)

# イベントID( EVT-20260620-host16-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→11→12→11→…→12→13→14→12
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 19:20:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.797, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260620-host16-005 active_connections の推移](charts/EVT-20260620-host16-005.svg)

# イベントID( EVT-20260620-host16-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→13→12→13→…→13→12→13→12
* 開始   : 2026-06-20 06:05:00 (UTC)
* 終了   : 2026-06-20 19:40:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.218, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260620-host16-006 active_connections の推移](charts/EVT-20260620-host16-006.svg)

# イベントID( EVT-20260622-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 8→8→13→10→9
* 開始   : 2026-06-22 02:15:00 (UTC)
* 終了   : 2026-06-22 02:15:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260622-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host16-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 13→14→15→16→…→13→14→13→12
* 開始   : 2026-06-22 02:30:00 (UTC)
* 終了   : 2026-06-22 20:25:00 (UTC)
* 現象   : 2026-06-22 20:25:00 (UTC)を境に水準が 11.93から15へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.311, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.951, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host16-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→17→14→17→…→15→11→13→14
* 開始   : 2026-06-22 03:30:00 (UTC)
* 終了   : 2026-06-22 20:35:00 (UTC)
* 現象   : 2026-06-22 20:35:00 (UTC)を境に水準が 11.89から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.017, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.667, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host16-007 active_connections の推移](charts/EVT-20260622-host16-007.svg)

# イベントID( EVT-20260623-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→11→15→12→…→12→14→12→13
* 開始   : 2026-06-23 04:10:00 (UTC)
* 終了   : 2026-06-23 04:20:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.44倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-010 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260623-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 15→16→22→18→19
* 開始   : 2026-06-23 07:10:00 (UTC)
* 終了   : 2026-06-23 07:10:00 (UTC)
* 現象   : 平常時(16)に対し 1.375倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host16-003 active_connections の推移](charts/EVT-20260623-host16-003.svg)

# イベントID( EVT-20260623-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 22→19→26→20→21
* 開始   : 2026-06-23 12:20:00 (UTC)
* 終了   : 2026-06-23 12:20:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→14→11→13→…→13→9→13→11
* 開始   : 2026-06-23 19:20:00 (UTC)
* 終了   : 2026-06-23 19:30:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.7586(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.469σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host16-010 active_connections の推移](charts/EVT-20260623-host16-010.svg)

# イベントID( EVT-20260623-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→8→9→12→11→8→9→12→13
* 開始   : 2026-06-23 20:00:00 (UTC)
* 終了   : 2026-06-23 20:05:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.6234(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→12→19→16→16
* 開始   : 2026-06-24 06:25:00 (UTC)
* 終了   : 2026-06-24 06:25:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 22→18→19→22→21
* 開始   : 2026-06-24 08:20:00 (UTC)
* 終了   : 2026-06-24 08:40:00 (UTC)
* 現象   : 2026-06-24 08:40:00 (UTC)を境に水準が 14.97から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.205, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→18→24→20→19
* 開始   : 2026-06-24 08:40:00 (UTC)
* 終了   : 2026-06-24 08:40:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.274倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.615σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host16-004 active_connections の推移](charts/EVT-20260624-host16-004.svg)

# イベントID( EVT-20260624-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→18→24→19→20
* 開始   : 2026-06-24 09:25:00 (UTC)
* 終了   : 2026-06-24 09:25:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 22→22→21→20→19→18→20→18→21
* 開始   : 2026-06-24 15:30:00 (UTC)
* 終了   : 2026-06-24 19:25:00 (UTC)
* 現象   : 2026-06-24 19:25:00 (UTC)を境に水準が 15.1から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.045, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→18→13→17→15
* 開始   : 2026-06-24 17:25:00 (UTC)
* 終了   : 2026-06-24 17:25:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→14→10→11→12→14→10→11→12
* 開始   : 2026-06-24 18:50:00 (UTC)
* 終了   : 2026-06-24 18:55:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.377σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→10→8→12→12
* 開始   : 2026-06-24 20:05:00 (UTC)
* 終了   : 2026-06-24 20:05:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→10→5→7→9
* 開始   : 2026-06-24 22:40:00 (UTC)
* 終了   : 2026-06-24 22:40:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-078 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260624-host16-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 8→8→12→6→8
* 開始   : 2026-06-25 00:05:00 (UTC)
* 終了   : 2026-06-25 00:05:00 (UTC)
* 現象   : 平常時(7.25)に対し 1.655倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→10→14→10→10
* 開始   : 2026-06-25 02:30:00 (UTC)
* 終了   : 2026-06-25 02:30:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.6倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.682σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host16-002 active_connections の推移](charts/EVT-20260625-host16-002.svg)

# イベントID( EVT-20260625-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→13→16→18→…→16→18→16→13
* 開始   : 2026-06-25 05:15:00 (UTC)
* 終了   : 2026-06-25 05:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.799σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host16-003 active_connections の推移](charts/EVT-20260625-host16-003.svg)

# イベントID( EVT-20260625-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 16→16→20→15→16
* 開始   : 2026-06-25 06:25:00 (UTC)
* 終了   : 2026-06-25 06:25:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.311倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.351σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→16→20→15→17
* 開始   : 2026-06-25 06:45:00 (UTC)
* 終了   : 2026-06-25 07:40:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.377σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260625-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260625-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 20→18→24→23→…→24→23→22→19
* 開始   : 2026-06-25 09:10:00 (UTC)
* 終了   : 2026-06-25 09:15:00 (UTC)
* 現象   : 平常時(19.17)に対し 1.252倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 23→22→18→21→22
* 開始   : 2026-06-25 12:10:00 (UTC)
* 終了   : 2026-06-25 12:10:00 (UTC)
* 現象   : 平常時(22.58)に対し 0.797(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→11→10→8→11→10→8→11→12
* 開始   : 2026-06-25 19:50:00 (UTC)
* 終了   : 2026-06-25 19:55:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-079 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-078 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→10→6→11→9
* 開始   : 2026-06-25 21:35:00 (UTC)
* 終了   : 2026-06-25 21:35:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.5625(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host11-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 8→8→12→11→8→14→10→10
* 開始   : 2026-06-26 01:55:00 (UTC)
* 終了   : 2026-06-26 02:30:00 (UTC)
* 現象   : 2026-06-26 02:30:00 (UTC)を境に水準が 14.91から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.615σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.928, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 17→19→22→17→19
* 開始   : 2026-06-26 08:00:00 (UTC)
* 終了   : 2026-06-26 08:00:00 (UTC)
* 現象   : 平常時(17.25)に対し 1.275倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→12→…→12→10→13→10
* 開始   : 2026-06-27 05:15:00 (UTC)
* 終了   : 2026-06-27 19:05:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.884, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host16-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260627-host16-001 active_connections の推移](charts/EVT-20260627-host16-001.svg)

# イベントID( EVT-20260627-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→11→12→13→…→12→9→11→12
* 開始   : 2026-06-27 05:35:00 (UTC)
* 終了   : 2026-06-27 18:30:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.266σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.126, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260627-host16-002 active_connections の推移](charts/EVT-20260627-host16-002.svg)

# イベントID( EVT-20260627-host16-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 10→12→10→11→…→14→10→11→12
* 開始   : 2026-06-27 05:40:00 (UTC)
* 終了   : 2026-06-27 19:00:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.44, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host16-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260627-host16-003 active_connections の推移](charts/EVT-20260627-host16-003.svg)

# イベントID( EVT-20260627-host16-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→11→10→11→…→13→11→13→12
* 開始   : 2026-06-27 05:45:00 (UTC)
* 終了   : 2026-06-27 17:50:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.374, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260627-host16-004 active_connections の推移](charts/EVT-20260627-host16-004.svg)

# イベントID( EVT-20260627-host16-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→9→11→10→…→13→11→12→13
* 開始   : 2026-06-27 05:50:00 (UTC)
* 終了   : 2026-06-27 18:20:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.445, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260627-host16-005 active_connections の推移](charts/EVT-20260627-host16-005.svg)

# イベントID( EVT-20260627-host16-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→10→12→10→…→12→14→12→14
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 18:05:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.742, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260627-host16-006 active_connections の推移](charts/EVT-20260627-host16-006.svg)

# イベントID( EVT-20260628-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→17→13→16→17→13→16→12
* 開始   : 2026-06-28 07:25:00 (UTC)
* 終了   : 2026-06-28 07:35:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.377σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→11→7→10→9
* 開始   : 2026-06-28 19:05:00 (UTC)
* 終了   : 2026-06-28 19:05:00 (UTC)
* 現象   : 平常時(12)に対し 0.5833(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260628-host16-005 active_connections の推移](charts/EVT-20260628-host16-005.svg)

# イベントID( EVT-20260628-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→9→4→8→10
* 開始   : 2026-06-28 21:50:00 (UTC)
* 終了   : 2026-06-28 21:50:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→13→17→12→14
* 開始   : 2026-06-30 05:10:00 (UTC)
* 終了   : 2026-06-30 05:10:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.388倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→15→17→14→15
* 開始   : 2026-06-30 05:25:00 (UTC)
* 終了   : 2026-06-30 05:25:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.057σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 19→18→14→19→18
* 開始   : 2026-06-30 16:25:00 (UTC)
* 終了   : 2026-06-30 16:25:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.7336(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host16-008 active_connections の推移](charts/EVT-20260630-host16-008.svg)

# イベントID( EVT-20260630-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→18→16→13→18→16→13→18→16
* 開始   : 2026-06-30 16:30:00 (UTC)
* 終了   : 2026-06-30 16:35:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.8458(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host16-009 active_connections の推移](charts/EVT-20260630-host16-009.svg)

# イベントID( EVT-20260601-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→12→16→17→…→16→17→15→16
* 開始   : 2026-06-01 05:45:00 (UTC)
* 終了   : 2026-06-01 05:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 23→22→25→22→…→22→19→23→22
* 開始   : 2026-06-01 12:05:00 (UTC)
* 終了   : 2026-06-01 12:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-035 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 18→17→15→14→…→15→14→16→18
* 開始   : 2026-06-01 16:50:00 (UTC)
* 終了   : 2026-06-01 16:55:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→14→13→14→13→14→13
* 開始   : 2026-06-01 18:25:00 (UTC)
* 終了   : 2026-06-01 18:30:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host16-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260601-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→12→13→15→12→13
* 開始   : 2026-06-01 18:25:00 (UTC)
* 終了   : 2026-06-01 18:30:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host16-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260601-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→10→12→10→…→10→13→10→9
* 開始   : 2026-06-02 03:00:00 (UTC)
* 終了   : 2026-06-02 03:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260602-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 21→23→19→21→23→19
* 開始   : 2026-06-02 10:00:00 (UTC)
* 終了   : 2026-06-02 10:05:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 21→23→22→22→24→23→24→24
* 開始   : 2026-06-02 11:25:00 (UTC)
* 終了   : 2026-06-02 12:00:00 (UTC)
* 現象   : 2026-06-02 12:00:00 (UTC)を境に水準が 15.06から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.928, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 21→20→18→20→18→20→18→20→22
* 開始   : 2026-06-02 13:55:00 (UTC)
* 終了   : 2026-06-02 14:05:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.8405(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.405σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→10→12→10→12
* 開始   : 2026-06-02 19:30:00 (UTC)
* 終了   : 2026-06-02 19:35:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.469σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260602-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→15→16→15→15→17
* 開始   : 2026-06-03 05:20:00 (UTC)
* 終了   : 2026-06-03 05:55:00 (UTC)
* 現象   : 2026-06-03 05:55:00 (UTC)を境に水準が 14.93から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.928, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 23→19→23→21→23→21→22→24→23
* 開始   : 2026-06-03 09:30:00 (UTC)
* 終了   : 2026-06-03 10:30:00 (UTC)
* 現象   : 2026-06-03 10:30:00 (UTC)を境に水準が 14.91から15.17へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 21→21→22
* 開始   : 2026-06-03 15:20:00 (UTC)
* 終了   : 2026-06-03 15:30:00 (UTC)
* 現象   : 2026-06-03 15:30:00 (UTC)を境に水準が 15.06から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.933, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→14→15→13→14→15→13→16→15
* 開始   : 2026-06-03 17:50:00 (UTC)
* 終了   : 2026-06-03 18:00:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→11→14→11→14→16
* 開始   : 2026-06-03 19:05:00 (UTC)
* 終了   : 2026-06-03 19:10:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260603-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host16-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 9→11→10→10→10→8→11→8→10
* 開始   : 2026-06-03 22:15:00 (UTC)
* 終了   : 2026-06-03 23:30:00 (UTC)
* 現象   : 2026-06-03 23:30:00 (UTC)を境に水準が 14.98から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.855, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→16→17→16→13→16→17→16→13
* 開始   : 2026-06-04 05:20:00 (UTC)
* 終了   : 2026-06-04 05:25:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.346σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260604-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→15→16→14→15→16→14→13
* 開始   : 2026-06-04 05:35:00 (UTC)
* 終了   : 2026-06-04 05:40:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260604-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 24→23→25→22→…→22→19→24→21
* 開始   : 2026-06-04 11:10:00 (UTC)
* 終了   : 2026-06-04 11:20:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.158倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 22→21→25→23→…→23→19→23→22
* 開始   : 2026-06-04 12:00:00 (UTC)
* 終了   : 2026-06-04 12:10:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.172倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.581σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260604-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 18→15→17→14→15→17→14→16
* 開始   : 2026-06-04 16:55:00 (UTC)
* 終了   : 2026-06-04 17:05:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-049 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260604-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→17→13→15→13→15→13→15
* 開始   : 2026-06-04 17:35:00 (UTC)
* 終了   : 2026-06-04 17:45:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7761(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.64σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→14→12→12→12
* 開始   : 2026-06-04 18:40:00 (UTC)
* 終了   : 2026-06-04 20:30:00 (UTC)
* 現象   : 2026-06-04 20:30:00 (UTC)を境に水準が 14.98から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 10→7→9→6→7→9→6→9→8
* 開始   : 2026-06-04 21:50:00 (UTC)
* 終了   : 2026-06-04 22:00:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 8→11→9→8→11
* 開始   : 2026-06-05 01:10:00 (UTC)
* 終了   : 2026-06-05 01:30:00 (UTC)
* 現象   : 2026-06-05 01:30:00 (UTC)を境に水準が 14.96から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.205, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 8→11→13→11→13→11
* 開始   : 2026-06-05 03:15:00 (UTC)
* 終了   : 2026-06-05 03:20:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host16-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→9→6→13→…→6→13→10→11
* 開始   : 2026-06-05 03:15:00 (UTC)
* 終了   : 2026-06-05 03:20:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host16-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→15→14→15→19→18→18→16→18
* 開始   : 2026-06-05 05:20:00 (UTC)
* 終了   : 2026-06-05 06:55:00 (UTC)
* 現象   : 2026-06-05 06:55:00 (UTC)を境に水準が 14.9から14.63へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.935, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 15→12→16→15→12→16→15
* 開始   : 2026-06-05 18:15:00 (UTC)
* 終了   : 2026-06-05 18:20:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.766(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260605-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→15→14→14→14→12→16
* 開始   : 2026-06-05 18:40:00 (UTC)
* 終了   : 2026-06-05 19:10:00 (UTC)
* 現象   : 2026-06-05 19:10:00 (UTC)を境に水準が 14.87から11.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.51, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→11→13→12→11→12→11
* 開始   : 2026-06-05 20:10:00 (UTC)
* 終了   : 2026-06-05 20:40:00 (UTC)
* 現象   : 2026-06-05 20:40:00 (UTC)を境に水準が 14.94から12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.178, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host16-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→12→11→10→10→10→10→10→9
* 開始   : 2026-06-05 20:45:00 (UTC)
* 終了   : 2026-06-05 21:30:00 (UTC)
* 現象   : 2026-06-05 21:30:00 (UTC)を境に水準が 15から11.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.967, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→11→6→9→13→6→9→13→11
* 開始   : 2026-06-06 03:50:00 (UTC)
* 終了   : 2026-06-06 04:00:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 9→8→6→10→6→10→6→9→8
* 開始   : 2026-06-06 22:25:00 (UTC)
* 終了   : 2026-06-06 22:35:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260606-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 9→10→8→9→8→8→9→10→11
* 開始   : 2026-06-07 01:40:00 (UTC)
* 終了   : 2026-06-07 02:50:00 (UTC)
* 現象   : 2026-06-07 02:50:00 (UTC)を境に水準が 11.89から11.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.61, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→10→13→12→…→13→12→11→10
* 開始   : 2026-06-07 04:10:00 (UTC)
* 終了   : 2026-06-07 04:15:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.472倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.916σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260607-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260607-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→14→15→15
* 開始   : 2026-06-07 07:20:00 (UTC)
* 終了   : 2026-06-07 07:35:00 (UTC)
* 現象   : 2026-06-07 07:35:00 (UTC)を境に水準が 11.85から12.45へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.245, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host16-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→15→15→15→15→15→15→14→16
* 開始   : 2026-06-07 15:25:00 (UTC)
* 終了   : 2026-06-07 16:05:00 (UTC)
* 現象   : 2026-06-07 16:05:00 (UTC)を境に水準が 11.9から14.46へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host16-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→11→9→10→10→11→12→10→10
* 開始   : 2026-06-07 19:45:00 (UTC)
* 終了   : 2026-06-07 20:40:00 (UTC)
* 現象   : 2026-06-07 20:40:00 (UTC)を境に水準が 11.88から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.734, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→9→9→9→9→10→7→10→11
* 開始   : 2026-06-07 22:00:00 (UTC)
* 終了   : 2026-06-07 22:55:00 (UTC)
* 現象   : 2026-06-07 22:55:00 (UTC)を境に水準が 11.85から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.365, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 10→7→6→5→9→7→6→5→9
* 開始   : 2026-06-08 22:25:00 (UTC)
* 終了   : 2026-06-08 22:30:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260608-lsfhost01-055 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260608-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 7→9→7→10→8→8→7→10→10
* 開始   : 2026-06-09 00:35:00 (UTC)
* 終了   : 2026-06-09 01:35:00 (UTC)
* 現象   : 2026-06-09 01:35:00 (UTC)を境に水準が 14.95から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.045, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→13→13→14→14
* 開始   : 2026-06-09 03:45:00 (UTC)
* 終了   : 2026-06-09 04:05:00 (UTC)
* 現象   : 2026-06-09 04:05:00 (UTC)を境に水準が 15.02から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 18→21→23→21→23→21→19
* 開始   : 2026-06-09 09:15:00 (UTC)
* 終了   : 2026-06-09 09:20:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 22→23→22→21→24→22→22
* 開始   : 2026-06-09 10:25:00 (UTC)
* 終了   : 2026-06-09 11:10:00 (UTC)
* 現象   : 2026-06-09 11:10:00 (UTC)を境に水準が 15.04から15.02へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.085, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.692, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 22→23→24→22→22→24→22
* 開始   : 2026-06-09 11:35:00 (UTC)
* 終了   : 2026-06-09 12:05:00 (UTC)
* 現象   : 2026-06-09 12:05:00 (UTC)を境に水準が 15.03から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.178, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 23→22→22→22→22→23→20→22→23
* 開始   : 2026-06-09 12:20:00 (UTC)
* 終了   : 2026-06-09 13:45:00 (UTC)
* 現象   : 2026-06-09 13:45:00 (UTC)を境に水準が 14.89から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.337, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→16→12→14→12→14→12→13→12
* 開始   : 2026-06-09 18:25:00 (UTC)
* 終了   : 2026-06-09 18:35:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.464σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260609-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→10→7→8→…→8→6→10→9
* 開始   : 2026-06-09 21:15:00 (UTC)
* 終了   : 2026-06-09 21:25:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.672(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 20→19→22→19→16→22→19→16→20
* 開始   : 2026-06-10 08:45:00 (UTC)
* 終了   : 2026-06-10 09:50:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host16-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 1.1 時間

![EVT-20260610-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 17→19→22→21→19→22→21→20
* 開始   : 2026-06-10 09:00:00 (UTC)
* 終了   : 2026-06-10 09:05:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host16-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-035 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 21→21→20→22→23→22→20→23
* 開始   : 2026-06-10 10:05:00 (UTC)
* 終了   : 2026-06-10 10:40:00 (UTC)
* 現象   : 2026-06-10 10:40:00 (UTC)を境に水準が 14.91から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.928, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 21→25→19→22→21→25→19→22→21
* 開始   : 2026-06-10 12:40:00 (UTC)
* 終了   : 2026-06-10 12:45:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.346σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-042 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 21→20→21→19→21→20→20→21→21
* 開始   : 2026-06-10 14:50:00 (UTC)
* 終了   : 2026-06-10 15:35:00 (UTC)
* 現象   : 2026-06-10 15:35:00 (UTC)を境に水準が 14.97から14.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→13→12→14→…→14→11→14→13
* 開始   : 2026-06-10 18:10:00 (UTC)
* 終了   : 2026-06-10 18:20:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.117σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-062 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→9→11→8→9→11→8→10→12
* 開始   : 2026-06-10 20:05:00 (UTC)
* 終了   : 2026-06-10 20:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→9→6→11→…→11→7→8→9
* 開始   : 2026-06-10 21:45:00 (UTC)
* 終了   : 2026-06-10 21:55:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.5854(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.999σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→11→13→12→14→12
* 開始   : 2026-06-11 03:45:00 (UTC)
* 終了   : 2026-06-11 04:10:00 (UTC)
* 現象   : 2026-06-11 04:10:00 (UTC)を境に水準が 14.98から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.683, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→15→9→14→12→15→9→14→15
* 開始   : 2026-06-11 04:50:00 (UTC)
* 終了   : 2026-06-11 04:55:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→16→17→15→16→17→15→16
* 開始   : 2026-06-11 05:55:00 (UTC)
* 終了   : 2026-06-11 06:00:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 18→16→19→16→19→16
* 開始   : 2026-06-11 06:55:00 (UTC)
* 終了   : 2026-06-11 07:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 20→22→21→21→20→21→20→22→22
* 開始   : 2026-06-11 08:45:00 (UTC)
* 終了   : 2026-06-11 09:30:00 (UTC)
* 現象   : 2026-06-11 09:30:00 (UTC)を境に水準が 15.04から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host16-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 24→23→23→22→23→22→25→24
* 開始   : 2026-06-11 11:55:00 (UTC)
* 終了   : 2026-06-11 12:30:00 (UTC)
* 現象   : 2026-06-11 12:30:00 (UTC)を境に水準が 15.03から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.79, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 16→18→15→16→18→15
* 開始   : 2026-06-12 06:30:00 (UTC)
* 終了   : 2026-06-12 06:35:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-036 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-035 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 22→19→23→20→…→20→24→20→21
* 開始   : 2026-06-12 08:40:00 (UTC)
* 終了   : 2026-06-12 09:50:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.405σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host16-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260612-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260612-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 20→22→20→22→20→21
* 開始   : 2026-06-12 09:00:00 (UTC)
* 終了   : 2026-06-12 09:05:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.189倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.469σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host16-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 24→20→23→23
* 開始   : 2026-06-12 13:05:00 (UTC)
* 終了   : 2026-06-12 13:20:00 (UTC)
* 現象   : 2026-06-12 13:20:00 (UTC)を境に水準が 14.9から13.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.245, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→21→16→17→16→17→16→20→18
* 開始   : 2026-06-12 16:10:00 (UTC)
* 終了   : 2026-06-12 16:20:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→17→12→15→…→15→11→13→14
* 開始   : 2026-06-12 18:35:00 (UTC)
* 終了   : 2026-06-12 18:45:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.293σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-081 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→13→10→9→…→10→9→11→10
* 開始   : 2026-06-12 19:40:00 (UTC)
* 終了   : 2026-06-12 19:45:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host01-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host01-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→10→13→10→…→10→7→9→10
* 開始   : 2026-06-13 03:40:00 (UTC)
* 終了   : 2026-06-13 03:50:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.464σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260613-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260613-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 8→11→6→8→…→8→12→9→7
* 開始   : 2026-06-13 21:20:00 (UTC)
* 終了   : 2026-06-13 21:30:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.346σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260613-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 11→10→6→5→9→10→6→5→9
* 開始   : 2026-06-13 22:05:00 (UTC)
* 終了   : 2026-06-13 22:10:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.513σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260613-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 8→7→11→9→12→11→9→12→8
* 開始   : 2026-06-13 22:15:00 (UTC)
* 終了   : 2026-06-13 23:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429倍(6)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.352σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260613-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260613-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260613-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260613-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host16-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 8→9→9→11→7→8→9→8→9
* 開始   : 2026-06-13 23:20:00 (UTC)
* 終了   : 2026-06-14 00:05:00 (UTC)
* 現象   : 2026-06-14 00:05:00 (UTC)を境に水準が 11.82から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.989, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260613-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host16-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→12→10→10→10→12→12→13→11
* 開始   : 2026-06-14 04:10:00 (UTC)
* 終了   : 2026-06-14 04:50:00 (UTC)
* 現象   : 2026-06-14 04:50:00 (UTC)を境に水準が 11.78から11.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.169, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→11→14→15→13→11→14→15→13
* 開始   : 2026-06-14 06:00:00 (UTC)
* 終了   : 2026-06-14 06:05:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→12→9→15→…→9→15→13→12
* 開始   : 2026-06-14 06:20:00 (UTC)
* 終了   : 2026-06-14 06:25:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260614-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→12→16→13→16→13→16→13→15
* 開始   : 2026-06-14 07:50:00 (UTC)
* 終了   : 2026-06-14 08:00:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 17→16→17→18→17
* 開始   : 2026-06-14 12:15:00 (UTC)
* 終了   : 2026-06-14 13:15:00 (UTC)
* 現象   : 2026-06-14 13:15:00 (UTC)を境に水準が 11.92から13.6へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.117σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.984, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→11→8→15→…→8→15→10→11
* 開始   : 2026-06-14 18:25:00 (UTC)
* 終了   : 2026-06-14 18:30:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.6713(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.747σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-035 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260614-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→10→7→9→11
* 開始   : 2026-06-14 22:15:00 (UTC)
* 終了   : 2026-06-14 22:50:00 (UTC)
* 現象   : 2026-06-14 22:50:00 (UTC)を境に水準が 11.92から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.117σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.984, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→16→15→17→16→15→17→14
* 開始   : 2026-06-16 05:15:00 (UTC)
* 終了   : 2026-06-16 05:25:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.324倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.757σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-023 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260616-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→15→17→18→17→15→17→18→17
* 開始   : 2026-06-16 06:15:00 (UTC)
* 終了   : 2026-06-16 06:20:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分

![EVT-20260616-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→17→18→17→18→17→15
* 開始   : 2026-06-16 06:45:00 (UTC)
* 終了   : 2026-06-16 06:50:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260616-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 20→22→21→20→19→22→21→22→23
* 開始   : 2026-06-16 09:15:00 (UTC)
* 終了   : 2026-06-16 10:15:00 (UTC)
* 現象   : 2026-06-16 10:15:00 (UTC)を境に水準が 15.02から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→12→15→14→14
* 開始   : 2026-06-16 18:45:00 (UTC)
* 終了   : 2026-06-16 19:05:00 (UTC)
* 現象   : 2026-06-16 19:05:00 (UTC)を境に水準が 15.04から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 11→8→11→8→10→8→10→11
* 開始   : 2026-06-16 21:05:00 (UTC)
* 終了   : 2026-06-16 21:15:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.63σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host01-014 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260616-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host16-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 7→9→8→7→11→8→9→10→10
* 開始   : 2026-06-16 23:10:00 (UTC)
* 終了   : 2026-06-16 23:50:00 (UTC)
* 現象   : 2026-06-16 23:50:00 (UTC)を境に水準が 14.93から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→13→14→10→13→15→15→16→14
* 開始   : 2026-06-17 04:10:00 (UTC)
* 終了   : 2026-06-17 05:00:00 (UTC)
* 現象   : 2026-06-17 05:00:00 (UTC)を境に水準が 15.04から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.251, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 18→19→16→20→19
* 開始   : 2026-06-17 06:40:00 (UTC)
* 終了   : 2026-06-17 07:00:00 (UTC)
* 現象   : 2026-06-17 07:00:00 (UTC)を境に水準が 15.11から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 17→14→19→16→14→19→16→17
* 開始   : 2026-06-17 06:45:00 (UTC)
* 終了   : 2026-06-17 06:50:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 22→21→22→22→23
* 開始   : 2026-06-17 10:00:00 (UTC)
* 終了   : 2026-06-17 10:20:00 (UTC)
* 現象   : 2026-06-17 10:20:00 (UTC)を境に水準が 14.9から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.98, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 23→21→25→23→24
* 開始   : 2026-06-17 13:10:00 (UTC)
* 終了   : 2026-06-17 13:30:00 (UTC)
* 現象   : 2026-06-17 13:30:00 (UTC)を境に水準が 15.03から15.17へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.081, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 18→19→16→19→…→19→15→17→19
* 開始   : 2026-06-17 16:30:00 (UTC)
* 終了   : 2026-06-17 16:40:00 (UTC)
* 現象   : 平常時(19)に対し 0.8421(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→11→13→11→13→11→14→13
* 開始   : 2026-06-17 18:25:00 (UTC)
* 終了   : 2026-06-17 18:35:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7293(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.857σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260617-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→11→13→11→13→11→13→11
* 開始   : 2026-06-17 18:55:00 (UTC)
* 終了   : 2026-06-17 19:05:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.7416(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.698σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→13→10→13→10→13→10→14→11
* 開始   : 2026-06-17 19:30:00 (UTC)
* 終了   : 2026-06-17 19:40:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host16-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-lsfhost01-071 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260617-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-018 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260617-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→10→11→9→10→9→9→11→9
* 開始   : 2026-06-17 21:40:00 (UTC)
* 終了   : 2026-06-17 22:35:00 (UTC)
* 現象   : 2026-06-17 22:35:00 (UTC)を境に水準が 14.9から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.734, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host16-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 8→9→5→11→…→5→11→6→9
* 開始   : 2026-06-17 23:15:00 (UTC)
* 終了   : 2026-06-17 23:20:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host11-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host02-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host16-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→12→10→12→11
* 開始   : 2026-06-18 02:30:00 (UTC)
* 終了   : 2026-06-18 03:35:00 (UTC)
* 現象   : 2026-06-18 03:35:00 (UTC)を境に水準が 14.93から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.624σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→14→16→14→16
* 開始   : 2026-06-18 05:30:00 (UTC)
* 終了   : 2026-06-18 05:35:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 19→21→21→20→19→20
* 開始   : 2026-06-18 08:20:00 (UTC)
* 終了   : 2026-06-18 08:45:00 (UTC)
* 現象   : 2026-06-18 08:45:00 (UTC)を境に水準が 15.06から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 22→22→23→22→21→24→24→24→23
* 開始   : 2026-06-18 10:50:00 (UTC)
* 終了   : 2026-06-18 11:55:00 (UTC)
* 現象   : 2026-06-18 11:55:00 (UTC)を境に水準が 15.1から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.946, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 16→14→13→15→16→14→13→15→16
* 開始   : 2026-06-18 17:25:00 (UTC)
* 終了   : 2026-06-18 17:30:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 15→16→13→15→…→15→12→13→14
* 開始   : 2026-06-18 18:15:00 (UTC)
* 終了   : 2026-06-18 18:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→15→16→12→…→12→10→12→11
* 開始   : 2026-06-18 19:30:00 (UTC)
* 終了   : 2026-06-18 19:50:00 (UTC)
* 現象   : 2026-06-18 19:50:00 (UTC)を境に水準が 15.05から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.649, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 9→11→8→7→10→11→8→7→10
* 開始   : 2026-06-18 20:45:00 (UTC)
* 終了   : 2026-06-18 20:50:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 9→8→12→11→…→12→11→10→9
* 開始   : 2026-06-19 01:45:00 (UTC)
* 終了   : 2026-06-19 01:50:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.548倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.981σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→9→13→12→9→13→12→10
* 開始   : 2026-06-19 03:35:00 (UTC)
* 終了   : 2026-06-19 03:40:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.293σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 15→11→17→15→11→17→15
* 開始   : 2026-06-19 06:00:00 (UTC)
* 終了   : 2026-06-19 06:05:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260619-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 19→22→20→22→20→22→20→19
* 開始   : 2026-06-19 08:50:00 (UTC)
* 終了   : 2026-06-19 09:00:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host16-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 20→21→22→18→22→18→22→21
* 開始   : 2026-06-19 09:00:00 (UTC)
* 終了   : 2026-06-19 09:10:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.175σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host16-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 23→21→25→22→…→25→18→21→22
* 開始   : 2026-06-19 13:10:00 (UTC)
* 終了   : 2026-06-19 13:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.528σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 17→15→13→12→…→15→12→14→12
* 開始   : 2026-06-19 18:20:00 (UTC)
* 終了   : 2026-06-19 18:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260619-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260619-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 13→12→10→12→10→12→11
* 開始   : 2026-06-19 19:40:00 (UTC)
* 終了   : 2026-06-19 19:45:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.587σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→10→7→10→7→10→7→10
* 開始   : 2026-06-20 20:05:00 (UTC)
* 終了   : 2026-06-20 20:15:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.6412(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.747σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.836, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260620-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260620-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→11→14→12→11
* 開始   : 2026-06-21 04:30:00 (UTC)
* 終了   : 2026-06-21 04:50:00 (UTC)
* 現象   : 2026-06-21 04:50:00 (UTC)を境に水準が 11.8から12.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.081, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→13→13→11→13
* 開始   : 2026-06-21 04:40:00 (UTC)
* 終了   : 2026-06-21 05:00:00 (UTC)
* 現象   : 2026-06-21 05:00:00 (UTC)を境に水準が 11.84から12.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.205, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 11→9→13→10→…→10→14→13→11
* 開始   : 2026-06-21 05:15:00 (UTC)
* 終了   : 2026-06-21 05:25:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260621-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→9→15→14→12→9→15→14
* 開始   : 2026-06-21 06:10:00 (UTC)
* 終了   : 2026-06-21 06:15:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→16→16→15→17
* 開始   : 2026-06-21 07:55:00 (UTC)
* 終了   : 2026-06-21 08:15:00 (UTC)
* 現象   : 2026-06-21 08:15:00 (UTC)を境に水準が 11.82から12.6へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 16→15→14→14→14→14→13→13→15
* 開始   : 2026-06-21 15:30:00 (UTC)
* 終了   : 2026-06-21 17:05:00 (UTC)
* 現象   : 2026-06-21 17:05:00 (UTC)を境に水準が 11.86から14.61へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.935, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→8→5→7→…→11→5→8→7
* 開始   : 2026-06-21 23:45:00 (UTC)
* 終了   : 2026-06-22 00:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.405σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260622-lsfhost01-002 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260621-host11-019 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 10→10→9→11→8→8→10→8→10
* 開始   : 2026-06-22 01:10:00 (UTC)
* 終了   : 2026-06-22 02:10:00 (UTC)
* 現象   : 2026-06-22 02:10:00 (UTC)を境に水準が 11.83から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.045, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→12→13→14→14→12→12→14→14
* 開始   : 2026-06-23 02:50:00 (UTC)
* 終了   : 2026-06-23 04:35:00 (UTC)
* 現象   : 2026-06-23 04:35:00 (UTC)を境に水準が 14.92から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.489, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 19→21→21→21→20
* 開始   : 2026-06-23 15:10:00 (UTC)
* 終了   : 2026-06-23 15:30:00 (UTC)
* 現象   : 2026-06-23 15:30:00 (UTC)を境に水準が 14.91から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.205, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 17→15→14→15→14→15
* 開始   : 2026-06-23 17:20:00 (UTC)
* 終了   : 2026-06-23 17:25:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.8(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.469σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→15→16→18→16
* 開始   : 2026-06-23 17:45:00 (UTC)
* 終了   : 2026-06-23 18:05:00 (UTC)
* 現象   : 2026-06-23 18:05:00 (UTC)を境に水準が 15.08から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 16→18→13→18→13→18→13→16→14
* 開始   : 2026-06-23 17:55:00 (UTC)
* 終了   : 2026-06-23 18:40:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7879(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260623-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260623-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 30 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260623-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260623-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→15→10→11→15→10→11
* 開始   : 2026-06-23 19:10:00 (UTC)
* 終了   : 2026-06-23 19:15:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.7229(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.698σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260623-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→15→8→11→15→8→11
* 開始   : 2026-06-23 20:25:00 (UTC)
* 終了   : 2026-06-23 20:30:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.288σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260623-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→11→9→8→…→9→8→12→9
* 開始   : 2026-06-23 20:40:00 (UTC)
* 終了   : 2026-06-23 20:45:00 (UTC)
* 現象   : 平常時(12)に対し 0.75(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→11→12→10→10→13→12→12
* 開始   : 2026-06-24 03:05:00 (UTC)
* 終了   : 2026-06-24 03:40:00 (UTC)
* 現象   : 2026-06-24 03:40:00 (UTC)を境に水準が 14.96から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 20→22→19→20→…→20→18→20→21
* 開始   : 2026-06-24 13:50:00 (UTC)
* 終了   : 2026-06-24 14:00:00 (UTC)
* 現象   : 平常時(22)に対し 0.8636(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host16-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 21→20→24→20→…→20→17→20→21
* 開始   : 2026-06-24 13:55:00 (UTC)
* 終了   : 2026-06-24 14:05:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host16-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 20→17→20→17→…→20→17→20→18
* 開始   : 2026-06-24 15:20:00 (UTC)
* 終了   : 2026-06-24 15:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-009 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260624-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 16→18→13→15→13→15→13→15→16
* 開始   : 2026-06-24 17:35:00 (UTC)
* 終了   : 2026-06-24 17:45:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.7536(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.992σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-058 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→11→8→11→8→11→8→10
* 開始   : 2026-06-24 20:15:00 (UTC)
* 終了   : 2026-06-24 20:25:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.6761(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.698σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260624-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host16-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→10→11→11→9→11
* 開始   : 2026-06-24 21:00:00 (UTC)
* 終了   : 2026-06-24 21:25:00 (UTC)
* 現象   : 2026-06-24 21:25:00 (UTC)を境に水準が 15.11から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host16-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→19→13→19→…→16→19→17→18
* 開始   : 2026-06-25 06:50:00 (UTC)
* 終了   : 2026-06-25 07:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260625-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 18→19→16→19→16→19→18
* 開始   : 2026-06-25 16:10:00 (UTC)
* 終了   : 2026-06-25 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→15→17→17→16
* 開始   : 2026-06-25 17:30:00 (UTC)
* 終了   : 2026-06-25 17:50:00 (UTC)
* 現象   : 2026-06-25 17:50:00 (UTC)を境に水準が 14.93から14.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→12→12→12→11→9→10→12→11
* 開始   : 2026-06-25 20:15:00 (UTC)
* 終了   : 2026-06-25 21:00:00 (UTC)
* 現象   : 2026-06-25 21:00:00 (UTC)を境に水準が 14.9から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.138, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→10→8→8→9→7→9
* 開始   : 2026-06-25 23:00:00 (UTC)
* 終了   : 2026-06-25 23:30:00 (UTC)
* 現象   : 2026-06-25 23:30:00 (UTC)を境に水準が 14.89から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.514, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host16-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→8→5→9→…→9→11→8→7
* 開始   : 2026-06-25 23:25:00 (UTC)
* 終了   : 2026-06-25 23:35:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host16-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→10→13→14→…→13→14→13→11
* 開始   : 2026-06-26 03:50:00 (UTC)
* 終了   : 2026-06-26 03:55:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→14→15→11→12→14→15→11→13
* 開始   : 2026-06-26 04:00:00 (UTC)
* 終了   : 2026-06-26 04:05:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→11→16→15→11→16→15→13
* 開始   : 2026-06-26 05:20:00 (UTC)
* 終了   : 2026-06-26 05:25:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.306倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.646σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260626-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→13→16→17→…→16→17→16→14
* 開始   : 2026-06-26 05:35:00 (UTC)
* 終了   : 2026-06-26 05:40:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 16→19→21→19→…→19→22→20→18
* 開始   : 2026-06-26 08:10:00 (UTC)
* 終了   : 2026-06-26 08:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 17→20→21→22→…→21→22→19→18
* 開始   : 2026-06-26 08:15:00 (UTC)
* 終了   : 2026-06-26 08:20:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.161倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 19→17→16→18→…→18→15→20→18
* 開始   : 2026-06-26 16:10:00 (UTC)
* 終了   : 2026-06-26 16:20:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→18→16→22→…→16→22→15→18
* 開始   : 2026-06-26 16:10:00 (UTC)
* 終了   : 2026-06-26 16:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→12→10→13→…→13→9→12→11
* 開始   : 2026-06-26 19:30:00 (UTC)
* 終了   : 2026-06-26 19:40:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.7547(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260626-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→7→9→7→9→7→10→11
* 開始   : 2026-06-26 20:30:00 (UTC)
* 終了   : 2026-06-26 20:40:00 (UTC)
* 現象   : 金曜20時台の平常値(10.79)に対し 7であった
* 説明   : ALG-A1: 移動平均からの残差が 2.992σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.021σ 外れた (平常値=10.79)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260626-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host16-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 10→10→6→9→8→9→8→7→11
* 開始   : 2026-06-26 23:15:00 (UTC)
* 終了   : 2026-06-27 00:05:00 (UTC)
* 現象   : 2026-06-27 00:05:00 (UTC)を境に水準が 14.85から11.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.423, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host16-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→11→10→11→10→12
* 開始   : 2026-06-27 18:55:00 (UTC)
* 終了   : 2026-06-27 19:00:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(11)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.871, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260627-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分

![EVT-20260627-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 9→13→9→7→13→9→7→9→7
* 開始   : 2026-06-27 20:40:00 (UTC)
* 終了   : 2026-06-27 20:50:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→12→17→14→12→17→14
* 開始   : 2026-06-28 08:10:00 (UTC)
* 終了   : 2026-06-28 08:15:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.587σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host16-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 17→16→14→14→16→18→14→16
* 開始   : 2026-06-28 14:20:00 (UTC)
* 終了   : 2026-06-28 14:55:00 (UTC)
* 現象   : 2026-06-28 14:55:00 (UTC)を境に水準が 11.79から14.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→10→15→9→…→15→9→12→13
* 開始   : 2026-06-28 17:55:00 (UTC)
* 終了   : 2026-06-28 18:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260628-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→9→8→12→8→12→8→10
* 開始   : 2026-06-28 19:25:00 (UTC)
* 終了   : 2026-06-28 19:35:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 9→5→12→8→9→5→12→8→10
* 開始   : 2026-06-28 22:15:00 (UTC)
* 終了   : 2026-06-28 22:20:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.5825(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.528σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260628-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→8→9→10→10→10→13
* 開始   : 2026-06-29 01:40:00 (UTC)
* 終了   : 2026-06-29 02:10:00 (UTC)
* 現象   : 2026-06-29 02:10:00 (UTC)を境に水準が 11.85から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→10→9→10→10→10→10
* 開始   : 2026-06-29 02:25:00 (UTC)
* 終了   : 2026-06-29 02:55:00 (UTC)
* 現象   : 2026-06-29 02:55:00 (UTC)を境に水準が 11.81から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.178, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→8→6→10→8→6→10→7
* 開始   : 2026-06-29 22:55:00 (UTC)
* 終了   : 2026-06-29 23:00:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260629-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260629-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→10→11→12→11→10→10→11→14
* 開始   : 2026-06-30 02:30:00 (UTC)
* 終了   : 2026-06-30 03:45:00 (UTC)
* 現象   : 2026-06-30 03:45:00 (UTC)を境に水準が 14.94から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→9→9→10→11→11→10→13→15
* 開始   : 2026-06-30 02:40:00 (UTC)
* 終了   : 2026-06-30 03:55:00 (UTC)
* 現象   : 2026-06-30 03:55:00 (UTC)を境に水準が 14.87から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.148, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→10→10→12→10→11→12→13→12
* 開始   : 2026-06-30 03:15:00 (UTC)
* 終了   : 2026-06-30 04:45:00 (UTC)
* 現象   : 2026-06-30 04:45:00 (UTC)を境に水準が 14.95から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.423, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 22→20→24→22→25→24→22→25→22
* 開始   : 2026-06-30 10:50:00 (UTC)
* 終了   : 2026-06-30 11:00:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 23→19→18→22→23→19→18→22→21
* 開始   : 2026-06-30 13:25:00 (UTC)
* 終了   : 2026-06-30 13:30:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-041 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-042 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 17→15→16→15→15→14→15
* 開始   : 2026-06-30 18:05:00 (UTC)
* 終了   : 2026-06-30 18:35:00 (UTC)
* 現象   : 2026-06-30 18:35:00 (UTC)を境に水準が 14.97から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.514, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→15→11→10→14→15→11→10→14
* 開始   : 2026-06-30 18:50:00 (UTC)
* 終了   : 2026-06-30 18:55:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-057 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260630-host16-011 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
