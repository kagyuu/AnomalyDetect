# host07 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host07 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 348 (SEVERE: 22, FATAL: 134, WARN: 192, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 22 | 134 | 192 | 348 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260706-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→17→14→13→…→15→11→14→13
* 開始   : 2026-07-06 01:40:00 (UTC)
* 終了   : 2026-07-06 20:10:00 (UTC)
* 現象   : 2026-07-06 20:10:00 (UTC)を境に水準が 11.83から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.816, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.886, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host07-001 active_connections の推移](charts/EVT-20260706-host07-001.svg)

# イベントID( EVT-20260706-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→17→15→16→…→12→14→12→14
* 開始   : 2026-07-06 02:00:00 (UTC)
* 終了   : 2026-07-06 19:40:00 (UTC)
* 現象   : 2026-07-06 19:40:00 (UTC)を境に水準が 11.94から14.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.055, 限界=2.701)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host07-002 active_connections の推移](charts/EVT-20260706-host07-002.svg)

# イベントID( EVT-20260706-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→14→16→17→…→11→13→11→12
* 開始   : 2026-07-06 02:05:00 (UTC)
* 終了   : 2026-07-06 19:50:00 (UTC)
* 現象   : 2026-07-06 19:50:00 (UTC)を境に水準が 11.89から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.157, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.022, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host07-003 active_connections の推移](charts/EVT-20260706-host07-003.svg)

# イベントID( EVT-20260706-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→16→17→15→…→14→15→14→13
* 開始   : 2026-07-06 02:50:00 (UTC)
* 終了   : 2026-07-06 21:50:00 (UTC)
* 現象   : 2026-07-06 21:50:00 (UTC)を境に水準が 11.7から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.704, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host07-005 active_connections の推移](charts/EVT-20260706-host07-005.svg)

# イベントID( EVT-20260706-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→17→18→19→…→12→15→13→12
* 開始   : 2026-07-06 03:20:00 (UTC)
* 終了   : 2026-07-06 21:45:00 (UTC)
* 現象   : 2026-07-06 21:45:00 (UTC)を境に水準が 11.82から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.694, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host07-006 active_connections の推移](charts/EVT-20260706-host07-006.svg)

# イベントID( EVT-20260706-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→15→…→15→14→12→14
* 開始   : 2026-07-06 04:20:00 (UTC)
* 終了   : 2026-07-06 20:00:00 (UTC)
* 現象   : 2026-07-06 20:00:00 (UTC)を境に水準が 11.85から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.897, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.213, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host07-007 active_connections の推移](charts/EVT-20260706-host07-007.svg)

# イベントID( EVT-20260713-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 16→15→16→13→…→13→12→15→13
* 開始   : 2026-07-13 01:45:00 (UTC)
* 終了   : 2026-07-13 20:00:00 (UTC)
* 現象   : 2026-07-13 20:00:00 (UTC)を境に水準が 11.74から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.474σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.881, 限界=2.701)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.01, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host07-003 active_connections の推移](charts/EVT-20260713-host07-003.svg)

# イベントID( EVT-20260713-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→16→…→16→14→12→13
* 開始   : 2026-07-13 02:00:00 (UTC)
* 終了   : 2026-07-13 20:35:00 (UTC)
* 現象   : 2026-07-13 20:35:00 (UTC)を境に水準が 11.72から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.663, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.913, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host07-004 active_connections の推移](charts/EVT-20260713-host07-004.svg)

# イベントID( EVT-20260713-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→17→16→18→…→13→14→12→14
* 開始   : 2026-07-13 03:15:00 (UTC)
* 終了   : 2026-07-13 19:05:00 (UTC)
* 現象   : 2026-07-13 19:05:00 (UTC)を境に水準が 11.94から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.49σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.773, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.28, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host07-006 active_connections の推移](charts/EVT-20260713-host07-006.svg)

# イベントID( EVT-20260713-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→15→13→16→…→14→15→13→16
* 開始   : 2026-07-13 03:20:00 (UTC)
* 終了   : 2026-07-13 21:45:00 (UTC)
* 現象   : 2026-07-13 21:45:00 (UTC)を境に水準が 11.75から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.847, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host07-007 active_connections の推移](charts/EVT-20260713-host07-007.svg)

# イベントID( EVT-20260713-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→16→15→17→…→15→14→15→13
* 開始   : 2026-07-13 03:45:00 (UTC)
* 終了   : 2026-07-13 21:15:00 (UTC)
* 現象   : 2026-07-13 21:15:00 (UTC)を境に水準が 11.92から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.727, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host07-008 active_connections の推移](charts/EVT-20260713-host07-008.svg)

# イベントID( EVT-20260713-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→12→13→15→…→14→13→11→12
* 開始   : 2026-07-13 04:00:00 (UTC)
* 終了   : 2026-07-13 19:05:00 (UTC)
* 現象   : 2026-07-13 19:05:00 (UTC)を境に水準が 11.83から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.685, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.674, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host07-009 active_connections の推移](charts/EVT-20260713-host07-009.svg)

# イベントID( EVT-20260720-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→14→15→14→…→11→14→9→13
* 開始   : 2026-07-20 01:55:00 (UTC)
* 終了   : 2026-07-20 19:35:00 (UTC)
* 現象   : 2026-07-20 19:35:00 (UTC)を境に水準が 11.86から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.101, 限界=2.701)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host07-001 active_connections の推移](charts/EVT-20260720-host07-001.svg)

# イベントID( EVT-20260720-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→14→13→14→…→14→15→13→14
* 開始   : 2026-07-20 02:20:00 (UTC)
* 終了   : 2026-07-20 20:40:00 (UTC)
* 現象   : 2026-07-20 20:40:00 (UTC)を境に水準が 11.9から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.618σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.658, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.577, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host07-002 active_connections の推移](charts/EVT-20260720-host07-002.svg)

# イベントID( EVT-20260720-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 17→15→17→16→…→12→14→12→14
* 開始   : 2026-07-20 02:40:00 (UTC)
* 終了   : 2026-07-20 20:35:00 (UTC)
* 現象   : 2026-07-20 20:35:00 (UTC)を境に水準が 11.89から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.973, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.578, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host07-003 active_connections の推移](charts/EVT-20260720-host07-003.svg)

# イベントID( EVT-20260720-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→15→14→17→…→14→13→14→13
* 開始   : 2026-07-20 03:45:00 (UTC)
* 終了   : 2026-07-20 20:40:00 (UTC)
* 現象   : 2026-07-20 20:40:00 (UTC)を境に水準が 11.83から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.809σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.884, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.592, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host07-006 active_connections の推移](charts/EVT-20260720-host07-006.svg)

# イベントID( EVT-20260727-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→17→16→17→…→15→12→10→11
* 開始   : 2026-07-27 01:30:00 (UTC)
* 終了   : 2026-07-27 19:45:00 (UTC)
* 現象   : 2026-07-27 19:45:00 (UTC)を境に水準が 11.8から14.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.787, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.99, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host07-001 active_connections の推移](charts/EVT-20260727-host07-001.svg)

# イベントID( EVT-20260727-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→16→15→16→…→15→13→14→13
* 開始   : 2026-07-27 02:50:00 (UTC)
* 終了   : 2026-07-27 20:40:00 (UTC)
* 現象   : 2026-07-27 20:40:00 (UTC)を境に水準が 11.83から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.084σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.088, 限界=2.701)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host07-002 active_connections の推移](charts/EVT-20260727-host07-002.svg)

# イベントID( EVT-20260727-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 16→15→16→15→…→15→13→12→16
* 開始   : 2026-07-27 02:50:00 (UTC)
* 終了   : 2026-07-27 18:50:00 (UTC)
* 現象   : 2026-07-27 18:50:00 (UTC)を境に水準が 11.97から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.907, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.98, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host07-003 active_connections の推移](charts/EVT-20260727-host07-003.svg)

# イベントID( EVT-20260727-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→15→16→15→…→11→10→11→12
* 開始   : 2026-07-27 03:15:00 (UTC)
* 終了   : 2026-07-27 21:45:00 (UTC)
* 現象   : 2026-07-27 21:45:00 (UTC)を境に水準が 11.8から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.933, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.517, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host07-004 active_connections の推移](charts/EVT-20260727-host07-004.svg)

# イベントID( EVT-20260727-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→14→16→15→…→13→16→10→14
* 開始   : 2026-07-27 03:15:00 (UTC)
* 終了   : 2026-07-27 20:40:00 (UTC)
* 現象   : 2026-07-27 20:40:00 (UTC)を境に水準が 11.94から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.764, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host07-005 active_connections の推移](charts/EVT-20260727-host07-005.svg)

# イベントID( EVT-20260727-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→15→17→13→…→15→11→13→15
* 開始   : 2026-07-27 03:45:00 (UTC)
* 終了   : 2026-07-27 22:00:00 (UTC)
* 現象   : 2026-07-27 22:00:00 (UTC)を境に水準が 11.84から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.848, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.674, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host07-006 active_connections の推移](charts/EVT-20260727-host07-006.svg)

# イベントID( EVT-20260701-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→14→19→16→16
* 開始   : 2026-07-01 06:00:00 (UTC)
* 終了   : 2026-07-01 06:00:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.434倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.014σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host07-004 active_connections の推移](charts/EVT-20260701-host07-004.svg)

# イベントID( EVT-20260701-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 18→15→17→17→16→20
* 開始   : 2026-07-01 06:15:00 (UTC)
* 終了   : 2026-07-01 06:40:00 (UTC)
* 現象   : 2026-07-01 06:40:00 (UTC)を境に水準が 14.98から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.468, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 22→23→24→22→…→22→26→22→21
* 開始   : 2026-07-01 10:40:00 (UTC)
* 終了   : 2026-07-01 10:50:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host07-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-lsfhost01-037 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260701-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 20→20→15→18→21
* 開始   : 2026-07-01 15:30:00 (UTC)
* 終了   : 2026-07-01 15:30:00 (UTC)
* 現象   : 平常時(20)に対し 0.75(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260701-host07-010 active_connections の推移](charts/EVT-20260701-host07-010.svg)

# イベントID( EVT-20260701-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 16→17→13→17→16
* 開始   : 2026-07-01 17:20:00 (UTC)
* 終了   : 2026-07-01 17:20:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260701-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 17→16→12→15→16
* 開始   : 2026-07-01 17:40:00 (UTC)
* 終了   : 2026-07-01 17:40:00 (UTC)
* 現象   : 平常時(17)に対し 0.7059(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.474σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host07-013 active_connections の推移](charts/EVT-20260701-host07-013.svg)

# イベントID( EVT-20260702-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 9→8→14→9→12
* 開始   : 2026-07-02 02:30:00 (UTC)
* 終了   : 2026-07-02 02:30:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.6倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.686σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 13→14→18→13→14
* 開始   : 2026-07-02 05:20:00 (UTC)
* 終了   : 2026-07-02 05:20:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.403倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.59σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host07-002 active_connections の推移](charts/EVT-20260702-host07-002.svg)

# イベントID( EVT-20260702-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→13→18→12→18→12→18→17→16
* 開始   : 2026-07-02 05:35:00 (UTC)
* 終了   : 2026-07-02 06:05:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260702-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260702-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 20→20→24→20→20→20→22→24→22
* 開始   : 2026-07-02 09:05:00 (UTC)
* 終了   : 2026-07-02 09:55:00 (UTC)
* 現象   : 2026-07-02 09:55:00 (UTC)を境に水準が 14.97から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.289, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→14→10→13→15
* 開始   : 2026-07-02 18:50:00 (UTC)
* 終了   : 2026-07-02 18:50:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.663(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.555σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260702-host07-013 active_connections の推移](charts/EVT-20260702-host07-013.svg)

# イベントID( EVT-20260702-host07-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→12→8→11→10
* 開始   : 2026-07-02 20:00:00 (UTC)
* 終了   : 2026-07-02 20:00:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host04-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260702-host07-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 9→8→6→9→8→6→9
* 開始   : 2026-07-02 21:25:00 (UTC)
* 終了   : 2026-07-02 22:20:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.185σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-020 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host02-021 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-080 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host01-012 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260702-host02-022 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260702-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260702-host07-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-020 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→10→6→10→10
* 開始   : 2026-07-02 21:30:00 (UTC)
* 終了   : 2026-07-02 21:30:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-019 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host13-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host07-020 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→13→9→12→13
* 開始   : 2026-07-03 19:40:00 (UTC)
* 終了   : 2026-07-03 19:40:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→11→8→9→…→8→9→7→11
* 開始   : 2026-07-03 20:35:00 (UTC)
* 終了   : 2026-07-03 20:45:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.967σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-078 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260703-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 7→7→4→9→8
* 開始   : 2026-07-03 23:40:00 (UTC)
* 終了   : 2026-07-03 23:40:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→12→9→11→…→11→12→10→11
* 開始   : 2026-07-04 05:05:00 (UTC)
* 終了   : 2026-07-04 19:00:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.922, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260704-host07-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 45 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260704-host07-001 active_connections の推移](charts/EVT-20260704-host07-001.svg)

# イベントID( EVT-20260704-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→10→9→12→…→13→11→15→12
* 開始   : 2026-07-04 05:25:00 (UTC)
* 終了   : 2026-07-04 19:00:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.76, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260704-host07-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 40 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260704-host07-003 active_connections の推移](charts/EVT-20260704-host07-003.svg)

# イベントID( EVT-20260704-host07-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 11→12→10→12→…→12→11→13→12
* 開始   : 2026-07-04 05:35:00 (UTC)
* 終了   : 2026-07-04 19:25:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.254, 限界=2.701)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260704-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260704-host07-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260704-host07-004 active_connections の推移](charts/EVT-20260704-host07-004.svg)

# イベントID( EVT-20260704-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 12→11→14→12→…→11→10→11→10
* 開始   : 2026-07-04 05:45:00 (UTC)
* 終了   : 2026-07-04 19:20:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.761, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260704-host07-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260704-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260704-host07-005 active_connections の推移](charts/EVT-20260704-host07-005.svg)

# イベントID( EVT-20260704-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→11→10→12→…→9→11→12→9
* 開始   : 2026-07-04 06:10:00 (UTC)
* 終了   : 2026-07-04 19:30:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.28, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260704-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260704-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host07-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→15→14→13→…→13→12→13→12
* 開始   : 2026-07-04 07:25:00 (UTC)
* 終了   : 2026-07-04 18:45:00 (UTC)
* 現象   : 11.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.887, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260704-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260704-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260704-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260704-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.3 時間

![EVT-20260704-host07-007 active_connections の推移](charts/EVT-20260704-host07-007.svg)

# イベントID( EVT-20260705-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 8→8→4→9→8
* 開始   : 2026-07-05 01:25:00 (UTC)
* 終了   : 2026-07-05 01:25:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260705-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 11→10→15→12→10
* 開始   : 2026-07-05 05:10:00 (UTC)
* 終了   : 2026-07-05 05:10:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260705-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→15→10→14→13
* 開始   : 2026-07-05 16:15:00 (UTC)
* 終了   : 2026-07-05 16:15:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→13→18→12→12
* 開始   : 2026-07-05 16:40:00 (UTC)
* 終了   : 2026-07-05 16:40:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260705-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→10→7→12→12
* 開始   : 2026-07-05 18:30:00 (UTC)
* 終了   : 2026-07-05 18:30:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→8→5→7→11
* 開始   : 2026-07-06 21:45:00 (UTC)
* 終了   : 2026-07-06 21:45:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260706-lsfhost01-057 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260706-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 9→7→13→11→9
* 開始   : 2026-07-07 02:20:00 (UTC)
* 終了   : 2026-07-07 02:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.243σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-006 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260707-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 16→15→14→16→14→15
* 開始   : 2026-07-07 04:45:00 (UTC)
* 終了   : 2026-07-07 05:15:00 (UTC)
* 現象   : 2026-07-07 05:15:00 (UTC)を境に水準が 14.96から14.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 17→22→19→22→19→22→18→20
* 開始   : 2026-07-07 08:05:00 (UTC)
* 終了   : 2026-07-07 08:15:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.263倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260707-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260707-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 18→22→25→22→22
* 開始   : 2026-07-07 09:35:00 (UTC)
* 終了   : 2026-07-07 09:35:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.23倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 22→23→17→22→22
* 開始   : 2026-07-07 13:30:00 (UTC)
* 終了   : 2026-07-07 13:30:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 19→20→15→18→19
* 開始   : 2026-07-07 15:25:00 (UTC)
* 終了   : 2026-07-07 15:25:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.7438(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.6σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host07-010 active_connections の推移](charts/EVT-20260707-host07-010.svg)

# イベントID( EVT-20260707-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→16→10→13→14
* 開始   : 2026-07-07 18:50:00 (UTC)
* 終了   : 2026-07-07 18:50:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260707-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 18→19→20→17→20→17→20→19
* 開始   : 2026-07-08 07:40:00 (UTC)
* 終了   : 2026-07-08 08:25:00 (UTC)
* 現象   : 平常時(16.75)に対し 1.194倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 45 分
  - EVT-20260708-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260708-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 24→24→22→20→23→20→21→21→23
* 開始   : 2026-07-08 13:05:00 (UTC)
* 終了   : 2026-07-08 14:15:00 (UTC)
* 現象   : 2026-07-08 14:15:00 (UTC)を境に水準が 15から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.142σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→14→9→13→14
* 開始   : 2026-07-08 19:20:00 (UTC)
* 終了   : 2026-07-08 19:20:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 8→10→13→8→11
* 開始   : 2026-07-09 02:15:00 (UTC)
* 終了   : 2026-07-09 02:15:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.011σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→13→18→15→13→18→15→14
* 開始   : 2026-07-09 06:00:00 (UTC)
* 終了   : 2026-07-09 06:05:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.35倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host07-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260709-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→18→19→16→20→19→16→20→17
* 開始   : 2026-07-09 07:15:00 (UTC)
* 終了   : 2026-07-09 08:00:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260709-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260709-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 18→16→21→18→18
* 開始   : 2026-07-09 07:40:00 (UTC)
* 終了   : 2026-07-09 07:40:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.292倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.3σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260709-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 19→19→24→21→23
* 開始   : 2026-07-09 10:00:00 (UTC)
* 終了   : 2026-07-09 10:00:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.22倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.011σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→13→9→13→12
* 開始   : 2026-07-09 19:40:00 (UTC)
* 終了   : 2026-07-09 19:40:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→13→16→14→11
* 開始   : 2026-07-10 04:40:00 (UTC)
* 終了   : 2026-07-10 04:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→14→18→16→13
* 開始   : 2026-07-10 05:45:00 (UTC)
* 終了   : 2026-07-10 05:45:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 19→18→23→20→19
* 開始   : 2026-07-10 08:40:00 (UTC)
* 終了   : 2026-07-10 08:40:00 (UTC)
* 現象   : 平常時(18.17)に対し 1.266倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 21→20→16→21→20
* 開始   : 2026-07-10 15:15:00 (UTC)
* 終了   : 2026-07-10 15:15:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 13→9→11→8→9→11→8→9→12
* 開始   : 2026-07-10 20:00:00 (UTC)
* 終了   : 2026-07-10 20:10:00 (UTC)
* 現象   : 平常時(13)に対し 0.6923(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.779σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host07-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-lsfhost01-076 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260710-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-078 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260710-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→10→6→9→9
* 開始   : 2026-07-10 21:15:00 (UTC)
* 終了   : 2026-07-10 21:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 10→10→6→10→8
* 開始   : 2026-07-10 22:05:00 (UTC)
* 終了   : 2026-07-10 22:05:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-086 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260710-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 9→9→4→10→9
* 開始   : 2026-07-11 02:30:00 (UTC)
* 終了   : 2026-07-11 02:30:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260711-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→9→10→9→…→13→12→10→13
* 開始   : 2026-07-11 04:40:00 (UTC)
* 終了   : 2026-07-11 18:40:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.768, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260711-host07-002 active_connections の推移](charts/EVT-20260711-host07-002.svg)

# イベントID( EVT-20260711-host07-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 13→15→11→14→…→11→12→11→12
* 開始   : 2026-07-11 04:50:00 (UTC)
* 終了   : 2026-07-11 18:50:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.857, 限界=2.701)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260711-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260711-host07-003 active_connections の推移](charts/EVT-20260711-host07-003.svg)

# イベントID( EVT-20260711-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→12→11→12→…→10→11→12→11
* 開始   : 2026-07-11 05:45:00 (UTC)
* 終了   : 2026-07-11 18:55:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.802, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260711-host07-004 active_connections の推移](charts/EVT-20260711-host07-004.svg)

# イベントID( EVT-20260711-host07-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→10→12→14→…→12→11→12→10
* 開始   : 2026-07-11 05:50:00 (UTC)
* 終了   : 2026-07-11 18:40:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.899, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260711-host07-005 active_connections の推移](charts/EVT-20260711-host07-005.svg)

# イベントID( EVT-20260711-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→11→12→10→…→11→10→14→13
* 開始   : 2026-07-11 06:00:00 (UTC)
* 終了   : 2026-07-11 18:25:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.785, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260711-host07-006 active_connections の推移](charts/EVT-20260711-host07-006.svg)

# イベントID( EVT-20260711-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→11→14→12→…→9→10→9→11
* 開始   : 2026-07-11 06:25:00 (UTC)
* 終了   : 2026-07-11 19:30:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.852, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260711-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260711-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260711-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260711-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260711-host07-007 active_connections の推移](charts/EVT-20260711-host07-007.svg)

# イベントID( EVT-20260711-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→9→11→9→…→9→8→9→10
* 開始   : 2026-07-11 19:35:00 (UTC)
* 終了   : 2026-07-11 20:15:00 (UTC)
* 現象   : 40分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.491σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.769, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 40 分
  - EVT-20260711-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260711-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 20 分
  - EVT-20260711-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260711-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260711-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260711-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260711-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260711-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260711-host07-008 active_connections の推移](charts/EVT-20260711-host07-008.svg)

# イベントID( EVT-20260712-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→10→6→9→9
* 開始   : 2026-07-12 19:50:00 (UTC)
* 終了   : 2026-07-12 19:50:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.5581(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→8→11→8→11→8→9
* 開始   : 2026-07-13 00:30:00 (UTC)
* 終了   : 2026-07-13 01:30:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48倍(4)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260713-lsfhost01-002 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260713-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260713-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→9→9→13→8→11→9→11→11
* 開始   : 2026-07-14 02:20:00 (UTC)
* 終了   : 2026-07-14 03:15:00 (UTC)
* 現象   : 2026-07-14 03:15:00 (UTC)を境に水準が 14.93から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.071, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 16→18→20→18→20→18
* 開始   : 2026-07-14 06:45:00 (UTC)
* 終了   : 2026-07-14 07:50:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260714-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260714-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260714-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260714-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 19→17→23→20→18
* 開始   : 2026-07-14 08:15:00 (UTC)
* 終了   : 2026-07-14 08:15:00 (UTC)
* 現象   : 平常時(18)に対し 1.278倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host07-003 active_connections の推移](charts/EVT-20260714-host07-003.svg)

# イベントID( EVT-20260714-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→22→20→23→22→20→23→21
* 開始   : 2026-07-14 08:30:00 (UTC)
* 終了   : 2026-07-14 09:05:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260714-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260714-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→14→8→13→12
* 開始   : 2026-07-14 19:30:00 (UTC)
* 終了   : 2026-07-14 20:05:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.5783(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.073σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260714-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260714-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host07-007 active_connections の推移](charts/EVT-20260714-host07-007.svg)

# イベントID( EVT-20260715-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 19→20→16→19→19
* 開始   : 2026-07-15 15:25:00 (UTC)
* 終了   : 2026-07-15 15:25:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.147σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260715-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 13→14→10→11→…→10→11→13→12
* 開始   : 2026-07-15 18:55:00 (UTC)
* 終了   : 2026-07-15 19:00:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.394σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260715-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→13→9→14→14
* 開始   : 2026-07-15 19:20:00 (UTC)
* 終了   : 2026-07-15 19:20:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.6353(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.59σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host07-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host07-012 active_connections の推移](charts/EVT-20260715-host07-012.svg)

# イベントID( EVT-20260716-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 22→18→25→20→21
* 開始   : 2026-07-16 10:30:00 (UTC)
* 終了   : 2026-07-16 10:30:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260716-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 20→18→15→16→…→15→16→17→20
* 開始   : 2026-07-16 16:05:00 (UTC)
* 終了   : 2026-07-16 16:10:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260716-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→9→8→12→9→8→12→10
* 開始   : 2026-07-16 20:15:00 (UTC)
* 終了   : 2026-07-16 20:20:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.6879(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.837σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-078 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260716-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 8→11→12→10→…→10→5→10→9
* 開始   : 2026-07-16 22:00:00 (UTC)
* 終了   : 2026-07-16 22:10:00 (UTC)
* 現象   : 木曜22時台の平常値(8.445)に対し 12であった
* 説明   : ALG-A1: 移動平均からの残差が 3.358σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.149σ 外れた (平常値=8.445)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260716-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-087 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260716-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 7→11→3→9→…→9→5→7→8
* 開始   : 2026-07-17 00:10:00 (UTC)
* 終了   : 2026-07-17 00:20:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.3495(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.879σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260717-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260717-host07-001 active_connections の推移](charts/EVT-20260717-host07-001.svg)

# イベントID( EVT-20260717-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→19→20→17→16→19→20→17→16
* 開始   : 2026-07-17 06:40:00 (UTC)
* 終了   : 2026-07-17 06:45:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.26倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.734σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260717-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 23→22→17→19→22
* 開始   : 2026-07-17 14:45:00 (UTC)
* 終了   : 2026-07-17 14:45:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 20→19→16→19→16→19→16→17→18
* 開始   : 2026-07-17 16:35:00 (UTC)
* 終了   : 2026-07-17 17:25:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260717-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260717-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 16→17→13→16→16
* 開始   : 2026-07-17 17:15:00 (UTC)
* 終了   : 2026-07-17 17:15:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→14→9→10→12→14→9→10→12
* 開始   : 2026-07-17 19:45:00 (UTC)
* 終了   : 2026-07-17 19:50:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 12→9→9→9→11→12→10→12→12
* 開始   : 2026-07-17 21:20:00 (UTC)
* 終了   : 2026-07-18 00:00:00 (UTC)
* 現象   : 2026-07-18 00:00:00 (UTC)を境に水準が 15.04から11.75へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.21, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→10→5→7→8
* 開始   : 2026-07-17 23:10:00 (UTC)
* 終了   : 2026-07-17 23:10:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→10→14→11→10
* 開始   : 2026-07-18 04:30:00 (UTC)
* 終了   : 2026-07-18 04:30:00 (UTC)
* 現象   : 平常時(9.167)に対し 1.527倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.358σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260718-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260718-lsfhost01-007 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260718-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260718-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260718-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→11→13→12→…→13→14→12→13
* 開始   : 2026-07-18 04:40:00 (UTC)
* 終了   : 2026-07-18 19:20:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.77, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260718-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260718-lsfhost01-007 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.7 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260718-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260718-host07-002 active_connections の推移](charts/EVT-20260718-host07-002.svg)

# イベントID( EVT-20260718-host07-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→12→10→14→…→11→10→13→12
* 開始   : 2026-07-18 05:15:00 (UTC)
* 終了   : 2026-07-18 20:10:00 (UTC)
* 現象   : 14.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.911, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260718-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260718-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260718-host07-003 active_connections の推移](charts/EVT-20260718-host07-003.svg)

# イベントID( EVT-20260718-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→14→12→13→…→10→13→12→13
* 開始   : 2026-07-18 05:45:00 (UTC)
* 終了   : 2026-07-18 19:10:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.151, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260718-host07-004 active_connections の推移](charts/EVT-20260718-host07-004.svg)

# イベントID( EVT-20260718-host07-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→12→10→12→…→12→10→13→12
* 開始   : 2026-07-18 05:50:00 (UTC)
* 終了   : 2026-07-18 19:05:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.987, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260718-host07-005 active_connections の推移](charts/EVT-20260718-host07-005.svg)

# イベントID( EVT-20260718-host07-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 11→12→10→12→…→11→10→13→14
* 開始   : 2026-07-18 05:50:00 (UTC)
* 終了   : 2026-07-18 19:35:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.798, 限界=2.701)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260718-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260718-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260718-host07-006 active_connections の推移](charts/EVT-20260718-host07-006.svg)

# イベントID( EVT-20260718-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→10→13→11→…→13→14→13→14
* 開始   : 2026-07-18 06:35:00 (UTC)
* 終了   : 2026-07-18 19:10:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.904, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260718-host07-007 active_connections の推移](charts/EVT-20260718-host07-007.svg)

# イベントID( EVT-20260719-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 10→11→14→9→9
* 開始   : 2026-07-19 03:10:00 (UTC)
* 終了   : 2026-07-19 03:10:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host07-002 active_connections の推移](charts/EVT-20260719-host07-002.svg)

# イベントID( EVT-20260719-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→10→15→11→10
* 開始   : 2026-07-19 05:45:00 (UTC)
* 終了   : 2026-07-19 05:45:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.452倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.243σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→15→10→13→13
* 開始   : 2026-07-19 16:20:00 (UTC)
* 終了   : 2026-07-19 16:20:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host07-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→17→16→15→…→13→14→13→12
* 開始   : 2026-07-20 03:00:00 (UTC)
* 終了   : 2026-07-20 21:20:00 (UTC)
* 現象   : 2026-07-20 21:20:00 (UTC)を境に水準が 11.82から14.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.881, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host07-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→12→14→12→…→16→14→13→16
* 開始   : 2026-07-20 03:05:00 (UTC)
* 終了   : 2026-07-20 21:30:00 (UTC)
* 現象   : 2026-07-20 21:30:00 (UTC)を境に水準が 11.86から15.07へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.044, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host07-005 active_connections の推移](charts/EVT-20260720-host07-005.svg)

# イベントID( EVT-20260721-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 11→10→16→11→12
* 開始   : 2026-07-21 04:40:00 (UTC)
* 終了   : 2026-07-21 04:40:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.3σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→18→21→17→17
* 開始   : 2026-07-21 07:20:00 (UTC)
* 終了   : 2026-07-21 07:20:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 22→23→26→22→24
* 開始   : 2026-07-21 12:30:00 (UTC)
* 終了   : 2026-07-21 12:30:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.214倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260721-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→9→6→8→12
* 開始   : 2026-07-21 21:05:00 (UTC)
* 終了   : 2026-07-21 21:05:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.127σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→10→6→7→…→6→7→12→10
* 開始   : 2026-07-21 21:20:00 (UTC)
* 終了   : 2026-07-21 21:25:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-073 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260721-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 10→12→14→15→…→14→15→10→12
* 開始   : 2026-07-22 04:10:00 (UTC)
* 終了   : 2026-07-22 05:15:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260722-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260722-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260722-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→15→17→14→13
* 開始   : 2026-07-22 05:25:00 (UTC)
* 終了   : 2026-07-22 05:25:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 18→16→17→17→16→17
* 開始   : 2026-07-22 05:55:00 (UTC)
* 終了   : 2026-07-22 07:15:00 (UTC)
* 現象   : 2026-07-22 07:15:00 (UTC)を境に水準が 15.04から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.011σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.468, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→16→20→18→17
* 開始   : 2026-07-22 07:15:00 (UTC)
* 終了   : 2026-07-22 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 24→20→21→22
* 開始   : 2026-07-22 09:00:00 (UTC)
* 終了   : 2026-07-22 09:15:00 (UTC)
* 現象   : 2026-07-22 09:15:00 (UTC)を境に水準が 15.03から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.549σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.832, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→16→15→18→…→18→14→19→16
* 開始   : 2026-07-22 16:45:00 (UTC)
* 終了   : 2026-07-22 18:00:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260722-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260722-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260722-host07-010 active_connections の推移](charts/EVT-20260722-host07-010.svg)

# イベントID( EVT-20260723-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 9→11→14→8→11
* 開始   : 2026-07-23 03:15:00 (UTC)
* 終了   : 2026-07-23 03:15:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.585倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.607σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260723-host07-001 active_connections の推移](charts/EVT-20260723-host07-001.svg)

# イベントID( EVT-20260723-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→20→23→19→17
* 開始   : 2026-07-23 08:20:00 (UTC)
* 終了   : 2026-07-23 08:20:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.29倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.599σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host07-006 active_connections の推移](charts/EVT-20260723-host07-006.svg)

# イベントID( EVT-20260723-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 20→20→23→20→22
* 開始   : 2026-07-23 08:55:00 (UTC)
* 終了   : 2026-07-23 08:55:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→14→17→14→17→14→13
* 開始   : 2026-07-24 05:30:00 (UTC)
* 終了   : 2026-07-24 06:05:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.325倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.926σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 35 分
  - EVT-20260724-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260724-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host07-002 active_connections の推移](charts/EVT-20260724-host07-002.svg)

# イベントID( EVT-20260724-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 23→23→23→24→23→23→23
* 開始   : 2026-07-24 12:20:00 (UTC)
* 終了   : 2026-07-24 14:50:00 (UTC)
* 現象   : 2026-07-24 14:50:00 (UTC)を境に水準が 14.88から13.28へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→10→6→9→10
* 開始   : 2026-07-24 21:20:00 (UTC)
* 終了   : 2026-07-24 21:20:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host07-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→14→11→12→…→13→10→15→10
* 開始   : 2026-07-25 05:30:00 (UTC)
* 終了   : 2026-07-25 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.843, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260725-host07-002 active_connections の推移](charts/EVT-20260725-host07-002.svg)

# イベントID( EVT-20260725-host07-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→10→12→11→…→10→9→13→9
* 開始   : 2026-07-25 05:30:00 (UTC)
* 終了   : 2026-07-25 19:35:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.184, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260725-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.1 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260725-host07-003 active_connections の推移](charts/EVT-20260725-host07-003.svg)

# イベントID( EVT-20260725-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→11→12→9→…→11→12→11→10
* 開始   : 2026-07-25 05:35:00 (UTC)
* 終了   : 2026-07-25 20:35:00 (UTC)
* 現象   : 15.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.575σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.811, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260725-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260725-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 14.8 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.5 時間
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260725-host07-004 active_connections の推移](charts/EVT-20260725-host07-004.svg)

# イベントID( EVT-20260725-host07-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→11→12→9→…→12→10→11→12
* 開始   : 2026-07-25 05:40:00 (UTC)
* 終了   : 2026-07-25 18:55:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.752, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260725-host07-005 active_connections の推移](charts/EVT-20260725-host07-005.svg)

# イベントID( EVT-20260725-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 13→12→11→13→…→10→11→13→12
* 開始   : 2026-07-25 06:15:00 (UTC)
* 終了   : 2026-07-25 18:45:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.185σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.762, 限界=2.701)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260725-host07-006 active_connections の推移](charts/EVT-20260725-host07-006.svg)

# イベントID( EVT-20260725-host07-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 13→14→12→15→…→11→14→15→12
* 開始   : 2026-07-25 06:35:00 (UTC)
* 終了   : 2026-07-25 18:00:00 (UTC)
* 現象   : 11.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.918, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host07-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-host07-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.4 時間
  - EVT-20260725-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260725-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間

![EVT-20260725-host07-007 active_connections の推移](charts/EVT-20260725-host07-007.svg)

# イベントID( EVT-20260726-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→13→17→14→12
* 開始   : 2026-07-26 07:25:00 (UTC)
* 終了   : 2026-07-26 07:25:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 9→10→15→11→11
* 開始   : 2026-07-28 04:15:00 (UTC)
* 終了   : 2026-07-28 04:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.452倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.243σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260728-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→15→16→14→18→16→14→18→14
* 開始   : 2026-07-28 05:35:00 (UTC)
* 終了   : 2026-07-28 05:45:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260728-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260728-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 17→19→21→19→17→19→21→19→17
* 開始   : 2026-07-28 07:10:00 (UTC)
* 終了   : 2026-07-28 07:15:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host07-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host07-007 active_connections の推移](charts/EVT-20260728-host07-007.svg)

# イベントID( EVT-20260728-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 22→23→16→19→19
* 開始   : 2026-07-28 15:10:00 (UTC)
* 終了   : 2026-07-28 15:10:00 (UTC)
* 現象   : 平常時(20.83)に対し 0.768(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260728-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 16→17→11→13→14
* 開始   : 2026-07-28 18:25:00 (UTC)
* 終了   : 2026-07-28 18:25:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.6911(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.416σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260728-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→4→9→5→4→9→5→10→9
* 開始   : 2026-07-29 01:20:00 (UTC)
* 終了   : 2026-07-29 01:30:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.4571(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260729-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 17→15→12→17→12→17→12→15
* 開始   : 2026-07-29 17:55:00 (UTC)
* 終了   : 2026-07-29 18:05:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260729-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→15→19→17→16
* 開始   : 2026-07-30 06:25:00 (UTC)
* 終了   : 2026-07-30 06:25:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.185σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260730-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 18→16→22→20→16→22→20→17
* 開始   : 2026-07-30 08:25:00 (UTC)
* 終了   : 2026-07-30 08:30:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.269倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 21→21→26→19→21
* 開始   : 2026-07-30 10:40:00 (UTC)
* 終了   : 2026-07-30 10:40:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.233倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 19→19→16→20→18
* 開始   : 2026-07-30 15:40:00 (UTC)
* 終了   : 2026-07-30 15:40:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 19→17→15→19→18
* 開始   : 2026-07-30 16:10:00 (UTC)
* 終了   : 2026-07-30 16:10:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.069σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260730-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→16→18→14→16
* 開始   : 2026-07-31 06:00:00 (UTC)
* 終了   : 2026-07-31 06:00:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→15→19→18→…→19→18→14→16
* 開始   : 2026-07-31 06:15:00 (UTC)
* 終了   : 2026-07-31 06:20:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.341倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.358σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260731-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 22→24→24→22→24
* 開始   : 2026-07-31 11:45:00 (UTC)
* 終了   : 2026-07-31 13:05:00 (UTC)
* 現象   : 2026-07-31 13:05:00 (UTC)を境に水準が 15.01から12.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.2σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 22→21→17→23→19→21→17→23→19
* 開始   : 2026-07-31 14:55:00 (UTC)
* 終了   : 2026-07-31 15:00:00 (UTC)
* 現象   : 金曜14時台の平常値(20.59)に対し 17であった
* 説明   : ALG-A1: 移動平均からの残差が 3.316σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.039σ 外れた (平常値=20.59)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260731-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-039 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260731-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 8→11→13→7→…→13→7→12→11
* 開始   : 2026-07-01 03:15:00 (UTC)
* 終了   : 2026-07-01 03:20:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→12→14→11→…→11→15→10→13
* 開始   : 2026-07-01 04:05:00 (UTC)
* 終了   : 2026-07-01 04:15:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260701-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260701-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→15→11→15→11→15→11→13
* 開始   : 2026-07-01 04:45:00 (UTC)
* 終了   : 2026-07-01 04:55:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260701-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 20→19→23→20→19→23→20→22
* 開始   : 2026-07-01 09:20:00 (UTC)
* 終了   : 2026-07-01 09:25:00 (UTC)
* 現象   : 平常時(19.25)に対し 1.195倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-lsfhost01-034 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260701-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 21→20→24→21→…→21→18→22→21
* 開始   : 2026-07-01 10:40:00 (UTC)
* 終了   : 2026-07-01 10:50:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260701-lsfhost01-037 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260701-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host07-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 23→22→22→21→21→23→22
* 開始   : 2026-07-01 13:35:00 (UTC)
* 終了   : 2026-07-01 14:05:00 (UTC)
* 現象   : 2026-07-01 14:05:00 (UTC)を境に水準が 14.98から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.546, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 20→16→17→22→20→16→17→22→19
* 開始   : 2026-07-01 15:40:00 (UTC)
* 終了   : 2026-07-01 15:45:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.7901(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.972σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260701-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host07-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→9→11→10→10→12→11
* 開始   : 2026-07-01 19:50:00 (UTC)
* 終了   : 2026-07-01 21:20:00 (UTC)
* 現象   : 2026-07-01 21:20:00 (UTC)を境に水準が 14.9から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.327, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host07-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→9→8→10→8→10→8→8→10
* 開始   : 2026-07-01 22:45:00 (UTC)
* 終了   : 2026-07-02 00:00:00 (UTC)
* 現象   : 2026-07-02 00:00:00 (UTC)を境に水準が 14.83から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.329, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260701-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host07-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 7→5→7→11→5→7→11→7→8
* 開始   : 2026-07-01 22:45:00 (UTC)
* 終了   : 2026-07-01 22:55:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host09-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host05-019 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host07-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host07-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→7→5→9→5→9→5→8
* 開始   : 2026-07-01 23:00:00 (UTC)
* 終了   : 2026-07-01 23:10:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.5607(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.729σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host05-019 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-075 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260701-host07-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→16→14→15→16→14→15
* 開始   : 2026-07-02 05:45:00 (UTC)
* 終了   : 2026-07-02 05:50:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260702-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→18→16→19→18→16→19→15→17
* 開始   : 2026-07-02 06:30:00 (UTC)
* 終了   : 2026-07-02 06:40:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 18→20→21→19→21→19→21→18→20
* 開始   : 2026-07-02 08:15:00 (UTC)
* 終了   : 2026-07-02 08:25:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 23→20→25→22→…→22→18→20→22
* 開始   : 2026-07-02 14:15:00 (UTC)
* 終了   : 2026-07-02 14:25:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.172倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.575σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260702-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260702-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 17→15→17→14→15→17→14→16→17
* 開始   : 2026-07-02 16:55:00 (UTC)
* 終了   : 2026-07-02 17:05:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260702-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 18→14→18→14→18→14→17→16
* 開始   : 2026-07-02 17:10:00 (UTC)
* 終了   : 2026-07-02 17:20:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260702-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 18→17→15→14→…→15→14→15→17
* 開始   : 2026-07-02 17:15:00 (UTC)
* 終了   : 2026-07-02 17:20:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260702-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→14→12→11→14→12→11→14
* 開始   : 2026-07-02 18:35:00 (UTC)
* 終了   : 2026-07-02 18:40:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260702-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→11→15→11→12→11→12
* 開始   : 2026-07-02 19:20:00 (UTC)
* 終了   : 2026-07-02 19:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.953σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260702-host02-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→12→10→12→10→12
* 開始   : 2026-07-02 19:20:00 (UTC)
* 終了   : 2026-07-02 19:25:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.7229(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.676σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host07-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260702-host02-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 12→14→9→12→14→9→12→10
* 開始   : 2026-07-02 19:45:00 (UTC)
* 終了   : 2026-07-02 19:50:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.6968(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.75σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-019 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260702-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-068 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host07-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host07-018 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→13→10→11→11→8→10→10→11
* 開始   : 2026-07-02 20:30:00 (UTC)
* 終了   : 2026-07-02 21:40:00 (UTC)
* 現象   : 2026-07-02 21:40:00 (UTC)を境に水準が 14.98から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.121, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host07-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→11→14→11→14→11
* 開始   : 2026-07-03 04:20:00 (UTC)
* 終了   : 2026-07-03 04:25:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260703-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host07-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→13→15→12→13→15
* 開始   : 2026-07-03 04:35:00 (UTC)
* 終了   : 2026-07-03 05:00:00 (UTC)
* 現象   : 2026-07-03 05:00:00 (UTC)を境に水準が 14.93から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.809, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 18→17→20→19→17→20→19
* 開始   : 2026-07-03 07:35:00 (UTC)
* 終了   : 2026-07-03 07:40:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 21→19→23→21→…→21→17→18→21
* 開始   : 2026-07-03 08:40:00 (UTC)
* 終了   : 2026-07-03 08:50:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.548σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 17→15→17→14→15→17→14→17→15
* 開始   : 2026-07-03 16:45:00 (UTC)
* 終了   : 2026-07-03 16:55:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260703-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260703-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→14→13→14→13→14→15
* 開始   : 2026-07-03 18:05:00 (UTC)
* 終了   : 2026-07-03 18:10:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 14→12→10→12→10→12→10→12
* 開始   : 2026-07-03 19:25:00 (UTC)
* 終了   : 2026-07-03 19:35:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7018(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.961σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-072 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260703-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 9→11→7→13→8→11→7→13→8
* 開始   : 2026-07-03 21:20:00 (UTC)
* 終了   : 2026-07-03 21:25:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.6829(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host03-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260703-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host07-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 10→11→10→11→…→11→10→12→13
* 開始   : 2026-07-04 05:20:00 (UTC)
* 終了   : 2026-07-04 06:05:00 (UTC)
* 現象   : 45分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.807, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260704-host07-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260704-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260704-host07-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260704-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260704-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260704-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260704-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分

![EVT-20260704-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→9→8→8→8→8→9→11→8
* 開始   : 2026-07-05 00:40:00 (UTC)
* 終了   : 2026-07-05 01:45:00 (UTC)
* 現象   : 2026-07-05 01:45:00 (UTC)を境に水準が 11.9から11.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.888, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host07-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→10→9→10
* 開始   : 2026-07-05 01:25:00 (UTC)
* 終了   : 2026-07-05 01:40:00 (UTC)
* 現象   : 2026-07-05 01:40:00 (UTC)を境に水準が 11.77から11.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.312, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 8→11→5→8→11→5→8→6
* 開始   : 2026-07-05 02:25:00 (UTC)
* 終了   : 2026-07-05 02:30:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host07-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→13→14→13→13→12→11→15→13
* 開始   : 2026-07-05 06:00:00 (UTC)
* 終了   : 2026-07-05 06:50:00 (UTC)
* 現象   : 2026-07-05 06:50:00 (UTC)を境に水準が 11.81から12.25へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.815, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→14→18→16→18→16→18→16→14
* 開始   : 2026-07-05 09:45:00 (UTC)
* 終了   : 2026-07-05 09:55:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260705-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260705-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→16→17→16→16→17→17→16→18
* 開始   : 2026-07-05 11:15:00 (UTC)
* 終了   : 2026-07-05 12:00:00 (UTC)
* 現象   : 2026-07-05 12:00:00 (UTC)を境に水準が 11.88から13.47へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.78, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host07-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→8→9→10→9→9→9→8→12
* 開始   : 2026-07-05 20:40:00 (UTC)
* 終了   : 2026-07-05 21:30:00 (UTC)
* 現象   : 2026-07-05 21:30:00 (UTC)を境に水準が 11.7から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.335, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 8→5→11→6→8→5→11→6→7
* 開始   : 2026-07-05 23:40:00 (UTC)
* 終了   : 2026-07-05 23:45:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.2σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host07-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 10→10→9→10→10→10→10→10
* 開始   : 2026-07-06 02:05:00 (UTC)
* 終了   : 2026-07-06 02:40:00 (UTC)
* 現象   : 2026-07-06 02:40:00 (UTC)を境に水準が 11.76から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→8→11→15→8→11→15→13→12
* 開始   : 2026-07-07 04:10:00 (UTC)
* 終了   : 2026-07-07 05:10:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007倍(8)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 20 分
  - EVT-20260707-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 15 分
  - EVT-20260707-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260707-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260707-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260707-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→17→15→18→…→16→19→15→17
* 開始   : 2026-07-07 06:25:00 (UTC)
* 終了   : 2026-07-07 06:45:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260707-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→18→19→18→14→18→19→18→17
* 開始   : 2026-07-07 07:00:00 (UTC)
* 終了   : 2026-07-07 07:05:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 21→18→24→19→21→18→24→19→21
* 開始   : 2026-07-07 14:00:00 (UTC)
* 終了   : 2026-07-07 14:05:00 (UTC)
* 現象   : 平常時(21)に対し 0.8571(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260707-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 17→19→16→17→19→16→17→18
* 開始   : 2026-07-07 15:55:00 (UTC)
* 終了   : 2026-07-07 16:00:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 17→16→14→13→…→14→13→14→15
* 開始   : 2026-07-07 17:50:00 (UTC)
* 終了   : 2026-07-07 17:55:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260707-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 14→13→12→11→…→12→11→15→13
* 開始   : 2026-07-07 18:35:00 (UTC)
* 終了   : 2026-07-07 18:40:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260707-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260707-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host07-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→12→8→10→8→10→8
* 開始   : 2026-07-07 20:25:00 (UTC)
* 終了   : 2026-07-07 20:35:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260707-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260707-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→13→11→11→15
* 開始   : 2026-07-08 04:00:00 (UTC)
* 終了   : 2026-07-08 04:20:00 (UTC)
* 現象   : 2026-07-08 04:20:00 (UTC)を境に水準が 14.84から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 12→13→15→12→15→12→15→12→13
* 開始   : 2026-07-08 04:45:00 (UTC)
* 終了   : 2026-07-08 04:55:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.304倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.432σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260708-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→15→16→12→15→16→12→15
* 開始   : 2026-07-08 05:20:00 (UTC)
* 終了   : 2026-07-08 05:25:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260708-host02-005 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260708-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host07-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→16→15→15→17
* 開始   : 2026-07-08 05:30:00 (UTC)
* 終了   : 2026-07-08 05:50:00 (UTC)
* 現象   : 2026-07-08 05:50:00 (UTC)を境に水準が 14.84から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 22→21→20→22→22→22→20→21→23
* 開始   : 2026-07-08 13:55:00 (UTC)
* 終了   : 2026-07-08 15:00:00 (UTC)
* 現象   : 2026-07-08 15:00:00 (UTC)を境に水準が 15.01から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 21→23→18→17→…→18→17→20→21
* 開始   : 2026-07-08 14:35:00 (UTC)
* 終了   : 2026-07-08 14:40:00 (UTC)
* 現象   : 平常時(21)に対し 0.8571(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-lsfhost01-051 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260708-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 22→19→17→16→18→19→17→16→18
* 開始   : 2026-07-08 15:50:00 (UTC)
* 終了   : 2026-07-08 15:55:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host07-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 21→17→20→18→17→17→17→17→18
* 開始   : 2026-07-08 16:30:00 (UTC)
* 終了   : 2026-07-08 17:25:00 (UTC)
* 現象   : 2026-07-08 17:25:00 (UTC)を境に水準が 15.05から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.497, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 19→17→15→18→15→18→15→17→19
* 開始   : 2026-07-08 16:35:00 (UTC)
* 終了   : 2026-07-08 16:45:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 7→11→8→7→11→8
* 開始   : 2026-07-09 01:05:00 (UTC)
* 終了   : 2026-07-09 01:10:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-002 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 15→14→17→15→…→17→18→13→16
* 開始   : 2026-07-09 06:00:00 (UTC)
* 終了   : 2026-07-09 06:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host07-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260709-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260709-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 21→22→24→23→22→24→23→22
* 開始   : 2026-07-09 10:25:00 (UTC)
* 終了   : 2026-07-09 10:30:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 23→21→18→24→18→24→20
* 開始   : 2026-07-09 14:25:00 (UTC)
* 終了   : 2026-07-09 14:35:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-048 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260709-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 18→19→16→17→19→16→17→19
* 開始   : 2026-07-09 16:05:00 (UTC)
* 終了   : 2026-07-09 16:10:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host02-008 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260709-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 16→15→13→17→13→17→13→15→14
* 開始   : 2026-07-09 17:45:00 (UTC)
* 終了   : 2026-07-09 17:55:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.7685(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.729σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→14→13→14→13→15
* 開始   : 2026-07-09 18:00:00 (UTC)
* 終了   : 2026-07-09 18:10:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260709-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→11→6→9→…→9→12→9→8
* 開始   : 2026-07-09 22:20:00 (UTC)
* 終了   : 2026-07-09 22:30:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.6372(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host16-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260709-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 17→19→15→20→19→15→20→17→19
* 開始   : 2026-07-10 07:10:00 (UTC)
* 終了   : 2026-07-10 07:20:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260710-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260710-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 18→20→22→23→22→23→21→22
* 開始   : 2026-07-10 09:15:00 (UTC)
* 終了   : 2026-07-10 09:25:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 21→20→25→19→…→25→19→23→21
* 開始   : 2026-07-10 11:35:00 (UTC)
* 終了   : 2026-07-10 11:40:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260710-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 16→17→14→16→17→14→16
* 開始   : 2026-07-10 17:30:00 (UTC)
* 終了   : 2026-07-10 17:35:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260710-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→16→13→15→…→15→12→14→16
* 開始   : 2026-07-10 18:00:00 (UTC)
* 終了   : 2026-07-10 18:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→15→11→15→11→13→11→13
* 開始   : 2026-07-10 19:00:00 (UTC)
* 終了   : 2026-07-10 19:10:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.671σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host02-010 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260710-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260710-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 14→11→9→8→…→9→8→11→12
* 開始   : 2026-07-10 20:10:00 (UTC)
* 終了   : 2026-07-10 20:20:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host07-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-076 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260710-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-080 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260710-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→9→9→10→7→12→8→9→11
* 開始   : 2026-07-12 02:00:00 (UTC)
* 終了   : 2026-07-12 02:45:00 (UTC)
* 現象   : 2026-07-12 02:45:00 (UTC)を境に水準が 11.71から11.79へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.348, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 7→8→11→9→11→9→11→8→11
* 開始   : 2026-07-12 02:40:00 (UTC)
* 終了   : 2026-07-12 02:50:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-lsfhost01-004 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260712-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260712-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host07-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 17→16→16→18→17→17
* 開始   : 2026-07-12 14:20:00 (UTC)
* 終了   : 2026-07-12 14:45:00 (UTC)
* 現象   : 2026-07-12 14:45:00 (UTC)を境に水準が 11.84から14.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→13→11→14→…→14→17→13→15
* 開始   : 2026-07-12 16:20:00 (UTC)
* 終了   : 2026-07-12 16:30:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260712-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host07-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 9→12→11→10→11→9→14
* 開始   : 2026-07-12 20:00:00 (UTC)
* 終了   : 2026-07-12 20:30:00 (UTC)
* 現象   : 2026-07-12 20:30:00 (UTC)を境に水準が 11.68から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.944, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→11→7→6→11→7→6→11→9
* 開始   : 2026-07-12 21:05:00 (UTC)
* 終了   : 2026-07-12 21:10:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-lsfhost01-043 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260712-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 8→9→5→7→5→7→5→8→9
* 開始   : 2026-07-12 22:50:00 (UTC)
* 終了   : 2026-07-12 23:00:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 10→9→6→5→9→6→5→9→7
* 開始   : 2026-07-12 23:25:00 (UTC)
* 終了   : 2026-07-12 23:30:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.084σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260712-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host07-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 7→9→8→7→9→10→10
* 開始   : 2026-07-12 23:45:00 (UTC)
* 終了   : 2026-07-13 00:15:00 (UTC)
* 現象   : 2026-07-13 00:15:00 (UTC)を境に水準が 11.74から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.944, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host07-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→10→8→10→8→7→8→9→10
* 開始   : 2026-07-13 01:25:00 (UTC)
* 終了   : 2026-07-13 02:35:00 (UTC)
* 現象   : 2026-07-13 02:35:00 (UTC)を境に水準が 11.82から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.837, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 8→9→11→8→…→8→12→10→9
* 開始   : 2026-07-13 02:10:00 (UTC)
* 終了   : 2026-07-13 02:20:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260713-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260713-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host07-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→11→11→10→10→10→11→11→11
* 開始   : 2026-07-13 20:35:00 (UTC)
* 終了   : 2026-07-13 21:45:00 (UTC)
* 現象   : 2026-07-13 21:45:00 (UTC)を境に水準が 14.89から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.022, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 9→7→6→12→…→6→12→8→9
* 開始   : 2026-07-13 22:30:00 (UTC)
* 終了   : 2026-07-13 22:35:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260713-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260713-lsfhost01-061 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260713-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260713-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260713-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 8→7→12→6→7→12→6→9
* 開始   : 2026-07-13 23:35:00 (UTC)
* 終了   : 2026-07-13 23:40:00 (UTC)
* 現象   : 2026-07-13 23:40:00 (UTC)を境に水準が 14.96から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.844σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.27, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host07-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 23→23→24→21→22→21→21
* 開始   : 2026-07-14 12:35:00 (UTC)
* 終了   : 2026-07-14 13:05:00 (UTC)
* 現象   : 2026-07-14 13:05:00 (UTC)を境に水準が 14.95から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.791, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→12→15→12→15→12→14→13
* 開始   : 2026-07-14 18:25:00 (UTC)
* 終了   : 2026-07-14 18:35:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260714-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260714-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→12→14→14
* 開始   : 2026-07-14 19:40:00 (UTC)
* 終了   : 2026-07-14 19:55:00 (UTC)
* 現象   : 2026-07-14 19:55:00 (UTC)を境に水準が 14.87から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.024, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→10→7→13→10→7→13→10
* 開始   : 2026-07-14 21:20:00 (UTC)
* 終了   : 2026-07-14 21:25:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260714-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host07-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→10→11→10→13→10→11
* 開始   : 2026-07-14 21:30:00 (UTC)
* 終了   : 2026-07-14 22:00:00 (UTC)
* 現象   : 2026-07-14 22:00:00 (UTC)を境に水準が 15から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.857, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 13→11→15→11→15→11→15→12→14
* 開始   : 2026-07-15 04:25:00 (UTC)
* 終了   : 2026-07-15 04:35:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260715-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 12→11→15→14→11→15→14→15
* 開始   : 2026-07-15 04:45:00 (UTC)
* 終了   : 2026-07-15 04:50:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.324倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260715-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 16→15→18→16→…→16→19→16→15
* 開始   : 2026-07-15 06:20:00 (UTC)
* 終了   : 2026-07-15 06:30:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260715-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 18→21→22→19→18→21→22→19
* 開始   : 2026-07-15 08:25:00 (UTC)
* 終了   : 2026-07-15 08:30:00 (UTC)
* 現象   : 平常時(18)に対し 1.167倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260715-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 21→24→21→24→21→23
* 開始   : 2026-07-15 10:00:00 (UTC)
* 終了   : 2026-07-15 10:05:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.18倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.554σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260715-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 23→19→24→18→19→24→18→23→21
* 開始   : 2026-07-15 12:45:00 (UTC)
* 終了   : 2026-07-15 12:55:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→21→16→17→21→16→17→16
* 開始   : 2026-07-15 16:25:00 (UTC)
* 終了   : 2026-07-15 16:30:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260715-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 18→20→15→18→…→18→14→17→16
* 開始   : 2026-07-15 16:50:00 (UTC)
* 終了   : 2026-07-15 17:00:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.258σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260715-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260715-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 13→9→11→8→9→11→8→12→10
* 開始   : 2026-07-15 19:15:00 (UTC)
* 終了   : 2026-07-15 20:25:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host07-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 50 分
  - EVT-20260715-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 15 分

![EVT-20260715-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 8→7→11→10→7→11→10→9
* 開始   : 2026-07-16 01:55:00 (UTC)
* 終了   : 2026-07-16 02:00:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→17→16→15→17→16
* 開始   : 2026-07-16 06:15:00 (UTC)
* 終了   : 2026-07-16 06:20:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 18→17→19→17→19→17
* 開始   : 2026-07-16 07:05:00 (UTC)
* 終了   : 2026-07-16 07:10:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host07-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→17→20→17→21→19→21→20→22
* 開始   : 2026-07-16 07:40:00 (UTC)
* 終了   : 2026-07-16 08:35:00 (UTC)
* 現象   : 2026-07-16 08:35:00 (UTC)を境に水準が 15から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.071, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 17→21→20→18→…→20→18→21→19
* 開始   : 2026-07-16 07:55:00 (UTC)
* 終了   : 2026-07-16 08:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.895σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-032 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 21→23→20→23→20→23→20→21
* 開始   : 2026-07-16 09:45:00 (UTC)
* 終了   : 2026-07-16 09:55:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 20→21→24→22→21→24→22→20
* 開始   : 2026-07-16 10:10:00 (UTC)
* 終了   : 2026-07-16 10:15:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.18倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.575σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260716-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 23→22→24→22→22→24
* 開始   : 2026-07-16 10:20:00 (UTC)
* 終了   : 2026-07-16 10:45:00 (UTC)
* 現象   : 2026-07-16 10:45:00 (UTC)を境に水準が 14.94から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.182, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host07-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 15→13→14→14→13→14→14→14→13
* 開始   : 2026-07-16 18:50:00 (UTC)
* 終了   : 2026-07-16 19:30:00 (UTC)
* 現象   : 2026-07-16 19:30:00 (UTC)を境に水準が 14.94から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.102, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host07-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→8→8→6→9→10→11
* 開始   : 2026-07-16 23:20:00 (UTC)
* 終了   : 2026-07-16 23:50:00 (UTC)
* 現象   : 2026-07-16 23:50:00 (UTC)を境に水準が 15.01から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.944, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260716-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 17→19→20→19→17→19→20→19→18
* 開始   : 2026-07-17 07:15:00 (UTC)
* 終了   : 2026-07-17 07:20:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 19→17→20→17→…→17→21→20→19
* 開始   : 2026-07-17 07:35:00 (UTC)
* 終了   : 2026-07-17 07:45:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.206倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260717-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-040 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260717-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 18→22→15→19→18→22→15→19→20
* 開始   : 2026-07-17 08:45:00 (UTC)
* 終了   : 2026-07-17 08:50:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.168倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260717-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 8→11→9→8→11→11→7→10
* 開始   : 2026-07-19 01:30:00 (UTC)
* 終了   : 2026-07-19 02:05:00 (UTC)
* 現象   : 2026-07-19 02:05:00 (UTC)を境に水準が 11.81から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.047, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→14→12→14→12→14→10→11
* 開始   : 2026-07-19 05:30:00 (UTC)
* 終了   : 2026-07-19 05:40:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260719-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→18→15→16→17→18→15
* 開始   : 2026-07-19 09:15:00 (UTC)
* 終了   : 2026-07-19 09:20:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host07-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 16→16→17→15→15→17→17
* 開始   : 2026-07-19 11:35:00 (UTC)
* 終了   : 2026-07-19 12:05:00 (UTC)
* 現象   : 2026-07-19 12:05:00 (UTC)を境に水準が 11.89から13.49へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.21, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 16→16→18→15→15→16→14→15→15
* 開始   : 2026-07-19 13:50:00 (UTC)
* 終了   : 2026-07-19 15:45:00 (UTC)
* 現象   : 2026-07-19 15:45:00 (UTC)を境に水準が 11.72から14.36へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.993, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→14→10→9→…→10→9→12→13
* 開始   : 2026-07-19 17:30:00 (UTC)
* 終了   : 2026-07-19 17:35:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260719-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 9→10→13→7→…→13→7→11→9
* 開始   : 2026-07-19 20:05:00 (UTC)
* 終了   : 2026-07-19 20:10:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host07-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 10→9→8→10→12→11→9→8→9
* 開始   : 2026-07-21 01:25:00 (UTC)
* 終了   : 2026-07-21 02:20:00 (UTC)
* 現象   : 2026-07-21 02:20:00 (UTC)を境に水準が 15から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.618, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 9→12→13→9→13→9→13→11
* 開始   : 2026-07-21 03:25:00 (UTC)
* 終了   : 2026-07-21 03:35:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260721-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260721-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 21→24→24
* 開始   : 2026-07-21 09:20:00 (UTC)
* 終了   : 2026-07-21 09:30:00 (UTC)
* 現象   : 2026-07-21 09:30:00 (UTC)を境に水準が 14.99から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.967σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.768, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 21→23→19→22→23→19→22→23
* 開始   : 2026-07-21 12:50:00 (UTC)
* 終了   : 2026-07-21 12:55:00 (UTC)
* 現象   : 平常時(22.75)に対し 0.8352(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.613σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260721-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 17→15→13→16→13→16→13→14
* 開始   : 2026-07-21 18:00:00 (UTC)
* 終了   : 2026-07-21 18:10:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260721-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 16→12→10→12→10→12→10→12→13
* 開始   : 2026-07-21 19:35:00 (UTC)
* 終了   : 2026-07-21 19:45:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.564σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260721-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→14→12→11→14→12
* 開始   : 2026-07-22 04:20:00 (UTC)
* 終了   : 2026-07-22 04:25:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260722-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 16→15→18→15→18→15→18→17→16
* 開始   : 2026-07-22 06:35:00 (UTC)
* 終了   : 2026-07-22 06:45:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.612σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-019 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 25→23→22→23→22→24→24→21→22
* 開始   : 2026-07-22 10:45:00 (UTC)
* 終了   : 2026-07-22 12:15:00 (UTC)
* 現象   : 2026-07-22 12:15:00 (UTC)を境に水準が 14.97から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.863, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 23→20→25→23→25→23→25→22
* 開始   : 2026-07-22 11:15:00 (UTC)
* 終了   : 2026-07-22 11:25:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.167倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260722-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 16→18→14→15→14→15→14→16→17
* 開始   : 2026-07-22 17:20:00 (UTC)
* 終了   : 2026-07-22 17:30:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.8(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→15→12→14→15→12→14→16
* 開始   : 2026-07-22 18:30:00 (UTC)
* 終了   : 2026-07-22 18:35:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260722-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260722-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→15→12→14→12→14→12→13
* 開始   : 2026-07-22 18:45:00 (UTC)
* 終了   : 2026-07-22 18:55:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260722-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260722-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 12→13→9→11→…→11→8→12→11
* 開始   : 2026-07-22 19:55:00 (UTC)
* 終了   : 2026-07-22 20:05:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.6968(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.739σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host15-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260722-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host15-019 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host15-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host07-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→7→11→7→11→7→9→7
* 開始   : 2026-07-22 21:45:00 (UTC)
* 終了   : 2026-07-22 21:55:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.6667(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-016 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host06-019 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host11-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-081 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260722-lsfhost01-080 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260722-host07-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 8→7→11→8→7→11→8
* 開始   : 2026-07-22 21:55:00 (UTC)
* 終了   : 2026-07-22 22:00:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host07-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-017 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→9→9→8→10
* 開始   : 2026-07-22 23:15:00 (UTC)
* 終了   : 2026-07-22 23:45:00 (UTC)
* 現象   : 2026-07-22 23:45:00 (UTC)を境に水準が 14.91から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host07-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-018 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 7→9→8→9→10→9→10→8→9
* 開始   : 2026-07-22 23:20:00 (UTC)
* 終了   : 2026-07-23 00:15:00 (UTC)
* 現象   : 2026-07-23 00:15:00 (UTC)を境に水準が 14.94から14.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.071, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host07-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host07-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 7→10→5→8→5→8→5→7→9
* 開始   : 2026-07-22 23:40:00 (UTC)
* 終了   : 2026-07-22 23:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260722-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host07-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 11→14→11→15→14→11→15→12→11
* 開始   : 2026-07-23 04:25:00 (UTC)
* 終了   : 2026-07-23 04:35:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host02-003 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260723-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 14→15→17→13→18→17→13→18→15
* 開始   : 2026-07-23 05:45:00 (UTC)
* 終了   : 2026-07-23 05:55:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.316σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host07-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 16→16→16→16→16→18→20→19→19
* 開始   : 2026-07-23 06:05:00 (UTC)
* 終了   : 2026-07-23 07:00:00 (UTC)
* 現象   : 2026-07-23 07:00:00 (UTC)を境に水準が 15.05から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.62, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 15→17→19→20→…→19→20→19→18
* 開始   : 2026-07-23 07:25:00 (UTC)
* 終了   : 2026-07-23 07:30:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host01-007 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260723-lsfhost01-025 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260723-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 21→20→18→24→…→24→22→24→22
* 開始   : 2026-07-23 11:45:00 (UTC)
* 終了   : 2026-07-23 12:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 15→16→14→13→…→14→13→15→14
* 開始   : 2026-07-23 17:35:00 (UTC)
* 終了   : 2026-07-23 17:40:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.142σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260723-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260723-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host07-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 13→13→7→11→10→9→10→10→11
* 開始   : 2026-07-23 20:55:00 (UTC)
* 終了   : 2026-07-23 21:50:00 (UTC)
* 現象   : 2026-07-23 21:50:00 (UTC)を境に水準が 14.87から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 14→13→15→12→…→12→16→15→14
* 開始   : 2026-07-24 05:15:00 (UTC)
* 終了   : 2026-07-24 05:25:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-lsfhost01-012 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260724-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260724-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 17→18→20→19→20→19→20→17→19
* 開始   : 2026-07-24 07:25:00 (UTC)
* 終了   : 2026-07-24 07:35:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260724-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host07-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 22→22→22→23
* 開始   : 2026-07-24 09:45:00 (UTC)
* 終了   : 2026-07-24 10:00:00 (UTC)
* 現象   : 2026-07-24 10:00:00 (UTC)を境に水準が 14.89から13.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.312, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host07-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 23→21→23→22→23→23→23→23→23
* 開始   : 2026-07-24 10:10:00 (UTC)
* 終了   : 2026-07-24 11:20:00 (UTC)
* 現象   : 2026-07-24 11:20:00 (UTC)を境に水準が 14.96から13.64へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.022, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 21→17→24→20→21→17→24→20→23
* 開始   : 2026-07-24 10:40:00 (UTC)
* 終了   : 2026-07-24 10:45:00 (UTC)
* 現象   : 平常時(21)に対し 0.8095(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.792σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260724-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 17→18→15→16→18→15→16→15
* 開始   : 2026-07-24 17:00:00 (UTC)
* 終了   : 2026-07-24 17:05:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 15→12→15→12→14
* 開始   : 2026-07-24 18:50:00 (UTC)
* 終了   : 2026-07-24 18:55:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 11→12→10→9→10→9→13→11
* 開始   : 2026-07-24 20:10:00 (UTC)
* 終了   : 2026-07-24 20:45:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 11→9→5→10→…→10→12→9→10
* 開始   : 2026-07-25 02:20:00 (UTC)
* 終了   : 2026-07-25 02:30:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260725-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 11→10→7→9→7→9→7→9→11
* 開始   : 2026-07-25 20:40:00 (UTC)
* 終了   : 2026-07-25 20:50:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.6412(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.721σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260725-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 9→12→6→10→9→12→6→10
* 開始   : 2026-07-26 03:10:00 (UTC)
* 終了   : 2026-07-26 03:15:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260726-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260726-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→11→12→14→10→14
* 開始   : 2026-07-26 04:05:00 (UTC)
* 終了   : 2026-07-26 05:20:00 (UTC)
* 現象   : 2026-07-26 05:20:00 (UTC)を境に水準が 11.84から12.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.502σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.248, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 8→9→13→10→13→10→13→10
* 開始   : 2026-07-26 04:25:00 (UTC)
* 終了   : 2026-07-26 04:35:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.405倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.606σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-009 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260726-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260726-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260726-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host07-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 18→16→19→16→16→16
* 開始   : 2026-07-26 13:00:00 (UTC)
* 終了   : 2026-07-26 13:25:00 (UTC)
* 現象   : 2026-07-26 13:25:00 (UTC)を境に水準が 11.9から13.76へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.182, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host07-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→14→14→14→14→17→13→14→15
* 開始   : 2026-07-26 15:15:00 (UTC)
* 終了   : 2026-07-26 16:25:00 (UTC)
* 現象   : 2026-07-26 16:25:00 (UTC)を境に水準が 11.84から14.33へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.121, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 10→11→11→11→11→10→10→11
* 開始   : 2026-07-26 19:55:00 (UTC)
* 終了   : 2026-07-26 20:30:00 (UTC)
* 現象   : 2026-07-26 20:30:00 (UTC)を境に水準が 11.79から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.047, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host07-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 9→9→9→9→8→7→9→9→7
* 開始   : 2026-07-27 22:05:00 (UTC)
* 終了   : 2026-07-27 22:50:00 (UTC)
* 現象   : 2026-07-27 22:50:00 (UTC)を境に水準が 14.8から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.081, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 8→7→12→5→…→12→5→10→6
* 開始   : 2026-07-28 01:15:00 (UTC)
* 終了   : 2026-07-28 01:20:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.548倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.984σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 8→10→12→10→12→10
* 開始   : 2026-07-28 02:30:00 (UTC)
* 終了   : 2026-07-28 02:35:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-007 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260728-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 11→14→15→11→14→15→11→13
* 開始   : 2026-07-28 04:25:00 (UTC)
* 終了   : 2026-07-28 04:30:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-010 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260728-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 17→19→18→17→19→18
* 開始   : 2026-07-28 07:10:00 (UTC)
* 終了   : 2026-07-28 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host07-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host07-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 21→23→23→22→25→22→22→23
* 開始   : 2026-07-28 10:45:00 (UTC)
* 終了   : 2026-07-28 11:20:00 (UTC)
* 現象   : 2026-07-28 11:20:00 (UTC)を境に水準が 14.99から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 21→22→24→23→…→23→25→23→21
* 開始   : 2026-07-28 10:50:00 (UTC)
* 終了   : 2026-07-28 11:00:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260728-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host07-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 12→11→10→12→10→12→10→12→11
* 開始   : 2026-07-28 19:45:00 (UTC)
* 終了   : 2026-07-28 19:55:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260728-host07-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host07-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_2
* 値     : 11→12→10→9→9→11→9→8→9
* 開始   : 2026-07-28 21:35:00 (UTC)
* 終了   : 2026-07-28 22:30:00 (UTC)
* 現象   : 2026-07-28 22:30:00 (UTC)を境に水準が 14.92から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.937, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host07-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host07-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 16→19→16→19→16→19→17→19
* 開始   : 2026-07-29 07:10:00 (UTC)
* 終了   : 2026-07-29 07:20:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260729-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260729-host07-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 19→18→21→22→18→21→22→18→20
* 開始   : 2026-07-29 08:35:00 (UTC)
* 終了   : 2026-07-29 08:40:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260729-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host07-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 22→23→23→22→22→23→22→23→23
* 開始   : 2026-07-29 10:25:00 (UTC)
* 終了   : 2026-07-29 11:25:00 (UTC)
* 現象   : 2026-07-29 11:25:00 (UTC)を境に水準が 15.07から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.705, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host07-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 24→19→22→25→19→22→25→22→23
* 開始   : 2026-07-29 12:25:00 (UTC)
* 終了   : 2026-07-29 12:35:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host07-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 22→22→21→21→21→21→23→21→22
* 開始   : 2026-07-29 14:15:00 (UTC)
* 終了   : 2026-07-29 14:55:00 (UTC)
* 現象   : 2026-07-29 14:55:00 (UTC)を境に水準が 15.02から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.303, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host07-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 20→17→14→15→17→14→15→17
* 開始   : 2026-07-29 16:40:00 (UTC)
* 終了   : 2026-07-29 16:45:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.7706(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.914σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host07-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 17→14→13→15→17→14→13→15
* 開始   : 2026-07-29 17:45:00 (UTC)
* 終了   : 2026-07-29 17:50:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260729-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→9→12→9→12→9
* 開始   : 2026-07-29 20:20:00 (UTC)
* 終了   : 2026-07-29 20:30:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260729-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host07-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_1
* 値     : 11→12→15→8→…→15→8→10→11
* 開始   : 2026-07-30 03:45:00 (UTC)
* 終了   : 2026-07-30 03:50:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.385倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.903σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260730-host07-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 18→20→22→20→…→20→23→22→21
* 開始   : 2026-07-30 09:20:00 (UTC)
* 終了   : 2026-07-30 09:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-046 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260730-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260730-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260730-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→17→13→15→13→15→13→15
* 開始   : 2026-07-30 17:25:00 (UTC)
* 終了   : 2026-07-30 17:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.78(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260730-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host07-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 14→17→13→14→17→13→14→13
* 開始   : 2026-07-30 18:10:00 (UTC)
* 終了   : 2026-07-30 18:15:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260730-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260730-host07-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 11→10→12→16→10→12→16→11→12
* 開始   : 2026-07-30 19:20:00 (UTC)
* 終了   : 2026-07-30 19:30:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host02-014 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260730-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host07-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host07-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 9→7→5→11→9→7→5→11→9
* 開始   : 2026-07-30 23:40:00 (UTC)
* 終了   : 2026-07-30 23:45:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260730-host07-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host07-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 15→14→18→14→18→14→16
* 開始   : 2026-07-31 06:55:00 (UTC)
* 終了   : 2026-07-31 07:00:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host07-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host07-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 15→16→19→20→…→19→20→18→19
* 開始   : 2026-07-31 07:20:00 (UTC)
* 終了   : 2026-07-31 07:25:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260731-host07-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host07-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_6
* 値     : 22→20→20→21→20→21→20→21→21
* 開始   : 2026-07-31 08:20:00 (UTC)
* 終了   : 2026-07-31 09:10:00 (UTC)
* 現象   : 2026-07-31 09:10:00 (UTC)を境に水準が 14.95から14.26へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.35, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host07-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host07-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_5
* 値     : 18→22→20→22→20→22→21→20
* 開始   : 2026-07-31 08:25:00 (UTC)
* 終了   : 2026-07-31 08:35:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.234倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.908σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260731-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host07-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host07-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_3
* 値     : 22→23→25→22→…→22→19→22→24
* 開始   : 2026-07-31 11:55:00 (UTC)
* 終了   : 2026-07-31 12:05:00 (UTC)
* 現象   : 平常時(21.83)に対し 1.145倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260731-host07-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host07-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host07, port=7003, datasource=OraclePool_4
* 値     : 18→16→16→18→16→17
* 開始   : 2026-07-31 17:15:00 (UTC)
* 終了   : 2026-07-31 17:50:00 (UTC)
* 現象   : 2026-07-31 17:50:00 (UTC)を境に水準が 14.93から12.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.248, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host07-010 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
