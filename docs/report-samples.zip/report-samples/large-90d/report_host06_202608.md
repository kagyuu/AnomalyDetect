# host06 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host06 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 290 (SEVERE: 17, FATAL: 136, WARN: 137, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 17 | 136 | 137 | 290 | ALG-A1, ALG-A2, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260803-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→16→14→16→…→15→14→12→13
* 開始   : 2026-08-03 01:30:00 (UTC)
* 終了   : 2026-08-03 19:20:00 (UTC)
* 現象   : 2026-08-03 19:20:00 (UTC)を境に水準が 11.71から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.126, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.439, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host06-002 active_connections の推移](charts/EVT-20260803-host06-002.svg)

# イベントID( EVT-20260803-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→15→18→17→…→15→16→14→15
* 開始   : 2026-08-03 01:30:00 (UTC)
* 終了   : 2026-08-03 20:55:00 (UTC)
* 現象   : 2026-08-03 20:55:00 (UTC)を境に水準が 11.8から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.761, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.16, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host06-003 active_connections の推移](charts/EVT-20260803-host06-003.svg)

# イベントID( EVT-20260803-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→17→16→17→…→16→12→10→11
* 開始   : 2026-08-03 02:15:00 (UTC)
* 終了   : 2026-08-03 19:55:00 (UTC)
* 現象   : 2026-08-03 19:55:00 (UTC)を境に水準が 11.85から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.498σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.849, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host06-004 active_connections の推移](charts/EVT-20260803-host06-004.svg)

# イベントID( EVT-20260803-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→12→15→16→…→13→15→16→14
* 開始   : 2026-08-03 03:00:00 (UTC)
* 終了   : 2026-08-03 20:55:00 (UTC)
* 現象   : 2026-08-03 20:55:00 (UTC)を境に水準が 11.73から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.634σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.738, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.864, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host06-005 active_connections の推移](charts/EVT-20260803-host06-005.svg)

# イベントID( EVT-20260803-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→16→…→13→16→13→15
* 開始   : 2026-08-03 03:35:00 (UTC)
* 終了   : 2026-08-03 22:10:00 (UTC)
* 現象   : 2026-08-03 22:10:00 (UTC)を境に水準が 11.7から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.868, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host06-006 active_connections の推移](charts/EVT-20260803-host06-006.svg)

# イベントID( EVT-20260803-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→16→14→15→…→13→12→10→12
* 開始   : 2026-08-03 03:55:00 (UTC)
* 終了   : 2026-08-03 21:30:00 (UTC)
* 現象   : 2026-08-03 21:30:00 (UTC)を境に水準が 11.87から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.203, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.51, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host06-007 active_connections の推移](charts/EVT-20260803-host06-007.svg)

# イベントID( EVT-20260810-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→12→15→14→…→15→14→10→13
* 開始   : 2026-08-10 02:30:00 (UTC)
* 終了   : 2026-08-10 19:35:00 (UTC)
* 現象   : 2026-08-10 19:35:00 (UTC)を境に水準が 11.97から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.778, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.21, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host06-002 active_connections の推移](charts/EVT-20260810-host06-002.svg)

# イベントID( EVT-20260810-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→15→16→17→…→15→11→14→12
* 開始   : 2026-08-10 03:10:00 (UTC)
* 終了   : 2026-08-10 19:55:00 (UTC)
* 現象   : 2026-08-10 19:55:00 (UTC)を境に水準が 11.74から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.515σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.665, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.66, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host06-004 active_connections の推移](charts/EVT-20260810-host06-004.svg)

# イベントID( EVT-20260810-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→15→16→14→…→15→14→12→14
* 開始   : 2026-08-10 03:10:00 (UTC)
* 終了   : 2026-08-10 20:05:00 (UTC)
* 現象   : 2026-08-10 20:05:00 (UTC)を境に水準が 11.97から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.614σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.777, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.872, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host06-005 active_connections の推移](charts/EVT-20260810-host06-005.svg)

# イベントID( EVT-20260810-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 11→13→16→15→…→14→15→13→15
* 開始   : 2026-08-10 03:25:00 (UTC)
* 終了   : 2026-08-10 21:25:00 (UTC)
* 現象   : 2026-08-10 21:25:00 (UTC)を境に水準が 11.9から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.693σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.988, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host06-006 active_connections の推移](charts/EVT-20260810-host06-006.svg)

# イベントID( EVT-20260817-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→16→15→17→…→13→14→13→14
* 開始   : 2026-08-17 02:15:00 (UTC)
* 終了   : 2026-08-17 21:15:00 (UTC)
* 現象   : 2026-08-17 21:15:00 (UTC)を境に水準が 11.85から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.395σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.703, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.672, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host06-002 active_connections の推移](charts/EVT-20260817-host06-002.svg)

# イベントID( EVT-20260817-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→15→16→15→…→13→12→11→12
* 開始   : 2026-08-17 02:45:00 (UTC)
* 終了   : 2026-08-17 20:35:00 (UTC)
* 現象   : 2026-08-17 20:35:00 (UTC)を境に水準が 11.73から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.765, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.774, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host06-003 active_connections の推移](charts/EVT-20260817-host06-003.svg)

# イベントID( EVT-20260817-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→15→…→14→17→11→16
* 開始   : 2026-08-17 03:00:00 (UTC)
* 終了   : 2026-08-17 20:25:00 (UTC)
* 現象   : 2026-08-17 20:25:00 (UTC)を境に水準が 11.91から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.811, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host06-004 active_connections の推移](charts/EVT-20260817-host06-004.svg)

# イベントID( EVT-20260817-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→15→14→15→…→13→16→12→15
* 開始   : 2026-08-17 03:10:00 (UTC)
* 終了   : 2026-08-17 21:05:00 (UTC)
* 現象   : 2026-08-17 21:05:00 (UTC)を境に水準が 11.99から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.693, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host06-005 active_connections の推移](charts/EVT-20260817-host06-005.svg)

# イベントID( EVT-20260817-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→17→19→16→…→11→14→11→12
* 開始   : 2026-08-17 03:25:00 (UTC)
* 終了   : 2026-08-17 20:05:00 (UTC)
* 現象   : 2026-08-17 20:05:00 (UTC)を境に水準が 11.82から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.722, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.897, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host06-006 active_connections の推移](charts/EVT-20260817-host06-006.svg)

# イベントID( EVT-20260824-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→15→16→17→…→12→15→13→12
* 開始   : 2026-08-24 02:50:00 (UTC)
* 終了   : 2026-08-24 21:30:00 (UTC)
* 現象   : 2026-08-24 21:30:00 (UTC)を境に水準が 11.76から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.792, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.995, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host06-003 active_connections の推移](charts/EVT-20260824-host06-003.svg)

# イベントID( EVT-20260824-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 14→16→18→15→…→15→12→13→14
* 開始   : 2026-08-24 02:55:00 (UTC)
* 終了   : 2026-08-24 19:50:00 (UTC)
* 現象   : 2026-08-24 19:50:00 (UTC)を境に水準が 11.81から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.846σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.425, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.62, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host06-004 active_connections の推移](charts/EVT-20260824-host06-004.svg)

# イベントID( EVT-20260801-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→9→4→10→9
* 開始   : 2026-08-01 01:30:00 (UTC)
* 終了   : 2026-08-01 01:30:00 (UTC)
* 現象   : 平常時(8.833)に対し 0.4528(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260801-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→10→13→9→9
* 開始   : 2026-08-01 03:50:00 (UTC)
* 終了   : 2026-08-01 03:50:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host06-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260801-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260801-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260801-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260801-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→11→12→13→…→9→10→11→10
* 開始   : 2026-08-01 05:10:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.079σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.851, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260801-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host06-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host06-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260801-host06-005 active_connections の推移](charts/EVT-20260801-host06-005.svg)

# イベントID( EVT-20260801-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→12→10→11→…→12→13→10→11
* 開始   : 2026-08-01 05:10:00 (UTC)
* 終了   : 2026-08-01 19:10:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.752, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260801-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host06-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host06-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260801-host06-006 active_connections の推移](charts/EVT-20260801-host06-006.svg)

# イベントID( EVT-20260801-host06-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 10→12→10→11→…→10→11→9→10
* 開始   : 2026-08-01 05:35:00 (UTC)
* 終了   : 2026-08-01 19:35:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.841, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host06-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260801-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260801-host06-007 active_connections の推移](charts/EVT-20260801-host06-007.svg)

# イベントID( EVT-20260801-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→13→10→11→…→12→14→13→10
* 開始   : 2026-08-01 06:00:00 (UTC)
* 終了   : 2026-08-01 18:40:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.826, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host06-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.7 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260801-host06-008 active_connections の推移](charts/EVT-20260801-host06-008.svg)

# イベントID( EVT-20260801-host06-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→12→11→13→…→12→13→14→10
* 開始   : 2026-08-01 06:30:00 (UTC)
* 終了   : 2026-08-01 18:55:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.111, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host06-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260801-host06-009 active_connections の推移](charts/EVT-20260801-host06-009.svg)

# イベントID( EVT-20260801-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→12→…→9→13→12→11
* 開始   : 2026-08-01 06:30:00 (UTC)
* 終了   : 2026-08-01 18:35:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.564σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.064, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host06-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.1 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.1 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260801-host06-010 active_connections の推移](charts/EVT-20260801-host06-010.svg)

# イベントID( EVT-20260802-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→14→16→15→18→18→16→18
* 開始   : 2026-08-02 11:30:00 (UTC)
* 終了   : 2026-08-02 13:20:00 (UTC)
* 現象   : 2026-08-02 13:20:00 (UTC)を境に水準が 11.75から13.39へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.158σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.886, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→15→20→12→16→15→20→12→16
* 開始   : 2026-08-02 13:00:00 (UTC)
* 終了   : 2026-08-02 13:05:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.136σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260802-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 8→9→12→8→7
* 開始   : 2026-08-03 00:10:00 (UTC)
* 終了   : 2026-08-03 00:10:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260803-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→17→19→16→17
* 開始   : 2026-08-04 06:40:00 (UTC)
* 終了   : 2026-08-04 06:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→18→23→19→19
* 開始   : 2026-08-04 08:45:00 (UTC)
* 終了   : 2026-08-04 08:45:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→18→21→18→17
* 開始   : 2026-08-05 07:35:00 (UTC)
* 終了   : 2026-08-05 07:35:00 (UTC)
* 現象   : 平常時(16.17)に対し 1.299倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.369σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 17→18→22→20→18
* 開始   : 2026-08-05 08:05:00 (UTC)
* 終了   : 2026-08-05 08:05:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.282倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 10→10→14→11→12
* 開始   : 2026-08-06 03:20:00 (UTC)
* 終了   : 2026-08-06 03:20:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→11→6→8→8
* 開始   : 2026-08-06 21:15:00 (UTC)
* 終了   : 2026-08-06 21:15:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.5625(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260806-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 8→9→11→12→…→12→13→9→7
* 開始   : 2026-08-07 01:50:00 (UTC)
* 終了   : 2026-08-07 02:00:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260807-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 10→11→15→14→13
* 開始   : 2026-08-07 04:35:00 (UTC)
* 終了   : 2026-08-07 04:35:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host06-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→14→17→16→14→17→16→14→15
* 開始   : 2026-08-07 05:05:00 (UTC)
* 終了   : 2026-08-07 05:10:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.457倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.723σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host06-005 active_connections の推移](charts/EVT-20260807-host06-005.svg)

# イベントID( EVT-20260807-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→17→21→17→17
* 開始   : 2026-08-07 07:35:00 (UTC)
* 終了   : 2026-08-07 07:35:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 24→22→18→21→21
* 開始   : 2026-08-07 13:50:00 (UTC)
* 終了   : 2026-08-07 13:50:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260807-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→15→11→14→13
* 開始   : 2026-08-07 18:25:00 (UTC)
* 終了   : 2026-08-07 18:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260807-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→13→9→13→13
* 開始   : 2026-08-07 19:45:00 (UTC)
* 終了   : 2026-08-07 19:45:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-076 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260807-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 9→10→12→8→…→11→9→11→10
* 開始   : 2026-08-08 05:00:00 (UTC)
* 終了   : 2026-08-08 19:30:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.793, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260808-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260808-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260808-host06-001 active_connections の推移](charts/EVT-20260808-host06-001.svg)

# イベントID( EVT-20260808-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→10→11→12→…→13→11→14→13
* 開始   : 2026-08-08 05:05:00 (UTC)
* 終了   : 2026-08-08 18:40:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.798, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260808-host06-002 active_connections の推移](charts/EVT-20260808-host06-002.svg)

# イベントID( EVT-20260808-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→10→9→11→…→11→12→11→12
* 開始   : 2026-08-08 05:15:00 (UTC)
* 終了   : 2026-08-08 19:20:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.217σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.211, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.1 時間

![EVT-20260808-host06-003 active_connections の推移](charts/EVT-20260808-host06-003.svg)

# イベントID( EVT-20260808-host06-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→11→13→12→…→11→13→10→12
* 開始   : 2026-08-08 05:40:00 (UTC)
* 終了   : 2026-08-08 18:25:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.79, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260808-host06-004 active_connections の推移](charts/EVT-20260808-host06-004.svg)

# イベントID( EVT-20260808-host06-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 14→12→13→12→…→11→12→13→10
* 開始   : 2026-08-08 06:05:00 (UTC)
* 終了   : 2026-08-08 18:45:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.813, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260808-host06-005 active_connections の推移](charts/EVT-20260808-host06-005.svg)

# イベントID( EVT-20260808-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 11→12→11→13→…→12→11→14→11
* 開始   : 2026-08-08 06:05:00 (UTC)
* 終了   : 2026-08-08 18:10:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.985σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.207, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260808-host06-006 active_connections の推移](charts/EVT-20260808-host06-006.svg)

# イベントID( EVT-20260808-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 12→8→5→8→…→8→6→8→9
* 開始   : 2026-08-08 21:20:00 (UTC)
* 終了   : 2026-08-08 21:30:00 (UTC)
* 現象   : 平常時(9.667)に対し 0.5172(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260808-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→10→16→12→12
* 開始   : 2026-08-09 06:25:00 (UTC)
* 終了   : 2026-08-09 06:25:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 9→10→5→7→11
* 開始   : 2026-08-09 21:50:00 (UTC)
* 終了   : 2026-08-09 21:50:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host06-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→14→15→14→…→16→13→14→13
* 開始   : 2026-08-10 01:45:00 (UTC)
* 終了   : 2026-08-10 20:30:00 (UTC)
* 現象   : 2026-08-10 20:30:00 (UTC)を境に水準が 11.88から15.01へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.787, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.195, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host06-001 active_connections の推移](charts/EVT-20260810-host06-001.svg)

# イベントID( EVT-20260810-host06-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→13→15→17→…→15→14→15→12
* 開始   : 2026-08-10 02:45:00 (UTC)
* 終了   : 2026-08-10 20:25:00 (UTC)
* 現象   : 2026-08-10 20:25:00 (UTC)を境に水準が 11.83から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.672, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 9→10→6→9→11
* 開始   : 2026-08-10 21:15:00 (UTC)
* 終了   : 2026-08-10 21:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260810-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→13→17→15→17→15→17→14→15
* 開始   : 2026-08-11 05:15:00 (UTC)
* 終了   : 2026-08-11 05:25:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.136σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260811-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 20→21→25→22→22
* 開始   : 2026-08-11 10:15:00 (UTC)
* 終了   : 2026-08-11 10:15:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 22→20→17→21→19
* 開始   : 2026-08-11 14:50:00 (UTC)
* 終了   : 2026-08-11 14:50:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 18→18→15→20→19
* 開始   : 2026-08-11 16:15:00 (UTC)
* 終了   : 2026-08-11 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.079σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host06-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→13→9→13→13
* 開始   : 2026-08-11 19:35:00 (UTC)
* 終了   : 2026-08-11 19:35:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.6316(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.664σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host06-015 active_connections の推移](charts/EVT-20260811-host06-015.svg)

# イベントID( EVT-20260812-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 8→8→13→9→7
* 開始   : 2026-08-12 01:15:00 (UTC)
* 終了   : 2026-08-12 01:15:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.642倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host06-002 active_connections の推移](charts/EVT-20260812-host06-002.svg)

# イベントID( EVT-20260812-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 8→7→13→9→9
* 開始   : 2026-08-12 02:45:00 (UTC)
* 終了   : 2026-08-12 02:45:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260812-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 9→10→12→14→…→12→14→11→12
* 開始   : 2026-08-12 03:25:00 (UTC)
* 終了   : 2026-08-12 03:30:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→13→17→13→14
* 開始   : 2026-08-12 04:45:00 (UTC)
* 終了   : 2026-08-12 04:45:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.374σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→10→16→11→13
* 開始   : 2026-08-13 04:10:00 (UTC)
* 終了   : 2026-08-13 04:10:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260813-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 18→17→14→16→15
* 開始   : 2026-08-13 17:15:00 (UTC)
* 終了   : 2026-08-13 17:15:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→16→13→17→15
* 開始   : 2026-08-13 17:20:00 (UTC)
* 終了   : 2026-08-13 17:20:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→15→10→12→13
* 開始   : 2026-08-13 19:05:00 (UTC)
* 終了   : 2026-08-13 19:05:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 12→10→9→7→…→9→7→11→13
* 開始   : 2026-08-13 20:10:00 (UTC)
* 終了   : 2026-08-13 20:15:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→16→20→15→17
* 開始   : 2026-08-14 07:10:00 (UTC)
* 終了   : 2026-08-14 07:10:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 19→18→23→18→19
* 開始   : 2026-08-14 08:40:00 (UTC)
* 終了   : 2026-08-14 08:40:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.296倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.664σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260814-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 21→20→24→20→21
* 開始   : 2026-08-14 09:15:00 (UTC)
* 終了   : 2026-08-14 09:15:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.258倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 20→18→23→15→…→23→15→19→18
* 開始   : 2026-08-14 15:55:00 (UTC)
* 終了   : 2026-08-14 16:00:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.19倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host06-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260814-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→18→13→15→15
* 開始   : 2026-08-14 17:30:00 (UTC)
* 終了   : 2026-08-14 17:30:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260814-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host06-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→11→13→15→…→12→11→15→13
* 開始   : 2026-08-15 05:15:00 (UTC)
* 終了   : 2026-08-15 18:55:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.765, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260815-host06-001 active_connections の推移](charts/EVT-20260815-host06-001.svg)

# イベントID( EVT-20260815-host06-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→11→12→11→…→14→10→11→14
* 開始   : 2026-08-15 05:30:00 (UTC)
* 終了   : 2026-08-15 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.867, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260815-host06-002 active_connections の推移](charts/EVT-20260815-host06-002.svg)

# イベントID( EVT-20260815-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→11→12→11→…→11→9→11→12
* 開始   : 2026-08-15 05:50:00 (UTC)
* 終了   : 2026-08-15 18:50:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.035, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260815-host06-003 active_connections の推移](charts/EVT-20260815-host06-003.svg)

# イベントID( EVT-20260815-host06-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→12→11→13→…→12→9→11→12
* 開始   : 2026-08-15 05:55:00 (UTC)
* 終了   : 2026-08-15 19:55:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.002, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260815-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260815-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260815-host06-004 active_connections の推移](charts/EVT-20260815-host06-004.svg)

# イベントID( EVT-20260815-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 12→13→9→13→…→12→13→12→13
* 開始   : 2026-08-15 06:00:00 (UTC)
* 終了   : 2026-08-15 18:05:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.899, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260815-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260815-host06-005 active_connections の推移](charts/EVT-20260815-host06-005.svg)

# イベントID( EVT-20260815-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→12→11→12→…→12→14→12→13
* 開始   : 2026-08-15 06:20:00 (UTC)
* 終了   : 2026-08-15 18:40:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.881, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260815-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260815-host06-006 active_connections の推移](charts/EVT-20260815-host06-006.svg)

# イベントID( EVT-20260816-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→14→17→13→13
* 開始   : 2026-08-16 07:10:00 (UTC)
* 終了   : 2026-08-16 07:10:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260816-lsfhost01-013 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260816-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→14→19→17→14
* 開始   : 2026-08-16 09:20:00 (UTC)
* 終了   : 2026-08-16 09:20:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.341倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 15→14→10→14→14
* 開始   : 2026-08-16 15:45:00 (UTC)
* 終了   : 2026-08-16 15:45:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260816-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host06-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→16→17→18→…→16→14→12→16
* 開始   : 2026-08-17 01:30:00 (UTC)
* 終了   : 2026-08-17 19:30:00 (UTC)
* 現象   : 2026-08-17 19:30:00 (UTC)を境に水準が 11.86から14.95へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.867, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.1, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 21→17→22→17→22→17→19→20
* 開始   : 2026-08-18 14:50:00 (UTC)
* 終了   : 2026-08-18 16:10:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.161σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-040 (他ホスト) lsf_queue / pend : FATAL / 重なり 25 分
  - EVT-20260818-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-041 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260818-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→12→16→12→16→12→13→16
* 開始   : 2026-08-18 17:20:00 (UTC)
* 終了   : 2026-08-18 18:30:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7393(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260818-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260818-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260818-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→17→11→15→14
* 開始   : 2026-08-18 18:15:00 (UTC)
* 終了   : 2026-08-18 18:15:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.6735(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.722σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host06-010 active_connections の推移](charts/EVT-20260818-host06-010.svg)

# イベントID( EVT-20260819-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→13→18→12→15
* 開始   : 2026-08-19 05:30:00 (UTC)
* 終了   : 2026-08-19 05:30:00 (UTC)
* 現象   : 平常時(13)に対し 1.385倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260819-host06-001 active_connections の推移](charts/EVT-20260819-host06-001.svg)

# イベントID( EVT-20260819-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→16→13→18→16→13→18→15→16
* 開始   : 2026-08-19 05:40:00 (UTC)
* 終了   : 2026-08-19 05:50:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260819-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260819-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 17→15→20→18→17
* 開始   : 2026-08-19 07:15:00 (UTC)
* 終了   : 2026-08-19 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 17→18→21→19→19
* 開始   : 2026-08-19 07:35:00 (UTC)
* 終了   : 2026-08-19 07:35:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 20→22→16→22→20
* 開始   : 2026-08-19 14:50:00 (UTC)
* 終了   : 2026-08-19 14:50:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260819-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→11→8→13→11
* 開始   : 2026-08-19 20:10:00 (UTC)
* 終了   : 2026-08-19 20:10:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.6358(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-063 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260819-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 12→13→17→14→12
* 開始   : 2026-08-20 04:55:00 (UTC)
* 終了   : 2026-08-20 04:55:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.447倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.688σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host06-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260820-host06-004 active_connections の推移](charts/EVT-20260820-host06-004.svg)

# イベントID( EVT-20260820-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 18→19→21→19→21→18→17
* 開始   : 2026-08-20 07:20:00 (UTC)
* 終了   : 2026-08-20 07:30:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260820-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→18→21→19→18
* 開始   : 2026-08-20 07:55:00 (UTC)
* 終了   : 2026-08-20 07:55:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 20→22→18→23→21
* 開始   : 2026-08-20 11:25:00 (UTC)
* 終了   : 2026-08-20 11:25:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.803(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.079σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→15→11→13→14
* 開始   : 2026-08-20 18:20:00 (UTC)
* 終了   : 2026-08-20 18:20:00 (UTC)
* 現象   : 平常時(16)に対し 0.6875(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host06-012 active_connections の推移](charts/EVT-20260820-host06-012.svg)

# イベントID( EVT-20260820-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 10→11→7→11→10
* 開始   : 2026-08-20 20:40:00 (UTC)
* 終了   : 2026-08-20 20:40:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.5915(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 10→13→11→9→12→12→13
* 開始   : 2026-08-21 02:45:00 (UTC)
* 終了   : 2026-08-21 03:15:00 (UTC)
* 現象   : 2026-08-21 03:15:00 (UTC)を境に水準が 14.94から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.714, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→13→16→13→12
* 開始   : 2026-08-21 04:45:00 (UTC)
* 終了   : 2026-08-21 04:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260821-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→14→18→15→14
* 開始   : 2026-08-21 05:55:00 (UTC)
* 終了   : 2026-08-21 05:55:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→16→18→16→13
* 開始   : 2026-08-21 06:00:00 (UTC)
* 終了   : 2026-08-21 06:00:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→18→19→16→…→20→22→17→18
* 開始   : 2026-08-21 07:20:00 (UTC)
* 終了   : 2026-08-21 07:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host06-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260821-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host06-006 active_connections の推移](charts/EVT-20260821-host06-006.svg)

# イベントID( EVT-20260821-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 17→18→21→19→19
* 開始   : 2026-08-21 07:30:00 (UTC)
* 終了   : 2026-08-21 07:30:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host06-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 10→9→6→8→10
* 開始   : 2026-08-21 21:25:00 (UTC)
* 終了   : 2026-08-21 21:25:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-077 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host06-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→13→11→12→…→13→11→13→12
* 開始   : 2026-08-22 03:45:00 (UTC)
* 終了   : 2026-08-22 18:25:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.889, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260822-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 14.1 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260822-host06-001 active_connections の推移](charts/EVT-20260822-host06-001.svg)

# イベントID( EVT-20260822-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→11→9→11→…→14→13→14→13
* 開始   : 2026-08-22 04:05:00 (UTC)
* 終了   : 2026-08-22 18:30:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.75, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260822-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 14.1 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260822-host06-002 active_connections の推移](charts/EVT-20260822-host06-002.svg)

# イベントID( EVT-20260822-host06-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 9→10→11→10→…→13→11→13→11
* 開始   : 2026-08-22 05:40:00 (UTC)
* 終了   : 2026-08-22 20:00:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.741, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260822-host06-003 active_connections の推移](charts/EVT-20260822-host06-003.svg)

# イベントID( EVT-20260822-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→14→13→12→…→12→10→11→10
* 開始   : 2026-08-22 05:55:00 (UTC)
* 終了   : 2026-08-22 19:00:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.821, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260822-host06-004 active_connections の推移](charts/EVT-20260822-host06-004.svg)

# イベントID( EVT-20260822-host06-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→12→10→12→…→12→9→10→12
* 開始   : 2026-08-22 05:55:00 (UTC)
* 終了   : 2026-08-22 19:00:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.835, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260822-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260822-host06-005 active_connections の推移](charts/EVT-20260822-host06-005.svg)

# イベントID( EVT-20260822-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 12→13→10→12→…→14→12→14→13
* 開始   : 2026-08-22 06:00:00 (UTC)
* 終了   : 2026-08-22 19:20:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.821, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260822-host06-006 active_connections の推移](charts/EVT-20260822-host06-006.svg)

# イベントID( EVT-20260822-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 9→9→4→10→8
* 開始   : 2026-08-22 22:45:00 (UTC)
* 終了   : 2026-08-22 22:45:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260822-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 16→17→20→17→17
* 開始   : 2026-08-23 13:15:00 (UTC)
* 終了   : 2026-08-23 13:15:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260823-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→15→10→15→16
* 開始   : 2026-08-23 14:35:00 (UTC)
* 終了   : 2026-08-23 14:35:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6857(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.199σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host06-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→17→14→15→…→13→12→13→12
* 開始   : 2026-08-24 02:30:00 (UTC)
* 終了   : 2026-08-24 19:20:00 (UTC)
* 現象   : 2026-08-24 19:20:00 (UTC)を境に水準が 11.93から15.12へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.088, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host06-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 12→16→15→14→…→14→13→14→12
* 開始   : 2026-08-24 02:40:00 (UTC)
* 終了   : 2026-08-24 19:55:00 (UTC)
* 現象   : 2026-08-24 19:55:00 (UTC)を境に水準が 11.78から14.92へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.717, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.554, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host06-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→15→16→14→…→13→14→12→13
* 開始   : 2026-08-24 03:10:00 (UTC)
* 終了   : 2026-08-24 20:10:00 (UTC)
* 現象   : 2026-08-24 20:10:00 (UTC)を境に水準が 11.8から14.83へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.971, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.056, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→15→19→17→…→13→12→10→12
* 開始   : 2026-08-24 03:20:00 (UTC)
* 終了   : 2026-08-24 20:25:00 (UTC)
* 現象   : 2026-08-24 20:25:00 (UTC)を境に水準が 11.97から14.98へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.009, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 14→13→18→15→14
* 開始   : 2026-08-25 05:35:00 (UTC)
* 終了   : 2026-08-25 05:35:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.394倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.543σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host06-003 active_connections の推移](charts/EVT-20260825-host06-003.svg)

# イベントID( EVT-20260825-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 17→20→21→17→…→17→15→16→17
* 開始   : 2026-08-25 16:05:00 (UTC)
* 終了   : 2026-08-25 16:50:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host01-011 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260825-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-053 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260825-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260825-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 16→16→11→14→15
* 開始   : 2026-08-25 18:05:00 (UTC)
* 終了   : 2026-08-25 18:05:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.6911(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260825-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→13→16→14→12→13→12→12→14
* 開始   : 2026-08-25 18:45:00 (UTC)
* 終了   : 2026-08-25 20:35:00 (UTC)
* 現象   : 2026-08-25 20:35:00 (UTC)を境に水準が 15.02から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→15→10→14→13
* 開始   : 2026-08-25 18:50:00 (UTC)
* 終了   : 2026-08-25 19:50:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.663(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260825-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 25 分
  - EVT-20260825-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260825-host06-010 active_connections の推移](charts/EVT-20260825-host06-010.svg)

# イベントID( EVT-20260825-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→8→11→9→8→11→9→10
* 開始   : 2026-08-25 20:05:00 (UTC)
* 終了   : 2026-08-25 20:15:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.6316(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.272σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→14→16
* 開始   : 2026-08-26 05:55:00 (UTC)
* 終了   : 2026-08-26 05:55:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 16→14→19→16→14
* 開始   : 2026-08-26 06:30:00 (UTC)
* 終了   : 2026-08-26 06:30:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.333倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 18→22→17→16→…→17→16→17→19
* 開始   : 2026-08-26 15:30:00 (UTC)
* 終了   : 2026-08-26 15:35:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.8193(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.617σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→14→11→14→14
* 開始   : 2026-08-26 18:25:00 (UTC)
* 終了   : 2026-08-26 18:25:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.6984(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-060 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→13→8→11→12
* 開始   : 2026-08-26 19:50:00 (UTC)
* 終了   : 2026-08-26 19:50:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.6194(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.432σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host06-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→10→8→13→10→8→13→10
* 開始   : 2026-08-26 19:50:00 (UTC)
* 終了   : 2026-08-26 19:55:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host06-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host06-011 active_connections の推移](charts/EVT-20260826-host06-011.svg)

# イベントID( EVT-20260827-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 20→19→23→21→19
* 開始   : 2026-08-27 08:25:00 (UTC)
* 終了   : 2026-08-27 08:25:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.26倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 21→23→25→21→20
* 開始   : 2026-08-27 10:00:00 (UTC)
* 終了   : 2026-08-27 10:00:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260827-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 22→21→18→22→21
* 開始   : 2026-08-27 14:05:00 (UTC)
* 終了   : 2026-08-27 14:05:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260827-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260827-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 21→20→16→19→19
* 開始   : 2026-08-27 15:15:00 (UTC)
* 終了   : 2026-08-27 15:15:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260827-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→19→13→16→17
* 開始   : 2026-08-27 17:20:00 (UTC)
* 終了   : 2026-08-27 17:35:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.021σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 16→14→12→14→14
* 開始   : 2026-08-27 18:05:00 (UTC)
* 終了   : 2026-08-27 18:05:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260827-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 9→8→5→10→8
* 開始   : 2026-08-27 22:15:00 (UTC)
* 終了   : 2026-08-27 22:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 7→9→14→8→9
* 開始   : 2026-08-28 02:30:00 (UTC)
* 終了   : 2026-08-28 02:30:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.732倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260828-host06-001 active_connections の推移](charts/EVT-20260828-host06-001.svg)

# イベントID( EVT-20260828-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 10→11→16→10→12
* 開始   : 2026-08-28 03:50:00 (UTC)
* 終了   : 2026-08-28 03:50:00 (UTC)
* 現象   : 平常時(10)に対し 1.6倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.188σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host06-002 active_connections の推移](charts/EVT-20260828-host06-002.svg)

# イベントID( EVT-20260828-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→14→16→11→13
* 開始   : 2026-08-28 04:40:00 (UTC)
* 終了   : 2026-08-28 04:40:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→12→17→15→15
* 開始   : 2026-08-28 05:05:00 (UTC)
* 終了   : 2026-08-28 05:05:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.437倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.622σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host06-004 active_connections の推移](charts/EVT-20260828-host06-004.svg)

# イベントID( EVT-20260828-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 10→14→17→14→13
* 開始   : 2026-08-28 05:20:00 (UTC)
* 終了   : 2026-08-28 05:20:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→14→19→16→16
* 開始   : 2026-08-28 06:25:00 (UTC)
* 終了   : 2026-08-28 06:25:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260828-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→15→19→15→15
* 開始   : 2026-08-28 06:30:00 (UTC)
* 終了   : 2026-08-28 06:30:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 18→19→23→19→20
* 開始   : 2026-08-28 08:35:00 (UTC)
* 終了   : 2026-08-28 08:35:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 21→18→15→18→20
* 開始   : 2026-08-28 16:00:00 (UTC)
* 終了   : 2026-08-28 16:00:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7692(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-052 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260828-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 16→17→13→15→17
* 開始   : 2026-08-28 17:20:00 (UTC)
* 終了   : 2026-08-28 17:20:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→14→12→16→12→16→12→13
* 開始   : 2026-08-28 17:20:00 (UTC)
* 終了   : 2026-08-28 18:25:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7164(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260828-host03-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host14-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260828-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→10→11→12→…→12→8→9→8
* 開始   : 2026-08-29 04:15:00 (UTC)
* 終了   : 2026-08-29 20:05:00 (UTC)
* 現象   : 15.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.808, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260829-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260829-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260829-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260829-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.9 時間

![EVT-20260829-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→14→13→14→…→13→14→11→12
* 開始   : 2026-08-29 05:15:00 (UTC)
* 終了   : 2026-08-29 20:10:00 (UTC)
* 現象   : 14.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.021, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260829-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260829-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260829-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260829-host06-003 active_connections の推移](charts/EVT-20260829-host06-003.svg)

# イベントID( EVT-20260829-host06-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→13→12→13→…→13→15→14→11
* 開始   : 2026-08-29 05:30:00 (UTC)
* 終了   : 2026-08-29 18:30:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.809, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260829-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260829-host06-004 active_connections の推移](charts/EVT-20260829-host06-004.svg)

# イベントID( EVT-20260829-host06-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 12→15→12→15→…→13→11→12→11
* 開始   : 2026-08-29 05:35:00 (UTC)
* 終了   : 2026-08-29 18:55:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.016, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260829-host06-005 active_connections の推移](charts/EVT-20260829-host06-005.svg)

# イベントID( EVT-20260829-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→10→11→12→…→11→13→12→11
* 開始   : 2026-08-29 05:55:00 (UTC)
* 終了   : 2026-08-29 18:15:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.257, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260829-host06-006 active_connections の推移](charts/EVT-20260829-host06-006.svg)

# イベントID( EVT-20260829-host06-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→10→12→13→…→10→11→12→11
* 開始   : 2026-08-29 06:05:00 (UTC)
* 終了   : 2026-08-29 18:40:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.762, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260829-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260829-host06-007 active_connections の推移](charts/EVT-20260829-host06-007.svg)

# イベントID( EVT-20260801-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→8→11→10→…→6→12→9→11
* 開始   : 2026-08-01 03:25:00 (UTC)
* 終了   : 2026-08-01 03:50:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 25 分
  - EVT-20260801-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260801-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260801-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host06-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→10→9→10→…→9→10→11→10
* 開始   : 2026-08-01 05:10:00 (UTC)
* 終了   : 2026-08-01 05:15:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.729, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 5 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 5 分
  - EVT-20260801-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260801-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 9→8→11→8→…→8→12→10→6
* 開始   : 2026-08-02 01:55:00 (UTC)
* 終了   : 2026-08-02 02:05:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260802-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 9→13→12→9→13→12
* 開始   : 2026-08-02 05:00:00 (UTC)
* 終了   : 2026-08-02 05:05:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260802-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→17→14→16→14→16
* 開始   : 2026-08-02 08:05:00 (UTC)
* 終了   : 2026-08-02 09:00:00 (UTC)
* 現象   : 2026-08-02 09:00:00 (UTC)を境に水準が 11.89から12.55へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→13→18→15→…→15→11→15→12
* 開始   : 2026-08-02 15:10:00 (UTC)
* 終了   : 2026-08-02 15:20:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260802-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260802-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host06-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→11→10→12→8→10→9→9→11
* 開始   : 2026-08-03 21:05:00 (UTC)
* 終了   : 2026-08-03 22:00:00 (UTC)
* 現象   : 2026-08-03 22:00:00 (UTC)を境に水準が 14.85から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 10→9→13→8→13→8→13→9→12
* 開始   : 2026-08-04 02:20:00 (UTC)
* 終了   : 2026-08-04 02:55:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-006 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260804-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-lsfhost01-004 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260804-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260804-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→16→13→16→…→13→16→13→14
* 開始   : 2026-08-04 05:25:00 (UTC)
* 終了   : 2026-08-04 06:55:00 (UTC)
* 現象   : 2026-08-04 06:55:00 (UTC)を境に水準が 15.05から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.408, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 23→19→23→22→…→22→24→23→21
* 開始   : 2026-08-04 10:20:00 (UTC)
* 終了   : 2026-08-04 10:30:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.145倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 21→20→17→18→16→17→18→16→18
* 開始   : 2026-08-04 15:50:00 (UTC)
* 終了   : 2026-08-04 16:00:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.398σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host06-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-lsfhost01-040 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260804-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 21→18→16→20→16→20→16→21→17
* 開始   : 2026-08-04 15:50:00 (UTC)
* 終了   : 2026-08-04 16:00:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.8136(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host06-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-lsfhost01-040 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260804-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 17→15→17→14→15→17→14→16→17
* 開始   : 2026-08-04 16:50:00 (UTC)
* 終了   : 2026-08-04 17:00:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→16→18→17→17→15→16→16→17
* 開始   : 2026-08-04 17:05:00 (UTC)
* 終了   : 2026-08-04 18:45:00 (UTC)
* 現象   : 2026-08-04 18:45:00 (UTC)を境に水準が 15.02から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→10→8→10→8→10→8→10
* 開始   : 2026-08-04 21:05:00 (UTC)
* 終了   : 2026-08-04 21:15:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260804-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 8→6→10→12→6→10→12→7→9
* 開始   : 2026-08-04 22:10:00 (UTC)
* 終了   : 2026-08-04 22:20:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→10→5→11→…→5→11→7→9
* 開始   : 2026-08-05 00:25:00 (UTC)
* 終了   : 2026-08-05 00:30:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.398σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-lsfhost01-001 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260805-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 15→16→18→16→18→16→17
* 開始   : 2026-08-05 06:30:00 (UTC)
* 終了   : 2026-08-05 06:35:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260805-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 18→21→20→18→21→20→21
* 開始   : 2026-08-05 08:40:00 (UTC)
* 終了   : 2026-08-05 08:45:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 19→18→22→20→18→22→20
* 開始   : 2026-08-05 08:55:00 (UTC)
* 終了   : 2026-08-05 09:00:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.205倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.629σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 24→23→23→23→24→22→22→24
* 開始   : 2026-08-05 12:10:00 (UTC)
* 終了   : 2026-08-05 12:45:00 (UTC)
* 現象   : 2026-08-05 12:45:00 (UTC)を境に水準が 14.95から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.768, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 23→23→23→22→23→21→24→23→21
* 開始   : 2026-08-05 13:10:00 (UTC)
* 終了   : 2026-08-05 14:05:00 (UTC)
* 現象   : 2026-08-05 14:05:00 (UTC)を境に水準が 15.15から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 21→24→19→22→24→19→22→24
* 開始   : 2026-08-05 13:40:00 (UTC)
* 終了   : 2026-08-05 13:45:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.8507(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260805-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→15→11→14→…→14→10→13→12
* 開始   : 2026-08-05 19:00:00 (UTC)
* 終了   : 2026-08-05 19:10:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-053 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260805-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→12→10→13→…→13→9→11→13
* 開始   : 2026-08-05 19:45:00 (UTC)
* 終了   : 2026-08-05 19:55:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→15→13→14→15→13→14→10→13
* 開始   : 2026-08-06 04:30:00 (UTC)
* 終了   : 2026-08-06 04:40:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.395倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.966σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host06-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260806-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→12→14→12→…→12→15→13→14
* 開始   : 2026-08-06 04:35:00 (UTC)
* 終了   : 2026-08-06 04:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host06-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260806-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host06-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→14→16→14→15→16
* 開始   : 2026-08-06 05:05:00 (UTC)
* 終了   : 2026-08-06 05:30:00 (UTC)
* 現象   : 2026-08-06 05:30:00 (UTC)を境に水準が 14.96から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.576, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→19→18→19→18→19→16→18
* 開始   : 2026-08-06 07:05:00 (UTC)
* 終了   : 2026-08-06 07:15:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 19→16→23→21→19→16→23→21→18
* 開始   : 2026-08-06 09:00:00 (UTC)
* 終了   : 2026-08-06 09:05:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260806-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260806-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 20→18→15→16→18→15→16→18
* 開始   : 2026-08-06 16:50:00 (UTC)
* 終了   : 2026-08-06 16:55:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.8036(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.575σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 17→18→15→14→15→14→15→17
* 開始   : 2026-08-06 17:15:00 (UTC)
* 終了   : 2026-08-06 17:25:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260806-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host06-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 9→10→10→10→10→12→9→9→11
* 開始   : 2026-08-06 21:55:00 (UTC)
* 終了   : 2026-08-06 22:35:00 (UTC)
* 現象   : 2026-08-06 22:35:00 (UTC)を境に水準が 14.97から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.918, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→7→12→13→…→12→13→9→11
* 開始   : 2026-08-07 03:15:00 (UTC)
* 終了   : 2026-08-07 03:20:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→9→15→11→15→11→15→12→14
* 開始   : 2026-08-07 04:35:00 (UTC)
* 終了   : 2026-08-07 04:45:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.304倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host02-005 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260807-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260807-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 18→17→16→18→17→16→18→17
* 開始   : 2026-08-07 16:20:00 (UTC)
* 終了   : 2026-08-07 16:25:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.4σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260807-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→15→13→15→13→15
* 開始   : 2026-08-07 18:00:00 (UTC)
* 終了   : 2026-08-07 18:05:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7839(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260807-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 10→12→7→8→7→8→7→8→9
* 開始   : 2026-08-07 21:30:00 (UTC)
* 終了   : 2026-08-07 21:40:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.515σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260807-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→8→10→10→10→10→9→10→11
* 開始   : 2026-08-09 01:05:00 (UTC)
* 終了   : 2026-08-09 01:55:00 (UTC)
* 現象   : 2026-08-09 01:55:00 (UTC)を境に水準が 11.85から11.72へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.218, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host06-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→12→12→13→12→12→14→13→13
* 開始   : 2026-08-09 05:10:00 (UTC)
* 終了   : 2026-08-09 06:00:00 (UTC)
* 現象   : 2026-08-09 06:00:00 (UTC)を境に水準が 11.91から12.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→13→16→14→16→14→16→12
* 開始   : 2026-08-09 07:15:00 (UTC)
* 終了   : 2026-08-09 07:25:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host06-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 15→16→17→14→14→16
* 開始   : 2026-08-09 08:20:00 (UTC)
* 終了   : 2026-08-09 08:45:00 (UTC)
* 現象   : 2026-08-09 08:45:00 (UTC)を境に水準が 11.94から12.51へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.664, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host06-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→16→16→17→17
* 開始   : 2026-08-09 11:50:00 (UTC)
* 終了   : 2026-08-09 12:10:00 (UTC)
* 現象   : 2026-08-09 12:10:00 (UTC)を境に水準が 11.8から13.63へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.897, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 16→17→17→17→17→16→14→16
* 開始   : 2026-08-09 13:25:00 (UTC)
* 終了   : 2026-08-09 14:00:00 (UTC)
* 現象   : 2026-08-09 14:00:00 (UTC)を境に水準が 11.84から13.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.816, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→9→7→6→…→7→6→8→9
* 開始   : 2026-08-10 21:35:00 (UTC)
* 終了   : 2026-08-10 21:40:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260810-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host06-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 10→10→9→9→9→11
* 開始   : 2026-08-10 22:00:00 (UTC)
* 終了   : 2026-08-10 22:45:00 (UTC)
* 現象   : 2026-08-10 22:45:00 (UTC)を境に水準が 14.87から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.664, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 10→9→6→10→6→10→6→9→6
* 開始   : 2026-08-10 22:40:00 (UTC)
* 終了   : 2026-08-10 22:50:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260810-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260810-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260810-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 8→6→10→6→10→6→9
* 開始   : 2026-08-11 00:40:00 (UTC)
* 終了   : 2026-08-11 00:50:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 9→10→11→13→12
* 開始   : 2026-08-11 02:30:00 (UTC)
* 終了   : 2026-08-11 04:05:00 (UTC)
* 現象   : 2026-08-11 04:05:00 (UTC)を境に水準が 14.91から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 9→7→12→10→12→10→12→10
* 開始   : 2026-08-11 02:30:00 (UTC)
* 終了   : 2026-08-11 02:40:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.443σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260811-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 15→14→17→16→…→16→18→14→15
* 開始   : 2026-08-11 06:10:00 (UTC)
* 終了   : 2026-08-11 06:50:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host06-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host06-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260811-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→18→17→19→18→17→19→18→15
* 開始   : 2026-08-11 06:20:00 (UTC)
* 終了   : 2026-08-11 06:30:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host06-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→18→15→19→18→15→19→17
* 開始   : 2026-08-11 06:35:00 (UTC)
* 終了   : 2026-08-11 06:45:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host06-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 19→16→23→20→19→16→23→20
* 開始   : 2026-08-11 08:35:00 (UTC)
* 終了   : 2026-08-11 08:40:00 (UTC)
* 現象   : 平常時(19)に対し 0.8421(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260811-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260811-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 18→22→18→22→18→19
* 開始   : 2026-08-11 08:45:00 (UTC)
* 終了   : 2026-08-11 08:50:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260811-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 18→21→16→17→16→17→16→17
* 開始   : 2026-08-11 16:10:00 (UTC)
* 終了   : 2026-08-11 16:20:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.8136(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.571σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host06-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→17→15→19→17→15→19→17
* 開始   : 2026-08-11 16:50:00 (UTC)
* 終了   : 2026-08-11 16:55:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260811-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 9→10→9→9→11
* 開始   : 2026-08-12 00:10:00 (UTC)
* 終了   : 2026-08-12 00:30:00 (UTC)
* 現象   : 2026-08-12 00:30:00 (UTC)を境に水準が 15.02から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 17→18→14→20→…→14→20→17→19
* 開始   : 2026-08-12 07:30:00 (UTC)
* 終了   : 2026-08-12 07:35:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→18→20→18→20→18→20
* 開始   : 2026-08-12 07:50:00 (UTC)
* 終了   : 2026-08-12 07:55:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 22→21→18→17→…→18→17→20→18
* 開始   : 2026-08-12 15:05:00 (UTC)
* 終了   : 2026-08-12 15:10:00 (UTC)
* 現象   : 平常時(21)に対し 0.8571(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260812-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 19→16→19→16→19
* 開始   : 2026-08-12 16:00:00 (UTC)
* 終了   : 2026-08-12 16:05:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→14→11→12→14→11→12→11
* 開始   : 2026-08-12 19:20:00 (UTC)
* 終了   : 2026-08-12 19:25:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→9→13→11→…→13→14→11→9
* 開始   : 2026-08-13 03:40:00 (UTC)
* 終了   : 2026-08-13 03:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260813-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260813-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→12→16→13→12→16→13→15
* 開始   : 2026-08-13 05:15:00 (UTC)
* 終了   : 2026-08-13 05:20:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→12→16→13→12→16→13→14
* 開始   : 2026-08-13 05:30:00 (UTC)
* 終了   : 2026-08-13 05:35:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host06-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260813-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 12→14→16→17→…→16→17→16→15
* 開始   : 2026-08-13 05:35:00 (UTC)
* 終了   : 2026-08-13 05:40:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host06-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260813-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260813-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→20→18→20→18→20→18
* 開始   : 2026-08-13 07:30:00 (UTC)
* 終了   : 2026-08-13 07:40:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.571σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 18→21→18→21→18→21→19→16
* 開始   : 2026-08-13 07:50:00 (UTC)
* 終了   : 2026-08-13 09:05:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.456σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host06-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260813-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260813-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 35 分
  - EVT-20260813-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分

![EVT-20260813-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 17→20→18→21→…→18→21→19→20
* 開始   : 2026-08-13 07:50:00 (UTC)
* 終了   : 2026-08-13 08:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host06-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260813-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host06-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 21→22→23→25→22→23→23
* 開始   : 2026-08-13 13:25:00 (UTC)
* 終了   : 2026-08-13 13:55:00 (UTC)
* 現象   : 2026-08-13 13:55:00 (UTC)を境に水準が 15.03から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.672, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→21→17→19→…→18→15→19→17
* 開始   : 2026-08-14 15:50:00 (UTC)
* 終了   : 2026-08-14 16:20:00 (UTC)
* 現象   : 30分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260814-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260814-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host06-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 9→7→10→9→7→10→8
* 開始   : 2026-08-15 20:40:00 (UTC)
* 終了   : 2026-08-15 20:45:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.798, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260815-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260815-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host06-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→17→17→17
* 開始   : 2026-08-16 09:55:00 (UTC)
* 終了   : 2026-08-16 10:10:00 (UTC)
* 現象   : 2026-08-16 10:10:00 (UTC)を境に水準が 11.93から12.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host06-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→11→11→8→10→12
* 開始   : 2026-08-16 21:00:00 (UTC)
* 終了   : 2026-08-16 21:25:00 (UTC)
* 現象   : 2026-08-16 21:25:00 (UTC)を境に水準が 11.85から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.66, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 8→9→5→11→…→5→11→8→10
* 開始   : 2026-08-16 22:30:00 (UTC)
* 終了   : 2026-08-16 22:35:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.5941(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260816-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 9→10→6→8→…→8→12→6→8
* 開始   : 2026-08-17 23:30:00 (UTC)
* 終了   : 2026-08-17 23:40:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260817-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260817-lsfhost01-061 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260817-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260817-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→17→15→14→16→17→15
* 開始   : 2026-08-18 05:30:00 (UTC)
* 終了   : 2026-08-18 05:35:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 17→19→22→19→22→19→18
* 開始   : 2026-08-18 08:40:00 (UTC)
* 終了   : 2026-08-18 08:45:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.217倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.749σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260818-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host06-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 23→25→22→23→23→23
* 開始   : 2026-08-18 10:50:00 (UTC)
* 終了   : 2026-08-18 11:15:00 (UTC)
* 現象   : 2026-08-18 11:15:00 (UTC)を境に水準が 14.99から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.66, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 22→23→24→23→22→22
* 開始   : 2026-08-18 13:55:00 (UTC)
* 終了   : 2026-08-18 14:45:00 (UTC)
* 現象   : 2026-08-18 14:45:00 (UTC)を境に水準が 15から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 18→17→16→18→…→18→15→17→18
* 開始   : 2026-08-18 16:15:00 (UTC)
* 終了   : 2026-08-18 16:25:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.8458(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 18→19→15→17→…→17→14→18→15
* 開始   : 2026-08-18 16:30:00 (UTC)
* 終了   : 2026-08-18 16:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.498σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-046 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260818-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260818-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→13→14→13→14→13→14→16
* 開始   : 2026-08-18 17:50:00 (UTC)
* 終了   : 2026-08-18 18:00:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→10→13→9→7→13→9→7→10
* 開始   : 2026-08-18 21:20:00 (UTC)
* 終了   : 2026-08-18 21:30:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host01-014 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260818-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-lsfhost01-071 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260818-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host06-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 18→17→17→17→15→16→16→16→17
* 開始   : 2026-08-19 16:30:00 (UTC)
* 終了   : 2026-08-19 18:05:00 (UTC)
* 現象   : 2026-08-19 18:05:00 (UTC)を境に水準が 14.93から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.589, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→15→13→18→13→18→13→16→15
* 開始   : 2026-08-19 17:45:00 (UTC)
* 終了   : 2026-08-19 17:55:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.78(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.573σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 8→10→13→11→…→11→6→10→9
* 開始   : 2026-08-19 21:25:00 (UTC)
* 終了   : 2026-08-19 21:35:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-072 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260819-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→8→9→11→9→9→11
* 開始   : 2026-08-20 01:30:00 (UTC)
* 終了   : 2026-08-20 02:00:00 (UTC)
* 現象   : 2026-08-20 02:00:00 (UTC)を境に水準が 14.94から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.774, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→10→13→12→10→13→12→11
* 開始   : 2026-08-20 03:40:00 (UTC)
* 終了   : 2026-08-20 03:45:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-lsfhost01-009 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260820-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→14→12→15→14→12→15→14→12
* 開始   : 2026-08-20 04:45:00 (UTC)
* 終了   : 2026-08-20 04:55:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260820-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260820-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 22→21→21→22→22→21→21
* 開始   : 2026-08-20 09:15:00 (UTC)
* 終了   : 2026-08-20 09:45:00 (UTC)
* 現象   : 2026-08-20 09:45:00 (UTC)を境に水準が 14.98から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.672, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 22→20→23→22→23→22→23→22→21
* 開始   : 2026-08-20 10:30:00 (UTC)
* 終了   : 2026-08-20 10:40:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.398σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host06-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 22→23→23→22→23→20→22→21→23
* 開始   : 2026-08-20 13:30:00 (UTC)
* 終了   : 2026-08-20 14:25:00 (UTC)
* 現象   : 2026-08-20 14:25:00 (UTC)を境に水準が 14.88から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 22→21→19→18→21→19→18→21
* 開始   : 2026-08-20 13:30:00 (UTC)
* 終了   : 2026-08-20 13:35:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260820-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 10→8→7→10→8→7→10→8
* 開始   : 2026-08-20 21:15:00 (UTC)
* 終了   : 2026-08-20 21:20:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-070 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260820-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host06-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 8→7→9→10→8→9→9→11
* 開始   : 2026-08-20 22:40:00 (UTC)
* 終了   : 2026-08-20 23:15:00 (UTC)
* 現象   : 2026-08-20 23:15:00 (UTC)を境に水準が 14.9から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.816, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host06-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 18→18→16→16→18→16→18→17→19
* 開始   : 2026-08-21 06:15:00 (UTC)
* 終了   : 2026-08-21 07:35:00 (UTC)
* 現象   : 2026-08-21 07:35:00 (UTC)を境に水準が 14.84から14.39へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.807σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.882, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 17→19→20→17→19→20→17→19
* 開始   : 2026-08-21 07:25:00 (UTC)
* 終了   : 2026-08-21 07:30:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 24→21→22→19→22
* 開始   : 2026-08-21 09:40:00 (UTC)
* 終了   : 2026-08-21 10:00:00 (UTC)
* 現象   : 2026-08-21 10:00:00 (UTC)を境に水準が 14.93から13.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 20→24→19→21→19→21→19→23→24
* 開始   : 2026-08-21 13:35:00 (UTC)
* 終了   : 2026-08-21 13:45:00 (UTC)
* 現象   : 平常時(22.08)に対し 0.8604(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260821-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 19→22→21→21→24
* 開始   : 2026-08-21 15:10:00 (UTC)
* 終了   : 2026-08-21 15:30:00 (UTC)
* 現象   : 2026-08-21 15:30:00 (UTC)を境に水準が 15.04から12.47へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.03, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 19→20→15→18→…→19→22→16→19
* 開始   : 2026-08-21 15:45:00 (UTC)
* 終了   : 2026-08-21 16:05:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.985σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 19→18→15→16→15→16→15→19→18
* 開始   : 2026-08-21 16:55:00 (UTC)
* 終了   : 2026-08-21 17:05:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-049 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260821-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260821-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260821-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 17→15→14→17→13→14→17→13→17
* 開始   : 2026-08-21 17:35:00 (UTC)
* 終了   : 2026-08-21 17:45:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260821-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→12→10→9→…→10→9→13→12
* 開始   : 2026-08-21 19:55:00 (UTC)
* 終了   : 2026-08-21 20:00:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.7742(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260821-host06-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 10→9→8→11→14→8→11→14→9
* 開始   : 2026-08-21 20:35:00 (UTC)
* 終了   : 2026-08-21 20:45:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.7218(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host11-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-074 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host06-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host06-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→10→10→8→10→11→11→10
* 開始   : 2026-08-21 21:15:00 (UTC)
* 終了   : 2026-08-21 21:50:00 (UTC)
* 現象   : 2026-08-21 21:50:00 (UTC)を境に水準が 14.97から11.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.885, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host06-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 10→8→12→10→8→12→10
* 開始   : 2026-08-23 03:40:00 (UTC)
* 終了   : 2026-08-23 03:45:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260823-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 15→13→17→15→…→15→11→13→14
* 開始   : 2026-08-23 16:10:00 (UTC)
* 終了   : 2026-08-23 16:20:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-037 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260823-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260823-lsfhost01-036 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260823-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260823-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host06-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→15→16→13→15
* 開始   : 2026-08-23 16:35:00 (UTC)
* 終了   : 2026-08-23 16:55:00 (UTC)
* 現象   : 2026-08-23 16:55:00 (UTC)を境に水準が 11.73から14.57へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.897, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host06-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 10→11→10→8→9→11
* 開始   : 2026-08-23 22:00:00 (UTC)
* 終了   : 2026-08-23 22:25:00 (UTC)
* 現象   : 2026-08-23 22:25:00 (UTC)を境に水準が 11.7から14.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.576, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→10→13→9→9→9→9→10→9
* 開始   : 2026-08-24 20:50:00 (UTC)
* 終了   : 2026-08-24 22:10:00 (UTC)
* 現象   : 2026-08-24 22:10:00 (UTC)を境に水準が 15.03から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.735, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→10→12→6→…→12→6→7→10
* 開始   : 2026-08-24 22:55:00 (UTC)
* 終了   : 2026-08-24 23:00:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260824-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260824-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 10→8→11→9→11
* 開始   : 2026-08-25 01:30:00 (UTC)
* 終了   : 2026-08-25 01:50:00 (UTC)
* 現象   : 2026-08-25 01:50:00 (UTC)を境に水準が 14.93から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.554, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 9→12→14→11→…→11→15→12→13
* 開始   : 2026-08-25 04:20:00 (UTC)
* 終了   : 2026-08-25 04:30:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260825-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-014 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260825-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→15→18→19→…→18→19→15→16
* 開始   : 2026-08-25 06:45:00 (UTC)
* 終了   : 2026-08-25 06:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.4σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260825-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 17→20→19→17→20→19
* 開始   : 2026-08-25 07:55:00 (UTC)
* 終了   : 2026-08-25 08:00:00 (UTC)
* 現象   : 平常時(16.75)に対し 1.194倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260825-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260825-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→12→14→15→12→14→13
* 開始   : 2026-08-25 18:40:00 (UTC)
* 終了   : 2026-08-25 18:45:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260825-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host06-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→20→20→20→21
* 開始   : 2026-08-26 08:35:00 (UTC)
* 終了   : 2026-08-26 08:55:00 (UTC)
* 現象   : 2026-08-26 08:55:00 (UTC)を境に水準が 14.91から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.554, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 20→20→21→21→21→20→20→20
* 開始   : 2026-08-26 15:20:00 (UTC)
* 終了   : 2026-08-26 16:25:00 (UTC)
* 現象   : 2026-08-26 16:25:00 (UTC)を境に水準が 15から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.692σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.768, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 15→16→12→14→16→12→14
* 開始   : 2026-08-26 18:40:00 (UTC)
* 終了   : 2026-08-26 18:45:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.7579(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.69σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→12→15→11→12→15→11→15→13
* 開始   : 2026-08-26 18:50:00 (UTC)
* 終了   : 2026-08-26 19:00:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260826-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→14→11→10→13→14→11→10→13
* 開始   : 2026-08-26 19:25:00 (UTC)
* 終了   : 2026-08-26 19:30:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.166σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-068 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260826-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 10→8→7→11→10→8→7→11→9
* 開始   : 2026-08-26 21:05:00 (UTC)
* 終了   : 2026-08-26 21:10:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260826-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host06-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→10→8→13→10→11→10
* 開始   : 2026-08-26 21:40:00 (UTC)
* 終了   : 2026-08-26 22:10:00 (UTC)
* 現象   : 2026-08-26 22:10:00 (UTC)を境に水準が 14.94から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.714, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host06-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→11→9→8→9→10→8→9→9
* 開始   : 2026-08-26 22:15:00 (UTC)
* 終了   : 2026-08-26 23:30:00 (UTC)
* 現象   : 2026-08-26 23:30:00 (UTC)を境に水準が 15.01から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.772, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→8→11→9→10→14→11→12→12
* 開始   : 2026-08-27 02:45:00 (UTC)
* 終了   : 2026-08-27 04:15:00 (UTC)
* 現象   : 2026-08-27 04:15:00 (UTC)を境に水準が 14.89から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→14→16→11→16→11→16→15→14
* 開始   : 2026-08-27 05:35:00 (UTC)
* 終了   : 2026-08-27 05:45:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260827-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260827-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→17→19→17→19→18
* 開始   : 2026-08-27 06:55:00 (UTC)
* 終了   : 2026-08-27 07:00:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host06-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 23→23→22→22→21→22→24→21→24
* 開始   : 2026-08-27 13:05:00 (UTC)
* 終了   : 2026-08-27 13:45:00 (UTC)
* 現象   : 2026-08-27 13:45:00 (UTC)を境に水準が 14.97から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.864, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→13→11→13→…→13→10→11→13
* 開始   : 2026-08-27 19:00:00 (UTC)
* 終了   : 2026-08-27 19:10:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-073 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 19→18→21→18→21→18→21→18→21
* 開始   : 2026-08-28 08:00:00 (UTC)
* 終了   : 2026-08-28 08:10:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 20→18→17→22→20→18→17→22→18
* 開始   : 2026-08-28 14:55:00 (UTC)
* 終了   : 2026-08-28 15:00:00 (UTC)
* 現象   : 平常時(21)に対し 0.8571(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260828-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 19→16→20→16→20→16→19
* 開始   : 2026-08-28 16:10:00 (UTC)
* 終了   : 2026-08-28 16:20:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.224σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-053 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-host03-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-052 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260828-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host06-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 13→12→11→10→10→11→11→11
* 開始   : 2026-08-28 20:30:00 (UTC)
* 終了   : 2026-08-28 21:05:00 (UTC)
* 現象   : 2026-08-28 21:05:00 (UTC)を境に水準が 14.97から11.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.886, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host06-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 8→6→5→9→5→9→5→8→7
* 開始   : 2026-08-29 00:10:00 (UTC)
* 終了   : 2026-08-29 00:20:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260829-host06-001 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
