# host03 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host03 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 279 (SEVERE: 28, FATAL: 105, WARN: 146, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 28 | 105 | 146 | 279 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260801-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→9→16→14→…→12→11→13→11
* 開始   : 2026-08-01 05:05:00 (UTC)
* 終了   : 2026-08-01 18:40:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.786, 限界=2.706)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.34σ 外れた (平常値=14.88)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260801-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260801-host03-003 active_connections の推移](charts/EVT-20260801-host03-003.svg)

# イベントID( EVT-20260803-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→16→14→16→…→14→17→12→14
* 開始   : 2026-08-03 02:30:00 (UTC)
* 終了   : 2026-08-03 19:45:00 (UTC)
* 現象   : 2026-08-03 19:45:00 (UTC)を境に水準が 11.91から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.047σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.107, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.654, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host03-002 active_connections の推移](charts/EVT-20260803-host03-002.svg)

# イベントID( EVT-20260803-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→16→15→16→…→11→15→11→14
* 開始   : 2026-08-03 02:45:00 (UTC)
* 終了   : 2026-08-03 20:40:00 (UTC)
* 現象   : 2026-08-03 20:40:00 (UTC)を境に水準が 11.9から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.675, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host03-003 active_connections の推移](charts/EVT-20260803-host03-003.svg)

# イベントID( EVT-20260803-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→16→15→13→…→15→14→15→13
* 開始   : 2026-08-03 03:10:00 (UTC)
* 終了   : 2026-08-03 21:10:00 (UTC)
* 現象   : 2026-08-03 21:10:00 (UTC)を境に水準が 11.9から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.741, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.705, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host03-004 active_connections の推移](charts/EVT-20260803-host03-004.svg)

# イベントID( EVT-20260803-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→15→17→15→…→15→14→12→14
* 開始   : 2026-08-03 03:35:00 (UTC)
* 終了   : 2026-08-03 20:00:00 (UTC)
* 現象   : 2026-08-03 20:00:00 (UTC)を境に水準が 11.91から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.757, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.932, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host03-005 active_connections の推移](charts/EVT-20260803-host03-005.svg)

# イベントID( EVT-20260803-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 16→14→16→17→…→12→15→14→15
* 開始   : 2026-08-03 03:40:00 (UTC)
* 終了   : 2026-08-03 20:05:00 (UTC)
* 現象   : 2026-08-03 20:05:00 (UTC)を境に水準が 11.88から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.749, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.29, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host03-006 active_connections の推移](charts/EVT-20260803-host03-006.svg)

# イベントID( EVT-20260803-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 10→9→11→9→9→10→10→9→9
* 開始   : 2026-08-03 21:20:00 (UTC)
* 終了   : 2026-08-03 22:30:00 (UTC)
* 現象   : 2026-08-03 22:30:00 (UTC)を境に水準が 14.89から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.936, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host03-007 active_connections の推移](charts/EVT-20260803-host03-007.svg)

# イベントID( EVT-20260803-host03-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 9→9→9→7→9→9
* 開始   : 2026-08-03 23:55:00 (UTC)
* 終了   : 2026-08-04 00:20:00 (UTC)
* 現象   : 2026-08-04 00:20:00 (UTC)を境に水準が 14.99から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host03-009 active_connections の推移](charts/EVT-20260803-host03-009.svg)

# イベントID( EVT-20260810-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→16→15→16→…→14→16→15→14
* 開始   : 2026-08-10 02:30:00 (UTC)
* 終了   : 2026-08-10 20:35:00 (UTC)
* 現象   : 2026-08-10 20:35:00 (UTC)を境に水準が 11.87から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.873, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.962, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host03-003 active_connections の推移](charts/EVT-20260810-host03-003.svg)

# イベントID( EVT-20260810-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→17→18→17→…→12→13→12→10
* 開始   : 2026-08-10 02:30:00 (UTC)
* 終了   : 2026-08-10 20:40:00 (UTC)
* 現象   : 2026-08-10 20:40:00 (UTC)を境に水準が 11.96から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.942, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host03-004 active_connections の推移](charts/EVT-20260810-host03-004.svg)

# イベントID( EVT-20260810-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→14→15→18→…→15→18→13→15
* 開始   : 2026-08-10 02:35:00 (UTC)
* 終了   : 2026-08-10 19:45:00 (UTC)
* 現象   : 2026-08-10 19:45:00 (UTC)を境に水準が 11.95から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.75, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.938, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host03-005 active_connections の推移](charts/EVT-20260810-host03-005.svg)

# イベントID( EVT-20260810-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→16→15→16→…→10→12→11→12
* 開始   : 2026-08-10 03:05:00 (UTC)
* 終了   : 2026-08-10 20:50:00 (UTC)
* 現象   : 2026-08-10 20:50:00 (UTC)を境に水準が 11.9から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.233, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host03-006 active_connections の推移](charts/EVT-20260810-host03-006.svg)

# イベントID( EVT-20260810-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→15→16→13→…→13→16→13→15
* 開始   : 2026-08-10 03:50:00 (UTC)
* 終了   : 2026-08-10 20:40:00 (UTC)
* 現象   : 2026-08-10 20:40:00 (UTC)を境に水準が 11.88から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.277, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.68, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host03-007 active_connections の推移](charts/EVT-20260810-host03-007.svg)

# イベントID( EVT-20260811-host03-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 11→11→12→11→12→13→12→12→15
* 開始   : 2026-08-11 03:20:00 (UTC)
* 終了   : 2026-08-11 04:45:00 (UTC)
* 現象   : 2026-08-11 04:45:00 (UTC)を境に水準が 15.02から14.89へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.923, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host03-002 active_connections の推移](charts/EVT-20260811-host03-002.svg)

# イベントID( EVT-20260816-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→14→13→14→13→15
* 開始   : 2026-08-16 16:55:00 (UTC)
* 終了   : 2026-08-16 17:20:00 (UTC)
* 現象   : 2026-08-16 17:20:00 (UTC)を境に水準が 11.81から14.64へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host03-006 active_connections の推移](charts/EVT-20260816-host03-006.svg)

# イベントID( EVT-20260817-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 12→15→17→16→…→11→15→14→11
* 開始   : 2026-08-17 01:50:00 (UTC)
* 終了   : 2026-08-17 21:00:00 (UTC)
* 現象   : 2026-08-17 21:00:00 (UTC)を境に水準が 11.75から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.87, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.102, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host03-001 active_connections の推移](charts/EVT-20260817-host03-001.svg)

# イベントID( EVT-20260817-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→14→13→14→…→10→11→10→11
* 開始   : 2026-08-17 02:05:00 (UTC)
* 終了   : 2026-08-17 20:50:00 (UTC)
* 現象   : 2026-08-17 20:50:00 (UTC)を境に水準が 11.73から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.519σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.696, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host03-002 active_connections の推移](charts/EVT-20260817-host03-002.svg)

# イベントID( EVT-20260817-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→14→17→15→…→14→15→11→14
* 開始   : 2026-08-17 02:20:00 (UTC)
* 終了   : 2026-08-17 20:25:00 (UTC)
* 現象   : 2026-08-17 20:25:00 (UTC)を境に水準が 11.82から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.805, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host03-003 active_connections の推移](charts/EVT-20260817-host03-003.svg)

# イベントID( EVT-20260817-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→14→13→16→…→13→11→15→13
* 開始   : 2026-08-17 03:25:00 (UTC)
* 終了   : 2026-08-17 20:25:00 (UTC)
* 現象   : 2026-08-17 20:25:00 (UTC)を境に水準が 11.84から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.662, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.949, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host03-006 active_connections の推移](charts/EVT-20260817-host03-006.svg)

# イベントID( EVT-20260819-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 10→8→10→9→13
* 開始   : 2026-08-19 01:55:00 (UTC)
* 終了   : 2026-08-19 02:15:00 (UTC)
* 現象   : 2026-08-19 02:15:00 (UTC)を境に水準が 15.03から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.979, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host03-001 active_connections の推移](charts/EVT-20260819-host03-001.svg)

# イベントID( EVT-20260824-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→16→…→15→13→15→13
* 開始   : 2026-08-24 01:15:00 (UTC)
* 終了   : 2026-08-24 19:30:00 (UTC)
* 現象   : 2026-08-24 19:30:00 (UTC)を境に水準が 11.97から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.704, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.575, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host03-001 active_connections の推移](charts/EVT-20260824-host03-001.svg)

# イベントID( EVT-20260824-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→16→17→16→…→13→14→13→11
* 開始   : 2026-08-24 01:30:00 (UTC)
* 終了   : 2026-08-24 20:40:00 (UTC)
* 現象   : 2026-08-24 20:40:00 (UTC)を境に水準が 11.89から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.729σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.935, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host03-002 active_connections の推移](charts/EVT-20260824-host03-002.svg)

# イベントID( EVT-20260824-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→18→15→17→…→12→14→12→13
* 開始   : 2026-08-24 02:40:00 (UTC)
* 終了   : 2026-08-24 19:30:00 (UTC)
* 現象   : 2026-08-24 19:30:00 (UTC)を境に水準が 11.81から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.21, 限界=2.665)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.945, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host03-003 active_connections の推移](charts/EVT-20260824-host03-003.svg)

# イベントID( EVT-20260824-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→17→16→15→…→11→13→14→13
* 開始   : 2026-08-24 03:20:00 (UTC)
* 終了   : 2026-08-24 20:50:00 (UTC)
* 現象   : 2026-08-24 20:50:00 (UTC)を境に水準が 11.83から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.998, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host03-004 active_connections の推移](charts/EVT-20260824-host03-004.svg)

# イベントID( EVT-20260824-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→16→17→16→…→12→14→15→12
* 開始   : 2026-08-24 04:05:00 (UTC)
* 終了   : 2026-08-24 20:10:00 (UTC)
* 現象   : 2026-08-24 20:10:00 (UTC)を境に水準が 12から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.742, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host03-005 active_connections の推移](charts/EVT-20260824-host03-005.svg)

# イベントID( EVT-20260824-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→13→17→15→…→13→15→12→14
* 開始   : 2026-08-24 04:30:00 (UTC)
* 終了   : 2026-08-24 20:10:00 (UTC)
* 現象   : 2026-08-24 20:10:00 (UTC)を境に水準が 11.92から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.728σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.249, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host03-006 active_connections の推移](charts/EVT-20260824-host03-006.svg)

# イベントID( EVT-20260824-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 12→9→11→10→9
* 開始   : 2026-08-24 21:00:00 (UTC)
* 終了   : 2026-08-24 21:20:00 (UTC)
* 現象   : 2026-08-24 21:20:00 (UTC)を境に水準が 14.81から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.979, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host03-007 active_connections の推移](charts/EVT-20260824-host03-007.svg)

# イベントID( EVT-20260827-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 21→21→22→21→21→19
* 開始   : 2026-08-27 14:50:00 (UTC)
* 終了   : 2026-08-27 15:15:00 (UTC)
* 現象   : 2026-08-27 15:15:00 (UTC)を境に水準が 14.99から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host03-008 active_connections の推移](charts/EVT-20260827-host03-008.svg)

# イベントID( EVT-20260801-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→9→12→9→…→12→14→12→14
* 開始   : 2026-08-01 04:55:00 (UTC)
* 終了   : 2026-08-01 18:00:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.251σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.116, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host03-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260801-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260801-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260801-host03-001 active_connections の推移](charts/EVT-20260801-host03-001.svg)

# イベントID( EVT-20260801-host03-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→11→10→14→…→11→12→11→12
* 開始   : 2026-08-01 05:05:00 (UTC)
* 終了   : 2026-08-01 19:00:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.062, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host03-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260801-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260801-host03-002 active_connections の推移](charts/EVT-20260801-host03-002.svg)

# イベントID( EVT-20260801-host03-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→11→12→13→…→14→13→10→12
* 開始   : 2026-08-01 05:10:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.015, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host03-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260801-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260801-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host03-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260801-host03-004 active_connections の推移](charts/EVT-20260801-host03-004.svg)

# イベントID( EVT-20260801-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 12→10→11→10→…→12→11→12→10
* 開始   : 2026-08-01 06:10:00 (UTC)
* 終了   : 2026-08-01 19:00:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.184, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host03-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260801-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host01-007 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260801-host03-005 active_connections の推移](charts/EVT-20260801-host03-005.svg)

# イベントID( EVT-20260801-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→11→13→10→…→12→13→11→12
* 開始   : 2026-08-01 06:15:00 (UTC)
* 終了   : 2026-08-01 19:25:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.918, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host03-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.4 時間
  - EVT-20260801-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260801-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host03-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260801-host03-006 active_connections の推移](charts/EVT-20260801-host03-006.svg)

# イベントID( EVT-20260802-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→15→9→12→12
* 開始   : 2026-08-02 16:45:00 (UTC)
* 終了   : 2026-08-02 16:45:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260802-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 9→12→5→8→10
* 開始   : 2026-08-02 21:20:00 (UTC)
* 終了   : 2026-08-02 21:20:00 (UTC)
* 現象   : 平常時(10)に対し 0.5(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.482σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host03-007 active_connections の推移](charts/EVT-20260802-host03-007.svg)

# イベントID( EVT-20260803-host03-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→16→…→14→16→14→13
* 開始   : 2026-08-03 02:00:00 (UTC)
* 終了   : 2026-08-03 20:55:00 (UTC)
* 現象   : 2026-08-03 20:55:00 (UTC)を境に水準が 11.98から14.88へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.89, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.99, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→13→16→12→12
* 開始   : 2026-08-04 04:35:00 (UTC)
* 終了   : 2026-08-04 04:35:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260804-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260804-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 19→18→16→19→…→19→17→18→19
* 開始   : 2026-08-04 15:35:00 (UTC)
* 終了   : 2026-08-04 15:45:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260804-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260804-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→15→12→16→13
* 開始   : 2026-08-04 17:55:00 (UTC)
* 終了   : 2026-08-04 17:55:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260804-host04-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 12→10→6→10→8
* 開始   : 2026-08-04 21:25:00 (UTC)
* 終了   : 2026-08-04 21:25:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.5538(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.398σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→15→19→17→18
* 開始   : 2026-08-05 06:30:00 (UTC)
* 終了   : 2026-08-05 06:30:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host03-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260805-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 19→22→23→20→19→22→23→20→21
* 開始   : 2026-08-05 08:30:00 (UTC)
* 終了   : 2026-08-05 08:35:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.2倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.555σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 22→21→17→20→22
* 開始   : 2026-08-05 13:40:00 (UTC)
* 終了   : 2026-08-05 13:40:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.7757(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.452σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 20→19→17→19→…→19→15→17→19
* 開始   : 2026-08-05 16:20:00 (UTC)
* 終了   : 2026-08-05 16:30:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host03-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 17→15→11→15→15
* 開始   : 2026-08-05 17:45:00 (UTC)
* 終了   : 2026-08-05 17:45:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.6804(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.628σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260805-host03-010 active_connections の推移](charts/EVT-20260805-host03-010.svg)

# イベントID( EVT-20260805-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→12→11→13→9→11→13→9→11
* 開始   : 2026-08-05 19:15:00 (UTC)
* 終了   : 2026-08-05 19:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260805-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 11→11→8→11→11
* 開始   : 2026-08-05 20:20:00 (UTC)
* 終了   : 2026-08-05 20:20:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 8→11→12→8→…→14→11→13→12
* 開始   : 2026-08-06 03:10:00 (UTC)
* 終了   : 2026-08-06 03:35:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260806-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260806-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260806-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→12→16→13→14
* 開始   : 2026-08-06 05:00:00 (UTC)
* 終了   : 2026-08-06 05:00:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 21→16→21→16→21→20
* 開始   : 2026-08-06 14:55:00 (UTC)
* 終了   : 2026-08-06 15:00:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.7773(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.222σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 10→9→9→10→10→7→9→10
* 開始   : 2026-08-06 21:25:00 (UTC)
* 終了   : 2026-08-06 22:25:00 (UTC)
* 現象   : 2026-08-06 22:25:00 (UTC)を境に水準が 14.97から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.948, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 9→6→8→7→6→8→7→9→10
* 開始   : 2026-08-06 21:50:00 (UTC)
* 終了   : 2026-08-06 22:00:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.5496(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.418σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-074 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260806-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260806-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→15→18→15→16
* 開始   : 2026-08-07 06:00:00 (UTC)
* 終了   : 2026-08-07 06:00:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→20→14→17→18
* 開始   : 2026-08-07 16:00:00 (UTC)
* 終了   : 2026-08-07 16:00:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.7149(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.925σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host03-006 active_connections の推移](charts/EVT-20260807-host03-006.svg)

# イベントID( EVT-20260807-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 16→14→11→18→15
* 開始   : 2026-08-07 17:50:00 (UTC)
* 終了   : 2026-08-07 17:50:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.6911(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.424σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→13→11→14→9→11→14→9→13
* 開始   : 2026-08-07 19:15:00 (UTC)
* 終了   : 2026-08-07 19:25:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host03-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260807-host03-009 active_connections の推移](charts/EVT-20260807-host03-009.svg)

# イベントID( EVT-20260807-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 9→6→4→8→8
* 開始   : 2026-08-07 23:45:00 (UTC)
* 終了   : 2026-08-07 23:45:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260807-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 11→12→11→12→…→10→12→13→11
* 開始   : 2026-08-08 05:00:00 (UTC)
* 終了   : 2026-08-08 19:50:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.818, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.8 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260808-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260808-host03-002 active_connections の推移](charts/EVT-20260808-host03-002.svg)

# イベントID( EVT-20260808-host03-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→11→12→14→…→11→9→13→12
* 開始   : 2026-08-08 05:05:00 (UTC)
* 終了   : 2026-08-08 19:10:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.933, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260808-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260808-host03-003 active_connections の推移](charts/EVT-20260808-host03-003.svg)

# イベントID( EVT-20260808-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 12→11→10→11→…→12→13→11→12
* 開始   : 2026-08-08 05:05:00 (UTC)
* 終了   : 2026-08-08 18:35:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.457σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.011, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260808-host03-004 active_connections の推移](charts/EVT-20260808-host03-004.svg)

# イベントID( EVT-20260808-host03-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 10→11→10→11→…→11→10→11→12
* 開始   : 2026-08-08 05:40:00 (UTC)
* 終了   : 2026-08-08 19:40:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.933, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.0 時間
  - EVT-20260808-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.0 時間

![EVT-20260808-host03-005 active_connections の推移](charts/EVT-20260808-host03-005.svg)

# イベントID( EVT-20260808-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→12→11→12→…→15→11→13→11
* 開始   : 2026-08-08 06:15:00 (UTC)
* 終了   : 2026-08-08 19:30:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.902σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.144, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260808-host03-006 active_connections の推移](charts/EVT-20260808-host03-006.svg)

# イベントID( EVT-20260808-host03-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→12→13→11→…→9→10→13→10
* 開始   : 2026-08-08 06:15:00 (UTC)
* 終了   : 2026-08-08 19:55:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.259, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260808-host03-007 active_connections の推移](charts/EVT-20260808-host03-007.svg)

# イベントID( EVT-20260809-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→13→10→6→13→10→6→11→9
* 開始   : 2026-08-09 03:30:00 (UTC)
* 終了   : 2026-08-09 03:40:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260809-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→12→8→13→10
* 開始   : 2026-08-09 17:15:00 (UTC)
* 終了   : 2026-08-09 17:15:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.6076(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.632σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 9→10→5→8→8
* 開始   : 2026-08-09 21:55:00 (UTC)
* 終了   : 2026-08-09 21:55:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host03-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→16→15→13→…→13→15→12→14
* 開始   : 2026-08-10 01:35:00 (UTC)
* 終了   : 2026-08-10 22:30:00 (UTC)
* 現象   : 2026-08-10 22:30:00 (UTC)を境に水準が 11.74から15.01へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.955, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.654, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 7→6→12→9→10
* 開始   : 2026-08-11 01:35:00 (UTC)
* 終了   : 2026-08-11 01:35:00 (UTC)
* 現象   : 平常時(7.333)に対し 1.636倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.25σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 19→19→15→21→19
* 開始   : 2026-08-11 15:45:00 (UTC)
* 終了   : 2026-08-11 15:45:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→18→13→15→…→15→13→14→15
* 開始   : 2026-08-11 17:35:00 (UTC)
* 終了   : 2026-08-11 18:00:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260811-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260811-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260811-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260811-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260811-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→13→8→12→11
* 開始   : 2026-08-11 20:05:00 (UTC)
* 終了   : 2026-08-11 20:05:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.6234(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.366σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 9→10→5→8→9
* 開始   : 2026-08-11 22:30:00 (UTC)
* 終了   : 2026-08-11 23:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host10-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260811-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 8→6→11→7→…→7→5→8→9
* 開始   : 2026-08-12 00:30:00 (UTC)
* 終了   : 2026-08-12 01:40:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615倍(4)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-003 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260811-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 25 分
  - EVT-20260812-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260812-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 8→7→12→7→9
* 開始   : 2026-08-12 00:30:00 (UTC)
* 終了   : 2026-08-12 00:30:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260812-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 20→21→22→19→…→19→23→20→22
* 開始   : 2026-08-12 07:40:00 (UTC)
* 終了   : 2026-08-12 08:55:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260812-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host13-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host01-006 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260812-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260812-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→13→19→13→16
* 開始   : 2026-08-13 05:45:00 (UTC)
* 終了   : 2026-08-13 05:45:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.425倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.947σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host03-002 active_connections の推移](charts/EVT-20260813-host03-002.svg)

# イベントID( EVT-20260813-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 17→15→20→14→17
* 開始   : 2026-08-13 06:50:00 (UTC)
* 終了   : 2026-08-13 06:50:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260813-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→16→21→18→19
* 開始   : 2026-08-14 07:30:00 (UTC)
* 終了   : 2026-08-14 07:30:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.26倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260814-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→19→23→19→19
* 開始   : 2026-08-14 08:30:00 (UTC)
* 終了   : 2026-08-14 08:30:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.26倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.309σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-039 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260814-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 10→11→12→13→…→11→14→12→10
* 開始   : 2026-08-15 05:05:00 (UTC)
* 終了   : 2026-08-15 18:45:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.959, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260815-host03-002 active_connections の推移](charts/EVT-20260815-host03-002.svg)

# イベントID( EVT-20260815-host03-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 9→10→12→10→…→11→12→11→9
* 開始   : 2026-08-15 05:20:00 (UTC)
* 終了   : 2026-08-15 20:00:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.847, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260815-host03-003 active_connections の推移](charts/EVT-20260815-host03-003.svg)

# イベントID( EVT-20260815-host03-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→9→12→11→…→11→12→13→11
* 開始   : 2026-08-15 05:30:00 (UTC)
* 終了   : 2026-08-15 18:40:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.144, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260815-host03-004 active_connections の推移](charts/EVT-20260815-host03-004.svg)

# イベントID( EVT-20260815-host03-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 12→11→12→11→…→13→12→13→11
* 開始   : 2026-08-15 05:55:00 (UTC)
* 終了   : 2026-08-15 19:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.028, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260815-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260815-host03-005 active_connections の推移](charts/EVT-20260815-host03-005.svg)

# イベントID( EVT-20260815-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→13→…→11→13→14→12
* 開始   : 2026-08-15 06:05:00 (UTC)
* 終了   : 2026-08-15 18:30:00 (UTC)
* 現象   : 12.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.084, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.4 時間
  - EVT-20260815-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間

![EVT-20260815-host03-006 active_connections の推移](charts/EVT-20260815-host03-006.svg)

# イベントID( EVT-20260815-host03-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→12→11→13→…→13→11→14→13
* 開始   : 2026-08-15 06:30:00 (UTC)
* 終了   : 2026-08-15 19:10:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.858, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260815-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260815-host03-007 active_connections の推移](charts/EVT-20260815-host03-007.svg)

# イベントID( EVT-20260815-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 10→9→6→9→9
* 開始   : 2026-08-15 20:15:00 (UTC)
* 終了   : 2026-08-15 20:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-lsfhost01-056 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260815-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 10→11→6→9→9
* 開始   : 2026-08-16 19:55:00 (UTC)
* 終了   : 2026-08-16 19:55:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260816-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 7→7→13→9→9
* 開始   : 2026-08-16 21:45:00 (UTC)
* 終了   : 2026-08-16 21:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host01-007 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260816-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host03-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→14→15→13→…→11→15→13→12
* 開始   : 2026-08-17 02:55:00 (UTC)
* 終了   : 2026-08-17 20:15:00 (UTC)
* 現象   : 2026-08-17 20:15:00 (UTC)を境に水準が 11.82から15.06へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.846, 限界=2.703)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.492, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host03-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 14→17→15→17→…→13→14→12→10
* 開始   : 2026-08-17 03:00:00 (UTC)
* 終了   : 2026-08-17 21:10:00 (UTC)
* 現象   : 2026-08-17 21:10:00 (UTC)を境に水準が 11.8から15.03へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.931, 限界=2.706)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 9→10→14→12→12
* 開始   : 2026-08-18 03:35:00 (UTC)
* 終了   : 2026-08-18 03:35:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 21→21→16→21→19
* 開始   : 2026-08-18 14:55:00 (UTC)
* 終了   : 2026-08-18 14:55:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-040 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260818-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→13→11→14→13
* 開始   : 2026-08-18 18:45:00 (UTC)
* 終了   : 2026-08-18 18:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260818-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 10→11→6→10→9
* 開始   : 2026-08-18 21:10:00 (UTC)
* 終了   : 2026-08-18 21:10:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260818-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→10→14→10→10
* 開始   : 2026-08-19 03:05:00 (UTC)
* 終了   : 2026-08-19 03:05:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 9→12→13→11→…→11→15→12→13
* 開始   : 2026-08-19 03:45:00 (UTC)
* 終了   : 2026-08-19 03:55:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260819-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260819-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→14→19→17→16
* 開始   : 2026-08-19 06:25:00 (UTC)
* 終了   : 2026-08-19 06:25:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 19→19→22→20→19
* 開始   : 2026-08-19 08:15:00 (UTC)
* 終了   : 2026-08-19 08:15:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.134σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→17→14→16→19
* 開始   : 2026-08-19 16:35:00 (UTC)
* 終了   : 2026-08-19 16:35:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→10→6→8→9
* 開始   : 2026-08-19 22:05:00 (UTC)
* 終了   : 2026-08-19 22:05:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.019σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260819-host03-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 8→10→5→9→10
* 開始   : 2026-08-19 22:55:00 (UTC)
* 終了   : 2026-08-19 22:55:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260819-host03-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→13→19→14→16
* 開始   : 2026-08-20 06:35:00 (UTC)
* 終了   : 2026-08-20 06:35:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 16→13→10→13→14
* 開始   : 2026-08-20 18:25:00 (UTC)
* 終了   : 2026-08-20 18:25:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.6593(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.6σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260820-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host03-008 active_connections の推移](charts/EVT-20260820-host03-008.svg)

# イベントID( EVT-20260820-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→13→12→16→11→12→16→11→14
* 開始   : 2026-08-20 18:35:00 (UTC)
* 終了   : 2026-08-20 19:20:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260820-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260820-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260820-host07-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-059 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260820-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260820-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host03-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 8→10→11→10→…→10→13→11→12
* 開始   : 2026-08-22 05:05:00 (UTC)
* 終了   : 2026-08-22 18:40:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.934, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260822-host03-002 active_connections の推移](charts/EVT-20260822-host03-002.svg)

# イベントID( EVT-20260822-host03-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→10→12→11→…→13→12→16→10
* 開始   : 2026-08-22 05:15:00 (UTC)
* 終了   : 2026-08-22 18:50:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.872, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260822-host03-003 active_connections の推移](charts/EVT-20260822-host03-003.svg)

# イベントID( EVT-20260822-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 16→12→10→12→…→9→10→11→12
* 開始   : 2026-08-22 05:25:00 (UTC)
* 終了   : 2026-08-22 19:15:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.277σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.081, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260822-host03-004 active_connections の推移](charts/EVT-20260822-host03-004.svg)

# イベントID( EVT-20260822-host03-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 11→12→11→13→…→11→12→10→11
* 開始   : 2026-08-22 05:45:00 (UTC)
* 終了   : 2026-08-22 19:10:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.822, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260822-host03-005 active_connections の推移](charts/EVT-20260822-host03-005.svg)

# イベントID( EVT-20260822-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→10→12→10→…→12→11→15→12
* 開始   : 2026-08-22 05:50:00 (UTC)
* 終了   : 2026-08-22 19:10:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.775, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260822-host03-006 active_connections の推移](charts/EVT-20260822-host03-006.svg)

# イベントID( EVT-20260822-host03-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→13→12→14→…→12→11→12→11
* 開始   : 2026-08-22 05:50:00 (UTC)
* 終了   : 2026-08-22 19:30:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.015, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260822-host03-007 active_connections の推移](charts/EVT-20260822-host03-007.svg)

# イベントID( EVT-20260825-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→14→10→11→…→10→11→13→11
* 開始   : 2026-08-25 18:50:00 (UTC)
* 終了   : 2026-08-25 18:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260825-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260825-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 12→11→6→10→10
* 開始   : 2026-08-25 21:20:00 (UTC)
* 終了   : 2026-08-25 21:20:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.5414(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.574σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host08-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260825-host03-007 active_connections の推移](charts/EVT-20260825-host03-007.svg)

# イベントID( EVT-20260826-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→14→17→15→15
* 開始   : 2026-08-26 05:20:00 (UTC)
* 終了   : 2026-08-26 05:20:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260826-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 20→17→14→16→17
* 開始   : 2026-08-26 17:05:00 (UTC)
* 終了   : 2026-08-26 17:45:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260826-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260826-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host03-007 active_connections の推移](charts/EVT-20260826-host03-007.svg)

# イベントID( EVT-20260826-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→14→12→15→13→12→15→13→14
* 開始   : 2026-08-26 18:05:00 (UTC)
* 終了   : 2026-08-26 18:15:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host03-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260826-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 15→13→8→11→13
* 開始   : 2026-08-26 19:40:00 (UTC)
* 終了   : 2026-08-26 19:40:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.6(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.745σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→16→20→15→17
* 開始   : 2026-08-27 06:50:00 (UTC)
* 終了   : 2026-08-27 06:50:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 21→23→26→22→23
* 開始   : 2026-08-27 11:00:00 (UTC)
* 終了   : 2026-08-27 11:00:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260827-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 21→21→27→20→21
* 開始   : 2026-08-27 12:00:00 (UTC)
* 終了   : 2026-08-27 12:00:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.261倍(27)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.92σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260827-host03-005 active_connections の推移](charts/EVT-20260827-host03-005.svg)

# イベントID( EVT-20260827-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→12→16→12→16→12→15→14
* 開始   : 2026-08-27 18:00:00 (UTC)
* 終了   : 2026-08-27 18:10:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260827-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 7→7→12→8→9
* 開始   : 2026-08-28 00:50:00 (UTC)
* 終了   : 2026-08-28 00:50:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-004 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260828-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 10→9→11→10→…→10→14→10→8
* 開始   : 2026-08-28 02:15:00 (UTC)
* 終了   : 2026-08-28 02:25:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260828-host03-002 active_connections の推移](charts/EVT-20260828-host03-002.svg)

# イベントID( EVT-20260828-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 10→10→14→11→11
* 開始   : 2026-08-28 03:05:00 (UTC)
* 終了   : 2026-08-28 03:05:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.514倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-012 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260828-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→14→17→13→14
* 開始   : 2026-08-28 05:10:00 (UTC)
* 終了   : 2026-08-28 05:10:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.388倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.339σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→17→21→17→17
* 開始   : 2026-08-28 07:30:00 (UTC)
* 終了   : 2026-08-28 07:30:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260828-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 20→21→25→23→22
* 開始   : 2026-08-28 10:20:00 (UTC)
* 終了   : 2026-08-28 10:20:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.077σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260828-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→15→11→14→14
* 開始   : 2026-08-28 18:25:00 (UTC)
* 終了   : 2026-08-28 18:25:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host14-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260828-host03-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 14→12→11→13→…→11→14→13→11
* 開始   : 2026-08-29 04:40:00 (UTC)
* 終了   : 2026-08-29 18:05:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.7, 限界=2.665)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260829-host03-001 active_connections の推移](charts/EVT-20260829-host03-001.svg)

# イベントID( EVT-20260829-host03-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 9→11→13→10→…→11→10→13→10
* 開始   : 2026-08-29 04:45:00 (UTC)
* 終了   : 2026-08-29 18:55:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.114, 限界=2.706)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260829-host03-002 active_connections の推移](charts/EVT-20260829-host03-002.svg)

# イベントID( EVT-20260829-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→12→11→12→…→11→9→12→11
* 開始   : 2026-08-29 05:00:00 (UTC)
* 終了   : 2026-08-29 19:05:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.753, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260829-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260829-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260829-host03-003 active_connections の推移](charts/EVT-20260829-host03-003.svg)

# イベントID( EVT-20260829-host03-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 11→12→9→10→…→11→12→11→12
* 開始   : 2026-08-29 05:15:00 (UTC)
* 終了   : 2026-08-29 18:30:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.86, 限界=2.703)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260829-host03-004 active_connections の推移](charts/EVT-20260829-host03-004.svg)

# イベントID( EVT-20260829-host03-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→12→13→11→…→11→12→14→13
* 開始   : 2026-08-29 05:45:00 (UTC)
* 終了   : 2026-08-29 19:10:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.771, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260829-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260829-host03-005 active_connections の推移](charts/EVT-20260829-host03-005.svg)

# イベントID( EVT-20260829-host03-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→13→14→13→…→12→11→12→13
* 開始   : 2026-08-29 06:40:00 (UTC)
* 終了   : 2026-08-29 18:55:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.767, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host03-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host03-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host03-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260829-host03-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260829-host03-006 active_connections の推移](charts/EVT-20260829-host03-006.svg)

# イベントID( EVT-20260801-host03-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 9→10→9→11→…→11→9→12→11
* 開始   : 2026-08-01 19:20:00 (UTC)
* 終了   : 2026-08-01 19:50:00 (UTC)
* 現象   : 30分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.061, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host03-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260801-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260801-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260801-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260801-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260801-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260801-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 30 分
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分

![EVT-20260801-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host03-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 8→9→8→9→10→9→8→9→10
* 開始   : 2026-08-01 20:30:00 (UTC)
* 終了   : 2026-08-01 20:35:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.762, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260801-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→9→10→10→8→8→9→9
* 開始   : 2026-08-02 01:35:00 (UTC)
* 終了   : 2026-08-02 02:10:00 (UTC)
* 現象   : 2026-08-02 02:10:00 (UTC)を境に水準が 11.88から11.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.923, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host03-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 18→16→16→18→15→17
* 開始   : 2026-08-02 11:40:00 (UTC)
* 終了   : 2026-08-02 12:05:00 (UTC)
* 現象   : 2026-08-02 12:05:00 (UTC)を境に水準が 11.91から13.52へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.944, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host03-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→13→13→16→15→12→15
* 開始   : 2026-08-02 16:25:00 (UTC)
* 終了   : 2026-08-02 16:55:00 (UTC)
* 現象   : 2026-08-02 16:55:00 (UTC)を境に水準が 11.75から14.61へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.705, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 11→8→10→8→10→8→11
* 開始   : 2026-08-02 18:55:00 (UTC)
* 終了   : 2026-08-02 19:05:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260802-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260802-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→12→12→12→11→13→12→12
* 開始   : 2026-08-02 19:25:00 (UTC)
* 終了   : 2026-08-02 20:00:00 (UTC)
* 現象   : 2026-08-02 20:00:00 (UTC)を境に水準が 11.84から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.437, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→9→7→9→7→9→7→11→10
* 開始   : 2026-08-02 23:35:00 (UTC)
* 終了   : 2026-08-03 00:15:00 (UTC)
* 現象   : 2026-08-03 00:15:00 (UTC)を境に水準が 11.82から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 11→12→10→11→8→10→10→9
* 開始   : 2026-08-03 21:20:00 (UTC)
* 終了   : 2026-08-03 21:55:00 (UTC)
* 現象   : 2026-08-03 21:55:00 (UTC)を境に水準が 14.82から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 12→7→13→11→12→7→13→11→9
* 開始   : 2026-08-04 03:05:00 (UTC)
* 終了   : 2026-08-04 03:10:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→13→16→14→13→16→14→15
* 開始   : 2026-08-04 05:35:00 (UTC)
* 終了   : 2026-08-04 05:40:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260804-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 16→17→20→19→21→20→19→21→18
* 開始   : 2026-08-04 07:50:00 (UTC)
* 終了   : 2026-08-04 08:00:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→15→11→10→12→15→11→10→12
* 開始   : 2026-08-04 19:10:00 (UTC)
* 終了   : 2026-08-04 19:15:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260804-host04-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260804-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 13→16→17→15→13→16→17→15→14
* 開始   : 2026-08-05 05:35:00 (UTC)
* 終了   : 2026-08-05 05:40:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260805-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→16→15→13→16→15→16
* 開始   : 2026-08-05 05:45:00 (UTC)
* 終了   : 2026-08-05 05:50:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260805-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260805-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→14→17→15→…→15→18→17→15
* 開始   : 2026-08-05 06:20:00 (UTC)
* 終了   : 2026-08-05 06:30:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host03-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260805-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 22→23→23→23→23→22→23
* 開始   : 2026-08-05 11:55:00 (UTC)
* 終了   : 2026-08-05 12:25:00 (UTC)
* 現象   : 2026-08-05 12:25:00 (UTC)を境に水準が 14.99から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.558, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 18→16→19→15→16→19→15→16
* 開始   : 2026-08-05 16:30:00 (UTC)
* 終了   : 2026-08-05 16:40:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.8458(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.051σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host03-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 12→10→11→11→9→11
* 開始   : 2026-08-06 01:35:00 (UTC)
* 終了   : 2026-08-06 02:45:00 (UTC)
* 現象   : 2026-08-06 02:45:00 (UTC)を境に水準が 15から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.461, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→16→18→19→…→18→19→14→16
* 開始   : 2026-08-06 06:25:00 (UTC)
* 終了   : 2026-08-06 06:30:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260806-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 22→25→21→23→22→23→22→24
* 開始   : 2026-08-06 12:10:00 (UTC)
* 終了   : 2026-08-06 12:45:00 (UTC)
* 現象   : 2026-08-06 12:45:00 (UTC)を境に水準が 15から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.948, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 17→18→14→19→14→19→14→15→18
* 開始   : 2026-08-06 16:45:00 (UTC)
* 終了   : 2026-08-06 16:55:00 (UTC)
* 現象   : 木曜16時台の平常値(17.67)に対し 14であった
* 説明   : ALG-A1: 移動平均からの残差が 2.852σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.042σ 外れた (平常値=17.67)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260806-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 15→17→13→14→17→13→14→16
* 開始   : 2026-08-06 18:15:00 (UTC)
* 終了   : 2026-08-06 18:20:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host03-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260806-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→14→12→15→…→15→11→14→16
* 開始   : 2026-08-06 18:20:00 (UTC)
* 終了   : 2026-08-06 18:30:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host03-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host01-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 9→6→9→6→9→7
* 開始   : 2026-08-06 22:45:00 (UTC)
* 終了   : 2026-08-06 22:50:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260806-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 10→12→10→9→13→11→11
* 開始   : 2026-08-07 02:30:00 (UTC)
* 終了   : 2026-08-07 03:00:00 (UTC)
* 現象   : 2026-08-07 03:00:00 (UTC)を境に水準が 14.89から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.823, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→10→14→13→10→14→13
* 開始   : 2026-08-07 04:35:00 (UTC)
* 終了   : 2026-08-07 04:40:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host02-005 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260807-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 18→17→18→18→16→18→18→21
* 開始   : 2026-08-07 06:45:00 (UTC)
* 終了   : 2026-08-07 07:20:00 (UTC)
* 現象   : 2026-08-07 07:20:00 (UTC)を境に水準が 14.93から14.51へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 21→22→24→21→…→21→25→22→23
* 開始   : 2026-08-07 10:50:00 (UTC)
* 終了   : 2026-08-07 11:00:00 (UTC)
* 現象   : 平常時(21)に対し 1.143倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-037 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260807-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→15→14→16→15→14→16
* 開始   : 2026-08-07 17:25:00 (UTC)
* 終了   : 2026-08-07 17:30:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.344σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260807-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 13→16→17→13→…→13→10→11→12
* 開始   : 2026-08-07 19:25:00 (UTC)
* 終了   : 2026-08-07 19:35:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-074 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260807-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→9→8→7→10→9→8→7→10
* 開始   : 2026-08-07 20:50:00 (UTC)
* 終了   : 2026-08-07 20:55:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-079 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260807-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260807-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 9→10→6→9→…→9→12→11→9
* 開始   : 2026-08-08 03:00:00 (UTC)
* 終了   : 2026-08-08 03:10:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260808-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 11→10→13→12→…→12→14→11→12
* 開始   : 2026-08-09 05:00:00 (UTC)
* 終了   : 2026-08-09 05:10:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-011 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分

![EVT-20260809-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→15→17→15→17→15→16
* 開始   : 2026-08-09 09:10:00 (UTC)
* 終了   : 2026-08-09 09:15:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260809-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→15→11→14→11→14→11→13→14
* 開始   : 2026-08-09 16:20:00 (UTC)
* 終了   : 2026-08-09 16:30:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 9→8→12→9→…→9→5→10→7
* 開始   : 2026-08-09 22:30:00 (UTC)
* 終了   : 2026-08-09 22:40:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260809-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260809-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→7→11→6→…→6→5→9→7
* 開始   : 2026-08-09 23:20:00 (UTC)
* 終了   : 2026-08-09 23:30:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260809-lsfhost01-055 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260809-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 9→9→9→9→8→9
* 開始   : 2026-08-10 00:50:00 (UTC)
* 終了   : 2026-08-10 01:15:00 (UTC)
* 現象   : 2026-08-10 01:15:00 (UTC)を境に水準が 11.82から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.944, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→9→9→11→8→10→9→10→9
* 開始   : 2026-08-10 23:45:00 (UTC)
* 終了   : 2026-08-11 00:30:00 (UTC)
* 現象   : 2026-08-11 00:30:00 (UTC)を境に水準が 14.89から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.44, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→13→15→13→15→13
* 開始   : 2026-08-11 04:40:00 (UTC)
* 終了   : 2026-08-11 04:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.324倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 18→18→18→18→18→18→18→20→20
* 開始   : 2026-08-11 07:10:00 (UTC)
* 終了   : 2026-08-11 07:55:00 (UTC)
* 現象   : 2026-08-11 07:55:00 (UTC)を境に水準が 15.05から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.65, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 22→20→24→17→…→24→17→19→23
* 開始   : 2026-08-11 09:15:00 (UTC)
* 終了   : 2026-08-11 09:20:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.18倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260811-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 20→21→25→20→21→25→20→23
* 開始   : 2026-08-11 12:20:00 (UTC)
* 終了   : 2026-08-11 12:25:00 (UTC)
* 現象   : 平常時(21.33)に対し 1.172倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260811-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 20→20→19→19→17→18→19
* 開始   : 2026-08-11 16:15:00 (UTC)
* 終了   : 2026-08-11 16:45:00 (UTC)
* 現象   : 2026-08-11 16:45:00 (UTC)を境に水準が 15.11から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.383, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→14→13→15→13→15→13→14→13
* 開始   : 2026-08-11 18:10:00 (UTC)
* 終了   : 2026-08-11 18:20:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.344σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260811-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260811-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 8→12→14→11→12→14→11→13
* 開始   : 2026-08-12 04:20:00 (UTC)
* 終了   : 2026-08-12 04:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→17→16→14→17→16→15
* 開始   : 2026-08-12 05:50:00 (UTC)
* 終了   : 2026-08-12 05:55:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 18→20→19→19→20→20→22→20→22
* 開始   : 2026-08-12 08:00:00 (UTC)
* 終了   : 2026-08-12 09:00:00 (UTC)
* 現象   : 2026-08-12 09:00:00 (UTC)を境に水準が 15.04から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.75, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 14→11→10→13→14→11→10→13→12
* 開始   : 2026-08-12 19:20:00 (UTC)
* 終了   : 2026-08-12 19:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→12→9→12→9→12→11
* 開始   : 2026-08-12 19:50:00 (UTC)
* 終了   : 2026-08-12 19:55:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.7059(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.636σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260812-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 9→7→11→7→11→7→11→9
* 開始   : 2026-08-13 00:45:00 (UTC)
* 終了   : 2026-08-13 00:55:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-004 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260813-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 18→19→20→19→…→19→21→19→18
* 開始   : 2026-08-13 08:05:00 (UTC)
* 終了   : 2026-08-13 08:15:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260813-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 18→20→19→21→20→19→21→17→20
* 開始   : 2026-08-13 08:20:00 (UTC)
* 終了   : 2026-08-13 08:55:00 (UTC)
* 現象   : 35分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.051σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host03-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260813-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260813-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 35 分
  - EVT-20260813-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→20→21→20→…→22→23→20→21
* 開始   : 2026-08-13 08:40:00 (UTC)
* 終了   : 2026-08-13 08:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host03-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260813-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260813-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260813-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 19→18→16→15→18→16→15→18→17
* 開始   : 2026-08-13 16:00:00 (UTC)
* 終了   : 2026-08-13 16:05:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 18→17→14→16→…→15→14→17→16
* 開始   : 2026-08-13 16:55:00 (UTC)
* 終了   : 2026-08-13 17:15:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.902σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260813-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→16→12→15→…→15→11→12→13
* 開始   : 2026-08-13 18:05:00 (UTC)
* 終了   : 2026-08-13 18:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host03-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260813-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 14→16→12→14→16→12→14
* 開始   : 2026-08-13 18:15:00 (UTC)
* 終了   : 2026-08-13 18:20:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.766(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host03-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260813-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→9→11→9→11→9→11→10
* 開始   : 2026-08-13 20:15:00 (UTC)
* 終了   : 2026-08-13 20:25:00 (UTC)
* 現象   : 平常時(13)に対し 0.6923(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.794σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260813-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 10→6→10→6→10→8
* 開始   : 2026-08-13 22:25:00 (UTC)
* 終了   : 2026-08-13 22:30:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-host09-018 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-065 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260813-host12-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→16→17→14→17→14→17→15
* 開始   : 2026-08-14 05:50:00 (UTC)
* 終了   : 2026-08-14 06:00:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260814-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host03-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→17→17→17→18→19→19→20→19
* 開始   : 2026-08-14 07:15:00 (UTC)
* 終了   : 2026-08-14 08:10:00 (UTC)
* 現象   : 2026-08-14 08:10:00 (UTC)を境に水準が 14.94から14.35へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 22→19→24→19→24→19→22
* 開始   : 2026-08-14 12:35:00 (UTC)
* 終了   : 2026-08-14 12:45:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 21→25→24→18→25→24→18→21→23
* 開始   : 2026-08-14 12:50:00 (UTC)
* 終了   : 2026-08-14 13:00:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→18→16→21→…→21→16→19→17
* 開始   : 2026-08-14 16:15:00 (UTC)
* 終了   : 2026-08-14 16:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260814-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→15→18→15→18→15→17
* 開始   : 2026-08-14 16:35:00 (UTC)
* 終了   : 2026-08-14 16:45:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.8036(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.555σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host01-007 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260814-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260814-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host03-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→17→16→13→15→13→16→16
* 開始   : 2026-08-14 18:15:00 (UTC)
* 終了   : 2026-08-14 18:50:00 (UTC)
* 現象   : 2026-08-14 18:50:00 (UTC)を境に水準が 15.04から12.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.95, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 13→9→11→9→11→9→12→11
* 開始   : 2026-08-14 20:15:00 (UTC)
* 終了   : 2026-08-14 20:25:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.7297(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260814-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-075 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260814-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260814-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host16-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host03-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→12→8→10→8→10→8→10
* 開始   : 2026-08-14 21:15:00 (UTC)
* 終了   : 2026-08-14 21:25:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.344σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-079 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260814-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 9→10→8→7→8→10→10→9→9
* 開始   : 2026-08-15 00:10:00 (UTC)
* 終了   : 2026-08-15 01:05:00 (UTC)
* 現象   : 2026-08-15 01:05:00 (UTC)を境に水準が 15.01から11.73へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260815-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 7→5→10→9→5→10→9
* 開始   : 2026-08-16 00:55:00 (UTC)
* 終了   : 2026-08-16 01:00:00 (UTC)
* 現象   : 平常時(6.833)に対し 1.463倍(10)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→10→15→13→15→13→15→11→13
* 開始   : 2026-08-16 06:45:00 (UTC)
* 終了   : 2026-08-16 06:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.324倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.575σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 13→11→16→13→…→13→10→14→12
* 開始   : 2026-08-16 07:50:00 (UTC)
* 終了   : 2026-08-16 08:00:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260816-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260816-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→16→13→12→…→13→12→14→15
* 開始   : 2026-08-16 11:50:00 (UTC)
* 終了   : 2026-08-16 11:55:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 16→17→15→14
* 開始   : 2026-08-16 16:15:00 (UTC)
* 終了   : 2026-08-16 16:30:00 (UTC)
* 現象   : 2026-08-16 16:30:00 (UTC)を境に水準が 11.72から14.51へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host03-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 8→10→8→10→8→9→6→9→10
* 開始   : 2026-08-16 23:35:00 (UTC)
* 終了   : 2026-08-17 00:30:00 (UTC)
* 現象   : 2026-08-17 00:30:00 (UTC)を境に水準が 11.75から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.922, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 11→11→9→8→10
* 開始   : 2026-08-18 01:10:00 (UTC)
* 終了   : 2026-08-18 01:30:00 (UTC)
* 現象   : 2026-08-18 01:30:00 (UTC)を境に水準が 14.99から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.218, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 8→10→11→7→…→7→5→8→6
* 開始   : 2026-08-18 01:50:00 (UTC)
* 終了   : 2026-08-18 02:00:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260818-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 10→14→15→14→16→15→14→16→15
* 開始   : 2026-08-18 04:40:00 (UTC)
* 終了   : 2026-08-18 04:50:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260818-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 18→17→18→16→18→17→19→18→19
* 開始   : 2026-08-18 06:40:00 (UTC)
* 終了   : 2026-08-18 07:35:00 (UTC)
* 現象   : 2026-08-18 07:35:00 (UTC)を境に水準が 14.97から15.13へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.402σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→19→20→17→…→17→21→20→18
* 開始   : 2026-08-18 07:50:00 (UTC)
* 終了   : 2026-08-18 08:00:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260818-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host02-006 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260818-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 19→18→21→20→…→20→22→21→20
* 開始   : 2026-08-18 08:30:00 (UTC)
* 終了   : 2026-08-18 08:40:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 18→19→23→22→19→23→22→21
* 開始   : 2026-08-18 09:40:00 (UTC)
* 終了   : 2026-08-18 09:45:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.216倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.845σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260818-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260818-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host03-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 23→20→21→22→21→22→19→22→21
* 開始   : 2026-08-18 13:35:00 (UTC)
* 終了   : 2026-08-18 15:00:00 (UTC)
* 現象   : 2026-08-18 15:00:00 (UTC)を境に水準が 15.07から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.577, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 9→8→12→7→8→12→7→8→10
* 開始   : 2026-08-18 21:15:00 (UTC)
* 終了   : 2026-08-18 22:15:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164倍(8)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host01-014 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260818-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host09-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-071 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260818-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→14→15→15→17→15→17
* 開始   : 2026-08-19 05:35:00 (UTC)
* 終了   : 2026-08-19 06:15:00 (UTC)
* 現象   : 2026-08-19 06:15:00 (UTC)を境に水準が 14.88から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 15→12→17→15→17→15→17→15→14
* 開始   : 2026-08-19 05:55:00 (UTC)
* 終了   : 2026-08-19 06:05:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 20→19→22→20→19→22→20
* 開始   : 2026-08-19 08:45:00 (UTC)
* 終了   : 2026-08-19 08:50:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 16→20→22→20→22
* 開始   : 2026-08-19 09:05:00 (UTC)
* 終了   : 2026-08-19 09:10:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260819-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 20→19→17→16→19→17→16→19→18
* 開始   : 2026-08-19 15:15:00 (UTC)
* 終了   : 2026-08-19 15:20:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260819-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 17→15→12→14→12→14→12→15→14
* 開始   : 2026-08-19 18:15:00 (UTC)
* 終了   : 2026-08-19 18:25:00 (UTC)
* 現象   : 平常時(16)に対し 0.75(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.787σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260819-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 11→8→11→8→9→8→9→8
* 開始   : 2026-08-19 20:30:00 (UTC)
* 終了   : 2026-08-19 20:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.554σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-lsfhost01-066 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260819-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260819-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→7→12→10→7→12→9
* 開始   : 2026-08-19 21:45:00 (UTC)
* 終了   : 2026-08-19 21:50:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host08-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260819-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 13→15→17→15→17→15→17→13→15
* 開始   : 2026-08-20 05:30:00 (UTC)
* 終了   : 2026-08-20 05:40:00 (UTC)
* 現象   : 平常時(13)に対し 1.308倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.794σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260820-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→19→18→15→19→18→17
* 開始   : 2026-08-20 07:10:00 (UTC)
* 終了   : 2026-08-20 07:15:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260820-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260820-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 16→17→20→18→17→20→18→17
* 開始   : 2026-08-20 07:25:00 (UTC)
* 終了   : 2026-08-20 07:30:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.206倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260820-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host03-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 23→24→23→23→21→21→21→23
* 開始   : 2026-08-20 13:30:00 (UTC)
* 終了   : 2026-08-20 14:05:00 (UTC)
* 現象   : 2026-08-20 14:05:00 (UTC)を境に水準が 14.93から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.259, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 21→22→19→22→20→19→21→19→19
* 開始   : 2026-08-20 14:30:00 (UTC)
* 終了   : 2026-08-20 15:55:00 (UTC)
* 現象   : 2026-08-20 15:55:00 (UTC)を境に水準が 14.99から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.344σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.019, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 19→20→17→16→…→17→16→17→19
* 開始   : 2026-08-20 15:45:00 (UTC)
* 終了   : 2026-08-20 15:50:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host03-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→13→12→12→12→11→9→10→11
* 開始   : 2026-08-20 19:55:00 (UTC)
* 終了   : 2026-08-20 20:50:00 (UTC)
* 現象   : 2026-08-20 20:50:00 (UTC)を境に水準が 15.01から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host03-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 10→7→8→9→8→7→10→10→12
* 開始   : 2026-08-20 23:55:00 (UTC)
* 終了   : 2026-08-21 00:35:00 (UTC)
* 現象   : 2026-08-21 00:35:00 (UTC)を境に水準が 14.96から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.29, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 7→8→11→5→…→11→5→7→8
* 開始   : 2026-08-21 00:15:00 (UTC)
* 終了   : 2026-08-21 00:20:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260821-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 12→15→16→13→12→15→16→13
* 開始   : 2026-08-21 04:55:00 (UTC)
* 終了   : 2026-08-21 05:00:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→15→19→15→19→16
* 開始   : 2026-08-21 07:10:00 (UTC)
* 終了   : 2026-08-21 07:15:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→19→22→19→22→19→22→19
* 開始   : 2026-08-21 08:45:00 (UTC)
* 終了   : 2026-08-21 08:55:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.195倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-032 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260821-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260821-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 21→22→25→22→25→22→25→22→21
* 開始   : 2026-08-21 11:45:00 (UTC)
* 終了   : 2026-08-21 11:55:00 (UTC)
* 現象   : 平常時(21.75)に対し 1.149倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260821-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 20→18→20→18→20→18→21→19
* 開始   : 2026-08-21 14:10:00 (UTC)
* 終了   : 2026-08-21 15:25:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 18→17→16→17→…→17→15→16→17
* 開始   : 2026-08-21 16:40:00 (UTC)
* 終了   : 2026-08-21 16:50:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.8458(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260821-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-lsfhost01-049 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260821-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260821-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→12→11→14→…→11→14→11→14
* 開始   : 2026-08-21 19:05:00 (UTC)
* 終了   : 2026-08-21 19:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260821-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260821-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-071 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260821-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 10→11→8→11→…→11→7→12→11
* 開始   : 2026-08-21 20:55:00 (UTC)
* 終了   : 2026-08-21 22:10:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260821-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host06-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-077 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host11-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host01-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host08-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host03-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 9→10→8→10→11→10→8→10→11
* 開始   : 2026-08-22 04:10:00 (UTC)
* 終了   : 2026-08-22 04:15:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.952, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260822-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260822-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260822-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260822-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 11→14→13→14
* 開始   : 2026-08-23 05:50:00 (UTC)
* 終了   : 2026-08-23 06:05:00 (UTC)
* 現象   : 2026-08-23 06:05:00 (UTC)を境に水準が 11.8から12.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.461, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 15→12→18→14→15→12→18→14→15
* 開始   : 2026-08-23 12:20:00 (UTC)
* 終了   : 2026-08-23 12:25:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.344σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260823-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260823-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host03-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 17→14→12→15→14→17→14→15→16
* 開始   : 2026-08-23 14:50:00 (UTC)
* 終了   : 2026-08-23 16:05:00 (UTC)
* 現象   : 2026-08-23 16:05:00 (UTC)を境に水準が 11.8から14.46へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.881, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host03-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 8→12→9→8→9→9→11
* 開始   : 2026-08-25 00:15:00 (UTC)
* 終了   : 2026-08-25 00:45:00 (UTC)
* 現象   : 2026-08-25 00:45:00 (UTC)を境に水準が 14.92から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→12→17→14→12→17→14
* 開始   : 2026-08-25 05:40:00 (UTC)
* 終了   : 2026-08-25 05:45:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.275倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.578σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260825-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 18→20→17→20→17→20→17→19
* 開始   : 2026-08-25 07:35:00 (UTC)
* 終了   : 2026-08-25 07:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 1.2倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.343σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分

![EVT-20260825-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 17→18→15→16→18→15→16→18
* 開始   : 2026-08-25 17:05:00 (UTC)
* 終了   : 2026-08-25 17:10:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 17→14→13→15→…→15→12→16→14
* 開始   : 2026-08-25 17:50:00 (UTC)
* 終了   : 2026-08-25 18:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260825-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260825-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host03-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 9→10→9→9→11→8→10→10
* 開始   : 2026-08-25 22:35:00 (UTC)
* 終了   : 2026-08-25 23:10:00 (UTC)
* 現象   : 2026-08-25 23:10:00 (UTC)を境に水準が 14.9から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.95, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 13→15→16→14→16→14→16→15
* 開始   : 2026-08-26 05:25:00 (UTC)
* 終了   : 2026-08-26 05:35:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260826-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260826-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host03-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 25→21→23→23→21→23→22→23→24
* 開始   : 2026-08-26 12:15:00 (UTC)
* 終了   : 2026-08-26 14:20:00 (UTC)
* 現象   : 2026-08-26 14:20:00 (UTC)を境に水準が 14.98から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host03-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 21→22→25→22→25→22→25→22→21
* 開始   : 2026-08-26 12:30:00 (UTC)
* 終了   : 2026-08-26 12:40:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.186倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.728σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host03-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 20→19→17→20→…→20→16→22→19
* 開始   : 2026-08-26 15:05:00 (UTC)
* 終了   : 2026-08-26 15:15:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-046 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260826-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260826-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260826-host03-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 20→16→20→15→16→20→15→18
* 開始   : 2026-08-26 16:00:00 (UTC)
* 終了   : 2026-08-26 16:10:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.817(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260826-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host03-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 17→16→13→14→16→13→14→16
* 開始   : 2026-08-26 18:00:00 (UTC)
* 終了   : 2026-08-26 18:05:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host03-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host03-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 15→15→14→13→15
* 開始   : 2026-08-26 18:10:00 (UTC)
* 終了   : 2026-08-26 19:05:00 (UTC)
* 現象   : 2026-08-26 19:05:00 (UTC)を境に水準が 15.03から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.218, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host03-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 10→11→12→11→13→12→11→13→10
* 開始   : 2026-08-27 03:15:00 (UTC)
* 終了   : 2026-08-27 03:25:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260827-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260827-host03-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host03-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 8→13→15→10→15→10→15→12→13
* 開始   : 2026-08-27 04:15:00 (UTC)
* 終了   : 2026-08-27 04:25:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.374倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.845σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260827-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-016 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260827-host03-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host03-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 22→23→24→22→21
* 開始   : 2026-08-27 14:30:00 (UTC)
* 終了   : 2026-08-27 14:50:00 (UTC)
* 現象   : 2026-08-27 14:50:00 (UTC)を境に水準が 14.92から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.827, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host03-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 20→21→20→20→22→21→21→20→22
* 開始   : 2026-08-27 14:35:00 (UTC)
* 終了   : 2026-08-27 15:20:00 (UTC)
* 現象   : 2026-08-27 15:20:00 (UTC)を境に水準が 14.9から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.574, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 20→17→16→15→…→16→15→16→18
* 開始   : 2026-08-27 16:35:00 (UTC)
* 終了   : 2026-08-27 16:40:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260827-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host03-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 16→14→16→14→17→13→13→13→14
* 開始   : 2026-08-27 18:00:00 (UTC)
* 終了   : 2026-08-27 19:10:00 (UTC)
* 現象   : 2026-08-27 19:10:00 (UTC)を境に水準が 14.93から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.481, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host03-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host03-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 9→7→6→8→…→8→12→8→10
* 開始   : 2026-08-27 22:05:00 (UTC)
* 終了   : 2026-08-27 22:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 11→12→14→10→14→10→14→12→10
* 開始   : 2026-08-28 04:10:00 (UTC)
* 終了   : 2026-08-28 04:20:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260828-host03-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_3
* 値     : 12→14→16→17→…→14→17→15→13
* 開始   : 2026-08-28 05:30:00 (UTC)
* 終了   : 2026-08-28 05:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260828-lsfhost01-019 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260828-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host03-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 16→17→19→17→19→17
* 開始   : 2026-08-28 07:00:00 (UTC)
* 終了   : 2026-08-28 07:05:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260828-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260828-host03-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_1
* 値     : 17→19→21→18→21→18→21→20
* 開始   : 2026-08-28 08:15:00 (UTC)
* 終了   : 2026-08-28 08:25:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.206倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260828-host03-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 19→18→21→20→…→20→22→20→19
* 開始   : 2026-08-28 08:40:00 (UTC)
* 終了   : 2026-08-28 08:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.051σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host03-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 25→23→22→22→21→23→24
* 開始   : 2026-08-28 11:15:00 (UTC)
* 終了   : 2026-08-28 11:45:00 (UTC)
* 現象   : 2026-08-28 11:45:00 (UTC)を境に水準が 15.01から13.71へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.56, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host03-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_4
* 値     : 21→24→18→21→24→18→21→20
* 開始   : 2026-08-28 11:25:00 (UTC)
* 終了   : 2026-08-28 11:30:00 (UTC)
* 現象   : 平常時(21)に対し 1.143倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host03-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 21→19→24→18→…→24→18→21→19
* 開始   : 2026-08-28 14:25:00 (UTC)
* 終了   : 2026-08-28 14:30:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260828-host03-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_5
* 値     : 18→19→16→18→16→18→16→21
* 開始   : 2026-08-28 16:10:00 (UTC)
* 終了   : 2026-08-28 16:20:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-053 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-052 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260828-host03-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_2
* 値     : 15→14→11→13→11→13→11→15→11
* 開始   : 2026-08-28 18:50:00 (UTC)
* 終了   : 2026-08-28 19:00:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.7416(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.671σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host03-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host03-018 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host03, port=7003, datasource=OraclePool_6
* 値     : 14→11→10→8→10→8→11→7→8
* 開始   : 2026-08-28 21:55:00 (UTC)
* 終了   : 2026-08-28 23:20:00 (UTC)
* 現象   : 2026-08-28 23:20:00 (UTC)を境に水準が 15.06から11.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.577, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host03-018 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
