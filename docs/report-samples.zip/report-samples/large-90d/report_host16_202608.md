# host16 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host16 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 302 (SEVERE: 24, FATAL: 123, WARN: 155, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 24 | 123 | 155 | 302 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260801-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→10→11→12→…→12→9→12→11
* 開始   : 2026-08-01 05:05:00 (UTC)
* 終了   : 2026-08-01 18:45:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.809, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260801-host16-003 active_connections の推移](charts/EVT-20260801-host16-003.svg)

# イベントID( EVT-20260803-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→15→16→15→…→12→14→13→15
* 開始   : 2026-08-03 01:35:00 (UTC)
* 終了   : 2026-08-03 22:50:00 (UTC)
* 現象   : 2026-08-03 22:50:00 (UTC)を境に水準が 11.66から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.977, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host16-002 active_connections の推移](charts/EVT-20260803-host16-002.svg)

# イベントID( EVT-20260803-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→13→15→13→…→12→15→12→11
* 開始   : 2026-08-03 02:05:00 (UTC)
* 終了   : 2026-08-03 20:20:00 (UTC)
* 現象   : 2026-08-03 20:20:00 (UTC)を境に水準が 11.83から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.841, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.16, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host16-003 active_connections の推移](charts/EVT-20260803-host16-003.svg)

# イベントID( EVT-20260803-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→15→17→16→…→15→14→12→14
* 開始   : 2026-08-03 02:05:00 (UTC)
* 終了   : 2026-08-03 21:15:00 (UTC)
* 現象   : 2026-08-03 21:15:00 (UTC)を境に水準が 11.81から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.777, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.946, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host16-004 active_connections の推移](charts/EVT-20260803-host16-004.svg)

# イベントID( EVT-20260803-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→14→…→12→14→15→11
* 開始   : 2026-08-03 02:55:00 (UTC)
* 終了   : 2026-08-03 21:10:00 (UTC)
* 現象   : 2026-08-03 21:10:00 (UTC)を境に水準が 11.75から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.763σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.762, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host16-005 active_connections の推移](charts/EVT-20260803-host16-005.svg)

# イベントID( EVT-20260803-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→15→16→15→…→14→15→13→12
* 開始   : 2026-08-03 03:30:00 (UTC)
* 終了   : 2026-08-03 20:55:00 (UTC)
* 現象   : 2026-08-03 20:55:00 (UTC)を境に水準が 11.86から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.045, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.446, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host16-007 active_connections の推移](charts/EVT-20260803-host16-007.svg)

# イベントID( EVT-20260810-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→16→17→16→…→15→17→15→16
* 開始   : 2026-08-10 01:05:00 (UTC)
* 終了   : 2026-08-10 21:20:00 (UTC)
* 現象   : 2026-08-10 21:20:00 (UTC)を境に水準が 11.84から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.682σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.208, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host16-001 active_connections の推移](charts/EVT-20260810-host16-001.svg)

# イベントID( EVT-20260810-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→16→15→14→…→15→14→15→14
* 開始   : 2026-08-10 01:55:00 (UTC)
* 終了   : 2026-08-10 21:15:00 (UTC)
* 現象   : 2026-08-10 21:15:00 (UTC)を境に水準が 11.79から14.86へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.057σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.656, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.984, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host16-003 active_connections の推移](charts/EVT-20260810-host16-003.svg)

# イベントID( EVT-20260810-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→15→12→15→…→15→12→11→14
* 開始   : 2026-08-10 02:50:00 (UTC)
* 終了   : 2026-08-10 21:05:00 (UTC)
* 現象   : 2026-08-10 21:05:00 (UTC)を境に水準が 11.79から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.05, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host16-004 active_connections の推移](charts/EVT-20260810-host16-004.svg)

# イベントID( EVT-20260810-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→15→17→16→…→14→13→14→13
* 開始   : 2026-08-10 03:05:00 (UTC)
* 終了   : 2026-08-10 20:40:00 (UTC)
* 現象   : 2026-08-10 20:40:00 (UTC)を境に水準が 11.87から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.168σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.813, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.138, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host16-005 active_connections の推移](charts/EVT-20260810-host16-005.svg)

# イベントID( EVT-20260810-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 15→16→17→15→…→14→12→13→10
* 開始   : 2026-08-10 03:55:00 (UTC)
* 終了   : 2026-08-10 19:40:00 (UTC)
* 現象   : 2026-08-10 19:40:00 (UTC)を境に水準が 11.95から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.981, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host16-006 active_connections の推移](charts/EVT-20260810-host16-006.svg)

# イベントID( EVT-20260810-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→15→16→15→…→14→13→11→13
* 開始   : 2026-08-10 04:05:00 (UTC)
* 終了   : 2026-08-10 21:35:00 (UTC)
* 現象   : 2026-08-10 21:35:00 (UTC)を境に水準が 11.96から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.661, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.205, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host16-007 active_connections の推移](charts/EVT-20260810-host16-007.svg)

# イベントID( EVT-20260813-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→18→16→18→18
* 開始   : 2026-08-13 17:15:00 (UTC)
* 終了   : 2026-08-13 18:10:00 (UTC)
* 現象   : 2026-08-13 18:10:00 (UTC)を境に水準が 15から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host16-011 active_connections の推移](charts/EVT-20260813-host16-011.svg)

# イベントID( EVT-20260817-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→15→13→17→…→16→15→16→15
* 開始   : 2026-08-17 02:25:00 (UTC)
* 終了   : 2026-08-17 20:25:00 (UTC)
* 現象   : 2026-08-17 20:25:00 (UTC)を境に水準が 11.89から14.82へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.842, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.93, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host16-004 active_connections の推移](charts/EVT-20260817-host16-004.svg)

# イベントID( EVT-20260817-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→14→18→16→…→15→17→14→15
* 開始   : 2026-08-17 02:35:00 (UTC)
* 終了   : 2026-08-17 21:15:00 (UTC)
* 現象   : 2026-08-17 21:15:00 (UTC)を境に水準が 11.96から14.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.246, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host16-005 active_connections の推移](charts/EVT-20260817-host16-005.svg)

# イベントID( EVT-20260817-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→16→15→17→…→14→16→13→12
* 開始   : 2026-08-17 02:35:00 (UTC)
* 終了   : 2026-08-17 21:25:00 (UTC)
* 現象   : 2026-08-17 21:25:00 (UTC)を境に水準が 11.83から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.835, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host16-006 active_connections の推移](charts/EVT-20260817-host16-006.svg)

# イベントID( EVT-20260817-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→16→14→18→…→14→15→11→12
* 開始   : 2026-08-17 03:40:00 (UTC)
* 終了   : 2026-08-17 19:55:00 (UTC)
* 現象   : 2026-08-17 19:55:00 (UTC)を境に水準が 12から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.053σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.832, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.024, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host16-007 active_connections の推移](charts/EVT-20260817-host16-007.svg)

# イベントID( EVT-20260817-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→16→17→16→…→14→17→15→16
* 開始   : 2026-08-17 04:05:00 (UTC)
* 終了   : 2026-08-17 20:45:00 (UTC)
* 現象   : 2026-08-17 20:45:00 (UTC)を境に水準が 12.08から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.673, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.494, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host16-008 active_connections の推移](charts/EVT-20260817-host16-008.svg)

# イベントID( EVT-20260824-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→14→16→15→…→15→11→14→13
* 開始   : 2026-08-24 02:10:00 (UTC)
* 終了   : 2026-08-24 20:20:00 (UTC)
* 現象   : 2026-08-24 20:20:00 (UTC)を境に水準が 11.71から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.779, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.928, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host16-002 active_connections の推移](charts/EVT-20260824-host16-002.svg)

# イベントID( EVT-20260824-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→17→15→17→…→16→14→13→14
* 開始   : 2026-08-24 02:25:00 (UTC)
* 終了   : 2026-08-24 21:40:00 (UTC)
* 現象   : 2026-08-24 21:40:00 (UTC)を境に水準が 11.81から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.382, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.978, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host16-003 active_connections の推移](charts/EVT-20260824-host16-003.svg)

# イベントID( EVT-20260824-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→15→13→14→…→15→14→12→14
* 開始   : 2026-08-24 02:35:00 (UTC)
* 終了   : 2026-08-24 19:40:00 (UTC)
* 現象   : 2026-08-24 19:40:00 (UTC)を境に水準が 11.86から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.763σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.056, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host16-004 active_connections の推移](charts/EVT-20260824-host16-004.svg)

# イベントID( EVT-20260824-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→17→16→15→…→13→15→14→15
* 開始   : 2026-08-24 02:45:00 (UTC)
* 終了   : 2026-08-24 20:05:00 (UTC)
* 現象   : 2026-08-24 20:05:00 (UTC)を境に水準が 11.94から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.881, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host16-005 active_connections の推移](charts/EVT-20260824-host16-005.svg)

# イベントID( EVT-20260824-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→15→17→15→…→13→14→10→14
* 開始   : 2026-08-24 02:55:00 (UTC)
* 終了   : 2026-08-24 21:45:00 (UTC)
* 現象   : 2026-08-24 21:45:00 (UTC)を境に水準が 11.85から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.402σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.832, 限界=2.686)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.707, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host16-006 active_connections の推移](charts/EVT-20260824-host16-006.svg)

# イベントID( EVT-20260824-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→14→13→14→…→14→15→12→13
* 開始   : 2026-08-24 03:00:00 (UTC)
* 終了   : 2026-08-24 20:35:00 (UTC)
* 現象   : 2026-08-24 20:35:00 (UTC)を境に水準が 11.87から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.72, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.514, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host16-007 active_connections の推移](charts/EVT-20260824-host16-007.svg)

# イベントID( EVT-20260801-host16-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→11→13→9→…→10→12→10→12
* 開始   : 2026-08-01 05:20:00 (UTC)
* 終了   : 2026-08-01 18:20:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.969, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host16-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260801-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260801-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260801-host16-004 active_connections の推移](charts/EVT-20260801-host16-004.svg)

# イベントID( EVT-20260801-host16-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→9→11→12→…→12→9→14→10
* 開始   : 2026-08-01 05:35:00 (UTC)
* 終了   : 2026-08-01 18:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.132, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host16-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260801-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260801-host16-005 active_connections の推移](charts/EVT-20260801-host16-005.svg)

# イベントID( EVT-20260801-host16-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→12→9→12→…→12→11→14→11
* 開始   : 2026-08-01 05:55:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.798, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host16-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260801-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260801-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260801-host16-006 active_connections の推移](charts/EVT-20260801-host16-006.svg)

# イベントID( EVT-20260801-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→11→10→9→…→9→11→10→12
* 開始   : 2026-08-01 05:55:00 (UTC)
* 終了   : 2026-08-01 18:55:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.637σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.156, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host16-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260801-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260801-host16-007 active_connections の推移](charts/EVT-20260801-host16-007.svg)

# イベントID( EVT-20260801-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 15→13→12→13→…→10→11→12→11
* 開始   : 2026-08-01 06:35:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.766, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host16-003 (同一ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260801-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.1 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260801-host16-008 active_connections の推移](charts/EVT-20260801-host16-008.svg)

# イベントID( EVT-20260801-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→11→7→6→…→7→6→9→10
* 開始   : 2026-08-01 20:35:00 (UTC)
* 終了   : 2026-08-01 20:40:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.522σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260801-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260801-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260801-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→13→17→13→14
* 開始   : 2026-08-02 07:15:00 (UTC)
* 終了   : 2026-08-02 07:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.168σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→11→7→12→11
* 開始   : 2026-08-02 18:45:00 (UTC)
* 終了   : 2026-08-02 18:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260802-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 9→10→7→8→…→8→5→9→8
* 開始   : 2026-08-02 21:00:00 (UTC)
* 終了   : 2026-08-02 21:10:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.058σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260802-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host16-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 15→14→16→14→…→15→14→15→14
* 開始   : 2026-08-03 03:20:00 (UTC)
* 終了   : 2026-08-03 19:15:00 (UTC)
* 現象   : 2026-08-03 19:15:00 (UTC)を境に水準が 11.87から14.91へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.027, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host16-006 active_connections の推移](charts/EVT-20260803-host16-006.svg)

# イベントID( EVT-20260804-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→17→13→16→15
* 開始   : 2026-08-04 16:55:00 (UTC)
* 終了   : 2026-08-04 16:55:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260804-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→12→7→10→12
* 開始   : 2026-08-04 20:25:00 (UTC)
* 終了   : 2026-08-04 20:25:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.5915(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 9→9→10→8→10
* 開始   : 2026-08-04 23:50:00 (UTC)
* 終了   : 2026-08-05 00:30:00 (UTC)
* 現象   : 2026-08-05 00:30:00 (UTC)を境に水準が 14.92から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.081, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→19→17
* 開始   : 2026-08-05 06:15:00 (UTC)
* 終了   : 2026-08-05 06:25:00 (UTC)
* 現象   : 2026-08-05 06:25:00 (UTC)を境に水準が 14.95から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.469σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→16→20→18→16
* 開始   : 2026-08-05 06:55:00 (UTC)
* 終了   : 2026-08-05 06:55:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host16-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 18→17→20→22→…→20→22→19→18
* 開始   : 2026-08-05 07:50:00 (UTC)
* 終了   : 2026-08-05 08:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.411σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260805-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260805-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host16-006 active_connections の推移](charts/EVT-20260805-host16-006.svg)

# イベントID( EVT-20260805-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→16→12→9→11→13→13
* 開始   : 2026-08-05 19:30:00 (UTC)
* 終了   : 2026-08-05 20:00:00 (UTC)
* 現象   : 2026-08-05 20:00:00 (UTC)を境に水準が 14.92から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.435σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.514, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→7→5→8→8
* 開始   : 2026-08-05 22:15:00 (UTC)
* 終了   : 2026-08-05 22:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260805-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 21→20→16→19→21
* 開始   : 2026-08-06 14:55:00 (UTC)
* 終了   : 2026-08-06 14:55:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.7773(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 15→14→10→13→12→10→13→12→14
* 開始   : 2026-08-06 18:10:00 (UTC)
* 終了   : 2026-08-06 18:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.6283(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host01-011 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260806-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host16-005 active_connections の推移](charts/EVT-20260806-host16-005.svg)

# イベントID( EVT-20260806-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→14→10→13→14
* 開始   : 2026-08-06 19:05:00 (UTC)
* 終了   : 2026-08-06 19:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.057σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-062 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260806-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 18→19→22→21→19→22→21→19→17
* 開始   : 2026-08-07 07:45:00 (UTC)
* 終了   : 2026-08-07 07:50:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 22→20→25→22→22
* 開始   : 2026-08-07 10:10:00 (UTC)
* 終了   : 2026-08-07 10:10:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.23倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260807-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→12→10→11→12→10→11→13
* 開始   : 2026-08-07 19:00:00 (UTC)
* 終了   : 2026-08-07 19:30:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.6897(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.156σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host16-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260807-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260807-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-074 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260807-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 13→14→11→13→…→13→9→11→14
* 開始   : 2026-08-07 19:15:00 (UTC)
* 終了   : 2026-08-07 19:25:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.176σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→9→14→13→…→14→13→8→9
* 開始   : 2026-08-08 04:45:00 (UTC)
* 終了   : 2026-08-08 05:15:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.8, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260808-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260808-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260808-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260808-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260808-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260808-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260808-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host16-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→13→12→11→…→14→11→12→11
* 開始   : 2026-08-08 05:00:00 (UTC)
* 終了   : 2026-08-08 18:20:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.762, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260808-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260808-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260808-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260808-host16-002 active_connections の推移](charts/EVT-20260808-host16-002.svg)

# イベントID( EVT-20260808-host16-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→14→13→15→…→11→9→12→11
* 開始   : 2026-08-08 05:55:00 (UTC)
* 終了   : 2026-08-08 19:55:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.11, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260808-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.0 時間
  - EVT-20260808-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.0 時間

![EVT-20260808-host16-003 active_connections の推移](charts/EVT-20260808-host16-003.svg)

# イベントID( EVT-20260808-host16-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→11→12→11→…→12→11→14→11
* 開始   : 2026-08-08 06:00:00 (UTC)
* 終了   : 2026-08-08 18:40:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.725, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260808-host16-004 active_connections の推移](charts/EVT-20260808-host16-004.svg)

# イベントID( EVT-20260808-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→12→11→12→…→12→11→14→13
* 開始   : 2026-08-08 06:10:00 (UTC)
* 終了   : 2026-08-08 18:00:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.108, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260808-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間

![EVT-20260808-host16-005 active_connections の推移](charts/EVT-20260808-host16-005.svg)

# イベントID( EVT-20260808-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→11→13→12→…→13→11→14→12
* 開始   : 2026-08-08 06:20:00 (UTC)
* 終了   : 2026-08-08 19:40:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.864σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.897, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260808-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260808-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260808-host16-006 active_connections の推移](charts/EVT-20260808-host16-006.svg)

# イベントID( EVT-20260808-host16-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→12→9→13→…→8→12→10→11
* 開始   : 2026-08-08 06:25:00 (UTC)
* 終了   : 2026-08-08 19:10:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.184, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260808-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260808-host16-007 active_connections の推移](charts/EVT-20260808-host16-007.svg)

# イベントID( EVT-20260808-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 9→9→6→12→11
* 開始   : 2026-08-08 20:10:00 (UTC)
* 終了   : 2026-08-08 20:10:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-lsfhost01-054 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260808-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260808-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→14→11→16→14
* 開始   : 2026-08-09 13:45:00 (UTC)
* 終了   : 2026-08-09 13:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 13→13→9→14→15
* 開始   : 2026-08-09 16:45:00 (UTC)
* 終了   : 2026-08-09 16:45:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-041 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260809-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260809-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260809-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→7→4→9→10
* 開始   : 2026-08-10 22:45:00 (UTC)
* 終了   : 2026-08-10 22:45:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260810-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260810-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 17→17→20→18→17
* 開始   : 2026-08-11 07:00:00 (UTC)
* 終了   : 2026-08-11 07:00:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.116σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host16-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 20→19→25→23→22
* 開始   : 2026-08-11 11:00:00 (UTC)
* 終了   : 2026-08-11 11:00:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.175σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 22→19→15→19→19
* 開始   : 2026-08-11 15:20:00 (UTC)
* 終了   : 2026-08-11 15:20:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7377(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.732σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host16-009 active_connections の推移](charts/EVT-20260811-host16-009.svg)

# イベントID( EVT-20260811-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→13→8→13→11
* 開始   : 2026-08-11 19:10:00 (UTC)
* 終了   : 2026-08-11 19:10:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.5818(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host16-012 active_connections の推移](charts/EVT-20260811-host16-012.svg)

# イベントID( EVT-20260812-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→10→14→11→11
* 開始   : 2026-08-12 03:35:00 (UTC)
* 終了   : 2026-08-12 03:35:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260812-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 16→17→13→18→16
* 開始   : 2026-08-12 17:10:00 (UTC)
* 終了   : 2026-08-12 17:10:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.175σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 17→15→12→15→15
* 開始   : 2026-08-12 17:50:00 (UTC)
* 終了   : 2026-08-12 17:50:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.6957(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.668σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host16-009 active_connections の推移](charts/EVT-20260812-host16-009.svg)

# イベントID( EVT-20260812-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→13→10→13→13
* 開始   : 2026-08-12 19:05:00 (UTC)
* 終了   : 2026-08-12 19:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host13-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host13-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→14→9→13→14
* 開始   : 2026-08-12 19:10:00 (UTC)
* 終了   : 2026-08-12 19:10:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.6506(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.377σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host13-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 17→16→21→17→17
* 開始   : 2026-08-13 07:15:00 (UTC)
* 終了   : 2026-08-13 07:15:00 (UTC)
* 現象   : 平常時(16.17)に対し 1.299倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.377σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260813-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 19→18→23→20→19
* 開始   : 2026-08-13 08:25:00 (UTC)
* 終了   : 2026-08-13 08:25:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.272倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host16-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host16-005 active_connections の推移](charts/EVT-20260813-host16-005.svg)

# イベントID( EVT-20260813-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 17→18→23→22→…→23→22→20→17
* 開始   : 2026-08-13 08:35:00 (UTC)
* 終了   : 2026-08-13 08:40:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 19→21→25→19→22
* 開始   : 2026-08-13 09:40:00 (UTC)
* 終了   : 2026-08-13 09:40:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.245倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260813-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 20→22→16→21→21
* 開始   : 2026-08-13 15:10:00 (UTC)
* 終了   : 2026-08-13 15:10:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.7711(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.319σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260813-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 18→14→12→13→14→12→13→14→13
* 開始   : 2026-08-13 18:10:00 (UTC)
* 終了   : 2026-08-13 18:15:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260813-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 7→9→13→9→8
* 開始   : 2026-08-14 00:10:00 (UTC)
* 終了   : 2026-08-14 00:10:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.677倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.682σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260814-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→10→14→11→11
* 開始   : 2026-08-14 03:15:00 (UTC)
* 終了   : 2026-08-14 03:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.5倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.261σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→16→20→17→…→17→19→18→16
* 開始   : 2026-08-14 07:00:00 (UTC)
* 終了   : 2026-08-14 07:10:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 21→20→25→20→21
* 開始   : 2026-08-14 09:35:00 (UTC)
* 終了   : 2026-08-14 09:35:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.261倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.61σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-042 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260814-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-041 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host16-009 active_connections の推移](charts/EVT-20260814-host16-009.svg)

# イベントID( EVT-20260814-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 22→21→26→23→21
* 開始   : 2026-08-14 11:20:00 (UTC)
* 終了   : 2026-08-14 11:20:00 (UTC)
* 現象   : 平常時(21.25)に対し 1.224倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.351σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→15→13→14→14→13→15→14→15
* 開始   : 2026-08-14 17:55:00 (UTC)
* 終了   : 2026-08-14 19:35:00 (UTC)
* 現象   : 2026-08-14 19:35:00 (UTC)を境に水準が 14.97から12.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.595, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→14→10→13→14
* 開始   : 2026-08-14 18:50:00 (UTC)
* 終了   : 2026-08-14 18:50:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.678(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分

![EVT-20260814-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→11→8→11→12
* 開始   : 2026-08-14 20:05:00 (UTC)
* 終了   : 2026-08-14 20:05:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-074 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host16-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 7→9→4→7→9
* 開始   : 2026-08-14 23:40:00 (UTC)
* 終了   : 2026-08-14 23:40:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260814-host16-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→10→9→10→…→11→12→14→12
* 開始   : 2026-08-15 04:45:00 (UTC)
* 終了   : 2026-08-15 20:35:00 (UTC)
* 現象   : 15.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.168σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.854, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260815-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.1 時間
  - EVT-20260815-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260815-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260815-host16-002 active_connections の推移](charts/EVT-20260815-host16-002.svg)

# イベントID( EVT-20260815-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 12→10→9→11→…→10→9→10→11
* 開始   : 2026-08-15 05:20:00 (UTC)
* 終了   : 2026-08-15 20:15:00 (UTC)
* 現象   : 14.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.513σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.243, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260815-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260815-host16-003 active_connections の推移](charts/EVT-20260815-host16-003.svg)

# イベントID( EVT-20260815-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→12→10→11→…→9→10→11→13
* 開始   : 2026-08-15 05:45:00 (UTC)
* 終了   : 2026-08-15 19:20:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.884, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260815-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 13→12→9→12→…→10→9→13→14
* 開始   : 2026-08-15 05:55:00 (UTC)
* 終了   : 2026-08-15 19:30:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.234σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.797, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260815-host16-005 active_connections の推移](charts/EVT-20260815-host16-005.svg)

# イベントID( EVT-20260815-host16-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 13→12→13→14→…→10→11→12→11
* 開始   : 2026-08-15 05:55:00 (UTC)
* 終了   : 2026-08-15 19:15:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.963, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260815-host16-006 active_connections の推移](charts/EVT-20260815-host16-006.svg)

# イベントID( EVT-20260815-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→11→10→13→…→12→11→14→13
* 開始   : 2026-08-15 06:10:00 (UTC)
* 終了   : 2026-08-15 19:30:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.348, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260815-host16-007 active_connections の推移](charts/EVT-20260815-host16-007.svg)

# イベントID( EVT-20260815-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→9→4→8→6
* 開始   : 2026-08-15 23:15:00 (UTC)
* 終了   : 2026-08-15 23:15:00 (UTC)
* 現象   : 平常時(8.833)に対し 0.4528(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260815-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 9→7→13→8→8
* 開始   : 2026-08-16 03:20:00 (UTC)
* 終了   : 2026-08-16 03:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→10→6→10→9
* 開始   : 2026-08-16 20:15:00 (UTC)
* 終了   : 2026-08-16 20:15:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.5496(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.435σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260816-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 8→8→12→8→7
* 開始   : 2026-08-16 23:55:00 (UTC)
* 終了   : 2026-08-16 23:55:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→6→12→8→10
* 開始   : 2026-08-17 00:45:00 (UTC)
* 終了   : 2026-08-17 00:45:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260817-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host16-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→16→19→16→…→15→14→12→14
* 開始   : 2026-08-17 02:05:00 (UTC)
* 終了   : 2026-08-17 19:35:00 (UTC)
* 現象   : 2026-08-17 19:35:00 (UTC)を境に水準が 11.81から15.01へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.883, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 18→17→22→19→19
* 開始   : 2026-08-18 08:05:00 (UTC)
* 終了   : 2026-08-18 08:05:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 22→18→26→22→18→26→22→21
* 開始   : 2026-08-18 12:00:00 (UTC)
* 終了   : 2026-08-18 12:05:00 (UTC)
* 現象   : 火曜12時台の平常値(22.08)に対し 18であった
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.108σ 外れた (平常値=22.08)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260818-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260818-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 18→20→18→19→18→19→19→18→19
* 開始   : 2026-08-18 16:10:00 (UTC)
* 終了   : 2026-08-18 17:30:00 (UTC)
* 現象   : 2026-08-18 17:30:00 (UTC)を境に水準が 14.86から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.974σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→8→11→6→8→11→6→9→10
* 開始   : 2026-08-18 20:50:00 (UTC)
* 終了   : 2026-08-18 21:00:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260818-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260818-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→10→6→9→10
* 開始   : 2026-08-18 21:15:00 (UTC)
* 終了   : 2026-08-18 21:15:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.5669(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 13→14→19→16→17
* 開始   : 2026-08-19 05:55:00 (UTC)
* 終了   : 2026-08-19 05:55:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.373倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.615σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260819-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host16-004 active_connections の推移](charts/EVT-20260819-host16-004.svg)

# イベントID( EVT-20260819-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 18→19→12→14→17
* 開始   : 2026-08-19 17:35:00 (UTC)
* 終了   : 2026-08-19 17:35:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7164(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host16-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→13→10→12→14
* 開始   : 2026-08-19 18:50:00 (UTC)
* 終了   : 2026-08-19 18:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→13→10→11→13→10→11→13→12
* 開始   : 2026-08-19 19:15:00 (UTC)
* 終了   : 2026-08-19 19:20:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host16-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260819-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260819-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 22→22→26→20→22
* 開始   : 2026-08-20 11:50:00 (UTC)
* 終了   : 2026-08-20 11:50:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260820-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 20→16→17→20→16→17
* 開始   : 2026-08-20 15:30:00 (UTC)
* 終了   : 2026-08-20 15:35:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.116σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260820-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→12→7→9→10
* 開始   : 2026-08-20 20:20:00 (UTC)
* 終了   : 2026-08-20 20:20:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.5676(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.732σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host16-009 active_connections の推移](charts/EVT-20260820-host16-009.svg)

# イベントID( EVT-20260820-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→10→5→11→7
* 開始   : 2026-08-20 22:15:00 (UTC)
* 終了   : 2026-08-20 22:15:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.5128(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260820-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 22→22→18→20→22
* 開始   : 2026-08-21 13:40:00 (UTC)
* 終了   : 2026-08-21 13:40:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.803(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→19→20→19→18→18→18→18→18
* 開始   : 2026-08-21 16:00:00 (UTC)
* 終了   : 2026-08-21 18:25:00 (UTC)
* 現象   : 2026-08-21 18:25:00 (UTC)を境に水準が 14.93から12.46へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.615σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host16-005 active_connections の推移](charts/EVT-20260821-host16-005.svg)

# イベントID( EVT-20260821-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 17→15→11→16→14
* 開始   : 2026-08-21 18:05:00 (UTC)
* 終了   : 2026-08-21 18:05:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.6735(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.726σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host16-006 active_connections の推移](charts/EVT-20260821-host16-006.svg)

# イベントID( EVT-20260821-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 8→9→5→8→9
* 開始   : 2026-08-21 22:40:00 (UTC)
* 終了   : 2026-08-21 22:40:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host12-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-080 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260821-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host16-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→12→13→12→…→11→12→11→12
* 開始   : 2026-08-22 04:55:00 (UTC)
* 終了   : 2026-08-22 18:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.927, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260822-host16-001 active_connections の推移](charts/EVT-20260822-host16-001.svg)

# イベントID( EVT-20260822-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→12→10→12→…→10→11→13→12
* 開始   : 2026-08-22 05:10:00 (UTC)
* 終了   : 2026-08-22 18:30:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.129, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260822-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260822-host16-002 active_connections の推移](charts/EVT-20260822-host16-002.svg)

# イベントID( EVT-20260822-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→10→11→12→…→14→11→14→12
* 開始   : 2026-08-22 05:10:00 (UTC)
* 終了   : 2026-08-22 19:35:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.213σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.327, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260822-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260822-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260822-host16-003 active_connections の推移](charts/EVT-20260822-host16-003.svg)

# イベントID( EVT-20260822-host16-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→11→13→11→…→11→9→13→9
* 開始   : 2026-08-22 05:35:00 (UTC)
* 終了   : 2026-08-22 19:10:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.763, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260822-host16-004 active_connections の推移](charts/EVT-20260822-host16-004.svg)

# イベントID( EVT-20260822-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→10→11→10→…→12→11→12→11
* 開始   : 2026-08-22 05:50:00 (UTC)
* 終了   : 2026-08-22 19:30:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.959, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260822-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260822-host16-005 active_connections の推移](charts/EVT-20260822-host16-005.svg)

# イベントID( EVT-20260822-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→10→13→14→…→9→11→12→10
* 開始   : 2026-08-22 06:00:00 (UTC)
* 終了   : 2026-08-22 19:55:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.734, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host16-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host16-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260822-host16-006 active_connections の推移](charts/EVT-20260822-host16-006.svg)

# イベントID( EVT-20260823-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 9→8→5→10→…→10→13→10→9
* 開始   : 2026-08-23 02:15:00 (UTC)
* 終了   : 2026-08-23 02:25:00 (UTC)
* 現象   : 日曜2時台の平常値(8.818)に対し 5であった
* 説明   : ALG-A1: 移動平均からの残差が 2.176σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.087σ 外れた (平常値=8.818)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-006 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260823-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260823-lsfhost01-007 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260823-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host16-001 active_connections の推移](charts/EVT-20260823-host16-001.svg)

# イベントID( EVT-20260823-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→15→19→15→14
* 開始   : 2026-08-23 09:25:00 (UTC)
* 終了   : 2026-08-23 09:25:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.175σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host16-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 13→13→9→12→13
* 開始   : 2026-08-23 17:10:00 (UTC)
* 終了   : 2026-08-23 17:10:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260823-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→13→9→13→12
* 開始   : 2026-08-23 17:40:00 (UTC)
* 終了   : 2026-08-23 17:40:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→11→6→11→9
* 開始   : 2026-08-23 20:00:00 (UTC)
* 終了   : 2026-08-23 20:00:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.5255(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.79σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260823-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 8→6→4→12→…→4→12→8→7
* 開始   : 2026-08-24 01:45:00 (UTC)
* 終了   : 2026-08-24 01:50:00 (UTC)
* 現象   : 平常時(7.667)に対し 0.5217(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260824-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→18→21→18→17
* 開始   : 2026-08-25 07:25:00 (UTC)
* 終了   : 2026-08-25 07:25:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-029 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 20→17→23→19→21
* 開始   : 2026-08-25 08:55:00 (UTC)
* 終了   : 2026-08-25 08:55:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260825-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260825-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 9→10→6→12→10
* 開始   : 2026-08-25 20:50:00 (UTC)
* 終了   : 2026-08-25 20:50:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.5414(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.587σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-076 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host16-009 active_connections の推移](charts/EVT-20260825-host16-009.svg)

# イベントID( EVT-20260825-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→10→5→8→10
* 開始   : 2026-08-25 22:05:00 (UTC)
* 終了   : 2026-08-25 22:05:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 8→9→12→8→7
* 開始   : 2026-08-26 01:40:00 (UTC)
* 終了   : 2026-08-26 01:40:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 17→18→22→18→19
* 開始   : 2026-08-26 08:15:00 (UTC)
* 終了   : 2026-08-26 08:15:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.263倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 23→24→18→20→22
* 開始   : 2026-08-26 13:15:00 (UTC)
* 終了   : 2026-08-26 13:15:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 20→21→16→22→21
* 開始   : 2026-08-27 15:10:00 (UTC)
* 終了   : 2026-08-27 15:10:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260827-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 19→20→14→19→18
* 開始   : 2026-08-27 16:05:00 (UTC)
* 終了   : 2026-08-27 16:05:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.7273(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.674σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host16-012 active_connections の推移](charts/EVT-20260827-host16-012.svg)

# イベントID( EVT-20260827-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 18→19→14→17→17
* 開始   : 2026-08-27 16:40:00 (UTC)
* 終了   : 2026-08-27 16:40:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.7467(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.344σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260827-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→13→19→16→18
* 開始   : 2026-08-28 06:20:00 (UTC)
* 終了   : 2026-08-28 06:20:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260828-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→17→20→15→17
* 開始   : 2026-08-28 07:00:00 (UTC)
* 終了   : 2026-08-28 07:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260828-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 17→15→20→18→17
* 開始   : 2026-08-28 07:00:00 (UTC)
* 終了   : 2026-08-28 07:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260828-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 24→20→18→22→24
* 開始   : 2026-08-28 12:40:00 (UTC)
* 終了   : 2026-08-28 12:40:00 (UTC)
* 現象   : 平常時(22.58)に対し 0.797(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260828-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→15→12→15→15
* 開始   : 2026-08-28 17:35:00 (UTC)
* 終了   : 2026-08-28 17:35:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.72(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.261σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 13→10→11→13→10→11
* 開始   : 2026-08-28 18:15:00 (UTC)
* 終了   : 2026-08-28 20:05:00 (UTC)
* 現象   : 平常時(16)に対し 0.6875(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260828-host16-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host14-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260828-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host03-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260828-host16-012 active_connections の推移](charts/EVT-20260828-host16-012.svg)

# イベントID( EVT-20260829-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 13→12→11→9→…→13→14→12→11
* 開始   : 2026-08-29 05:05:00 (UTC)
* 終了   : 2026-08-29 20:15:00 (UTC)
* 現象   : 15.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.73, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260829-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260829-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260829-host16-003 active_connections の推移](charts/EVT-20260829-host16-003.svg)

# イベントID( EVT-20260829-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→10→9→11→…→11→10→13→11
* 開始   : 2026-08-29 05:20:00 (UTC)
* 終了   : 2026-08-29 19:50:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.344σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.891, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260829-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260829-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260829-host16-004 active_connections の推移](charts/EVT-20260829-host16-004.svg)

# イベントID( EVT-20260829-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 10→12→9→11→…→12→11→12→13
* 開始   : 2026-08-29 05:50:00 (UTC)
* 終了   : 2026-08-29 19:40:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.043, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260829-host16-005 active_connections の推移](charts/EVT-20260829-host16-005.svg)

# イベントID( EVT-20260829-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→11→14→11→…→10→11→10→12
* 開始   : 2026-08-29 06:05:00 (UTC)
* 終了   : 2026-08-29 20:00:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.737σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.737, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-lsfhost01-037 (他ホスト) lsf_queue / run : FATAL / 重なり 13.9 時間

![EVT-20260829-host16-006 active_connections の推移](charts/EVT-20260829-host16-006.svg)

# イベントID( EVT-20260829-host16-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→12→…→12→11→14→11
* 開始   : 2026-08-29 06:05:00 (UTC)
* 終了   : 2026-08-29 18:35:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.124, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host16-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260829-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260829-host16-007 active_connections の推移](charts/EVT-20260829-host16-007.svg)

# イベントID( EVT-20260829-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 10→11→10→12→…→11→14→12→11
* 開始   : 2026-08-29 06:20:00 (UTC)
* 終了   : 2026-08-29 18:15:00 (UTC)
* 現象   : 11.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 4.233σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.151, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host16-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host16-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host16-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間

![EVT-20260829-host16-008 active_connections の推移](charts/EVT-20260829-host16-008.svg)

# イベントID( EVT-20260801-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 8→12→13→12→8→12→13→12→8
* 開始   : 2026-08-01 03:05:00 (UTC)
* 終了   : 2026-08-01 03:10:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260801-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260801-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host16-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 8→7→8→9→…→8→9→11→9
* 開始   : 2026-08-01 03:50:00 (UTC)
* 終了   : 2026-08-01 03:55:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.847, 限界=2.686)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260801-lsfhost01-008 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260801-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260801-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 8→9→6→10→6→10→6→10→8
* 開始   : 2026-08-02 01:00:00 (UTC)
* 終了   : 2026-08-02 01:10:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-lsfhost01-002 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260802-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→7→11→10→…→10→12→10→11
* 開始   : 2026-08-02 03:25:00 (UTC)
* 終了   : 2026-08-02 03:35:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260802-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260802-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260802-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→9→7→10→7→10→7→12→9
* 開始   : 2026-08-02 20:00:00 (UTC)
* 終了   : 2026-08-02 20:10:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.6667(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260802-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host16-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 9→9→8→10→7→10→8→9→9
* 開始   : 2026-08-02 22:25:00 (UTC)
* 終了   : 2026-08-02 23:20:00 (UTC)
* 現象   : 2026-08-02 23:20:00 (UTC)を境に水準が 11.73から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.361, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 8→4→11→9→8→4→11→9→8
* 開始   : 2026-08-03 00:15:00 (UTC)
* 終了   : 2026-08-03 00:20:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.4898(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.911σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260803-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→9→7→6→7→6→11→7
* 開始   : 2026-08-03 21:50:00 (UTC)
* 終了   : 2026-08-03 22:00:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260803-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→10→9→9→11→9→7→9→9
* 開始   : 2026-08-04 00:25:00 (UTC)
* 終了   : 2026-08-04 01:15:00 (UTC)
* 現象   : 2026-08-04 01:15:00 (UTC)を境に水準が 15.03から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.251, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→13→16→11→16→11→16→12→14
* 開始   : 2026-08-04 04:55:00 (UTC)
* 終了   : 2026-08-04 05:05:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.446σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host16-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 15→13→12→13→16→14→14
* 開始   : 2026-08-04 04:55:00 (UTC)
* 終了   : 2026-08-04 05:25:00 (UTC)
* 現象   : 2026-08-04 05:25:00 (UTC)を境に水準が 14.91から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 22→21→21→23→20→22→22→22
* 開始   : 2026-08-04 14:40:00 (UTC)
* 終了   : 2026-08-04 15:45:00 (UTC)
* 現象   : 2026-08-04 15:45:00 (UTC)を境に水準が 14.99から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 24→22→18→22→19→18→18→18→19
* 開始   : 2026-08-04 14:50:00 (UTC)
* 終了   : 2026-08-04 17:15:00 (UTC)
* 現象   : 2026-08-04 17:15:00 (UTC)を境に水準が 15から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.988, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→15→12→13→…→13→11→13→14
* 開始   : 2026-08-04 18:25:00 (UTC)
* 終了   : 2026-08-04 18:35:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260804-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260804-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260804-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→12→9→10→12→9→10→11
* 開始   : 2026-08-04 19:55:00 (UTC)
* 終了   : 2026-08-04 20:00:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260804-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→13→9→12→9→12→9→14→10
* 開始   : 2026-08-04 20:10:00 (UTC)
* 終了   : 2026-08-04 20:20:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.7297(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260804-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 12→11→8→12→11→8→12→10
* 開始   : 2026-08-04 20:30:00 (UTC)
* 終了   : 2026-08-04 20:35:00 (UTC)
* 現象   : 平常時(11.5)に対し 0.6957(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.464σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host16-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 9→8→8→9→12→9→8→9→10
* 開始   : 2026-08-04 23:30:00 (UTC)
* 終了   : 2026-08-05 00:15:00 (UTC)
* 現象   : 2026-08-05 00:15:00 (UTC)を境に水準が 15.07から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→8→6→8→…→8→12→6→10
* 開始   : 2026-08-05 02:00:00 (UTC)
* 終了   : 2026-08-05 02:10:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260805-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 13→10→14→15→…→14→15→12→13
* 開始   : 2026-08-05 04:30:00 (UTC)
* 終了   : 2026-08-05 04:35:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分

![EVT-20260805-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 17→19→16→19→…→17→16→19→17
* 開始   : 2026-08-05 06:10:00 (UTC)
* 終了   : 2026-08-05 07:25:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.346σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 1.0 時間
  - EVT-20260805-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260805-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260805-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 22→21→24→18→…→18→21→24→21
* 開始   : 2026-08-05 10:25:00 (UTC)
* 終了   : 2026-08-05 10:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260805-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host16-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 22→21→20→22→24→24→21→20→22
* 開始   : 2026-08-05 13:50:00 (UTC)
* 終了   : 2026-08-05 14:35:00 (UTC)
* 現象   : 2026-08-05 14:35:00 (UTC)を境に水準が 15.04から15.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 19→18→16→17→16→17→16→19
* 開始   : 2026-08-05 16:15:00 (UTC)
* 終了   : 2026-08-05 16:25:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.817(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 18→18→18→16→17
* 開始   : 2026-08-05 16:55:00 (UTC)
* 終了   : 2026-08-05 17:15:00 (UTC)
* 現象   : 2026-08-05 17:15:00 (UTC)を境に水準が 15.06から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→16→14→16→14→16→14→15→14
* 開始   : 2026-08-05 17:40:00 (UTC)
* 終了   : 2026-08-05 17:50:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.8(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260805-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 14→15→13→14→15→13→14
* 開始   : 2026-08-06 04:55:00 (UTC)
* 終了   : 2026-08-06 05:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host16-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→18→17→18→15→17→16→20
* 開始   : 2026-08-06 06:15:00 (UTC)
* 終了   : 2026-08-06 06:50:00 (UTC)
* 現象   : 2026-08-06 06:50:00 (UTC)を境に水準が 15.01から15.15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.489, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 17→14→15→17→14→15→14
* 開始   : 2026-08-06 17:35:00 (UTC)
* 終了   : 2026-08-06 17:40:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7887(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.646σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260806-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→13→9→11→9→11→9→11→12
* 開始   : 2026-08-06 19:55:00 (UTC)
* 終了   : 2026-08-06 20:05:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.6792(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.974σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260806-host15-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host01-015 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260806-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host16-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→7→9→9→9→9→10→9→9
* 開始   : 2026-08-06 23:25:00 (UTC)
* 終了   : 2026-08-07 00:20:00 (UTC)
* 現象   : 2026-08-07 00:20:00 (UTC)を境に水準が 14.98から14.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host16-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→8→10→10→8→11→10→10
* 開始   : 2026-08-06 23:40:00 (UTC)
* 終了   : 2026-08-07 00:15:00 (UTC)
* 現象   : 2026-08-07 00:15:00 (UTC)を境に水準が 15.11から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.489, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→11→12→11→10→13→12→13
* 開始   : 2026-08-07 02:55:00 (UTC)
* 終了   : 2026-08-07 03:30:00 (UTC)
* 現象   : 2026-08-07 03:30:00 (UTC)を境に水準が 14.86から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.91, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→17→16→17→16→17
* 開始   : 2026-08-07 06:15:00 (UTC)
* 終了   : 2026-08-07 06:20:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-019 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 16→17→20→16→17→20→16→19
* 開始   : 2026-08-07 06:55:00 (UTC)
* 終了   : 2026-08-07 07:00:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.27倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.981σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-021 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260807-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 19→21→22→20→21→22→20
* 開始   : 2026-08-07 09:15:00 (UTC)
* 終了   : 2026-08-07 09:20:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-034 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260807-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 17→15→14→13→14→15→14→13→14
* 開始   : 2026-08-07 17:30:00 (UTC)
* 終了   : 2026-08-07 17:35:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.176σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260807-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→12→6→7→12→6→7→8
* 開始   : 2026-08-08 21:55:00 (UTC)
* 終了   : 2026-08-08 22:00:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.346σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260808-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 10→12→10→10→10→9→10→11→13
* 開始   : 2026-08-09 03:25:00 (UTC)
* 終了   : 2026-08-09 04:20:00 (UTC)
* 現象   : 2026-08-09 04:20:00 (UTC)を境に水準が 11.66から11.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.734, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→9→13→9→…→9→12→10→9
* 開始   : 2026-08-09 03:30:00 (UTC)
* 終了   : 2026-08-09 03:40:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.472倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.911σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260809-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→14→12→13→14→12→13
* 開始   : 2026-08-09 15:50:00 (UTC)
* 終了   : 2026-08-09 15:55:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260809-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→13→16→11→13→14→12→12
* 開始   : 2026-08-09 16:30:00 (UTC)
* 終了   : 2026-08-09 18:10:00 (UTC)
* 現象   : 2026-08-09 18:10:00 (UTC)を境に水準が 11.73から14.61へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.489, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host16-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→9→11→8→10
* 開始   : 2026-08-09 22:00:00 (UTC)
* 終了   : 2026-08-09 22:20:00 (UTC)
* 現象   : 2026-08-09 22:20:00 (UTC)を境に水準が 11.76から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host16-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→9→9→11→10→9→9→12
* 開始   : 2026-08-10 01:45:00 (UTC)
* 終了   : 2026-08-10 02:55:00 (UTC)
* 現象   : 2026-08-10 02:55:00 (UTC)を境に水準が 11.83から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.928, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→13→11
* 開始   : 2026-08-11 02:50:00 (UTC)
* 終了   : 2026-08-11 03:00:00 (UTC)
* 現象   : 2026-08-11 03:00:00 (UTC)を境に水準が 15.03から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.933, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→9→12→9→12→9→12
* 開始   : 2026-08-11 03:20:00 (UTC)
* 終了   : 2026-08-11 03:25:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.352σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→13→9→13→9→13→12
* 開始   : 2026-08-11 03:50:00 (UTC)
* 終了   : 2026-08-11 04:00:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260811-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260811-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→16→14→15→16→14→15
* 開始   : 2026-08-11 05:20:00 (UTC)
* 終了   : 2026-08-11 05:25:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 16→14→19→18→14→19→18→17
* 開始   : 2026-08-11 07:00:00 (UTC)
* 終了   : 2026-08-11 07:05:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 21→19→23→19→23→19→23→19→20
* 開始   : 2026-08-11 09:20:00 (UTC)
* 終了   : 2026-08-11 09:30:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260811-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 17→15→14→15→14→17→15
* 開始   : 2026-08-11 17:15:00 (UTC)
* 終了   : 2026-08-11 17:25:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-lsfhost01-048 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260811-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260811-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 14→17→13→14→15→11→14→16→13
* 開始   : 2026-08-11 18:45:00 (UTC)
* 終了   : 2026-08-11 19:25:00 (UTC)
* 現象   : 2026-08-11 19:25:00 (UTC)を境に水準が 15.09から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 11→10→8→15→…→8→15→11→9
* 開始   : 2026-08-11 20:30:00 (UTC)
* 終了   : 2026-08-11 20:35:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.6713(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.741σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host10-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260811-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 11→9→12→8→9→12→8→10
* 開始   : 2026-08-11 20:45:00 (UTC)
* 終了   : 2026-08-11 20:55:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260811-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260811-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→11→8→7→…→8→7→10→11
* 開始   : 2026-08-11 21:15:00 (UTC)
* 終了   : 2026-08-11 21:40:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host16-016 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260811-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260811-host16-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host16-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→9→7→13→…→7→11→7→8
* 開始   : 2026-08-11 21:30:00 (UTC)
* 終了   : 2026-08-11 21:55:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host16-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260811-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host16-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 12→14→15→14→15→14
* 開始   : 2026-08-12 05:10:00 (UTC)
* 終了   : 2026-08-12 05:15:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260812-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 15→14→18→16→14→18→16→15
* 開始   : 2026-08-12 06:15:00 (UTC)
* 終了   : 2026-08-12 06:20:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260812-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 18→16→20→21→20→21→18
* 開始   : 2026-08-12 07:45:00 (UTC)
* 終了   : 2026-08-12 07:55:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 21→20→21→19→20→20→22→22→22
* 開始   : 2026-08-12 08:20:00 (UTC)
* 終了   : 2026-08-12 10:05:00 (UTC)
* 現象   : 2026-08-12 10:05:00 (UTC)を境に水準が 14.9から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.503, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 21→21→21→22→22→23→21→22→24
* 開始   : 2026-08-12 09:45:00 (UTC)
* 終了   : 2026-08-12 10:40:00 (UTC)
* 現象   : 2026-08-12 10:40:00 (UTC)を境に水準が 14.98から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.361, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host16-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 17→18→17→16→17→18→18→16→17
* 開始   : 2026-08-12 17:00:00 (UTC)
* 終了   : 2026-08-12 17:45:00 (UTC)
* 現象   : 2026-08-12 17:45:00 (UTC)を境に水準が 15.07から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.41, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→11→9→8→11→9→8→11
* 開始   : 2026-08-12 20:45:00 (UTC)
* 終了   : 2026-08-12 20:50:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260812-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 9→7→12→10→12→10→12→9
* 開始   : 2026-08-13 02:40:00 (UTC)
* 終了   : 2026-08-13 02:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.426倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.522σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260813-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host16-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→17→16→18→18→18→17→21→18
* 開始   : 2026-08-13 06:05:00 (UTC)
* 終了   : 2026-08-13 07:50:00 (UTC)
* 現象   : 2026-08-13 07:50:00 (UTC)を境に水準が 14.87から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.845, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→15→19→16→15→19→16→18
* 開始   : 2026-08-13 07:05:00 (UTC)
* 終了   : 2026-08-13 07:10:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.239倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260813-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 17→20→21→18→20→21→18→19
* 開始   : 2026-08-13 08:25:00 (UTC)
* 終了   : 2026-08-13 08:30:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host16-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 19→20→24→22→24→22→24→22
* 開始   : 2026-08-13 09:45:00 (UTC)
* 終了   : 2026-08-13 09:55:00 (UTC)
* 現象   : 平常時(20)に対し 1.2倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.799σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-023 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→14→12→14→12→14
* 開始   : 2026-08-13 18:20:00 (UTC)
* 終了   : 2026-08-13 18:25:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-047 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260813-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 8→11→8→11→8→9
* 開始   : 2026-08-14 01:45:00 (UTC)
* 終了   : 2026-08-14 01:50:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→15→13→15→13→15→10→14
* 開始   : 2026-08-14 04:20:00 (UTC)
* 終了   : 2026-08-14 04:30:00 (UTC)
* 現象   : 平常時(11)に対し 1.364倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.799σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260814-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→15→17→16→…→16→18→17→15
* 開始   : 2026-08-14 06:15:00 (UTC)
* 終了   : 2026-08-14 06:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260814-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 19→21→19→21→19→17
* 開始   : 2026-08-14 08:10:00 (UTC)
* 終了   : 2026-08-14 08:15:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.411σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-037 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260814-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 20→21→17→23→21→17→23→21→19
* 開始   : 2026-08-14 09:10:00 (UTC)
* 終了   : 2026-08-14 09:15:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.053σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 23→21→22→24→21→22→22
* 開始   : 2026-08-14 10:20:00 (UTC)
* 終了   : 2026-08-14 10:50:00 (UTC)
* 現象   : 2026-08-14 10:50:00 (UTC)を境に水準が 14.86から13.64へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 23→22→21→22→22→23
* 開始   : 2026-08-14 14:30:00 (UTC)
* 終了   : 2026-08-14 15:10:00 (UTC)
* 現象   : 2026-08-14 15:10:00 (UTC)を境に水準が 14.94から12.8へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.3, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host16-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 11→9→8→13→11→9→8→13→9
* 開始   : 2026-08-14 20:25:00 (UTC)
* 終了   : 2026-08-14 20:30:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260814-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260814-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-075 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-077 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host16-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host16-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 10→9→11→10→9→11
* 開始   : 2026-08-15 04:25:00 (UTC)
* 終了   : 2026-08-15 04:30:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(10)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.768, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260815-host02-003 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260815-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260815-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 10→11→7→8→…→8→6→8→9
* 開始   : 2026-08-15 20:50:00 (UTC)
* 終了   : 2026-08-15 21:00:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260815-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260815-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→11→7→6→…→7→6→10→7
* 開始   : 2026-08-15 21:25:00 (UTC)
* 終了   : 2026-08-15 21:30:00 (UTC)
* 現象   : 平常時(10)に対し 0.7(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260815-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host16-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 8→7→11→9→10
* 開始   : 2026-08-15 23:15:00 (UTC)
* 終了   : 2026-08-15 23:35:00 (UTC)
* 現象   : 2026-08-15 23:35:00 (UTC)を境に水準が 11.81から11.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.984, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260815-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 12→13→15→13→15→13→11
* 開始   : 2026-08-16 06:05:00 (UTC)
* 終了   : 2026-08-16 06:10:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.353倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.763σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260816-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→14→15→14→15→14→16→15→18
* 開始   : 2026-08-16 08:05:00 (UTC)
* 終了   : 2026-08-16 09:20:00 (UTC)
* 現象   : 2026-08-16 09:20:00 (UTC)を境に水準が 11.71から12.73へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.855, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 11→14→12→12→11→12→12→12→12
* 開始   : 2026-08-16 18:00:00 (UTC)
* 終了   : 2026-08-16 19:15:00 (UTC)
* 現象   : 2026-08-16 19:15:00 (UTC)を境に水準が 11.88から14.73へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.582, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 13→12→14→11→11→11→11
* 開始   : 2026-08-16 18:50:00 (UTC)
* 終了   : 2026-08-16 19:20:00 (UTC)
* 現象   : 2026-08-16 19:20:00 (UTC)を境に水準が 11.83から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.377, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→11→12→11→11→11
* 開始   : 2026-08-16 20:00:00 (UTC)
* 終了   : 2026-08-16 20:25:00 (UTC)
* 現象   : 2026-08-16 20:25:00 (UTC)を境に水準が 11.88から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.683, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 9→10→6→7→5→6→7→5→10
* 開始   : 2026-08-16 22:30:00 (UTC)
* 終了   : 2026-08-16 22:40:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260816-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260816-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 8→8→9→9→9→10→10→9→10
* 開始   : 2026-08-17 00:15:00 (UTC)
* 終了   : 2026-08-17 01:00:00 (UTC)
* 現象   : 2026-08-17 01:00:00 (UTC)を境に水準が 11.91から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.138, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host16-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 9→9→11→9→10→10→9→9→10
* 開始   : 2026-08-17 21:25:00 (UTC)
* 終了   : 2026-08-17 22:30:00 (UTC)
* 現象   : 2026-08-17 22:30:00 (UTC)を境に水準が 15.01から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.754, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 8→10→11→5→8→10→11→5→8
* 開始   : 2026-08-18 00:55:00 (UTC)
* 終了   : 2026-08-18 01:00:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260818-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→11→14→12→14→12→14→11
* 開始   : 2026-08-18 03:55:00 (UTC)
* 終了   : 2026-08-18 04:05:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260818-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 13→14→15→14→15→14
* 開始   : 2026-08-18 05:05:00 (UTC)
* 終了   : 2026-08-18 05:10:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.234σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260818-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host16-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→15→13→16→16→15→15→17
* 開始   : 2026-08-18 05:05:00 (UTC)
* 終了   : 2026-08-18 05:40:00 (UTC)
* 現象   : 2026-08-18 05:40:00 (UTC)を境に水準が 14.9から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 16→17→18→17→16→17→18→17→16
* 開始   : 2026-08-18 06:15:00 (UTC)
* 終了   : 2026-08-18 06:20:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260818-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260818-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 8→5→10→12→5→10→12→8
* 開始   : 2026-08-19 02:25:00 (UTC)
* 終了   : 2026-08-19 02:35:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.5825(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.528σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260819-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 10→13→12→10→13→12
* 開始   : 2026-08-19 03:50:00 (UTC)
* 終了   : 2026-08-19 03:55:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260819-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host16-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→14→12→14→15
* 開始   : 2026-08-19 04:30:00 (UTC)
* 終了   : 2026-08-19 04:50:00 (UTC)
* 現象   : 2026-08-19 04:50:00 (UTC)を境に水準が 14.91から14.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.98, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 21→20→21→22→20
* 開始   : 2026-08-19 09:00:00 (UTC)
* 終了   : 2026-08-19 09:20:00 (UTC)
* 現象   : 2026-08-19 09:20:00 (UTC)を境に水準が 14.94から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.984, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 22→24→22→23→23→21→24→23
* 開始   : 2026-08-19 11:25:00 (UTC)
* 終了   : 2026-08-19 12:00:00 (UTC)
* 現象   : 2026-08-19 12:00:00 (UTC)を境に水準が 14.93から14.86へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.928, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host16-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 23→24→23→24→22→24
* 開始   : 2026-08-19 12:05:00 (UTC)
* 終了   : 2026-08-19 12:30:00 (UTC)
* 現象   : 2026-08-19 12:30:00 (UTC)を境に水準が 15.02から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.867, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 19→17→16→18→19→17→16→18→17
* 開始   : 2026-08-19 15:55:00 (UTC)
* 終了   : 2026-08-19 16:00:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 17→19→15→14→…→17→14→16→18
* 開始   : 2026-08-19 17:25:00 (UTC)
* 終了   : 2026-08-19 17:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host16-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→12→11→10→…→11→10→14→11
* 開始   : 2026-08-19 19:20:00 (UTC)
* 終了   : 2026-08-19 19:25:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.293σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host16-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260819-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260819-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260819-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→11→17→14→11→17→14→16
* 開始   : 2026-08-20 05:45:00 (UTC)
* 終了   : 2026-08-20 05:50:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260820-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→16→16→18→14→17→19→17
* 開始   : 2026-08-20 05:55:00 (UTC)
* 終了   : 2026-08-20 06:55:00 (UTC)
* 現象   : 2026-08-20 06:55:00 (UTC)を境に水準が 15.02から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host16-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 24→24→24→22→23→22→23→22→22
* 開始   : 2026-08-20 11:30:00 (UTC)
* 終了   : 2026-08-20 13:10:00 (UTC)
* 現象   : 2026-08-20 13:10:00 (UTC)を境に水準が 14.93から15.14へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.574, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 18→17→15→17→…→15→14→16→17
* 開始   : 2026-08-20 16:30:00 (UTC)
* 終了   : 2026-08-20 16:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host16-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-045 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260820-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 18→15→16→18→15→16→18
* 開始   : 2026-08-20 16:35:00 (UTC)
* 終了   : 2026-08-20 16:40:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.405σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host16-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→13→12→13
* 開始   : 2026-08-20 18:50:00 (UTC)
* 終了   : 2026-08-20 18:55:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-055 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260820-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→12→10→12→11→11
* 開始   : 2026-08-21 02:30:00 (UTC)
* 終了   : 2026-08-21 02:55:00 (UTC)
* 現象   : 2026-08-21 02:55:00 (UTC)を境に水準が 15.08から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host16-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 23→23→23→21→20→22→24→23→22
* 開始   : 2026-08-21 09:45:00 (UTC)
* 終了   : 2026-08-21 10:25:00 (UTC)
* 現象   : 2026-08-21 10:25:00 (UTC)を境に水準が 14.85から13.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.8, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 20→22→18→21→25→18→21→25→22
* 開始   : 2026-08-21 11:20:00 (UTC)
* 終了   : 2026-08-21 11:30:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.8372(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→11→12→6→…→12→6→9→10
* 開始   : 2026-08-22 21:45:00 (UTC)
* 終了   : 2026-08-22 21:50:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260822-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 10→14→9→10→14→9→11
* 開始   : 2026-08-23 05:05:00 (UTC)
* 終了   : 2026-08-23 05:10:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260823-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 14→16→12→16→12→16→12→15→14
* 開始   : 2026-08-23 09:25:00 (UTC)
* 終了   : 2026-08-23 09:35:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host16-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260823-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 17→15→17→16→17→15→17
* 開始   : 2026-08-23 13:25:00 (UTC)
* 終了   : 2026-08-23 13:55:00 (UTC)
* 現象   : 2026-08-23 13:55:00 (UTC)を境に水準が 11.89から13.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.514, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host16-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→8→11→10→7→9→11
* 開始   : 2026-08-24 21:50:00 (UTC)
* 終了   : 2026-08-24 22:20:00 (UTC)
* 現象   : 2026-08-24 22:20:00 (UTC)を境に水準が 14.9から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.514, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host16-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 16→19→18→16→19→18→14
* 開始   : 2026-08-25 07:05:00 (UTC)
* 終了   : 2026-08-25 07:10:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host16-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host16-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260825-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 15→18→13→19→18→13→19→18
* 開始   : 2026-08-25 07:05:00 (UTC)
* 終了   : 2026-08-25 07:10:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host16-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host16-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260825-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 16→17→19→17→19→17→15
* 開始   : 2026-08-25 07:10:00 (UTC)
* 終了   : 2026-08-25 07:15:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.352σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host16-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host16-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host16-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 23→23→22→21→24→22→21→25→23
* 開始   : 2026-08-25 12:40:00 (UTC)
* 終了   : 2026-08-25 13:30:00 (UTC)
* 現象   : 2026-08-25 13:30:00 (UTC)を境に水準が 14.93から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.423, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 17→18→15→17→18→15→17→18
* 開始   : 2026-08-25 16:25:00 (UTC)
* 終了   : 2026-08-25 16:30:00 (UTC)
* 現象   : 平常時(19)に対し 0.7895(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.822σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-lsfhost01-053 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260825-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host16-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→15→18→14→15→16→14→15
* 開始   : 2026-08-25 17:40:00 (UTC)
* 終了   : 2026-08-25 18:15:00 (UTC)
* 現象   : 2026-08-25 18:15:00 (UTC)を境に水準が 14.9から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 9→10→13→10→13→10→13→9→11
* 開始   : 2026-08-26 03:25:00 (UTC)
* 終了   : 2026-08-26 03:35:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260826-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 11→12→14→13→14→13→14→13→12
* 開始   : 2026-08-26 04:10:00 (UTC)
* 終了   : 2026-08-26 04:20:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.411σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260826-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→16→14→17→16→14→17→14→13
* 開始   : 2026-08-26 05:15:00 (UTC)
* 終了   : 2026-08-26 05:25:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.324倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.747σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260826-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260826-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260826-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host16-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 16→15→17→14→…→17→14→18→14
* 開始   : 2026-08-26 06:05:00 (UTC)
* 終了   : 2026-08-26 06:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260826-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 24→21→24→21→23→23
* 開始   : 2026-08-26 10:15:00 (UTC)
* 終了   : 2026-08-26 10:40:00 (UTC)
* 現象   : 2026-08-26 10:40:00 (UTC)を境に水準が 15.07から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.329σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.298, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→16→15→17→18→16→15→17→16
* 開始   : 2026-08-26 16:45:00 (UTC)
* 終了   : 2026-08-26 16:50:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.8458(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260826-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 17→19→15→17→19→15→17
* 開始   : 2026-08-26 17:00:00 (UTC)
* 終了   : 2026-08-26 17:05:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host08-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260826-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→11→…→12→11→14→13
* 開始   : 2026-08-26 18:40:00 (UTC)
* 終了   : 2026-08-26 18:45:00 (UTC)
* 現象   : 平常時(15)に対し 0.8(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260826-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host16-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 14→14→15→15→15→14→15
* 開始   : 2026-08-26 18:45:00 (UTC)
* 終了   : 2026-08-26 19:15:00 (UTC)
* 現象   : 2026-08-26 19:15:00 (UTC)を境に水準が 14.89から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.377, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host16-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→10→15→10→15→10→13→12
* 開始   : 2026-08-26 19:45:00 (UTC)
* 終了   : 2026-08-26 19:55:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260826-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 9→11→8→9→7→9→10→10
* 開始   : 2026-08-27 00:10:00 (UTC)
* 終了   : 2026-08-27 00:45:00 (UTC)
* 現象   : 2026-08-27 00:45:00 (UTC)を境に水準が 14.94から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host16-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 12→12→12→11→11→9→13→12→13
* 開始   : 2026-08-27 03:05:00 (UTC)
* 終了   : 2026-08-27 03:55:00 (UTC)
* 現象   : 2026-08-27 03:55:00 (UTC)を境に水準が 14.89から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.651, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→15→10→13→15→10→11
* 開始   : 2026-08-27 04:35:00 (UTC)
* 終了   : 2026-08-27 04:40:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.343倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.678σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-017 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260827-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host16-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 16→15→19→15→19→15→17
* 開始   : 2026-08-27 06:50:00 (UTC)
* 終了   : 2026-08-27 06:55:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.239倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host16-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host16-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 18→17→19→19→20→20→18→21→21
* 開始   : 2026-08-27 07:30:00 (UTC)
* 終了   : 2026-08-27 08:10:00 (UTC)
* 現象   : 2026-08-27 08:10:00 (UTC)を境に水準が 15.02から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.771, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host16-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host16-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 17→18→21→19→21→19→21→18→21
* 開始   : 2026-08-27 08:25:00 (UTC)
* 終了   : 2026-08-27 08:35:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260827-host16-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 23→22→23→20→21
* 開始   : 2026-08-27 09:10:00 (UTC)
* 終了   : 2026-08-27 09:30:00 (UTC)
* 現象   : 2026-08-27 09:30:00 (UTC)を境に水準が 14.96から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.757σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.569, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host16-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 21→20→23→20→23→20→23→22→19
* 開始   : 2026-08-27 09:30:00 (UTC)
* 終了   : 2026-08-27 09:40:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.169倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host16-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 23→22→25→22→…→22→19→22→21
* 開始   : 2026-08-27 12:20:00 (UTC)
* 終了   : 2026-08-27 12:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host16-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 21→20→18→21→20→18→21→20
* 開始   : 2026-08-27 14:40:00 (UTC)
* 終了   : 2026-08-27 14:45:00 (UTC)
* 現象   : 平常時(21.75)に対し 0.8276(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260827-host16-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 13→12→14
* 開始   : 2026-08-28 03:40:00 (UTC)
* 終了   : 2026-08-28 03:50:00 (UTC)
* 現象   : 2026-08-28 03:50:00 (UTC)を境に水準が 14.9から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.649, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 11→13→10→11→…→10→14→13→12
* 開始   : 2026-08-28 03:45:00 (UTC)
* 終了   : 2026-08-28 04:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.464σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260828-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_5
* 値     : 14→11→15→13→11→15→13→15
* 開始   : 2026-08-28 04:45:00 (UTC)
* 終了   : 2026-08-28 04:50:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260828-host16-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_1
* 値     : 18→16→20→21→…→20→21→18→19
* 開始   : 2026-08-28 07:55:00 (UTC)
* 終了   : 2026-08-28 08:00:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host16-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 18→19→16→18→14→17→16→16→15
* 開始   : 2026-08-28 17:30:00 (UTC)
* 終了   : 2026-08-28 18:15:00 (UTC)
* 現象   : 2026-08-28 18:15:00 (UTC)を境に水準が 15.06から12.17へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.138, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host16-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 15→14→12→13→…→12→11→13→12
* 開始   : 2026-08-28 18:15:00 (UTC)
* 終了   : 2026-08-28 18:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.763σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-host14-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host03-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260828-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host16-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 12→10→9→13→12→10→9→13→12
* 開始   : 2026-08-28 19:10:00 (UTC)
* 終了   : 2026-08-28 19:15:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host16-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→12→9→12→…→12→8→11→9
* 開始   : 2026-08-28 20:20:00 (UTC)
* 終了   : 2026-08-28 20:30:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260828-host16-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host16-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_3
* 値     : 10→9→11→8→9→11→8→11→10
* 開始   : 2026-08-28 20:35:00 (UTC)
* 終了   : 2026-08-28 20:45:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260828-lsfhost01-067 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260828-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host16-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host16-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_4
* 値     : 11→9→8→10→9→8→10→12→9
* 開始   : 2026-08-29 04:25:00 (UTC)
* 終了   : 2026-08-29 05:00:00 (UTC)
* 現象   : 35分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.793, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host16-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260829-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 35 分
  - EVT-20260829-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 35 分
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260829-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260829-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分

![EVT-20260829-host16-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host16-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_6
* 値     : 9→11→9→13→11→9→13→11
* 開始   : 2026-08-29 04:45:00 (UTC)
* 終了   : 2026-08-29 04:50:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(9)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.989, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host16-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260829-host16-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host16-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host16, port=7003, datasource=OraclePool_2
* 値     : 8→10→6→8→10→6→8
* 開始   : 2026-08-29 21:25:00 (UTC)
* 終了   : 2026-08-29 21:30:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.293σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-lsfhost01-080 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260829-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260829-host16-009 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
