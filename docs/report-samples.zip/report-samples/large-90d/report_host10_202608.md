# host10 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host10 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 277 (SEVERE: 19, FATAL: 126, WARN: 132, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 19 | 126 | 132 | 277 | ALG-A1, ALG-A2, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260803-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→17→…→16→14→16→15
* 開始   : 2026-08-03 02:45:00 (UTC)
* 終了   : 2026-08-03 19:45:00 (UTC)
* 現象   : 2026-08-03 19:45:00 (UTC)を境に水準が 11.86から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.885, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.072, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host10-001 active_connections の推移](charts/EVT-20260803-host10-001.svg)

# イベントID( EVT-20260803-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→19→16→18→…→12→16→14→12
* 開始   : 2026-08-03 03:05:00 (UTC)
* 終了   : 2026-08-03 22:05:00 (UTC)
* 現象   : 2026-08-03 22:05:00 (UTC)を境に水準が 11.85から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.446σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.253, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.553, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host10-002 active_connections の推移](charts/EVT-20260803-host10-002.svg)

# イベントID( EVT-20260803-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→15→14→15→…→13→14→13→12
* 開始   : 2026-08-03 03:15:00 (UTC)
* 終了   : 2026-08-03 20:05:00 (UTC)
* 現象   : 2026-08-03 20:05:00 (UTC)を境に水準が 11.91から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.817, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host10-003 active_connections の推移](charts/EVT-20260803-host10-003.svg)

# イベントID( EVT-20260803-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→17→18→19→…→12→15→11→12
* 開始   : 2026-08-03 03:25:00 (UTC)
* 終了   : 2026-08-03 21:00:00 (UTC)
* 現象   : 2026-08-03 21:00:00 (UTC)を境に水準が 11.93から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.647, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host10-004 active_connections の推移](charts/EVT-20260803-host10-004.svg)

# イベントID( EVT-20260803-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→17→19→15→…→14→13→12→11
* 開始   : 2026-08-03 03:30:00 (UTC)
* 終了   : 2026-08-03 21:15:00 (UTC)
* 現象   : 2026-08-03 21:15:00 (UTC)を境に水準が 11.85から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.16σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.801, 限界=2.673)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.74, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host10-005 active_connections の推移](charts/EVT-20260803-host10-005.svg)

# イベントID( EVT-20260803-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→14→17→14→…→14→16→13→14
* 開始   : 2026-08-03 03:35:00 (UTC)
* 終了   : 2026-08-03 19:55:00 (UTC)
* 現象   : 2026-08-03 19:55:00 (UTC)を境に水準が 11.89から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.727, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host10-006 active_connections の推移](charts/EVT-20260803-host10-006.svg)

# イベントID( EVT-20260810-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→16→15→16→…→16→14→11→13
* 開始   : 2026-08-10 01:10:00 (UTC)
* 終了   : 2026-08-10 20:10:00 (UTC)
* 現象   : 2026-08-10 20:10:00 (UTC)を境に水準が 11.8から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.328σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.721, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host10-001 active_connections の推移](charts/EVT-20260810-host10-001.svg)

# イベントID( EVT-20260810-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→16→17→16→…→12→13→12→11
* 開始   : 2026-08-10 01:25:00 (UTC)
* 終了   : 2026-08-10 20:15:00 (UTC)
* 現象   : 2026-08-10 20:15:00 (UTC)を境に水準が 11.9から14.77へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.105, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host10-002 active_connections の推移](charts/EVT-20260810-host10-002.svg)

# イベントID( EVT-20260810-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→16→…→16→13→14→12
* 開始   : 2026-08-10 02:05:00 (UTC)
* 終了   : 2026-08-10 21:05:00 (UTC)
* 現象   : 2026-08-10 21:05:00 (UTC)を境に水準が 11.7から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.714, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host10-003 active_connections の推移](charts/EVT-20260810-host10-003.svg)

# イベントID( EVT-20260810-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→13→15→13→…→13→14→13→10
* 開始   : 2026-08-10 02:25:00 (UTC)
* 終了   : 2026-08-10 20:15:00 (UTC)
* 現象   : 2026-08-10 20:15:00 (UTC)を境に水準が 11.83から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.666, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.569, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host10-004 active_connections の推移](charts/EVT-20260810-host10-004.svg)

# イベントID( EVT-20260810-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 17→16→14→15→…→14→16→12→15
* 開始   : 2026-08-10 03:25:00 (UTC)
* 終了   : 2026-08-10 20:40:00 (UTC)
* 現象   : 2026-08-10 20:40:00 (UTC)を境に水準が 11.92から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.575σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.706, 限界=2.673)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.854, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host10-006 active_connections の推移](charts/EVT-20260810-host10-006.svg)

# イベントID( EVT-20260817-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→16→15→16→…→14→16→14→13
* 開始   : 2026-08-17 02:10:00 (UTC)
* 終了   : 2026-08-17 21:45:00 (UTC)
* 現象   : 2026-08-17 21:45:00 (UTC)を境に水準が 11.87から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.982, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.448, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host10-001 active_connections の推移](charts/EVT-20260817-host10-001.svg)

# イベントID( EVT-20260817-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→16→18→14→…→13→14→12→13
* 開始   : 2026-08-17 02:15:00 (UTC)
* 終了   : 2026-08-17 20:00:00 (UTC)
* 現象   : 2026-08-17 20:00:00 (UTC)を境に水準が 11.88から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.096σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.674, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.785, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host10-002 active_connections の推移](charts/EVT-20260817-host10-002.svg)

# イベントID( EVT-20260817-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→14→15→14→…→16→15→13→12
* 開始   : 2026-08-17 02:45:00 (UTC)
* 終了   : 2026-08-17 19:15:00 (UTC)
* 現象   : 2026-08-17 19:15:00 (UTC)を境に水準が 11.85から14.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.701, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host10-003 active_connections の推移](charts/EVT-20260817-host10-003.svg)

# イベントID( EVT-20260817-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→16→15→17→…→15→14→15→14
* 開始   : 2026-08-17 03:15:00 (UTC)
* 終了   : 2026-08-17 22:05:00 (UTC)
* 現象   : 2026-08-17 22:05:00 (UTC)を境に水準が 12.04から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.872, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host10-004 active_connections の推移](charts/EVT-20260817-host10-004.svg)

# イベントID( EVT-20260817-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→16→17→16→…→15→14→16→14
* 開始   : 2026-08-17 03:15:00 (UTC)
* 終了   : 2026-08-17 21:45:00 (UTC)
* 現象   : 2026-08-17 21:45:00 (UTC)を境に水準が 11.89から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.652, 限界=2.673)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host10-005 active_connections の推移](charts/EVT-20260817-host10-005.svg)

# イベントID( EVT-20260817-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→16→17→16→…→15→14→13→14
* 開始   : 2026-08-17 03:25:00 (UTC)
* 終了   : 2026-08-17 20:25:00 (UTC)
* 現象   : 2026-08-17 20:25:00 (UTC)を境に水準が 11.82から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.789σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.876, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.897, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host10-006 active_connections の推移](charts/EVT-20260817-host10-006.svg)

# イベントID( EVT-20260824-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→15→14→18→…→12→13→12→13
* 開始   : 2026-08-24 03:30:00 (UTC)
* 終了   : 2026-08-24 20:25:00 (UTC)
* 現象   : 2026-08-24 20:25:00 (UTC)を境に水準が 11.9から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.152σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.705, 限界=2.68)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host10-006 active_connections の推移](charts/EVT-20260824-host10-006.svg)

# イベントID( EVT-20260824-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→15→16→13→…→11→14→11→14
* 開始   : 2026-08-24 03:35:00 (UTC)
* 終了   : 2026-08-24 20:15:00 (UTC)
* 現象   : 2026-08-24 20:15:00 (UTC)を境に水準が 11.9から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.749, 限界=2.677)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.85, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host10-007 active_connections の推移](charts/EVT-20260824-host10-007.svg)

# イベントID( EVT-20260801-host10-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→12→10→11→…→13→12→15→13
* 開始   : 2026-08-01 04:55:00 (UTC)
* 終了   : 2026-08-01 18:05:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.862, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260801-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260801-host10-002 active_connections の推移](charts/EVT-20260801-host10-002.svg)

# イベントID( EVT-20260801-host10-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→12→13→10→…→10→13→11→12
* 開始   : 2026-08-01 05:15:00 (UTC)
* 終了   : 2026-08-01 18:50:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.702, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260801-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260801-host10-003 active_connections の推移](charts/EVT-20260801-host10-003.svg)

# イベントID( EVT-20260801-host10-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→12→10→11→…→12→10→12→11
* 開始   : 2026-08-01 05:15:00 (UTC)
* 終了   : 2026-08-01 19:10:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.173, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260801-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.5 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260801-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260801-host10-004 active_connections の推移](charts/EVT-20260801-host10-004.svg)

# イベントID( EVT-20260801-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→11→12→11→…→12→11→12→11
* 開始   : 2026-08-01 05:20:00 (UTC)
* 終了   : 2026-08-01 18:50:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.752, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260801-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260801-host10-005 active_connections の推移](charts/EVT-20260801-host10-005.svg)

# イベントID( EVT-20260801-host10-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→12→9→13→…→11→9→11→9
* 開始   : 2026-08-01 05:45:00 (UTC)
* 終了   : 2026-08-01 19:25:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.197, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260801-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260801-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260801-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260801-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260801-host10-006 active_connections の推移](charts/EVT-20260801-host10-006.svg)

# イベントID( EVT-20260801-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→15→11→12→…→12→11→12→15
* 開始   : 2026-08-01 06:25:00 (UTC)
* 終了   : 2026-08-01 18:55:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.141, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260801-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260801-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.7 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260801-host10-007 active_connections の推移](charts/EVT-20260801-host10-007.svg)

# イベントID( EVT-20260802-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→15→20→16→13
* 開始   : 2026-08-02 10:05:00 (UTC)
* 終了   : 2026-08-02 10:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.395倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.964σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host10-003 active_connections の推移](charts/EVT-20260802-host10-003.svg)

# イベントID( EVT-20260802-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 11→11→8→14→12
* 開始   : 2026-08-02 17:30:00 (UTC)
* 終了   : 2026-08-02 17:30:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.6076(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.622σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260802-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→7→4→7→7
* 開始   : 2026-08-02 23:05:00 (UTC)
* 終了   : 2026-08-02 23:05:00 (UTC)
* 現象   : 平常時(8.833)に対し 0.4528(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.388σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260802-host10-006 active_connections の推移](charts/EVT-20260802-host10-006.svg)

# イベントID( EVT-20260804-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 21→20→24→19→…→19→17→18→22
* 開始   : 2026-08-04 15:15:00 (UTC)
* 終了   : 2026-08-04 15:55:00 (UTC)
* 現象   : 平常時(20.17)に対し 1.19倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.685σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260804-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260804-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 19→18→14→17→16
* 開始   : 2026-08-04 16:30:00 (UTC)
* 終了   : 2026-08-04 16:30:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260804-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 16→18→15→12→…→15→12→17→16
* 開始   : 2026-08-04 16:55:00 (UTC)
* 終了   : 2026-08-04 17:00:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host10-008 active_connections の推移](charts/EVT-20260804-host10-008.svg)

# イベントID( EVT-20260804-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→14→10→14→13
* 開始   : 2026-08-04 18:40:00 (UTC)
* 終了   : 2026-08-04 18:40:00 (UTC)
* 現象   : 平常時(15)に対し 0.6667(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.511σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260804-host10-009 active_connections の推移](charts/EVT-20260804-host10-009.svg)

# イベントID( EVT-20260804-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→10→9→7→…→9→7→12→14
* 開始   : 2026-08-04 20:05:00 (UTC)
* 終了   : 2026-08-04 20:10:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 8→9→6→5→8→9→6→5→8
* 開始   : 2026-08-04 22:00:00 (UTC)
* 終了   : 2026-08-04 22:05:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.6261(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→12→16→14→13
* 開始   : 2026-08-05 04:40:00 (UTC)
* 終了   : 2026-08-05 04:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 16→15→20→17→17
* 開始   : 2026-08-05 07:20:00 (UTC)
* 終了   : 2026-08-05 07:20:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 20→21→25→21→22
* 開始   : 2026-08-05 09:40:00 (UTC)
* 終了   : 2026-08-05 09:40:00 (UTC)
* 現象   : 平常時(20.25)に対し 1.235倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.33σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 22→20→17→20→…→20→18→22→20
* 開始   : 2026-08-05 14:20:00 (UTC)
* 終了   : 2026-08-05 14:30:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260805-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 19→18→19→16→20
* 開始   : 2026-08-05 16:40:00 (UTC)
* 終了   : 2026-08-05 18:05:00 (UTC)
* 現象   : 2026-08-05 18:05:00 (UTC)を境に水準が 14.95から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.426, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 16→16→13→16→19
* 開始   : 2026-08-05 17:15:00 (UTC)
* 終了   : 2026-08-05 17:15:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 21→21→24→19→21
* 開始   : 2026-08-06 08:55:00 (UTC)
* 終了   : 2026-08-06 08:55:00 (UTC)
* 現象   : 平常時(19.25)に対し 1.247倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260806-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 20→21→15→19→17
* 開始   : 2026-08-06 16:15:00 (UTC)
* 終了   : 2026-08-06 16:15:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 11→15→13→11→15→13→12
* 開始   : 2026-08-07 04:15:00 (UTC)
* 終了   : 2026-08-07 04:20:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260807-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→11→17→10→11
* 開始   : 2026-08-07 04:15:00 (UTC)
* 終了   : 2026-08-07 04:15:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.569倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260807-host10-003 active_connections の推移](charts/EVT-20260807-host10-003.svg)

# イベントID( EVT-20260807-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 19→18→22→19→23→22→19→23→19
* 開始   : 2026-08-07 08:20:00 (UTC)
* 終了   : 2026-08-07 08:30:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.228倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.867σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260807-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→9→6→8→9
* 開始   : 2026-08-07 20:55:00 (UTC)
* 終了   : 2026-08-07 20:55:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.5414(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-079 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260807-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host10-010 active_connections の推移](charts/EVT-20260807-host10-010.svg)

# イベントID( EVT-20260807-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 9→7→10→6→7→10→6→7
* 開始   : 2026-08-07 21:45:00 (UTC)
* 終了   : 2026-08-07 22:55:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942倍(7)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-083 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260807-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-084 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260807-host10-011 active_connections の推移](charts/EVT-20260807-host10-011.svg)

# イベントID( EVT-20260808-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→12→13→12→…→11→9→10→11
* 開始   : 2026-08-08 04:40:00 (UTC)
* 終了   : 2026-08-08 19:05:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.745σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.725, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260808-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260808-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260808-host10-001 active_connections の推移](charts/EVT-20260808-host10-001.svg)

# イベントID( EVT-20260808-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→10→12→10→…→14→11→12→11
* 開始   : 2026-08-08 05:05:00 (UTC)
* 終了   : 2026-08-08 18:35:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.803σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.724, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260808-host10-002 active_connections の推移](charts/EVT-20260808-host10-002.svg)

# イベントID( EVT-20260808-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 11→9→14→11→…→9→13→14→12
* 開始   : 2026-08-08 05:10:00 (UTC)
* 終了   : 2026-08-08 18:50:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.907, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260808-host10-003 active_connections の推移](charts/EVT-20260808-host10-003.svg)

# イベントID( EVT-20260808-host10-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→11→10→9→…→10→12→11→12
* 開始   : 2026-08-08 05:25:00 (UTC)
* 終了   : 2026-08-08 19:00:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.968, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260808-host10-004 active_connections の推移](charts/EVT-20260808-host10-004.svg)

# イベントID( EVT-20260808-host10-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→11→13→12→…→11→9→10→11
* 開始   : 2026-08-08 05:35:00 (UTC)
* 終了   : 2026-08-08 19:05:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.937, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260808-host10-005 active_connections の推移](charts/EVT-20260808-host10-005.svg)

# イベントID( EVT-20260808-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 16→14→12→13→…→12→15→12→11
* 開始   : 2026-08-08 05:40:00 (UTC)
* 終了   : 2026-08-08 18:55:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.026σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.948, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260808-host10-006 active_connections の推移](charts/EVT-20260808-host10-006.svg)

# イベントID( EVT-20260809-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 10→12→15→10→…→10→8→14→13
* 開始   : 2026-08-09 06:05:00 (UTC)
* 終了   : 2026-08-09 06:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260809-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260809-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260809-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260809-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→13→18→15→13
* 開始   : 2026-08-09 08:25:00 (UTC)
* 終了   : 2026-08-09 08:25:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.367倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260809-host10-005 active_connections の推移](charts/EVT-20260809-host10-005.svg)

# イベントID( EVT-20260810-host10-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→15→17→14→…→14→13→16→14
* 開始   : 2026-08-10 02:30:00 (UTC)
* 終了   : 2026-08-10 19:25:00 (UTC)
* 現象   : 2026-08-10 19:25:00 (UTC)を境に水準が 11.84から14.94へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.823, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.24, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host10-005 active_connections の推移](charts/EVT-20260810-host10-005.svg)

# イベントID( EVT-20260811-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→12→13→10→15→13→10→15→11
* 開始   : 2026-08-11 03:25:00 (UTC)
* 終了   : 2026-08-11 03:35:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host10-001 active_connections の推移](charts/EVT-20260811-host10-001.svg)

# イベントID( EVT-20260811-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→14→18→14→15
* 開始   : 2026-08-11 05:40:00 (UTC)
* 終了   : 2026-08-11 05:40:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.367倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host10-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→12→18→15→12→18→15→16
* 開始   : 2026-08-11 05:45:00 (UTC)
* 終了   : 2026-08-11 05:50:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.35倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.277σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260811-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→18→20→17→17
* 開始   : 2026-08-11 07:10:00 (UTC)
* 終了   : 2026-08-11 07:10:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→19→21→24→18→21→22→21
* 開始   : 2026-08-11 08:30:00 (UTC)
* 終了   : 2026-08-11 09:05:00 (UTC)
* 現象   : 2026-08-11 09:05:00 (UTC)を境に水準が 14.93から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.783σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 20→20→24→19→22
* 開始   : 2026-08-11 08:55:00 (UTC)
* 終了   : 2026-08-11 08:55:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.241倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 21→24→21→22→22→21→21→22→22
* 開始   : 2026-08-11 14:20:00 (UTC)
* 終了   : 2026-08-11 15:30:00 (UTC)
* 現象   : 2026-08-11 15:30:00 (UTC)を境に水準が 14.89から15.14へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.658, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→16→12→17→16
* 開始   : 2026-08-11 18:05:00 (UTC)
* 終了   : 2026-08-11 18:05:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→8→12→9→8→12→9
* 開始   : 2026-08-11 20:20:00 (UTC)
* 終了   : 2026-08-11 20:30:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host10-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 8→10→5→8→11
* 開始   : 2026-08-11 22:20:00 (UTC)
* 終了   : 2026-08-11 22:20:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host10-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 8→9→5→10→7
* 開始   : 2026-08-11 22:30:00 (UTC)
* 終了   : 2026-08-11 22:30:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host10-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→9→14→12→10
* 開始   : 2026-08-12 03:20:00 (UTC)
* 終了   : 2026-08-12 03:20:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→14→17→14→15
* 開始   : 2026-08-12 05:30:00 (UTC)
* 終了   : 2026-08-12 05:45:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260812-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 17→18→21→19→17
* 開始   : 2026-08-12 07:10:00 (UTC)
* 終了   : 2026-08-12 07:10:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.306倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host10-005 active_connections の推移](charts/EVT-20260812-host10-005.svg)

# イベントID( EVT-20260812-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→16→14→15→13→13→14→16→13
* 開始   : 2026-08-12 18:25:00 (UTC)
* 終了   : 2026-08-12 20:35:00 (UTC)
* 現象   : 2026-08-12 20:35:00 (UTC)を境に水準が 14.87から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→14→10→14→14
* 開始   : 2026-08-12 18:55:00 (UTC)
* 終了   : 2026-08-12 18:55:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.678(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host13-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→13→12→10→…→12→10→12→14
* 開始   : 2026-08-12 19:10:00 (UTC)
* 終了   : 2026-08-12 19:50:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host13-019 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260812-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260812-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→12→15→12→10
* 開始   : 2026-08-13 03:20:00 (UTC)
* 終了   : 2026-08-13 03:20:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.579倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.855σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260813-host10-001 active_connections の推移](charts/EVT-20260813-host10-001.svg)

# イベントID( EVT-20260813-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→12→17→12→14
* 開始   : 2026-08-13 05:20:00 (UTC)
* 終了   : 2026-08-13 05:20:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→10→12→12→11
* 開始   : 2026-08-13 20:20:00 (UTC)
* 終了   : 2026-08-13 21:15:00 (UTC)
* 現象   : 2026-08-13 21:15:00 (UTC)を境に水準が 14.97から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.16, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→10→15→12→12
* 開始   : 2026-08-14 04:35:00 (UTC)
* 終了   : 2026-08-14 04:35:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→12→16→14→12
* 開始   : 2026-08-14 05:05:00 (UTC)
* 終了   : 2026-08-14 05:05:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host10-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260814-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 11→9→11→12→…→12→11→10→12
* 開始   : 2026-08-15 05:15:00 (UTC)
* 終了   : 2026-08-15 18:30:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.405, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260815-host10-001 active_connections の推移](charts/EVT-20260815-host10-001.svg)

# イベントID( EVT-20260815-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→11→12→11→…→13→15→16→13
* 開始   : 2026-08-15 05:15:00 (UTC)
* 終了   : 2026-08-15 18:05:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.247, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260815-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260815-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260815-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260815-host10-002 active_connections の推移](charts/EVT-20260815-host10-002.svg)

# イベントID( EVT-20260815-host10-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→12→13→12→…→9→13→12→11
* 開始   : 2026-08-15 05:35:00 (UTC)
* 終了   : 2026-08-15 19:15:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.23, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260815-host10-003 active_connections の推移](charts/EVT-20260815-host10-003.svg)

# イベントID( EVT-20260815-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→13→…→13→10→12→10
* 開始   : 2026-08-15 06:05:00 (UTC)
* 終了   : 2026-08-15 18:55:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.222, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260815-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260815-host10-004 active_connections の推移](charts/EVT-20260815-host10-004.svg)

# イベントID( EVT-20260815-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→10→12→11→…→12→10→12→10
* 開始   : 2026-08-15 06:05:00 (UTC)
* 終了   : 2026-08-15 18:45:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.16σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.763, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260815-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260815-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260815-host10-005 active_connections の推移](charts/EVT-20260815-host10-005.svg)

# イベントID( EVT-20260815-host10-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→12→13→12→…→13→14→11→13
* 開始   : 2026-08-15 06:10:00 (UTC)
* 終了   : 2026-08-15 19:35:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.823, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260815-host10-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260815-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260815-host10-006 active_connections の推移](charts/EVT-20260815-host10-006.svg)

# イベントID( EVT-20260816-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→10→4→7→7
* 開始   : 2026-08-16 00:50:00 (UTC)
* 終了   : 2026-08-16 00:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260816-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→12→16→11→16→11→16→13
* 開始   : 2026-08-18 04:40:00 (UTC)
* 終了   : 2026-08-18 05:55:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.343倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.861σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-017 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260818-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260818-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260818-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 16→15→19→15→19→15→19→15→17
* 開始   : 2026-08-18 06:40:00 (UTC)
* 終了   : 2026-08-18 06:50:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260818-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 21→20→25→20→19
* 開始   : 2026-08-18 09:30:00 (UTC)
* 終了   : 2026-08-18 09:30:00 (UTC)
* 現象   : 平常時(19.17)に対し 1.304倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.074σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260818-host10-004 active_connections の推移](charts/EVT-20260818-host10-004.svg)

# イベントID( EVT-20260818-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 20→21→15→20→19
* 開始   : 2026-08-18 15:45:00 (UTC)
* 終了   : 2026-08-18 15:45:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.7595(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→8→13→10→8→13→10→11
* 開始   : 2026-08-19 02:15:00 (UTC)
* 終了   : 2026-08-19 02:45:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260819-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260819-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→12→15→16→…→16→15→13→15
* 開始   : 2026-08-19 04:55:00 (UTC)
* 終了   : 2026-08-19 05:05:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.685σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260819-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→13→17→15→14
* 開始   : 2026-08-19 05:25:00 (UTC)
* 終了   : 2026-08-19 05:25:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260819-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 20→21→16→20→20
* 開始   : 2026-08-19 13:50:00 (UTC)
* 終了   : 2026-08-19 13:50:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.7589(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.563σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260819-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 21→20→17→22→20
* 開始   : 2026-08-19 14:30:00 (UTC)
* 終了   : 2026-08-19 14:30:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-lsfhost01-048 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 22→20→15→19→19
* 開始   : 2026-08-19 15:20:00 (UTC)
* 終了   : 2026-08-19 15:20:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.7407(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.672σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host10-007 active_connections の推移](charts/EVT-20260819-host10-007.svg)

# イベントID( EVT-20260820-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 8→6→12→7→8
* 開始   : 2026-08-20 00:05:00 (UTC)
* 終了   : 2026-08-20 00:05:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260820-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→15→19→14→17
* 開始   : 2026-08-20 06:10:00 (UTC)
* 終了   : 2026-08-20 06:10:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.341倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→16→20→16→16
* 開始   : 2026-08-20 06:50:00 (UTC)
* 終了   : 2026-08-20 06:50:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260820-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 16→16→20→17→16
* 開始   : 2026-08-20 07:10:00 (UTC)
* 終了   : 2026-08-20 07:10:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 20→21→16→17→…→17→15→18→17
* 開始   : 2026-08-20 15:55:00 (UTC)
* 終了   : 2026-08-20 16:25:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260820-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→15→12→15→14
* 開始   : 2026-08-20 17:50:00 (UTC)
* 終了   : 2026-08-20 17:50:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→16→12→15→12→15→12→14→15
* 開始   : 2026-08-20 18:15:00 (UTC)
* 終了   : 2026-08-20 18:25:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host10-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260820-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260820-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→14→9→10→7→9→10→7→10
* 開始   : 2026-08-20 20:20:00 (UTC)
* 終了   : 2026-08-20 20:30:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host10-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host10-013 active_connections の推移](charts/EVT-20260820-host10-013.svg)

# イベントID( EVT-20260821-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 18→21→20→17→18→21→20→17→20
* 開始   : 2026-08-21 07:25:00 (UTC)
* 終了   : 2026-08-21 07:30:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.292倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 18→19→22→19→17
* 開始   : 2026-08-21 08:00:00 (UTC)
* 終了   : 2026-08-21 08:00:00 (UTC)
* 現象   : 平常時(17.42)に対し 1.263倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 22→22→17→21→23
* 開始   : 2026-08-21 11:55:00 (UTC)
* 終了   : 2026-08-21 11:55:00 (UTC)
* 現象   : 平常時(22)に対し 0.7727(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host10-005 active_connections の推移](charts/EVT-20260821-host10-005.svg)

# イベントID( EVT-20260822-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→13→12→13→…→11→12→11→12
* 開始   : 2026-08-22 04:40:00 (UTC)
* 終了   : 2026-08-22 18:30:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.211σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.912, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260822-host10-002 active_connections の推移](charts/EVT-20260822-host10-002.svg)

# イベントID( EVT-20260822-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→12→13→9→…→14→12→13→12
* 開始   : 2026-08-22 04:50:00 (UTC)
* 終了   : 2026-08-22 17:55:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.747, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260822-host10-003 active_connections の推移](charts/EVT-20260822-host10-003.svg)

# イベントID( EVT-20260822-host10-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→11→12→11→…→12→11→14→12
* 開始   : 2026-08-22 04:50:00 (UTC)
* 終了   : 2026-08-22 18:05:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.034, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260822-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260822-host10-004 active_connections の推移](charts/EVT-20260822-host10-004.svg)

# イベントID( EVT-20260822-host10-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→15→11→13→…→11→13→12→13
* 開始   : 2026-08-22 05:15:00 (UTC)
* 終了   : 2026-08-22 18:40:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.907, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260822-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260822-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260822-host10-005 active_connections の推移](charts/EVT-20260822-host10-005.svg)

# イベントID( EVT-20260822-host10-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→13→…→12→14→15→12
* 開始   : 2026-08-22 05:25:00 (UTC)
* 終了   : 2026-08-22 17:35:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.877, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260822-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260822-host10-006 active_connections の推移](charts/EVT-20260822-host10-006.svg)

# イベントID( EVT-20260822-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→11→13→12→…→12→8→13→11
* 開始   : 2026-08-22 06:00:00 (UTC)
* 終了   : 2026-08-22 19:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.914, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260822-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260822-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260822-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.6 時間
  - EVT-20260822-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260822-host10-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260822-host10-007 active_connections の推移](charts/EVT-20260822-host10-007.svg)

# イベントID( EVT-20260822-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→11→10→11→…→9→12→11→10
* 開始   : 2026-08-22 18:45:00 (UTC)
* 終了   : 2026-08-22 19:30:00 (UTC)
* 現象   : 45分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.628σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.927, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260822-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260822-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260822-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260822-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分
  - EVT-20260822-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 45 分

![EVT-20260822-host10-008 active_connections の推移](charts/EVT-20260822-host10-008.svg)

# イベントID( EVT-20260823-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 8→9→12→9→7
* 開始   : 2026-08-23 01:30:00 (UTC)
* 終了   : 2026-08-23 01:30:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260823-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→14→17→12→13
* 開始   : 2026-08-23 06:45:00 (UTC)
* 終了   : 2026-08-23 06:45:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.378倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260823-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 11→12→16→15→…→15→18→12→14
* 開始   : 2026-08-23 07:45:00 (UTC)
* 終了   : 2026-08-23 07:55:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260823-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→14→18→13→14
* 開始   : 2026-08-23 08:25:00 (UTC)
* 終了   : 2026-08-23 08:25:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260823-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 16→12→18→14→16→12→18→14→17
* 開始   : 2026-08-23 13:00:00 (UTC)
* 終了   : 2026-08-23 13:25:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260823-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→13→12
* 開始   : 2026-08-23 18:35:00 (UTC)
* 終了   : 2026-08-23 19:20:00 (UTC)
* 現象   : 2026-08-23 19:20:00 (UTC)を境に水準が 11.76から14.7へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.979σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.171, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host10-007 active_connections の推移](charts/EVT-20260823-host10-007.svg)

# イベントID( EVT-20260823-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→11→7→11→9
* 開始   : 2026-08-23 18:50:00 (UTC)
* 終了   : 2026-08-23 18:50:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.5957(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 8→10→13→9→10
* 開始   : 2026-08-24 02:25:00 (UTC)
* 終了   : 2026-08-24 02:25:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260824-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host10-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→16→15→16→…→12→11→13→12
* 開始   : 2026-08-24 02:50:00 (UTC)
* 終了   : 2026-08-24 20:05:00 (UTC)
* 現象   : 2026-08-24 20:05:00 (UTC)を境に水準が 11.79から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.255, 限界=2.676)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.519, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host10-003 active_connections の推移](charts/EVT-20260824-host10-003.svg)

# イベントID( EVT-20260824-host10-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→12→15→12→…→13→14→13→12
* 開始   : 2026-08-24 02:55:00 (UTC)
* 終了   : 2026-08-24 19:40:00 (UTC)
* 現象   : 2026-08-24 19:40:00 (UTC)を境に水準が 11.78から14.91へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.733, 限界=2.683)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.718, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host10-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→14→15→12→…→15→13→15→14
* 開始   : 2026-08-24 03:05:00 (UTC)
* 終了   : 2026-08-24 19:05:00 (UTC)
* 現象   : 2026-08-24 19:05:00 (UTC)を境に水準が 11.87から14.93へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.886, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.481, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host10-008 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→17→18→16→…→12→13→17→13
* 開始   : 2026-08-24 04:05:00 (UTC)
* 終了   : 2026-08-24 19:45:00 (UTC)
* 現象   : 2026-08-24 19:45:00 (UTC)を境に水準が 11.89から14.93へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.104, 限界=2.673)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host10-008 active_connections の推移](charts/EVT-20260824-host10-008.svg)

# イベントID( EVT-20260825-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 21→20→23→20→23→20→23→21
* 開始   : 2026-08-25 09:20:00 (UTC)
* 終了   : 2026-08-25 09:30:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→17→16→13→17→16→13→14
* 開始   : 2026-08-26 05:20:00 (UTC)
* 終了   : 2026-08-26 05:25:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260826-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 22→20→26→22→19
* 開始   : 2026-08-26 10:30:00 (UTC)
* 終了   : 2026-08-26 10:30:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.258倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.739σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 21→23→17→23→24
* 開始   : 2026-08-26 13:55:00 (UTC)
* 終了   : 2026-08-26 13:55:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.7757(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-043 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host10-009 active_connections の推移](charts/EVT-20260826-host10-009.svg)

# イベントID( EVT-20260826-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 20→20→16→19→21
* 開始   : 2026-08-26 14:40:00 (UTC)
* 終了   : 2026-08-26 14:40:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.7711(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→15→10→13→13
* 開始   : 2026-08-26 18:55:00 (UTC)
* 終了   : 2026-08-26 18:55:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host01-006 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260826-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→12→9→11→11→9→9→10→12
* 開始   : 2026-08-26 19:55:00 (UTC)
* 終了   : 2026-08-26 21:40:00 (UTC)
* 現象   : 2026-08-26 21:40:00 (UTC)を境に水準が 14.95から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.481, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 13→12→17→14→13
* 開始   : 2026-08-27 05:10:00 (UTC)
* 終了   : 2026-08-27 05:10:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-020 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260827-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 14→14→18→14→17
* 開始   : 2026-08-27 05:50:00 (UTC)
* 終了   : 2026-08-27 05:50:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→13→10→13→13
* 開始   : 2026-08-27 19:10:00 (UTC)
* 終了   : 2026-08-27 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→13→9→12→13
* 開始   : 2026-08-27 19:40:00 (UTC)
* 終了   : 2026-08-27 19:40:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 11→13→8→11→12
* 開始   : 2026-08-27 19:50:00 (UTC)
* 終了   : 2026-08-27 19:50:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.6316(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host15-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 9→7→4→9→8
* 開始   : 2026-08-28 22:50:00 (UTC)
* 終了   : 2026-08-28 22:50:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.4486(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.434σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260828-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 10→12→9→11→…→10→12→13→12
* 開始   : 2026-08-29 04:45:00 (UTC)
* 終了   : 2026-08-29 19:05:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.394σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.886, 限界=2.673)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260829-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間

![EVT-20260829-host10-002 active_connections の推移](charts/EVT-20260829-host10-002.svg)

# イベントID( EVT-20260829-host10-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→12→11→12→…→12→13→12→11
* 開始   : 2026-08-29 05:10:00 (UTC)
* 終了   : 2026-08-29 19:05:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.864, 限界=2.683)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260829-host10-003 active_connections の推移](charts/EVT-20260829-host10-003.svg)

# イベントID( EVT-20260829-host10-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→13→11→10→…→11→10→13→12
* 開始   : 2026-08-29 05:15:00 (UTC)
* 終了   : 2026-08-29 18:25:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.17, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260829-host10-004 active_connections の推移](charts/EVT-20260829-host10-004.svg)

# イベントID( EVT-20260829-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→17→13→14→…→12→11→13→12
* 開始   : 2026-08-29 05:20:00 (UTC)
* 終了   : 2026-08-29 18:55:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.327, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260829-host10-005 active_connections の推移](charts/EVT-20260829-host10-005.svg)

# イベントID( EVT-20260829-host10-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→11→13→12→…→13→12→15→13
* 開始   : 2026-08-29 05:30:00 (UTC)
* 終了   : 2026-08-29 19:20:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.089, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260829-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260829-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260829-host10-006 active_connections の推移](charts/EVT-20260829-host10-006.svg)

# イベントID( EVT-20260829-host10-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→13→10→12→…→9→12→13→11
* 開始   : 2026-08-29 05:45:00 (UTC)
* 終了   : 2026-08-29 18:35:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.885, 限界=2.68)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host10-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host10-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host10-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260829-host10-007 active_connections の推移](charts/EVT-20260829-host10-007.svg)

# イベントID( EVT-20260829-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→6→9→8→…→10→9→11→10
* 開始   : 2026-08-29 19:30:00 (UTC)
* 終了   : 2026-08-29 19:55:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.91σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.923, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host10-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260829-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260829-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260829-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260829-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260829-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 25 分

![EVT-20260829-host10-008 active_connections の推移](charts/EVT-20260829-host10-008.svg)

# イベントID( EVT-20260801-host10-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 10→8→9→10→…→8→9→10→12
* 開始   : 2026-08-01 04:00:00 (UTC)
* 終了   : 2026-08-01 04:10:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.729, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260801-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 11→7→10→7→10→7→8
* 開始   : 2026-08-01 21:10:00 (UTC)
* 終了   : 2026-08-01 21:20:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260801-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→11→11→10→11→12→13→12→13
* 開始   : 2026-08-02 04:45:00 (UTC)
* 終了   : 2026-08-02 06:05:00 (UTC)
* 現象   : 2026-08-02 06:05:00 (UTC)を境に水準が 11.81から12.18へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host10-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→15→12→13→11
* 開始   : 2026-08-02 06:00:00 (UTC)
* 終了   : 2026-08-02 06:20:00 (UTC)
* 現象   : 2026-08-02 06:20:00 (UTC)を境に水準が 11.84から12.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.285, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 17→15→12→14→15→12→14→15
* 開始   : 2026-08-02 15:40:00 (UTC)
* 終了   : 2026-08-02 15:45:00 (UTC)
* 現象   : 平常時(15.08)に対し 0.7956(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260802-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260802-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260802-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→9→11→10→8→8→12
* 開始   : 2026-08-03 21:20:00 (UTC)
* 終了   : 2026-08-03 21:50:00 (UTC)
* 現象   : 2026-08-03 21:50:00 (UTC)を境に水準が 14.85から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.97, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 9→10→12→13→10→12→13→10→11
* 開始   : 2026-08-04 03:05:00 (UTC)
* 終了   : 2026-08-04 03:10:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→13→18→14→18→14→18→17
* 開始   : 2026-08-04 06:45:00 (UTC)
* 終了   : 2026-08-04 06:55:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260804-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host10-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 20→21→22→20→21→20→22→22
* 開始   : 2026-08-04 08:50:00 (UTC)
* 終了   : 2026-08-04 09:25:00 (UTC)
* 現象   : 2026-08-04 09:25:00 (UTC)を境に水準が 14.95から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.479, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host10-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 22→21→22→20→22→21→20→25
* 開始   : 2026-08-04 09:25:00 (UTC)
* 終了   : 2026-08-04 10:00:00 (UTC)
* 現象   : 2026-08-04 10:00:00 (UTC)を境に水準が 15.01から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host10-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 24→24→23
* 開始   : 2026-08-04 11:40:00 (UTC)
* 終了   : 2026-08-04 11:50:00 (UTC)
* 現象   : 2026-08-04 11:50:00 (UTC)を境に水準が 15から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.179, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 15→14→11→12→11→12→11→14
* 開始   : 2026-08-04 18:45:00 (UTC)
* 終了   : 2026-08-04 18:55:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.7458(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.627σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260804-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260804-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 9→12→13→12→13→12
* 開始   : 2026-08-05 03:15:00 (UTC)
* 終了   : 2026-08-05 03:20:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 11→9→14→12→9→14→12→13
* 開始   : 2026-08-05 04:20:00 (UTC)
* 終了   : 2026-08-05 04:25:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分

![EVT-20260805-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 13→12→15→16→15→16→15→14
* 開始   : 2026-08-05 04:50:00 (UTC)
* 終了   : 2026-08-05 05:00:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-015 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分

![EVT-20260805-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 16→17→19→17→19→17→19→16
* 開始   : 2026-08-05 06:55:00 (UTC)
* 終了   : 2026-08-05 07:05:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.246倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.626σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 21→19→23→20→23→20→23→21→22
* 開始   : 2026-08-05 09:15:00 (UTC)
* 終了   : 2026-08-05 09:25:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.185倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260805-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 21→23→23→24→24→23
* 開始   : 2026-08-05 11:30:00 (UTC)
* 終了   : 2026-08-05 12:05:00 (UTC)
* 現象   : 2026-08-05 12:05:00 (UTC)を境に水準が 15.03から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.209, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 17→14→17→14→17→15
* 開始   : 2026-08-05 17:00:00 (UTC)
* 終了   : 2026-08-05 17:05:00 (UTC)
* 現象   : 平常時(18)に対し 0.7778(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.809σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260805-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 13→11→10→13→10→13→10→11
* 開始   : 2026-08-05 19:40:00 (UTC)
* 終了   : 2026-08-05 19:50:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 13→11→9→12→9→12→9→10→11
* 開始   : 2026-08-05 20:10:00 (UTC)
* 終了   : 2026-08-05 20:20:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host10-016 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host10-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host10-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 14→12→9→12→9→12→10
* 開始   : 2026-08-05 20:10:00 (UTC)
* 終了   : 2026-08-05 20:15:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host10-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host10-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 8→5→10→11→5→10→11→9
* 開始   : 2026-08-06 02:00:00 (UTC)
* 終了   : 2026-08-06 02:55:00 (UTC)
* 現象   : 平常時(8)に対し 0.625倍(5)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-005 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-004 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260806-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-006 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260806-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→15→8→12→10→15→8→12→11
* 開始   : 2026-08-06 04:05:00 (UTC)
* 終了   : 2026-08-06 04:10:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.343倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260806-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260806-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→16→18→14→18→14→18→17→18
* 開始   : 2026-08-06 06:15:00 (UTC)
* 終了   : 2026-08-06 06:25:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260806-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 18→15→19→20→19→15→19→20→19
* 開始   : 2026-08-06 07:25:00 (UTC)
* 終了   : 2026-08-06 07:30:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.181倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260806-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 22→17→20→23→17→20→23→20→21
* 開始   : 2026-08-06 14:25:00 (UTC)
* 終了   : 2026-08-06 14:35:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260806-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260806-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 18→18→19→18→18→17→19
* 開始   : 2026-08-06 16:10:00 (UTC)
* 終了   : 2026-08-06 17:15:00 (UTC)
* 現象   : 2026-08-06 17:15:00 (UTC)を境に水準が 15.01から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.398, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 16→15→11→13→15→11→13→11
* 開始   : 2026-08-06 19:25:00 (UTC)
* 終了   : 2026-08-06 19:30:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260806-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 11→9→11→9→11→9→10→12
* 開始   : 2026-08-06 20:15:00 (UTC)
* 終了   : 2026-08-06 20:25:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260806-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260806-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 11→9→7→8→…→8→6→10→9
* 開始   : 2026-08-06 22:00:00 (UTC)
* 終了   : 2026-08-06 22:10:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260806-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 8→9→11→12→…→12→10→12→8
* 開始   : 2026-08-07 01:55:00 (UTC)
* 終了   : 2026-08-07 02:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260807-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→17→18→14→17→18→14→17
* 開始   : 2026-08-07 06:15:00 (UTC)
* 終了   : 2026-08-07 06:20:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-019 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 18→17→20→17→20→17→20→17→18
* 開始   : 2026-08-07 07:35:00 (UTC)
* 終了   : 2026-08-07 07:45:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.231倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.629σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260807-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 22→19→18→17→…→19→17→19→18
* 開始   : 2026-08-07 15:15:00 (UTC)
* 終了   : 2026-08-07 15:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.043σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260807-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 20→19→22→16→18→19→22→16→18
* 開始   : 2026-08-07 16:15:00 (UTC)
* 終了   : 2026-08-07 16:20:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260807-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 16→17→14→16→…→16→13→15→17
* 開始   : 2026-08-07 17:20:00 (UTC)
* 終了   : 2026-08-07 17:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260807-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 20 分
  - EVT-20260807-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260807-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host10-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 9→8→9→7→8→9→7→8
* 開始   : 2026-08-08 20:40:00 (UTC)
* 終了   : 2026-08-08 20:45:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.957, 限界=2.677)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260808-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260808-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 9→6→7→9→6→7→9
* 開始   : 2026-08-08 21:45:00 (UTC)
* 終了   : 2026-08-08 21:50:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.6545(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260808-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host10-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 8→11→11→8→9
* 開始   : 2026-08-08 23:25:00 (UTC)
* 終了   : 2026-08-08 23:45:00 (UTC)
* 現象   : 2026-08-08 23:45:00 (UTC)を境に水準が 11.82から11.8へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.299, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260808-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 8→9→9→11→9→8
* 開始   : 2026-08-09 01:25:00 (UTC)
* 終了   : 2026-08-09 01:50:00 (UTC)
* 現象   : 2026-08-09 01:50:00 (UTC)を境に水準が 11.79から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.392, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 8→9→5→6→5→6→5→9
* 開始   : 2026-08-09 01:30:00 (UTC)
* 終了   : 2026-08-09 01:40:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.5769(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→12→16→13→16→13→16→15→14
* 開始   : 2026-08-09 07:45:00 (UTC)
* 終了   : 2026-08-09 07:55:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.315倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.677σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260809-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260809-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 13→15→11→14→17→11→14→17→14
* 開始   : 2026-08-09 15:50:00 (UTC)
* 終了   : 2026-08-09 16:00:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260809-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→13→15→14→15→14→14→14
* 開始   : 2026-08-09 16:10:00 (UTC)
* 終了   : 2026-08-09 16:45:00 (UTC)
* 現象   : 2026-08-09 16:45:00 (UTC)を境に水準が 11.76から14.62へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.455, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 9→11→12→9→8→12→12
* 開始   : 2026-08-09 20:20:00 (UTC)
* 終了   : 2026-08-09 20:50:00 (UTC)
* 現象   : 2026-08-09 20:50:00 (UTC)を境に水準が 11.82から14.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 9→8→6→10→6→10→6→9
* 開始   : 2026-08-09 20:55:00 (UTC)
* 終了   : 2026-08-09 21:05:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-051 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260809-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260809-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 9→10→11→9→8→10→11
* 開始   : 2026-08-10 22:45:00 (UTC)
* 終了   : 2026-08-10 23:15:00 (UTC)
* 現象   : 2026-08-10 23:15:00 (UTC)を境に水準が 14.93から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.967, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→13→16→14→13→16→14→15
* 開始   : 2026-08-11 05:35:00 (UTC)
* 終了   : 2026-08-11 05:40:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host10-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 16→13→17→19→13→17→19→16→18
* 開始   : 2026-08-11 06:55:00 (UTC)
* 終了   : 2026-08-11 07:05:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 16→18→14→17→…→17→13→17→16
* 開始   : 2026-08-11 17:20:00 (UTC)
* 終了   : 2026-08-11 17:30:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7887(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260811-lsfhost01-048 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260811-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 15→13→16→12→13→16→12→14
* 開始   : 2026-08-11 18:15:00 (UTC)
* 終了   : 2026-08-11 18:25:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.153σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260811-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 12→10→13→10→13→10→14→13
* 開始   : 2026-08-11 19:10:00 (UTC)
* 終了   : 2026-08-11 19:20:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.7273(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.629σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-059 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260811-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260811-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→13→10→12→13→10→12
* 開始   : 2026-08-11 19:25:00 (UTC)
* 終了   : 2026-08-11 19:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-057 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-058 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260811-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 10→9→6→12→9→6→12→9
* 開始   : 2026-08-12 02:30:00 (UTC)
* 終了   : 2026-08-12 02:35:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-007 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260812-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→15→18→15→…→15→18→15→18
* 開始   : 2026-08-12 05:55:00 (UTC)
* 終了   : 2026-08-12 06:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.744σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→8→10→12→8→10→8
* 開始   : 2026-08-12 21:10:00 (UTC)
* 終了   : 2026-08-12 21:15:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host08-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host10-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 9→9→10→10→8→6→9→9→8
* 開始   : 2026-08-12 23:20:00 (UTC)
* 終了   : 2026-08-13 00:30:00 (UTC)
* 現象   : 2026-08-13 00:30:00 (UTC)を境に水準が 15.03から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.072, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host10-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→13→15→15
* 開始   : 2026-08-13 04:30:00 (UTC)
* 終了   : 2026-08-13 04:45:00 (UTC)
* 現象   : 2026-08-13 04:45:00 (UTC)を境に水準が 14.89から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.928, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 21→19→16→18→16→18→16→17→19
* 開始   : 2026-08-13 16:20:00 (UTC)
* 終了   : 2026-08-13 16:30:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.8067(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260813-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 7→8→11→5→8→11→5→8→9
* 開始   : 2026-08-14 00:55:00 (UTC)
* 終了   : 2026-08-14 01:00:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 10→7→5→11→…→5→11→9→10
* 開始   : 2026-08-14 01:25:00 (UTC)
* 終了   : 2026-08-14 01:30:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-008 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260814-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 8→10→13→14→…→13→14→11→10
* 開始   : 2026-08-14 03:20:00 (UTC)
* 終了   : 2026-08-14 03:25:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.278σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260814-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260814-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→16→13→16→13→16→13→14
* 開始   : 2026-08-14 05:05:00 (UTC)
* 終了   : 2026-08-14 05:15:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.297倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.57σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host10-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host10-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260814-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260814-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 13→12→16→14→12→16→14→13
* 開始   : 2026-08-14 05:10:00 (UTC)
* 終了   : 2026-08-14 05:15:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host10-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260814-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260814-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 17→15→18→19→…→17→19→17→16
* 開始   : 2026-08-14 06:40:00 (UTC)
* 終了   : 2026-08-14 07:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host10-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260814-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-024 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260814-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260814-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→16→18→16→…→16→19→16→17
* 開始   : 2026-08-14 06:45:00 (UTC)
* 終了   : 2026-08-14 06:55:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host10-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260814-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260814-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260814-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260814-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host10-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 23→19→20→21→21→23→24→21→23
* 開始   : 2026-08-14 09:15:00 (UTC)
* 終了   : 2026-08-14 11:10:00 (UTC)
* 現象   : 2026-08-14 11:10:00 (UTC)を境に水準が 15.05から13.61へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.569, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 21→20→24→21→20→24→21→22
* 開始   : 2026-08-14 11:20:00 (UTC)
* 終了   : 2026-08-14 11:25:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260814-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host10-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 24→22→23→22→23→23→23→23→23
* 開始   : 2026-08-14 12:10:00 (UTC)
* 終了   : 2026-08-14 12:50:00 (UTC)
* 現象   : 2026-08-14 12:50:00 (UTC)を境に水準が 14.98から13.31へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.767, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host10-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 24→22→24→22→22→23→22→22
* 開始   : 2026-08-14 12:10:00 (UTC)
* 終了   : 2026-08-14 12:45:00 (UTC)
* 現象   : 2026-08-14 12:45:00 (UTC)を境に水準が 15.01から13.27へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→10→8→15→11→10→8→15→11
* 開始   : 2026-08-14 20:15:00 (UTC)
* 終了   : 2026-08-14 20:20:00 (UTC)
* 現象   : 平常時(11.83)に対し 0.6761(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.685σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260814-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-lsfhost01-075 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260814-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260814-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host10-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 18→18→17→16→15→17→17→17
* 開始   : 2026-08-16 11:50:00 (UTC)
* 終了   : 2026-08-16 12:25:00 (UTC)
* 現象   : 2026-08-16 12:25:00 (UTC)を境に水準が 11.81から13.53へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.856, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 9→7→12→6→…→12→6→9→10
* 開始   : 2026-08-16 22:45:00 (UTC)
* 終了   : 2026-08-16 22:50:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260816-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 9→12→14→11→12→14→11
* 開始   : 2026-08-18 03:55:00 (UTC)
* 終了   : 2026-08-18 04:00:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260818-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 21→20→18→20→18→20
* 開始   : 2026-08-18 14:45:00 (UTC)
* 終了   : 2026-08-18 14:50:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.8372(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-040 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260818-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260818-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→14→15→14→16→17→14
* 開始   : 2026-08-18 18:20:00 (UTC)
* 終了   : 2026-08-18 18:50:00 (UTC)
* 現象   : 2026-08-18 18:50:00 (UTC)を境に水準が 15.05から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.62, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 19→16→22→21→19→16→22→21→22
* 開始   : 2026-08-19 09:10:00 (UTC)
* 終了   : 2026-08-19 09:15:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 18→15→17→18→15→17→16
* 開始   : 2026-08-19 16:35:00 (UTC)
* 終了   : 2026-08-19 16:40:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260819-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 16→15→13→17→12→13→17→12→14
* 開始   : 2026-08-19 18:05:00 (UTC)
* 終了   : 2026-08-19 18:15:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.048σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260819-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 16→15→12→14→12→14→12→14
* 開始   : 2026-08-19 18:20:00 (UTC)
* 終了   : 2026-08-19 18:30:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.766(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.569σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260819-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 16→15→11→12→…→12→10→13→11
* 開始   : 2026-08-19 19:15:00 (UTC)
* 終了   : 2026-08-19 19:25:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260819-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260819-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-059 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260819-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→10→13→10→13→10→11
* 開始   : 2026-08-19 19:30:00 (UTC)
* 終了   : 2026-08-19 19:40:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260819-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260819-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host10-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 8→9→6→9→6→9→6→8→9
* 開始   : 2026-08-19 22:35:00 (UTC)
* 終了   : 2026-08-19 22:45:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.6486(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260819-host10-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 22→23→24→22→24
* 開始   : 2026-08-20 11:00:00 (UTC)
* 終了   : 2026-08-20 11:20:00 (UTC)
* 現象   : 2026-08-20 11:20:00 (UTC)を境に水準が 14.97から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.299, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 22→23→25→22→26→21→22→23→23
* 開始   : 2026-08-20 11:45:00 (UTC)
* 終了   : 2026-08-20 12:35:00 (UTC)
* 現象   : 2026-08-20 12:35:00 (UTC)を境に水準が 14.97から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.553, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 22→20→18→22→18→22→18→20→21
* 開始   : 2026-08-20 14:40:00 (UTC)
* 終了   : 2026-08-20 14:50:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260820-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 17→14→12→16→…→16→12→14→15
* 開始   : 2026-08-20 18:10:00 (UTC)
* 終了   : 2026-08-20 18:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.862σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host10-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260820-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260820-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260820-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 14→13→11→10→13→11→10→13
* 開始   : 2026-08-20 18:50:00 (UTC)
* 終了   : 2026-08-20 18:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.386σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-055 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260820-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 13→12→9→13→…→8→12→8→10
* 開始   : 2026-08-20 20:30:00 (UTC)
* 終了   : 2026-08-20 20:50:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host10-013 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260820-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host10-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→8→12→8→12→8→12
* 開始   : 2026-08-20 20:35:00 (UTC)
* 終了   : 2026-08-20 20:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host10-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260820-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260820-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host10-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host10-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→9→8→10→10→8
* 開始   : 2026-08-20 23:10:00 (UTC)
* 終了   : 2026-08-20 23:35:00 (UTC)
* 現象   : 2026-08-20 23:35:00 (UTC)を境に水準が 15から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.359, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host10-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host10-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 11→11→8→11→12→11→11→12
* 開始   : 2026-08-21 02:30:00 (UTC)
* 終了   : 2026-08-21 03:05:00 (UTC)
* 現象   : 2026-08-21 03:05:00 (UTC)を境に水準が 14.99から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.856, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 17→18→20→19→20→19→20→17→18
* 開始   : 2026-08-21 07:35:00 (UTC)
* 終了   : 2026-08-21 07:45:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260821-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260821-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 16→15→13→14→13→14→13
* 開始   : 2026-08-21 18:00:00 (UTC)
* 終了   : 2026-08-21 18:10:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260821-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260821-lsfhost01-057 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260821-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260821-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 8→6→11→9→6→11→9→10
* 開始   : 2026-08-22 02:00:00 (UTC)
* 終了   : 2026-08-22 02:05:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-lsfhost01-003 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260822-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host10-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 12→10→7→9→…→9→8→10→11
* 開始   : 2026-08-22 19:45:00 (UTC)
* 終了   : 2026-08-22 19:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.065, 限界=2.676)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host10-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260822-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260822-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260822-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host10-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→10→12→10→10→11→10→10
* 開始   : 2026-08-23 03:05:00 (UTC)
* 終了   : 2026-08-23 03:40:00 (UTC)
* 現象   : 2026-08-23 03:40:00 (UTC)を境に水準が 11.8から11.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.682, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host10-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 11→10→9→8→12→9→9→9→13
* 開始   : 2026-08-23 21:40:00 (UTC)
* 終了   : 2026-08-23 22:30:00 (UTC)
* 現象   : 2026-08-23 22:30:00 (UTC)を境に水準が 11.74から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.937, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host10-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 10→7→10→9→8→6→8→10→10
* 開始   : 2026-08-23 23:45:00 (UTC)
* 終了   : 2026-08-24 00:55:00 (UTC)
* 現象   : 2026-08-24 00:55:00 (UTC)を境に水準が 11.81から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.481, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 8→5→10→5→10→5→7
* 開始   : 2026-08-24 00:30:00 (UTC)
* 終了   : 2026-08-24 00:40:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.5882(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260824-lsfhost01-001 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260823-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260824-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 12→10→13→10→13→10→11
* 開始   : 2026-08-25 03:40:00 (UTC)
* 終了   : 2026-08-25 03:45:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260825-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→13→14→13→14
* 開始   : 2026-08-25 04:15:00 (UTC)
* 終了   : 2026-08-25 04:20:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 14→17→13→17→13→17→16→15
* 開始   : 2026-08-25 05:50:00 (UTC)
* 終了   : 2026-08-25 06:00:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.283倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.627σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260825-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260825-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 16→14→18→14→18→17
* 開始   : 2026-08-25 06:40:00 (UTC)
* 終了   : 2026-08-25 06:45:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.256倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 18→17→21→18→17→21→18
* 開始   : 2026-08-25 08:20:00 (UTC)
* 終了   : 2026-08-25 08:25:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.277σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260825-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260825-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host10-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 19→17→17
* 開始   : 2026-08-25 17:10:00 (UTC)
* 終了   : 2026-08-25 17:20:00 (UTC)
* 現象   : 2026-08-25 17:20:00 (UTC)を境に水準が 14.99から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host10-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host10-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 15→12→12→12→13→13→12→14→12
* 開始   : 2026-08-25 19:40:00 (UTC)
* 終了   : 2026-08-25 20:20:00 (UTC)
* 現象   : 2026-08-25 20:20:00 (UTC)を境に水準が 15.02から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.088, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 10→6→9→10→6→9→8
* 開始   : 2026-08-25 23:00:00 (UTC)
* 終了   : 2026-08-25 23:05:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-081 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260825-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host10-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 8→8→9→9→9→9→10→8→11
* 開始   : 2026-08-25 23:50:00 (UTC)
* 終了   : 2026-08-26 00:35:00 (UTC)
* 現象   : 2026-08-26 00:35:00 (UTC)を境に水準が 14.95から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.569, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 12→11→15→16→12→11→15→16→12
* 開始   : 2026-08-26 04:50:00 (UTC)
* 終了   : 2026-08-26 04:55:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.277倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.282σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260826-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 14→18→17→14→18→17→18
* 開始   : 2026-08-26 06:40:00 (UTC)
* 終了   : 2026-08-26 06:45:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host10-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host10-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 15→18→15→18→15→17
* 開始   : 2026-08-26 06:45:00 (UTC)
* 終了   : 2026-08-26 06:50:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host10-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host10-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→15→18→19→15→18→19→15→16
* 開始   : 2026-08-26 06:45:00 (UTC)
* 終了   : 2026-08-26 06:50:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.103σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host10-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host10-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 19→18→21→17→…→17→22→18→19
* 開始   : 2026-08-26 08:05:00 (UTC)
* 終了   : 2026-08-26 08:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260826-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host10-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 23→21→19→22→…→22→18→21→24
* 開始   : 2026-08-26 12:10:00 (UTC)
* 終了   : 2026-08-26 12:20:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.8476(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host10-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 20→21→17→16→17→16→21→18
* 開始   : 2026-08-26 15:45:00 (UTC)
* 終了   : 2026-08-26 15:55:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分

![EVT-20260826-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host10-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→15→13→12→13→12→13→16
* 開始   : 2026-08-26 18:15:00 (UTC)
* 終了   : 2026-08-26 18:25:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.161σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host05-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260826-lsfhost01-060 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260826-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host10-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 14→13→16→14→…→14→17→13→16
* 開始   : 2026-08-27 05:35:00 (UTC)
* 終了   : 2026-08-27 05:45:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260827-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260827-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host10-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_3
* 値     : 24→21→23→22→22→23→22→23→24
* 開始   : 2026-08-27 12:35:00 (UTC)
* 終了   : 2026-08-27 13:20:00 (UTC)
* 現象   : 2026-08-27 13:20:00 (UTC)を境に水準が 15.03から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.321, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 15→13→15→12→13→15→12→15→17
* 開始   : 2026-08-27 17:55:00 (UTC)
* 終了   : 2026-08-27 18:05:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260827-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 10→6→8→5→6→8→5→7
* 開始   : 2026-08-27 22:35:00 (UTC)
* 終了   : 2026-08-27 22:45:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.6316(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-086 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-087 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260827-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260827-host10-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host10-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 8→10→10→7→9→10
* 開始   : 2026-08-27 23:45:00 (UTC)
* 終了   : 2026-08-28 00:10:00 (UTC)
* 現象   : 2026-08-28 00:10:00 (UTC)を境に水準が 15.11から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.209, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host10-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host10-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 8→9→11→5→…→11→5→7→9
* 開始   : 2026-08-27 23:55:00 (UTC)
* 終了   : 2026-08-28 00:00:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host10-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_6
* 値     : 15→13→17→16→…→16→18→16→13
* 開始   : 2026-08-28 05:50:00 (UTC)
* 終了   : 2026-08-28 06:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260828-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host10-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 17→16→20→19→16→20→19
* 開始   : 2026-08-28 07:35:00 (UTC)
* 終了   : 2026-08-28 07:40:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.263倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.91σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260828-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host10-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host10-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_2
* 値     : 17→22→23→21→…→23→17→20→21
* 開始   : 2026-08-28 09:20:00 (UTC)
* 終了   : 2026-08-28 09:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.444σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host10-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host10-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 17→16→14→13→16→14→13→16→14
* 開始   : 2026-08-28 17:30:00 (UTC)
* 終了   : 2026-08-28 17:35:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host10-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host10-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_5
* 値     : 12→13→11→10→…→11→10→12→13
* 開始   : 2026-08-28 19:10:00 (UTC)
* 終了   : 2026-08-28 19:15:00 (UTC)
* 現象   : 平常時(14.25)に対し 0.7719(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host10-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host10-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 10→7→10→7→10→7→10→9
* 開始   : 2026-08-28 21:35:00 (UTC)
* 終了   : 2026-08-28 21:45:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.51σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-071 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260828-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host10-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host10-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_1
* 値     : 7→8→5→11→8→5→11→8
* 開始   : 2026-08-29 01:45:00 (UTC)
* 終了   : 2026-08-29 01:50:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260829-host10-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host10-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host10, port=7003, datasource=OraclePool_4
* 値     : 12→11→8→10→11→8→10
* 開始   : 2026-08-29 19:40:00 (UTC)
* 終了   : 2026-08-29 19:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.335σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host10-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260829-host10-009 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
