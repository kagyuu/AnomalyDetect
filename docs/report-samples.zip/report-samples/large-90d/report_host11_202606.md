# host11 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host11 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 332 (SEVERE: 38, FATAL: 121, WARN: 173, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 38 | 121 | 173 | 332 | ALG-A1, ALG-A2, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260602-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 23→22→25→24
* 開始   : 2026-06-02 10:05:00 (UTC)
* 終了   : 2026-06-02 10:20:00 (UTC)
* 現象   : 2026-06-02 10:20:00 (UTC)を境に水準が 14.99から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host11-004 active_connections の推移](charts/EVT-20260602-host11-004.svg)

# イベントID( EVT-20260603-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 25→24→22→22→23→21→23
* 開始   : 2026-06-03 12:05:00 (UTC)
* 終了   : 2026-06-03 12:35:00 (UTC)
* 現象   : 2026-06-03 12:35:00 (UTC)を境に水準が 15.06から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.962, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host11-004 active_connections の推移](charts/EVT-20260603-host11-004.svg)

# イベントID( EVT-20260605-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→14→15→17→15→18→14→17→19
* 開始   : 2026-06-05 05:20:00 (UTC)
* 終了   : 2026-06-05 06:10:00 (UTC)
* 現象   : 2026-06-05 06:10:00 (UTC)を境に水準が 15.07から14.75へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.512, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host11-002 active_connections の推移](charts/EVT-20260605-host11-002.svg)

# イベントID( EVT-20260607-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→14→13→14→16→18
* 開始   : 2026-06-07 07:35:00 (UTC)
* 終了   : 2026-06-07 08:00:00 (UTC)
* 現象   : 2026-06-07 08:00:00 (UTC)を境に水準が 11.85から12.43へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.825, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host11-005 active_connections の推移](charts/EVT-20260607-host11-005.svg)

# イベントID( EVT-20260608-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→16→15→16→…→15→14→12→13
* 開始   : 2026-06-08 01:45:00 (UTC)
* 終了   : 2026-06-08 20:10:00 (UTC)
* 現象   : 2026-06-08 20:10:00 (UTC)を境に水準が 11.77から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.417, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.329, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host11-001 active_connections の推移](charts/EVT-20260608-host11-001.svg)

# イベントID( EVT-20260608-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→14→17→14→…→10→14→12→11
* 開始   : 2026-06-08 02:00:00 (UTC)
* 終了   : 2026-06-08 22:50:00 (UTC)
* 現象   : 2026-06-08 22:50:00 (UTC)を境に水準が 11.67から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.089, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.943, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host11-002 active_connections の推移](charts/EVT-20260608-host11-002.svg)

# イベントID( EVT-20260608-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→14→16→14→…→12→14→11→12
* 開始   : 2026-06-08 02:45:00 (UTC)
* 終了   : 2026-06-08 20:05:00 (UTC)
* 現象   : 2026-06-08 20:05:00 (UTC)を境に水準が 11.83から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.775, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.981, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host11-003 active_connections の推移](charts/EVT-20260608-host11-003.svg)

# イベントID( EVT-20260608-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 17→15→17→16→…→16→15→13→14
* 開始   : 2026-06-08 02:55:00 (UTC)
* 終了   : 2026-06-08 19:50:00 (UTC)
* 現象   : 2026-06-08 19:50:00 (UTC)を境に水準が 11.95から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.032, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.493, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host11-004 active_connections の推移](charts/EVT-20260608-host11-004.svg)

# イベントID( EVT-20260608-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→13→14→13→…→15→12→14→13
* 開始   : 2026-06-08 03:20:00 (UTC)
* 終了   : 2026-06-08 21:40:00 (UTC)
* 現象   : 2026-06-08 21:40:00 (UTC)を境に水準が 11.88から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.346σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.792, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.203, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host11-005 active_connections の推移](charts/EVT-20260608-host11-005.svg)

# イベントID( EVT-20260608-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→15→18→16→…→16→15→11→13
* 開始   : 2026-06-08 04:30:00 (UTC)
* 終了   : 2026-06-08 19:40:00 (UTC)
* 現象   : 2026-06-08 19:40:00 (UTC)を境に水準が 11.93から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.903, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host11-006 active_connections の推移](charts/EVT-20260608-host11-006.svg)

# イベントID( EVT-20260609-host11-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→13→11→11→12→14
* 開始   : 2026-06-09 04:00:00 (UTC)
* 終了   : 2026-06-09 04:25:00 (UTC)
* 現象   : 2026-06-09 04:25:00 (UTC)を境に水準が 14.85から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.825, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host11-002 active_connections の推移](charts/EVT-20260609-host11-002.svg)

# イベントID( EVT-20260609-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→11→10→8→10→8→9→8→10
* 開始   : 2026-06-09 21:25:00 (UTC)
* 終了   : 2026-06-09 23:10:00 (UTC)
* 現象   : 2026-06-09 23:10:00 (UTC)を境に水準が 14.89から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.024, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host11-008 active_connections の推移](charts/EVT-20260609-host11-008.svg)

# イベントID( EVT-20260610-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 21→21→22→21→20→20→22
* 開始   : 2026-06-10 14:40:00 (UTC)
* 終了   : 2026-06-10 16:15:00 (UTC)
* 現象   : 2026-06-10 16:15:00 (UTC)を境に水準が 14.91から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.962, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host11-011 active_connections の推移](charts/EVT-20260610-host11-011.svg)

# イベントID( EVT-20260611-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→6→7→9→10→11→10
* 開始   : 2026-06-11 00:05:00 (UTC)
* 終了   : 2026-06-11 00:35:00 (UTC)
* 現象   : 2026-06-11 00:35:00 (UTC)を境に水準が 14.93から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.962, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host11-001 active_connections の推移](charts/EVT-20260611-host11-001.svg)

# イベントID( EVT-20260615-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→17→16→17→…→13→14→13→14
* 開始   : 2026-06-15 00:35:00 (UTC)
* 終了   : 2026-06-15 20:35:00 (UTC)
* 現象   : 2026-06-15 20:35:00 (UTC)を境に水準が 11.75から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.792, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.09, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-001 active_connections の推移](charts/EVT-20260615-host11-001.svg)

# イベントID( EVT-20260615-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→14→15→16→…→13→12→11→12
* 開始   : 2026-06-15 02:05:00 (UTC)
* 終了   : 2026-06-15 20:30:00 (UTC)
* 現象   : 2026-06-15 20:30:00 (UTC)を境に水準が 11.9から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.047, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.896, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-002 active_connections の推移](charts/EVT-20260615-host11-002.svg)

# イベントID( EVT-20260615-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→13→14→13→…→12→15→12→13
* 開始   : 2026-06-15 02:30:00 (UTC)
* 終了   : 2026-06-15 19:45:00 (UTC)
* 現象   : 2026-06-15 19:45:00 (UTC)を境に水準が 11.76から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.698, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.79, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-003 active_connections の推移](charts/EVT-20260615-host11-003.svg)

# イベントID( EVT-20260615-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→14→16→14→…→16→14→12→15
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 20:50:00 (UTC)
* 現象   : 2026-06-15 20:50:00 (UTC)を境に水準が 11.83から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.908, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.003, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-004 active_connections の推移](charts/EVT-20260615-host11-004.svg)

# イベントID( EVT-20260615-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 16→17→18→19→…→12→14→13→12
* 開始   : 2026-06-15 03:30:00 (UTC)
* 終了   : 2026-06-15 19:55:00 (UTC)
* 現象   : 2026-06-15 19:55:00 (UTC)を境に水準が 11.93から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.007, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-005 active_connections の推移](charts/EVT-20260615-host11-005.svg)

# イベントID( EVT-20260615-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 16→14→15→19→…→13→11→13→11
* 開始   : 2026-06-15 03:55:00 (UTC)
* 終了   : 2026-06-15 21:30:00 (UTC)
* 現象   : 2026-06-15 21:30:00 (UTC)を境に水準が 11.83から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.878, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.793, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-006 active_connections の推移](charts/EVT-20260615-host11-006.svg)

# イベントID( EVT-20260619-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 24→25→22→22→23
* 開始   : 2026-06-19 10:40:00 (UTC)
* 終了   : 2026-06-19 11:00:00 (UTC)
* 現象   : 2026-06-19 11:00:00 (UTC)を境に水準が 14.96から13.73へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host11-004 active_connections の推移](charts/EVT-20260619-host11-004.svg)

# イベントID( EVT-20260619-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 22→22→23→22→25
* 開始   : 2026-06-19 13:40:00 (UTC)
* 終了   : 2026-06-19 14:05:00 (UTC)
* 現象   : 2026-06-19 14:05:00 (UTC)を境に水準が 14.98から12.91へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host11-006 active_connections の推移](charts/EVT-20260619-host11-006.svg)

# イベントID( EVT-20260621-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→16→14→16→15→16
* 開始   : 2026-06-21 09:25:00 (UTC)
* 終了   : 2026-06-21 09:50:00 (UTC)
* 現象   : 2026-06-21 09:50:00 (UTC)を境に水準が 11.74から12.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.825, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host11-009 active_connections の推移](charts/EVT-20260621-host11-009.svg)

# イベントID( EVT-20260621-host11-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 15→17→17→17→16
* 開始   : 2026-06-21 11:10:00 (UTC)
* 終了   : 2026-06-21 11:30:00 (UTC)
* 現象   : 2026-06-21 11:30:00 (UTC)を境に水準が 11.79から13.22へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host11-011 active_connections の推移](charts/EVT-20260621-host11-011.svg)

# イベントID( EVT-20260622-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→15→14→15→…→14→17→12→14
* 開始   : 2026-06-22 02:15:00 (UTC)
* 終了   : 2026-06-22 20:50:00 (UTC)
* 現象   : 2026-06-22 20:50:00 (UTC)を境に水準が 11.81から14.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.094, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host11-001 active_connections の推移](charts/EVT-20260622-host11-001.svg)

# イベントID( EVT-20260622-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→15→16→13→…→13→12→11→13
* 開始   : 2026-06-22 02:35:00 (UTC)
* 終了   : 2026-06-22 23:30:00 (UTC)
* 現象   : 2026-06-22 23:30:00 (UTC)を境に水準が 11.82から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.874σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.074, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.61, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host11-002 active_connections の推移](charts/EVT-20260622-host11-002.svg)

# イベントID( EVT-20260622-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→14→17→13→…→14→12→11→10
* 開始   : 2026-06-22 02:40:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 11.83から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.791, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host11-003 active_connections の推移](charts/EVT-20260622-host11-003.svg)

# イベントID( EVT-20260622-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→18→17→18→…→14→12→15→12
* 開始   : 2026-06-22 03:00:00 (UTC)
* 終了   : 2026-06-22 20:35:00 (UTC)
* 現象   : 2026-06-22 20:35:00 (UTC)を境に水準が 11.96から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.69, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host11-004 active_connections の推移](charts/EVT-20260622-host11-004.svg)

# イベントID( EVT-20260622-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 14→16→17→15→…→12→15→13→14
* 開始   : 2026-06-22 03:50:00 (UTC)
* 終了   : 2026-06-22 20:05:00 (UTC)
* 現象   : 2026-06-22 20:05:00 (UTC)を境に水準が 11.95から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.987, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host11-005 active_connections の推移](charts/EVT-20260622-host11-005.svg)

# イベントID( EVT-20260622-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→15→13→14→…→15→13→15→13
* 開始   : 2026-06-22 04:05:00 (UTC)
* 終了   : 2026-06-22 22:35:00 (UTC)
* 現象   : 2026-06-22 22:35:00 (UTC)を境に水準が 11.9から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.852σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.836, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.831, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host11-006 active_connections の推移](charts/EVT-20260622-host11-006.svg)

# イベントID( EVT-20260623-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→13→12→11→9
* 開始   : 2026-06-23 20:25:00 (UTC)
* 終了   : 2026-06-23 21:15:00 (UTC)
* 現象   : 2026-06-23 21:15:00 (UTC)を境に水準が 14.97から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.973σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.687, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host11-011 active_connections の推移](charts/EVT-20260623-host11-011.svg)

# イベントID( EVT-20260625-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 23→23→24→23
* 開始   : 2026-06-25 13:30:00 (UTC)
* 終了   : 2026-06-25 13:45:00 (UTC)
* 現象   : 2026-06-25 13:45:00 (UTC)を境に水準が 14.95から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host11-010 active_connections の推移](charts/EVT-20260625-host11-010.svg)

# イベントID( EVT-20260629-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 16→18→20→18→…→13→14→12→11
* 開始   : 2026-06-29 01:05:00 (UTC)
* 終了   : 2026-06-29 21:40:00 (UTC)
* 現象   : 2026-06-29 21:40:00 (UTC)を境に水準が 11.72から14.84へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.398, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.257, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-001 active_connections の推移](charts/EVT-20260629-host11-001.svg)

# イベントID( EVT-20260629-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→15→14→17→…→16→15→14→12
* 開始   : 2026-06-29 02:05:00 (UTC)
* 終了   : 2026-06-29 21:45:00 (UTC)
* 現象   : 2026-06-29 21:45:00 (UTC)を境に水準が 11.88から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.888, 限界=2.684)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.749, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-002 active_connections の推移](charts/EVT-20260629-host11-002.svg)

# イベントID( EVT-20260629-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→14→13→14→…→14→16→14→15
* 開始   : 2026-06-29 02:25:00 (UTC)
* 終了   : 2026-06-29 21:30:00 (UTC)
* 現象   : 2026-06-29 21:30:00 (UTC)を境に水準が 11.8から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.908, 限界=2.688)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-003 active_connections の推移](charts/EVT-20260629-host11-003.svg)

# イベントID( EVT-20260629-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→17→16→17→…→15→16→14→15
* 開始   : 2026-06-29 02:50:00 (UTC)
* 終了   : 2026-06-29 21:50:00 (UTC)
* 現象   : 2026-06-29 21:50:00 (UTC)を境に水準が 11.9から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.88, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.66, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-004 active_connections の推移](charts/EVT-20260629-host11-004.svg)

# イベントID( EVT-20260629-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→15→14→16→…→14→15→11→14
* 開始   : 2026-06-29 03:25:00 (UTC)
* 終了   : 2026-06-29 18:50:00 (UTC)
* 現象   : 2026-06-29 18:50:00 (UTC)を境に水準が 11.8から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.808σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.072, 限界=2.689)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.51, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-005 active_connections の推移](charts/EVT-20260629-host11-005.svg)

# イベントID( EVT-20260629-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→16→13→15→…→13→12→13→12
* 開始   : 2026-06-29 03:40:00 (UTC)
* 終了   : 2026-06-29 19:25:00 (UTC)
* 現象   : 2026-06-29 19:25:00 (UTC)を境に水準が 11.9から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.522σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.023, 限界=2.679)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.402, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-006 active_connections の推移](charts/EVT-20260629-host11-006.svg)

# イベントID( EVT-20260601-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 22→21→18→23→20
* 開始   : 2026-06-01 12:05:00 (UTC)
* 終了   : 2026-06-01 12:05:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-035 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 19→20→16→18→20
* 開始   : 2026-06-01 15:25:00 (UTC)
* 終了   : 2026-06-01 15:25:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.167σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 9→11→6→9→11
* 開始   : 2026-06-01 21:15:00 (UTC)
* 終了   : 2026-06-01 21:15:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.5625(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→10→6→10→9
* 開始   : 2026-06-01 21:20:00 (UTC)
* 終了   : 2026-06-01 21:20:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.5496(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 19→20→14→17→14→17→14→16→18
* 開始   : 2026-06-02 16:45:00 (UTC)
* 終了   : 2026-06-02 16:55:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.75(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host15-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260602-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→13→10→14→15
* 開始   : 2026-06-02 18:40:00 (UTC)
* 終了   : 2026-06-02 18:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 0.6818(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→12→7→10→11
* 開始   : 2026-06-02 20:55:00 (UTC)
* 終了   : 2026-06-02 20:55:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host05-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260602-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→14→18→14→15
* 開始   : 2026-06-03 05:55:00 (UTC)
* 終了   : 2026-06-03 05:55:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→11→16→12→12
* 開始   : 2026-06-04 04:15:00 (UTC)
* 終了   : 2026-06-04 04:15:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.444倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→18→15→16→19
* 開始   : 2026-06-04 16:15:00 (UTC)
* 終了   : 2026-06-04 16:15:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 17→16→12→11→13→16→12→11→13
* 開始   : 2026-06-04 18:30:00 (UTC)
* 終了   : 2026-06-04 18:35:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→10→8→6→10→8→6→10→9
* 開始   : 2026-06-04 21:15:00 (UTC)
* 終了   : 2026-06-04 21:20:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 17→16→12→14→15
* 開始   : 2026-06-05 17:55:00 (UTC)
* 終了   : 2026-06-05 17:55:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-058 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260605-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→10→13→12→…→9→10→9→13
* 開始   : 2026-06-06 05:10:00 (UTC)
* 終了   : 2026-06-06 19:35:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.125, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260606-host11-001 active_connections の推移](charts/EVT-20260606-host11-001.svg)

# イベントID( EVT-20260606-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→13→…→10→12→10→12
* 開始   : 2026-06-06 05:15:00 (UTC)
* 終了   : 2026-06-06 19:45:00 (UTC)
* 現象   : 14.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.457σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.212, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260606-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260606-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260606-host11-002 active_connections の推移](charts/EVT-20260606-host11-002.svg)

# イベントID( EVT-20260606-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→10→9→12→…→10→11→10→11
* 開始   : 2026-06-06 05:20:00 (UTC)
* 終了   : 2026-06-06 18:55:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.088, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260606-host11-003 active_connections の推移](charts/EVT-20260606-host11-003.svg)

# イベントID( EVT-20260606-host11-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→11→13→12→…→12→11→13→12
* 開始   : 2026-06-06 05:25:00 (UTC)
* 終了   : 2026-06-06 19:25:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.836, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260606-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260606-host11-004 active_connections の推移](charts/EVT-20260606-host11-004.svg)

# イベントID( EVT-20260606-host11-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→13→10→13→…→12→10→11→12
* 開始   : 2026-06-06 05:40:00 (UTC)
* 終了   : 2026-06-06 19:05:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.887, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260606-host11-005 active_connections の推移](charts/EVT-20260606-host11-005.svg)

# イベントID( EVT-20260606-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 8→11→10→12→…→11→9→11→7
* 開始   : 2026-06-06 05:50:00 (UTC)
* 終了   : 2026-06-06 19:45:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.888, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host11-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260606-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260606-host11-006 active_connections の推移](charts/EVT-20260606-host11-006.svg)

# イベントID( EVT-20260606-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→9→4→7→9
* 開始   : 2026-06-06 23:30:00 (UTC)
* 終了   : 2026-06-06 23:30:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260606-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 9→10→4→9→9
* 開始   : 2026-06-07 00:45:00 (UTC)
* 終了   : 2026-06-07 00:45:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→9→14→12→11
* 開始   : 2026-06-07 05:00:00 (UTC)
* 終了   : 2026-06-07 05:55:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260607-lsfhost01-014 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260607-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→15→20→18→15
* 開始   : 2026-06-07 10:45:00 (UTC)
* 終了   : 2026-06-07 10:45:00 (UTC)
* 現象   : 平常時(15)に対し 1.333倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.52σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260607-host11-006 active_connections の推移](charts/EVT-20260607-host11-006.svg)

# イベントID( EVT-20260607-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→16→12→11→16→12→11→16→15
* 開始   : 2026-06-07 14:00:00 (UTC)
* 終了   : 2026-06-07 14:05:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.7619(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.626σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→15→15→14→14→14→14→17
* 開始   : 2026-06-07 16:20:00 (UTC)
* 終了   : 2026-06-07 17:15:00 (UTC)
* 現象   : 2026-06-07 17:15:00 (UTC)を境に水準が 11.87から14.52へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.602, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→13→9→12→12
* 開始   : 2026-06-07 17:30:00 (UTC)
* 終了   : 2026-06-07 17:30:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 8→9→5→9→…→9→11→9→8
* 開始   : 2026-06-07 22:10:00 (UTC)
* 終了   : 2026-06-07 22:35:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.285σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260607-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 8→8→4→9→9
* 開始   : 2026-06-08 23:30:00 (UTC)
* 終了   : 2026-06-08 23:30:00 (UTC)
* 現象   : 平常時(8.667)に対し 0.4615(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260608-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 8→12→14→11→11
* 開始   : 2026-06-09 03:20:00 (UTC)
* 終了   : 2026-06-09 03:20:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→14→17→14→17→14→17→15
* 開始   : 2026-06-10 05:45:00 (UTC)
* 終了   : 2026-06-10 06:50:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.291倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.698σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host11-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260610-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260610-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 21→19→23→19→19
* 開始   : 2026-06-10 08:15:00 (UTC)
* 終了   : 2026-06-10 08:35:00 (UTC)
* 現象   : 2026-06-10 08:35:00 (UTC)を境に水準が 14.95から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.81, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 20→18→24→20→19
* 開始   : 2026-06-10 09:15:00 (UTC)
* 終了   : 2026-06-10 09:15:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.258倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 20→19→24→20→22
* 開始   : 2026-06-10 09:30:00 (UTC)
* 終了   : 2026-06-10 09:30:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.226倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 19→20→25→22→22
* 開始   : 2026-06-10 10:20:00 (UTC)
* 終了   : 2026-06-10 10:20:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→14→10→15→10→15→10→13→11
* 開始   : 2026-06-10 19:15:00 (UTC)
* 終了   : 2026-06-10 19:25:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host12-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260610-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 9→9→5→7→7
* 開始   : 2026-06-10 22:55:00 (UTC)
* 終了   : 2026-06-10 22:55:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host11-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→10→13→15→…→13→15→11→12
* 開始   : 2026-06-11 03:50:00 (UTC)
* 終了   : 2026-06-11 03:55:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260611-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 16→14→19→16→16
* 開始   : 2026-06-11 06:15:00 (UTC)
* 終了   : 2026-06-11 06:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 20→18→23→21→18
* 開始   : 2026-06-11 08:40:00 (UTC)
* 終了   : 2026-06-11 08:40:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.26倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→20→24→21→21
* 開始   : 2026-06-11 08:50:00 (UTC)
* 終了   : 2026-06-11 08:50:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.28倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.685σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host11-007 active_connections の推移](charts/EVT-20260611-host11-007.svg)

# イベントID( EVT-20260611-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 19→20→14→17→16
* 開始   : 2026-06-11 16:45:00 (UTC)
* 終了   : 2026-06-11 16:45:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→14→11→13→15
* 開始   : 2026-06-11 18:40:00 (UTC)
* 終了   : 2026-06-11 18:40:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-067 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→12→9→14→12
* 開始   : 2026-06-11 19:25:00 (UTC)
* 終了   : 2026-06-11 19:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.6467(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→14→11→9→14→12→11→13
* 開始   : 2026-06-11 20:20:00 (UTC)
* 終了   : 2026-06-11 21:20:00 (UTC)
* 現象   : 2026-06-11 21:20:00 (UTC)を境に水準が 14.94から14.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.449σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.196, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 10→8→4→7→10
* 開始   : 2026-06-11 23:40:00 (UTC)
* 終了   : 2026-06-11 23:40:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→14→15→11→12→14→15→11→12
* 開始   : 2026-06-12 04:10:00 (UTC)
* 終了   : 2026-06-12 04:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.574σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 10→12→8→11→…→11→14→11→12
* 開始   : 2026-06-12 04:15:00 (UTC)
* 終了   : 2026-06-12 05:05:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111倍(8)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260612-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260612-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 22→21→25→19→23
* 開始   : 2026-06-12 10:05:00 (UTC)
* 終了   : 2026-06-12 10:05:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→14→11→16→14
* 開始   : 2026-06-12 18:15:00 (UTC)
* 終了   : 2026-06-12 18:15:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.6947(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-077 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-078 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-016 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 16→13→15→12→12→11
* 開始   : 2026-06-12 19:20:00 (UTC)
* 終了   : 2026-06-12 19:55:00 (UTC)
* 現象   : 2026-06-12 19:55:00 (UTC)を境に水準が 15.07から11.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.139σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host11-016 active_connections の推移](charts/EVT-20260612-host11-016.svg)

# イベントID( EVT-20260613-host11-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→12→10→12→…→11→10→12→11
* 開始   : 2026-06-13 04:55:00 (UTC)
* 終了   : 2026-06-13 19:55:00 (UTC)
* 現象   : 15.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.818, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260613-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.7 時間

![EVT-20260613-host11-002 active_connections の推移](charts/EVT-20260613-host11-002.svg)

# イベントID( EVT-20260613-host11-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→12→10→12→…→11→14→12→10
* 開始   : 2026-06-13 05:10:00 (UTC)
* 終了   : 2026-06-13 20:20:00 (UTC)
* 現象   : 15.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.115, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260613-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260613-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260613-host11-003 active_connections の推移](charts/EVT-20260613-host11-003.svg)

# イベントID( EVT-20260613-host11-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→12→13→10→…→10→13→10→11
* 開始   : 2026-06-13 05:20:00 (UTC)
* 終了   : 2026-06-13 19:05:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.772, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260613-host11-004 active_connections の推移](charts/EVT-20260613-host11-004.svg)

# イベントID( EVT-20260613-host11-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→15→11→13→…→9→12→13→12
* 開始   : 2026-06-13 05:35:00 (UTC)
* 終了   : 2026-06-13 18:55:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.867, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260613-host11-005 active_connections の推移](charts/EVT-20260613-host11-005.svg)

# イベントID( EVT-20260613-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→12→10→13→…→9→12→11→12
* 開始   : 2026-06-13 05:55:00 (UTC)
* 終了   : 2026-06-13 19:30:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.327, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260613-host11-006 active_connections の推移](charts/EVT-20260613-host11-006.svg)

# イベントID( EVT-20260613-host11-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→12→11→10→…→13→11→12→11
* 開始   : 2026-06-13 06:00:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.752, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260613-host11-007 active_connections の推移](charts/EVT-20260613-host11-007.svg)

# イベントID( EVT-20260614-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 8→11→4→9→9
* 開始   : 2026-06-14 01:40:00 (UTC)
* 終了   : 2026-06-14 01:40:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→13→17→15→13
* 開始   : 2026-06-14 07:35:00 (UTC)
* 終了   : 2026-06-14 07:35:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.378倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→12→9→14→14
* 開始   : 2026-06-14 16:30:00 (UTC)
* 終了   : 2026-06-14 16:30:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.167σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→13→18→14→15
* 開始   : 2026-06-16 05:25:00 (UTC)
* 終了   : 2026-06-16 05:25:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.403倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-023 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host11-002 active_connections の推移](charts/EVT-20260616-host11-002.svg)

# イベントID( EVT-20260616-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 16→16→21→17→16
* 開始   : 2026-06-16 07:25:00 (UTC)
* 終了   : 2026-06-16 07:25:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.306倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 20→19→16→20→21
* 開始   : 2026-06-16 15:20:00 (UTC)
* 終了   : 2026-06-16 15:20:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.7742(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 18→17→14→19→17
* 開始   : 2026-06-16 16:10:00 (UTC)
* 終了   : 2026-06-16 16:10:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.109σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→16→12→13→…→13→10→13→16
* 開始   : 2026-06-16 18:25:00 (UTC)
* 終了   : 2026-06-16 18:35:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260616-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260616-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 12→11→8→10→11
* 開始   : 2026-06-16 20:05:00 (UTC)
* 終了   : 2026-06-16 20:05:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.6443(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260616-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→17→21→18→18
* 開始   : 2026-06-17 07:35:00 (UTC)
* 終了   : 2026-06-17 07:35:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 17→19→23→19→20
* 開始   : 2026-06-17 08:45:00 (UTC)
* 終了   : 2026-06-17 08:45:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-035 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260617-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 17→20→23→19→21
* 開始   : 2026-06-17 08:55:00 (UTC)
* 終了   : 2026-06-17 08:55:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→15→12→16→17
* 開始   : 2026-06-17 17:15:00 (UTC)
* 終了   : 2026-06-17 17:15:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.7024(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.578σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host11-012 active_connections の推移](charts/EVT-20260617-host11-012.svg)

# イベントID( EVT-20260617-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 17→16→12→16→16
* 開始   : 2026-06-17 17:50:00 (UTC)
* 終了   : 2026-06-17 17:50:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.72(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→10→7→10→12
* 開始   : 2026-06-17 20:15:00 (UTC)
* 終了   : 2026-06-17 20:15:00 (UTC)
* 現象   : 平常時(12)に対し 0.5833(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.498σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-077 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→7→4→10→8
* 開始   : 2026-06-17 23:20:00 (UTC)
* 終了   : 2026-06-17 23:20:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host02-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host11-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→9→13→9→9
* 開始   : 2026-06-18 02:40:00 (UTC)
* 終了   : 2026-06-18 02:40:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→15→20→16→17
* 開始   : 2026-06-18 06:55:00 (UTC)
* 終了   : 2026-06-18 06:55:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→18→21→16→…→16→20→16→15
* 開始   : 2026-06-18 07:10:00 (UTC)
* 終了   : 2026-06-18 07:20:00 (UTC)
* 現象   : 平常時(16)に対し 1.312倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260618-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260618-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→13→10→12→14
* 開始   : 2026-06-18 18:55:00 (UTC)
* 終了   : 2026-06-18 18:55:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.6857(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260618-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 8→8→4→8→7
* 開始   : 2026-06-18 23:10:00 (UTC)
* 終了   : 2026-06-18 23:10:00 (UTC)
* 現象   : 平常時(8.583)に対し 0.466(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.226σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 21→20→21→19→20→21→23→22→21
* 開始   : 2026-06-19 08:25:00 (UTC)
* 終了   : 2026-06-19 10:10:00 (UTC)
* 現象   : 2026-06-19 10:10:00 (UTC)を境に水準が 15.03から14へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.26, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→9→5→10→10
* 開始   : 2026-06-19 22:10:00 (UTC)
* 終了   : 2026-06-19 22:10:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→10→12→13→…→11→13→10→11
* 開始   : 2026-06-20 04:50:00 (UTC)
* 終了   : 2026-06-20 19:10:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.853, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.2 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260620-host11-002 active_connections の推移](charts/EVT-20260620-host11-002.svg)

# イベントID( EVT-20260620-host11-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→9→11→10→…→12→10→13→12
* 開始   : 2026-06-20 04:55:00 (UTC)
* 終了   : 2026-06-20 18:55:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.006, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.0 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260620-host11-003 active_connections の推移](charts/EVT-20260620-host11-003.svg)

# イベントID( EVT-20260620-host11-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→14→13→14→…→9→12→13→11
* 開始   : 2026-06-20 05:15:00 (UTC)
* 終了   : 2026-06-20 19:05:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.897, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host11-004 active_connections の推移](charts/EVT-20260620-host11-004.svg)

# イベントID( EVT-20260620-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→13→12→14→…→12→9→12→11
* 開始   : 2026-06-20 05:25:00 (UTC)
* 終了   : 2026-06-20 19:15:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.009, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host11-005 active_connections の推移](charts/EVT-20260620-host11-005.svg)

# イベントID( EVT-20260620-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→12→13→12→…→12→10→12→10
* 開始   : 2026-06-20 05:25:00 (UTC)
* 終了   : 2026-06-20 19:35:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.461σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.737, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260620-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260620-host11-006 active_connections の推移](charts/EVT-20260620-host11-006.svg)

# イベントID( EVT-20260620-host11-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→15→10→14→…→11→13→11→12
* 開始   : 2026-06-20 06:35:00 (UTC)
* 終了   : 2026-06-20 18:20:00 (UTC)
* 現象   : 11.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.956, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間

![EVT-20260620-host11-007 active_connections の推移](charts/EVT-20260620-host11-007.svg)

# イベントID( EVT-20260620-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 9→9→5→10→10
* 開始   : 2026-06-20 21:40:00 (UTC)
* 終了   : 2026-06-20 21:40:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 8→11→15→12→12
* 開始   : 2026-06-21 05:35:00 (UTC)
* 終了   : 2026-06-21 05:35:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.452倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 13→11→17→14→13
* 開始   : 2026-06-21 06:55:00 (UTC)
* 終了   : 2026-06-21 06:55:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.437倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→13→18→14→14
* 開始   : 2026-06-21 08:25:00 (UTC)
* 終了   : 2026-06-21 08:25:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.376倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.461σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260621-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260621-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260621-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→16→19→12→…→19→12→13→14
* 開始   : 2026-06-21 15:15:00 (UTC)
* 終了   : 2026-06-21 15:50:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.281倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.915σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260621-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host11-014 active_connections の推移](charts/EVT-20260621-host11-014.svg)

# イベントID( EVT-20260621-host11-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 9→10→6→12→9
* 開始   : 2026-06-21 19:55:00 (UTC)
* 終了   : 2026-06-21 19:55:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.5714(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host11-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→18→15→17→18→15→17→16→14
* 開始   : 2026-06-23 05:55:00 (UTC)
* 終了   : 2026-06-23 06:05:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260623-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 18→18→20→17→17
* 開始   : 2026-06-23 06:55:00 (UTC)
* 終了   : 2026-06-23 06:55:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→15→19→21→…→19→21→18→19
* 開始   : 2026-06-23 07:15:00 (UTC)
* 終了   : 2026-06-23 07:20:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260623-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260623-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→13→17→13→13
* 開始   : 2026-06-24 04:35:00 (UTC)
* 終了   : 2026-06-24 04:35:00 (UTC)
* 現象   : 平常時(12)に対し 1.417倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host11-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→15→18→14→14
* 開始   : 2026-06-24 05:50:00 (UTC)
* 終了   : 2026-06-24 05:50:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.05σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 18→18→16→16→17→19→21→18→18
* 開始   : 2026-06-24 06:35:00 (UTC)
* 終了   : 2026-06-24 07:20:00 (UTC)
* 現象   : 2026-06-24 07:20:00 (UTC)を境に水準が 15から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→13→8→10→13→8→10→14
* 開始   : 2026-06-24 20:25:00 (UTC)
* 終了   : 2026-06-24 20:30:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260624-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→10→14→11→11
* 開始   : 2026-06-25 03:15:00 (UTC)
* 終了   : 2026-06-25 03:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 1.5倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host11-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→12→13→12→11→12→13→14→16
* 開始   : 2026-06-25 04:15:00 (UTC)
* 終了   : 2026-06-25 05:20:00 (UTC)
* 現象   : 2026-06-25 05:20:00 (UTC)を境に水準が 14.94から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.672σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.067, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→17→11→15→15
* 開始   : 2026-06-25 18:10:00 (UTC)
* 終了   : 2026-06-25 18:10:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→14→10→13→12
* 開始   : 2026-06-25 19:10:00 (UTC)
* 終了   : 2026-06-25 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.035σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→13→9→12→11
* 開始   : 2026-06-25 19:35:00 (UTC)
* 終了   : 2026-06-25 19:35:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host14-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-015 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→13→11
* 開始   : 2026-06-25 20:00:00 (UTC)
* 終了   : 2026-06-25 20:35:00 (UTC)
* 現象   : 2026-06-25 20:35:00 (UTC)を境に水準が 14.89から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.086, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 10→10→6→8→9
* 開始   : 2026-06-25 21:35:00 (UTC)
* 終了   : 2026-06-25 21:35:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-082 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host11-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→15→18→15→15
* 開始   : 2026-06-26 06:05:00 (UTC)
* 終了   : 2026-06-26 06:05:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260626-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 18→19→24→19→22
* 開始   : 2026-06-26 09:00:00 (UTC)
* 終了   : 2026-06-26 09:00:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.236倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 22→23→17→20→21
* 開始   : 2026-06-26 14:45:00 (UTC)
* 終了   : 2026-06-26 14:45:00 (UTC)
* 現象   : 平常時(21.58)に対し 0.7876(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 19→22→16→18→19
* 開始   : 2026-06-26 15:35:00 (UTC)
* 終了   : 2026-06-26 15:35:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.7589(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.56σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 19→18→12→16→15
* 開始   : 2026-06-26 17:10:00 (UTC)
* 終了   : 2026-06-26 17:10:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.6698(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260626-host11-013 active_connections の推移](charts/EVT-20260626-host11-013.svg)

# イベントID( EVT-20260626-host11-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→12→8→12→11
* 開始   : 2026-06-26 20:15:00 (UTC)
* 終了   : 2026-06-26 20:15:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host11-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 10→12→10→12→…→13→11→12→13
* 開始   : 2026-06-27 05:10:00 (UTC)
* 終了   : 2026-06-27 18:00:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.03, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260627-host11-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260627-host11-002 active_connections の推移](charts/EVT-20260627-host11-002.svg)

# イベントID( EVT-20260627-host11-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→12→10→12→…→12→11→12→10
* 開始   : 2026-06-27 05:45:00 (UTC)
* 終了   : 2026-06-27 18:45:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.633, 限界=2.688)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260627-host11-004 active_connections の推移](charts/EVT-20260627-host11-004.svg)

# イベントID( EVT-20260627-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→10→11→10→…→11→10→13→10
* 開始   : 2026-06-27 05:45:00 (UTC)
* 終了   : 2026-06-27 18:55:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.834, 限界=2.684)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260627-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host11-005 active_connections の推移](charts/EVT-20260627-host11-005.svg)

# イベントID( EVT-20260627-host11-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→12→…→11→10→9→11
* 開始   : 2026-06-27 06:00:00 (UTC)
* 終了   : 2026-06-27 19:35:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.741, 限界=2.689)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260627-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260627-host11-006 active_connections の推移](charts/EVT-20260627-host11-006.svg)

# イベントID( EVT-20260627-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 13→12→13→11→…→11→12→13→10
* 開始   : 2026-06-27 06:05:00 (UTC)
* 終了   : 2026-06-27 19:30:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.447, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host11-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260627-host11-007 active_connections の推移](charts/EVT-20260627-host11-007.svg)

# イベントID( EVT-20260627-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→12→14→11→…→12→7→11→12
* 開始   : 2026-06-27 06:50:00 (UTC)
* 終了   : 2026-06-27 19:30:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.285σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.015, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host11-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host11-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host11-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260627-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260627-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260627-host11-008 active_connections の推移](charts/EVT-20260627-host11-008.svg)

# イベントID( EVT-20260630-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→13→15→11→12
* 開始   : 2026-06-30 04:10:00 (UTC)
* 終了   : 2026-06-30 04:10:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→19→23→21→23→21→23→18→21
* 開始   : 2026-06-30 08:35:00 (UTC)
* 終了   : 2026-06-30 09:40:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260630-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260630-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→12→7→9→10
* 開始   : 2026-06-30 20:20:00 (UTC)
* 終了   : 2026-06-30 20:20:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.5676(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.754σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host11-009 active_connections の推移](charts/EVT-20260630-host11-009.svg)

# イベントID( EVT-20260630-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→11→7→10→9
* 開始   : 2026-06-30 20:55:00 (UTC)
* 終了   : 2026-06-30 20:55:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→14→16→17→16→17→13→16
* 開始   : 2026-06-01 05:45:00 (UTC)
* 終了   : 2026-06-01 05:55:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→14→17→16→14→17→16→15
* 開始   : 2026-06-01 05:55:00 (UTC)
* 終了   : 2026-06-01 06:00:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 16→19→20→17→16→19→20→17→19
* 開始   : 2026-06-01 07:20:00 (UTC)
* 終了   : 2026-06-01 07:25:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 20→19→21→18→…→18→22→20→19
* 開始   : 2026-06-01 08:15:00 (UTC)
* 終了   : 2026-06-01 08:25:00 (UTC)
* 現象   : 平常時(18)に対し 1.167倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260601-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260601-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→16→14→17→14→17→14→15
* 開始   : 2026-06-01 17:25:00 (UTC)
* 終了   : 2026-06-01 17:35:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-050 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→16→13→16→13→15→13→15
* 開始   : 2026-06-01 17:45:00 (UTC)
* 終了   : 2026-06-01 17:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.749σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260601-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260601-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 7→11→13→8→13→8→13→11
* 開始   : 2026-06-02 03:15:00 (UTC)
* 終了   : 2026-06-02 03:25:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.405倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.626σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-011 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260602-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 21→20→23→17→19→20→23→17→19
* 開始   : 2026-06-02 09:15:00 (UTC)
* 終了   : 2026-06-02 09:20:00 (UTC)
* 現象   : 平常時(19.92)に対し 1.155倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260602-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 20→23→21→23→21→23→21→20
* 開始   : 2026-06-02 09:35:00 (UTC)
* 終了   : 2026-06-02 09:45:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-039 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260602-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260602-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→12→14→13→13
* 開始   : 2026-06-03 03:50:00 (UTC)
* 終了   : 2026-06-03 04:10:00 (UTC)
* 現象   : 2026-06-03 04:10:00 (UTC)を境に水準が 14.9から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.81, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 22→23→23→21→23→21→23→23→24
* 開始   : 2026-06-03 11:35:00 (UTC)
* 終了   : 2026-06-03 12:30:00 (UTC)
* 現象   : 2026-06-03 12:30:00 (UTC)を境に水準が 15.04から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.324, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 23→21→22→21→22→21→22→22→22
* 開始   : 2026-06-03 13:35:00 (UTC)
* 終了   : 2026-06-03 14:40:00 (UTC)
* 現象   : 2026-06-03 14:40:00 (UTC)を境に水準が 14.98から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.644, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 20→18→17→18→20→18→17→18→20
* 開始   : 2026-06-03 15:10:00 (UTC)
* 終了   : 2026-06-03 15:15:00 (UTC)
* 現象   : 平常時(21.17)に対し 0.8504(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-046 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260603-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 20→17→18→20→17→18→20
* 開始   : 2026-06-03 15:50:00 (UTC)
* 終了   : 2026-06-03 15:55:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-046 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260603-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 20→18→17
* 開始   : 2026-06-03 16:45:00 (UTC)
* 終了   : 2026-06-03 16:55:00 (UTC)
* 現象   : 2026-06-03 16:55:00 (UTC)を境に水準が 14.94から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.086, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→13→11→11→15
* 開始   : 2026-06-03 20:10:00 (UTC)
* 終了   : 2026-06-03 20:30:00 (UTC)
* 現象   : 2026-06-03 20:30:00 (UTC)を境に水準が 15.08から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→12→12→11→13
* 開始   : 2026-06-03 20:10:00 (UTC)
* 終了   : 2026-06-03 20:40:00 (UTC)
* 現象   : 2026-06-03 20:40:00 (UTC)を境に水準が 14.96から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host11-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→11→10→11→9→11→12→10→12
* 開始   : 2026-06-03 20:40:00 (UTC)
* 終了   : 2026-06-03 21:30:00 (UTC)
* 現象   : 2026-06-03 21:30:00 (UTC)を境に水準が 14.96から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.644, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→14→15→13→11→14→15→13→11
* 開始   : 2026-06-04 04:20:00 (UTC)
* 終了   : 2026-06-04 04:25:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260604-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→15→16→14→13→15→16→14
* 開始   : 2026-06-04 04:40:00 (UTC)
* 終了   : 2026-06-04 04:45:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 17→16→18→19→16→18→19→16→18
* 開始   : 2026-06-04 06:20:00 (UTC)
* 終了   : 2026-06-04 06:25:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260604-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 21→22→23→23→21→21→22
* 開始   : 2026-06-04 13:10:00 (UTC)
* 終了   : 2026-06-04 13:40:00 (UTC)
* 現象   : 2026-06-04 13:40:00 (UTC)を境に水準が 15.03から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.534, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→16→14→15→14→15→14→16→15
* 開始   : 2026-06-04 17:20:00 (UTC)
* 終了   : 2026-06-04 17:30:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7925(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→13→11→13→11→13→11
* 開始   : 2026-06-04 18:55:00 (UTC)
* 終了   : 2026-06-04 19:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 12→10→9→12→…→12→8→9→12
* 開始   : 2026-06-04 20:25:00 (UTC)
* 終了   : 2026-06-04 20:35:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260604-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260604-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→10→8→15→10→8→15→10→9
* 開始   : 2026-06-04 20:45:00 (UTC)
* 終了   : 2026-06-04 21:10:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007倍(8)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.399σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260604-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260604-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host11-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 10→10→10→11→11→10→8→10→10
* 開始   : 2026-06-04 21:20:00 (UTC)
* 終了   : 2026-06-04 22:00:00 (UTC)
* 現象   : 2026-06-04 22:00:00 (UTC)を境に水準が 15.01から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.493, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→10→14→11→…→7→10→14→11
* 開始   : 2026-06-05 03:40:00 (UTC)
* 終了   : 2026-06-05 04:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.856σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-007 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260605-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260605-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 21→22→23→20→21→22
* 開始   : 2026-06-05 09:15:00 (UTC)
* 終了   : 2026-06-05 09:40:00 (UTC)
* 現象   : 2026-06-05 09:40:00 (UTC)を境に水準が 14.98から13.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 17→18→14→13→14→18→14→13→14
* 開始   : 2026-06-05 17:35:00 (UTC)
* 終了   : 2026-06-05 17:40:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260605-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→14→11→14→11→13
* 開始   : 2026-06-05 19:00:00 (UTC)
* 終了   : 2026-06-05 19:10:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host03-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→7→14→10→11→7→14→10→8
* 開始   : 2026-06-05 20:50:00 (UTC)
* 終了   : 2026-06-05 20:55:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.6316(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.856σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-075 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 9→9→9→8→11→8→8→10
* 開始   : 2026-06-07 00:40:00 (UTC)
* 終了   : 2026-06-07 01:15:00 (UTC)
* 現象   : 2026-06-07 01:15:00 (UTC)を境に水準が 11.72から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.896, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 10→7→12→13→…→12→13→10→11
* 開始   : 2026-06-07 04:25:00 (UTC)
* 終了   : 2026-06-07 04:30:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-011 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分

![EVT-20260607-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 16→19→13→15→16→19→13→15→14
* 開始   : 2026-06-07 12:35:00 (UTC)
* 終了   : 2026-06-07 12:40:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→14→10→12→…→12→9→13→11
* 開始   : 2026-06-07 17:35:00 (UTC)
* 終了   : 2026-06-07 17:45:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host11-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→10→9→11→10→9→10→7→10
* 開始   : 2026-06-07 20:25:00 (UTC)
* 終了   : 2026-06-07 22:00:00 (UTC)
* 現象   : 2026-06-07 22:00:00 (UTC)を境に水準が 11.82から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.541, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 18→15→21→19→15→21→19→18
* 開始   : 2026-06-09 07:50:00 (UTC)
* 終了   : 2026-06-09 07:55:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.248倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.933σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 21→18→20→18→20→18→19→18
* 開始   : 2026-06-09 14:55:00 (UTC)
* 終了   : 2026-06-09 15:05:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260609-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 17→15→20→15→20→15→18→19
* 開始   : 2026-06-09 16:40:00 (UTC)
* 終了   : 2026-06-09 16:50:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.786(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.874σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260609-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 14→11→12→14→11→12→16
* 開始   : 2026-06-09 18:55:00 (UTC)
* 終了   : 2026-06-09 19:00:00 (UTC)
* 現象   : 平常時(14.58)に対し 0.7543(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→14→9→11→8→9→11→8→11
* 開始   : 2026-06-09 20:10:00 (UTC)
* 終了   : 2026-06-09 20:20:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.7059(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 10→10→10→10→9
* 開始   : 2026-06-09 23:00:00 (UTC)
* 終了   : 2026-06-09 23:20:00 (UTC)
* 現象   : 2026-06-09 23:20:00 (UTC)を境に水準が 14.89から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.385, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→13→14→13→14→13→12
* 開始   : 2026-06-10 03:55:00 (UTC)
* 終了   : 2026-06-10 04:05:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→17→14→17→14
* 開始   : 2026-06-10 06:10:00 (UTC)
* 終了   : 2026-06-10 06:15:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.244倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host12-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 16→17→18→14→18→14→18→17→16
* 開始   : 2026-06-10 06:30:00 (UTC)
* 終了   : 2026-06-10 06:40:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 20→22→24→21→24→21→24→22→21
* 開始   : 2026-06-10 10:55:00 (UTC)
* 終了   : 2026-06-10 11:05:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.176倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.514σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 24→23→22→24→23→23→22→21→22
* 開始   : 2026-06-10 12:45:00 (UTC)
* 終了   : 2026-06-10 14:35:00 (UTC)
* 現象   : 2026-06-10 14:35:00 (UTC)を境に水準が 14.89から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.61, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 19→20→16→19→16→19→16→17→19
* 開始   : 2026-06-10 15:35:00 (UTC)
* 終了   : 2026-06-10 15:45:00 (UTC)
* 現象   : 平常時(20)に対し 0.8(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.808σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260610-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 20→19→16→18→19→18→18→16→19
* 開始   : 2026-06-10 16:20:00 (UTC)
* 終了   : 2026-06-10 17:25:00 (UTC)
* 現象   : 2026-06-10 17:25:00 (UTC)を境に水準が 15.04から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.343, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 16→14→10→13→14→10→13→11
* 開始   : 2026-06-10 19:10:00 (UTC)
* 終了   : 2026-06-10 19:15:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.7273(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.633σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host11-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 8→7→11→5→…→11→5→9→7
* 開始   : 2026-06-10 23:55:00 (UTC)
* 終了   : 2026-06-11 00:00:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.112σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host11-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→10→9→6→11→8→10→10
* 開始   : 2026-06-11 01:00:00 (UTC)
* 終了   : 2026-06-11 02:20:00 (UTC)
* 現象   : 2026-06-11 02:20:00 (UTC)を境に水準が 14.94から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→17→16→15→16→16→17
* 開始   : 2026-06-11 05:35:00 (UTC)
* 終了   : 2026-06-11 06:05:00 (UTC)
* 現象   : 2026-06-11 06:05:00 (UTC)を境に水準が 14.92から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.939, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→13→14→16
* 開始   : 2026-06-11 19:00:00 (UTC)
* 終了   : 2026-06-11 19:15:00 (UTC)
* 現象   : 2026-06-11 19:15:00 (UTC)を境に水準が 14.98から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.448, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 8→11→8→11→8→11→10→9
* 開始   : 2026-06-12 01:05:00 (UTC)
* 終了   : 2026-06-12 01:15:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→12→13→9→13→15
* 開始   : 2026-06-12 03:25:00 (UTC)
* 終了   : 2026-06-12 03:50:00 (UTC)
* 現象   : 2026-06-12 03:50:00 (UTC)を境に水準が 14.96から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→10→13→11→10→13→11→8
* 開始   : 2026-06-12 03:30:00 (UTC)
* 終了   : 2026-06-12 03:35:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 14→16→15→14→16→16→16→16→17
* 開始   : 2026-06-12 05:00:00 (UTC)
* 終了   : 2026-06-12 06:20:00 (UTC)
* 現象   : 2026-06-12 06:20:00 (UTC)を境に水準が 14.97から14.78へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.153, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→16→19→17→16→19→17→14
* 開始   : 2026-06-12 06:10:00 (UTC)
* 終了   : 2026-06-12 06:15:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.274倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.859σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-034 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 14→15→17→15→18→17→15→18→16
* 開始   : 2026-06-12 06:25:00 (UTC)
* 終了   : 2026-06-12 06:35:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-036 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-035 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 18→15→19→16→…→19→16→20→18
* 開始   : 2026-06-12 07:10:00 (UTC)
* 終了   : 2026-06-12 07:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-042 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 22→23→21→23→22→23
* 開始   : 2026-06-12 09:20:00 (UTC)
* 終了   : 2026-06-12 09:45:00 (UTC)
* 現象   : 2026-06-12 09:45:00 (UTC)を境に水準が 15.05から14.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 24→24→22→23→21→22→24→23→21
* 開始   : 2026-06-12 12:35:00 (UTC)
* 終了   : 2026-06-12 14:15:00 (UTC)
* 現象   : 2026-06-12 14:15:00 (UTC)を境に水準が 14.95から12.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.138, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 19→20→16→17→20→16→17
* 開始   : 2026-06-12 16:20:00 (UTC)
* 終了   : 2026-06-12 16:25:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 16→15→13→12→…→12→14→12→14
* 開始   : 2026-06-12 18:10:00 (UTC)
* 終了   : 2026-06-12 18:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-015 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260612-lsfhost01-077 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-079 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260612-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-078 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-080 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260612-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 12→10→9→14→12→10→9→14→12
* 開始   : 2026-06-12 19:30:00 (UTC)
* 終了   : 2026-06-12 19:35:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host11-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→9→7→10→6→7→10→6→8
* 開始   : 2026-06-12 21:25:00 (UTC)
* 終了   : 2026-06-12 21:35:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-019 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-lsfhost01-090 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260612-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host11-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host11-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→10→8→11→…→11→7→9→8
* 開始   : 2026-06-12 21:30:00 (UTC)
* 終了   : 2026-06-12 21:40:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-018 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host16-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-090 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260612-host11-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host11-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 8→10→7→9→…→7→9→12→10
* 開始   : 2026-06-13 03:50:00 (UTC)
* 終了   : 2026-06-13 03:55:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.123, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260613-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260613-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 10→10→11→9→8→9→8→9→11
* 開始   : 2026-06-14 01:30:00 (UTC)
* 終了   : 2026-06-14 02:15:00 (UTC)
* 現象   : 2026-06-14 02:15:00 (UTC)を境に水準が 11.74から11.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.003, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 12→12→12→11→14→12→12→13→12
* 開始   : 2026-06-14 05:25:00 (UTC)
* 終了   : 2026-06-14 06:15:00 (UTC)
* 現象   : 2026-06-14 06:15:00 (UTC)を境に水準が 11.97から12.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.644, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 16→15→18→12→15→18→12→15
* 開始   : 2026-06-14 14:20:00 (UTC)
* 終了   : 2026-06-14 14:25:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260614-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→13→9→13→9→13→9→12→10
* 開始   : 2026-06-14 18:05:00 (UTC)
* 終了   : 2026-06-14 18:15:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→9→8→11→9→9→7→9→10
* 開始   : 2026-06-14 20:25:00 (UTC)
* 終了   : 2026-06-14 22:15:00 (UTC)
* 現象   : 2026-06-14 22:15:00 (UTC)を境に水準が 11.84から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.325, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 10→9→9→9→7→9→8→9→10
* 開始   : 2026-06-15 23:55:00 (UTC)
* 終了   : 2026-06-16 00:35:00 (UTC)
* 現象   : 2026-06-16 00:35:00 (UTC)を境に水準が 14.93から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 9→13→10→13→10→13→12→9
* 開始   : 2026-06-16 03:25:00 (UTC)
* 終了   : 2026-06-16 03:35:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-012 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-013 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260616-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 17→18→20→16→20→16→20→17→19
* 開始   : 2026-06-16 07:45:00 (UTC)
* 終了   : 2026-06-16 07:55:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.522σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分

![EVT-20260616-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 19→18→16→18→…→18→15→16→17
* 開始   : 2026-06-16 16:30:00 (UTC)
* 終了   : 2026-06-16 16:40:00 (UTC)
* 現象   : 平常時(19)に対し 0.8421(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→10→12→10→12→13
* 開始   : 2026-06-16 19:45:00 (UTC)
* 終了   : 2026-06-16 19:50:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260616-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 10→11→6→13→11→6→13→11
* 開始   : 2026-06-17 02:55:00 (UTC)
* 終了   : 2026-06-17 03:00:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.6102(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.689σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→11→13→14→11→13→14→11→10
* 開始   : 2026-06-17 03:20:00 (UTC)
* 終了   : 2026-06-17 03:25:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.322倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.218σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host11-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 10→11→13→14→11→13→14→11→10
* 開始   : 2026-06-17 03:25:00 (UTC)
* 終了   : 2026-06-17 03:30:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host11-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 13→14→19→15→14→19→15→16
* 開始   : 2026-06-17 06:30:00 (UTC)
* 終了   : 2026-06-17 06:35:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.288倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.981σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→17→18→17→19→18→17→17→20
* 開始   : 2026-06-17 06:45:00 (UTC)
* 終了   : 2026-06-17 09:25:00 (UTC)
* 現象   : 2026-06-17 09:25:00 (UTC)を境に水準が 14.96から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.257, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 21→21→22
* 開始   : 2026-06-17 08:20:00 (UTC)
* 終了   : 2026-06-17 08:30:00 (UTC)
* 現象   : 2026-06-17 08:30:00 (UTC)を境に水準が 14.88から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.601, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 22→22→21→22→22→24
* 開始   : 2026-06-17 09:50:00 (UTC)
* 終了   : 2026-06-17 10:15:00 (UTC)
* 現象   : 2026-06-17 10:15:00 (UTC)を境に水準が 14.93から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.2, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 22→20→20→19→21→20→19→23→20
* 開始   : 2026-06-17 15:00:00 (UTC)
* 終了   : 2026-06-17 15:45:00 (UTC)
* 現象   : 2026-06-17 15:45:00 (UTC)を境に水準が 14.97から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host11-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→10→9→11→9→11→9→13→10
* 開始   : 2026-06-17 20:30:00 (UTC)
* 終了   : 2026-06-17 20:40:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-lsfhost01-078 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-079 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260617-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 10→9→11→9→11→9→11→9→10
* 開始   : 2026-06-18 01:50:00 (UTC)
* 終了   : 2026-06-18 02:00:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.398σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→13→15→11→…→11→16→13→12
* 開始   : 2026-06-18 04:55:00 (UTC)
* 終了   : 2026-06-18 05:05:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.304倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.457σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260618-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260618-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→18→20→15→…→15→21→18→19
* 開始   : 2026-06-18 07:35:00 (UTC)
* 終了   : 2026-06-18 07:45:00 (UTC)
* 現象   : 平常時(17.08)に対し 1.171倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.053σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260618-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 22→23→23→20→22→21→23→23
* 開始   : 2026-06-18 13:40:00 (UTC)
* 終了   : 2026-06-18 14:15:00 (UTC)
* 現象   : 2026-06-18 14:15:00 (UTC)を境に水準が 15.03から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.216, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 19→21→17→19→…→18→19→16→18
* 開始   : 2026-06-18 15:30:00 (UTC)
* 終了   : 2026-06-18 15:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.163σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host02-010 (他ホスト) jvm_gc / ou : WARN / 重なり 10 分
  - EVT-20260618-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 17→19→15→17→15→17→15→18→19
* 開始   : 2026-06-18 16:35:00 (UTC)
* 終了   : 2026-06-18 16:45:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 16→17→13→16→13→16→13→16→14
* 開始   : 2026-06-18 17:35:00 (UTC)
* 終了   : 2026-06-18 17:45:00 (UTC)
* 現象   : 平常時(16.67)に対し 0.78(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 8→5→8→11→5→8→11→8
* 開始   : 2026-06-18 23:20:00 (UTC)
* 終了   : 2026-06-18 23:30:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.6(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260618-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 13→12→17→14→12→17→14
* 開始   : 2026-06-19 05:25:00 (UTC)
* 終了   : 2026-06-19 05:30:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.316倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.874σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→17→15→14→17→15→14
* 開始   : 2026-06-19 05:50:00 (UTC)
* 終了   : 2026-06-19 05:55:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260619-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 24→20→21→22→22→23→21→21→22
* 開始   : 2026-06-19 13:00:00 (UTC)
* 終了   : 2026-06-19 13:55:00 (UTC)
* 現象   : 2026-06-19 13:55:00 (UTC)を境に水準が 15から12.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.343, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→17→16→18→17→16→18→19
* 開始   : 2026-06-19 15:30:00 (UTC)
* 終了   : 2026-06-19 15:35:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host11-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260619-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260619-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→19→16→19→…→19→22→18→21
* 開始   : 2026-06-19 15:30:00 (UTC)
* 終了   : 2026-06-19 15:40:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.817(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host11-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-lsfhost01-047 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260619-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 18→19→22→16→…→22→16→18→17
* 開始   : 2026-06-19 16:30:00 (UTC)
* 終了   : 2026-06-19 16:35:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.405σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-052 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 17→18→15→18→15→17
* 開始   : 2026-06-19 16:50:00 (UTC)
* 終了   : 2026-06-19 16:55:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 13→11→9→11→9→11
* 開始   : 2026-06-19 20:25:00 (UTC)
* 終了   : 2026-06-19 20:30:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-lsfhost01-074 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260619-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 9→8→5→6→11→5→6→11→9
* 開始   : 2026-06-19 23:40:00 (UTC)
* 終了   : 2026-06-19 23:50:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 9→8→12→10→12→10→12→10→8
* 開始   : 2026-06-20 03:00:00 (UTC)
* 終了   : 2026-06-20 03:10:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260620-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 10→6→8→10→7→8→10→7→11
* 開始   : 2026-06-21 00:25:00 (UTC)
* 終了   : 2026-06-21 01:35:00 (UTC)
* 現象   : 2026-06-21 01:35:00 (UTC)を境に水準が 11.84から11.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.155, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 8→10→9→10→12→9
* 開始   : 2026-06-21 01:40:00 (UTC)
* 終了   : 2026-06-21 02:05:00 (UTC)
* 現象   : 2026-06-21 02:05:00 (UTC)を境に水準が 11.8から11.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 11→11→12→10→11→12→12→12→15
* 開始   : 2026-06-21 04:25:00 (UTC)
* 終了   : 2026-06-21 05:10:00 (UTC)
* 現象   : 2026-06-21 05:10:00 (UTC)を境に水準が 11.81から12.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.619, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→13→10→12→12
* 開始   : 2026-06-21 04:25:00 (UTC)
* 終了   : 2026-06-21 04:45:00 (UTC)
* 現象   : 2026-06-21 04:45:00 (UTC)を境に水準が 11.76から11.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.001, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 14→14→14→14→14→15→15
* 開始   : 2026-06-21 07:00:00 (UTC)
* 終了   : 2026-06-21 07:30:00 (UTC)
* 現象   : 2026-06-21 07:30:00 (UTC)を境に水準が 11.83から12.34へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.939, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 15→18→15→17→16→17
* 開始   : 2026-06-21 10:35:00 (UTC)
* 終了   : 2026-06-21 11:00:00 (UTC)
* 現象   : 2026-06-21 11:00:00 (UTC)を境に水準が 11.87から13.22へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 19→17→17→18→15→16→16
* 開始   : 2026-06-21 12:05:00 (UTC)
* 終了   : 2026-06-21 12:35:00 (UTC)
* 現象   : 2026-06-21 12:35:00 (UTC)を境に水準が 11.91から13.53へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.939, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 17→17→16
* 開始   : 2026-06-21 14:20:00 (UTC)
* 終了   : 2026-06-21 14:30:00 (UTC)
* 現象   : 2026-06-21 14:30:00 (UTC)を境に水準が 11.91から14.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.086, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→11→15→12→15→12→15→12→11
* 開始   : 2026-06-21 17:30:00 (UTC)
* 終了   : 2026-06-21 17:40:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260621-host11-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→14→7→9→11→14→7→9→8
* 開始   : 2026-06-21 19:20:00 (UTC)
* 終了   : 2026-06-21 19:25:00 (UTC)
* 現象   : 平常時(11)に対し 1.273倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host11-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 8→10→7→10→7→10→8
* 開始   : 2026-06-21 20:30:00 (UTC)
* 終了   : 2026-06-21 20:35:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-038 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260621-host11-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host11-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 6→11→9→11→9→11→7→10
* 開始   : 2026-06-21 23:35:00 (UTC)
* 終了   : 2026-06-21 23:45:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.483倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.522σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260621-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260621-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host11-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 12→11→14→10→11→14→10→11
* 開始   : 2026-06-23 03:15:00 (UTC)
* 終了   : 2026-06-23 03:20:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.436倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.981σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 12→11→13→12
* 開始   : 2026-06-23 03:20:00 (UTC)
* 終了   : 2026-06-23 03:35:00 (UTC)
* 現象   : 2026-06-23 03:35:00 (UTC)を境に水準が 14.96から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 18→20→21→18→…→18→22→18→19
* 開始   : 2026-06-23 08:25:00 (UTC)
* 終了   : 2026-06-23 08:35:00 (UTC)
* 現象   : 平常時(18)に対し 1.167倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.105σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 21→19→22→23→22→23→21→20
* 開始   : 2026-06-23 09:25:00 (UTC)
* 終了   : 2026-06-23 09:35:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-029 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260623-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 22→18→22→25→18→22→25→23
* 開始   : 2026-06-23 12:40:00 (UTC)
* 終了   : 2026-06-23 12:50:00 (UTC)
* 現象   : 平常時(21.83)に対し 0.8244(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.681σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-038 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-035 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 19→16→15→20→15→20→15→18→16
* 開始   : 2026-06-23 16:55:00 (UTC)
* 終了   : 2026-06-23 17:05:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→11→10→9→11→10→9→11
* 開始   : 2026-06-23 20:00:00 (UTC)
* 終了   : 2026-06-23 20:05:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 9→10→8→12→10→8→12→9
* 開始   : 2026-06-23 20:50:00 (UTC)
* 終了   : 2026-06-23 20:55:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260623-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host11-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 10→7→6→8→10→7→6→8→11
* 開始   : 2026-06-23 22:00:00 (UTC)
* 終了   : 2026-06-23 22:05:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.6942(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.165σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260623-host11-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→8→13→10→8→13→10
* 開始   : 2026-06-24 03:10:00 (UTC)
* 終了   : 2026-06-24 03:15:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→12→14→12→14→12→14
* 開始   : 2026-06-24 04:15:00 (UTC)
* 終了   : 2026-06-24 04:20:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.355倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.572σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260624-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→14→11→14
* 開始   : 2026-06-24 04:35:00 (UTC)
* 終了   : 2026-06-24 04:40:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 16→13→17→16→…→16→18→17→16
* 開始   : 2026-06-24 06:20:00 (UTC)
* 終了   : 2026-06-24 06:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260624-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→20→17→20→19→21→21→20→20
* 開始   : 2026-06-24 07:55:00 (UTC)
* 終了   : 2026-06-24 09:00:00 (UTC)
* 現象   : 2026-06-24 09:00:00 (UTC)を境に水準が 15.01から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=7.981, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→14→16→14→14→14
* 開始   : 2026-06-24 18:45:00 (UTC)
* 終了   : 2026-06-24 19:10:00 (UTC)
* 現象   : 2026-06-24 19:10:00 (UTC)を境に水準が 14.97から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.202, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 11→9→11→11→11
* 開始   : 2026-06-25 01:40:00 (UTC)
* 終了   : 2026-06-25 02:00:00 (UTC)
* 現象   : 2026-06-25 02:00:00 (UTC)を境に水準が 14.9から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 10→11→13→10→11→13→10
* 開始   : 2026-06-25 03:15:00 (UTC)
* 終了   : 2026-06-25 03:20:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.397σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host11-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 11→14→12→14→12→14→12
* 開始   : 2026-06-25 04:20:00 (UTC)
* 終了   : 2026-06-25 04:30:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→16→18→14→18→14→18→15
* 開始   : 2026-06-25 06:35:00 (UTC)
* 終了   : 2026-06-25 06:45:00 (UTC)
* 現象   : 平常時(14.92)に対し 1.207倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host11-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260625-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 17→16→19→16→19→16→18
* 開始   : 2026-06-25 06:40:00 (UTC)
* 終了   : 2026-06-25 06:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.239倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.581σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host11-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 18→21→18→21→18→21→19→20
* 開始   : 2026-06-25 08:15:00 (UTC)
* 終了   : 2026-06-25 08:25:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-033 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 22→22→22→23→20→24→22→23→24
* 開始   : 2026-06-25 11:45:00 (UTC)
* 終了   : 2026-06-25 13:05:00 (UTC)
* 現象   : 2026-06-25 13:05:00 (UTC)を境に水準が 14.98から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260625-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 18→19→16→15→…→16→15→16→18
* 開始   : 2026-06-25 16:30:00 (UTC)
* 終了   : 2026-06-25 16:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-062 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host11-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→13→9→11→13→9→11
* 開始   : 2026-06-25 20:30:00 (UTC)
* 終了   : 2026-06-25 20:35:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.229σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260625-host11-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→13→13→14
* 開始   : 2026-06-26 03:40:00 (UTC)
* 終了   : 2026-06-26 04:05:00 (UTC)
* 現象   : 2026-06-26 04:05:00 (UTC)を境に水準が 14.96から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 18→19→21→20→21→20→21→18→19
* 開始   : 2026-06-26 07:50:00 (UTC)
* 終了   : 2026-06-26 08:00:00 (UTC)
* 現象   : 平常時(17.25)に対し 1.217倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.631σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→20→22→17→22→17→22→20
* 開始   : 2026-06-26 08:35:00 (UTC)
* 終了   : 2026-06-26 08:45:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260626-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 23→22→22→21→21→22→21→23→23
* 開始   : 2026-06-26 10:55:00 (UTC)
* 終了   : 2026-06-26 13:35:00 (UTC)
* 現象   : 2026-06-26 13:35:00 (UTC)を境に水準が 14.93から13.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.944, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 20→17→18→23→17→18→23→19
* 開始   : 2026-06-26 15:55:00 (UTC)
* 終了   : 2026-06-26 16:05:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host11-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260626-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 18→19→16→20→16→20→16→19→17
* 開始   : 2026-06-26 15:55:00 (UTC)
* 終了   : 2026-06-26 16:05:00 (UTC)
* 現象   : 平常時(19.58)に対し 0.817(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.516σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host11-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260626-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260626-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 19→18→18→19→17→18→17→17→17
* 開始   : 2026-06-26 16:15:00 (UTC)
* 終了   : 2026-06-26 17:40:00 (UTC)
* 現象   : 2026-06-26 17:40:00 (UTC)を境に水準が 15.01から12.23へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.515, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host11-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 19→18→16→18→17→15→16→15→17
* 開始   : 2026-06-26 16:50:00 (UTC)
* 終了   : 2026-06-26 18:10:00 (UTC)
* 現象   : 2026-06-26 18:10:00 (UTC)を境に水準が 15.07から12.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.4, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host11-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host11-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 18→16→14→13→15→16→14→13→15
* 開始   : 2026-06-26 17:35:00 (UTC)
* 終了   : 2026-06-26 17:40:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host11-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host11-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 9→11→7→9→7→9→7→12
* 開始   : 2026-06-27 04:10:00 (UTC)
* 終了   : 2026-06-27 04:20:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.841, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260627-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260627-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 12→11→14→8→…→14→8→13→12
* 開始   : 2026-06-27 05:10:00 (UTC)
* 終了   : 2026-06-27 05:30:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.17σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.069, 限界=2.679)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host11-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分

![EVT-20260627-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host11-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 11→8→7→9→7→9→7→10
* 開始   : 2026-06-27 20:50:00 (UTC)
* 終了   : 2026-06-27 21:00:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260627-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260627-host11-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host11-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 7→9→8→10→8→10→9→9→10
* 開始   : 2026-06-27 23:45:00 (UTC)
* 終了   : 2026-06-28 01:45:00 (UTC)
* 現象   : 2026-06-28 01:45:00 (UTC)を境に水準が 11.88から11.72へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.048, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260627-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host11-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 13→14→15→13→14→14→12→13→13
* 開始   : 2026-06-28 06:15:00 (UTC)
* 終了   : 2026-06-28 06:55:00 (UTC)
* 現象   : 2026-06-28 06:55:00 (UTC)を境に水準が 11.82から12.29へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.493, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host11-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_3
* 値     : 12→10→15→12→10→15→12→15
* 開始   : 2026-06-28 06:50:00 (UTC)
* 終了   : 2026-06-28 06:55:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260628-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host11-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 15→14→13→13→14→16
* 開始   : 2026-06-28 07:30:00 (UTC)
* 終了   : 2026-06-28 07:55:00 (UTC)
* 現象   : 2026-06-28 07:55:00 (UTC)を境に水準が 11.87から12.45へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.897, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host11-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 15→17→16→16→17→18→15→18→17
* 開始   : 2026-06-28 13:10:00 (UTC)
* 終了   : 2026-06-28 13:55:00 (UTC)
* 現象   : 2026-06-28 13:55:00 (UTC)を境に水準が 11.89から13.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host11-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_4
* 値     : 14→11→14→11→14→12
* 開始   : 2026-06-28 16:30:00 (UTC)
* 終了   : 2026-06-28 16:35:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host11-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host11-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 15→14→9→13→14→9→13→11
* 開始   : 2026-06-28 17:05:00 (UTC)
* 終了   : 2026-06-28 17:10:00 (UTC)
* 現象   : 平常時(13)に対し 0.6923(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.808σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260628-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 11→14→12→14→12
* 開始   : 2026-06-28 18:00:00 (UTC)
* 終了   : 2026-06-28 18:20:00 (UTC)
* 現象   : 2026-06-28 18:20:00 (UTC)を境に水準が 11.74から14.72へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.001, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host11-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 12→11→13→10→12→12→11→12
* 開始   : 2026-06-29 20:05:00 (UTC)
* 終了   : 2026-06-29 20:40:00 (UTC)
* 現象   : 2026-06-29 20:40:00 (UTC)を境に水準が 14.79から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.794, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host11-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 10→8→7→11→10→10
* 開始   : 2026-06-29 23:55:00 (UTC)
* 終了   : 2026-06-30 00:20:00 (UTC)
* 現象   : 2026-06-30 00:20:00 (UTC)を境に水準が 14.94から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_5
* 値     : 15→18→19→15→18→19→15→18
* 開始   : 2026-06-30 06:20:00 (UTC)
* 終了   : 2026-06-30 06:25:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.522σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260630-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host11-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 16→15→18→16→15→18→16→18
* 開始   : 2026-06-30 06:35:00 (UTC)
* 終了   : 2026-06-30 06:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host11-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 17→15→18→15→18→16
* 開始   : 2026-06-30 06:35:00 (UTC)
* 終了   : 2026-06-30 06:40:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host11-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 22→21→23→20→21→24
* 開始   : 2026-06-30 09:15:00 (UTC)
* 終了   : 2026-06-30 09:40:00 (UTC)
* 現象   : 2026-06-30 09:40:00 (UTC)を境に水準が 15.1から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host11-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 19→20→23→17→20→23→17→20→19
* 開始   : 2026-06-30 15:20:00 (UTC)
* 終了   : 2026-06-30 15:25:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.145倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host11-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_2
* 値     : 19→16→18→18→17→18
* 開始   : 2026-06-30 17:05:00 (UTC)
* 終了   : 2026-06-30 18:40:00 (UTC)
* 現象   : 2026-06-30 18:40:00 (UTC)を境に水準が 15.1から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.393σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.662, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host11-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_1
* 値     : 10→9→8→9→…→9→7→9→12
* 開始   : 2026-06-30 20:55:00 (UTC)
* 終了   : 2026-06-30 21:05:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.28σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-011 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host11-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host11-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host11, port=7003, datasource=OraclePool_6
* 値     : 9→12→6→7→9→12→6→7→6
* 開始   : 2026-06-30 23:35:00 (UTC)
* 終了   : 2026-06-30 23:40:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-069 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260630-host11-012 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
