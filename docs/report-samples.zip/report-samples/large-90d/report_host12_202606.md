# host12 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host12 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 327 (SEVERE: 36, FATAL: 135, WARN: 156, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 36 | 135 | 156 | 327 | ALG-A1, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260605-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 18→17→19→18→20→18→19→19→19
* 開始   : 2026-06-05 06:45:00 (UTC)
* 終了   : 2026-06-05 07:35:00 (UTC)
* 現象   : 2026-06-05 07:35:00 (UTC)を境に水準が 14.97から14.36へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.319, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host12-003 active_connections の推移](charts/EVT-20260605-host12-003.svg)

# イベントID( EVT-20260608-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→16→14→13→…→12→14→12→13
* 開始   : 2026-06-08 02:10:00 (UTC)
* 終了   : 2026-06-08 19:40:00 (UTC)
* 現象   : 2026-06-08 19:40:00 (UTC)を境に水準が 11.81から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.707, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host12-002 active_connections の推移](charts/EVT-20260608-host12-002.svg)

# イベントID( EVT-20260608-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 14→17→16→14→…→11→13→14→11
* 開始   : 2026-06-08 02:45:00 (UTC)
* 終了   : 2026-06-08 21:10:00 (UTC)
* 現象   : 2026-06-08 21:10:00 (UTC)を境に水準が 11.96から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.022σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.924, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.74, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host12-003 active_connections の推移](charts/EVT-20260608-host12-003.svg)

# イベントID( EVT-20260608-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 16→17→16→19→…→16→15→13→16
* 開始   : 2026-06-08 03:00:00 (UTC)
* 終了   : 2026-06-08 21:05:00 (UTC)
* 現象   : 2026-06-08 21:05:00 (UTC)を境に水準が 12から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.954, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.87, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host12-004 active_connections の推移](charts/EVT-20260608-host12-004.svg)

# イベントID( EVT-20260608-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→12→13→14→…→14→13→12→13
* 開始   : 2026-06-08 03:20:00 (UTC)
* 終了   : 2026-06-08 21:00:00 (UTC)
* 現象   : 2026-06-08 21:00:00 (UTC)を境に水準が 11.79から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.662, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.738, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host12-005 active_connections の推移](charts/EVT-20260608-host12-005.svg)

# イベントID( EVT-20260608-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 16→15→16→13→…→12→14→12→13
* 開始   : 2026-06-08 03:25:00 (UTC)
* 終了   : 2026-06-08 20:50:00 (UTC)
* 現象   : 2026-06-08 20:50:00 (UTC)を境に水準が 11.97から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.809, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.986, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host12-006 active_connections の推移](charts/EVT-20260608-host12-006.svg)

# イベントID( EVT-20260608-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→11→17→14→…→12→14→13→14
* 開始   : 2026-06-08 03:35:00 (UTC)
* 終了   : 2026-06-08 22:05:00 (UTC)
* 現象   : 2026-06-08 22:05:00 (UTC)を境に水準が 11.86から14.85へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.649, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.32, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host12-007 active_connections の推移](charts/EVT-20260608-host12-007.svg)

# イベントID( EVT-20260610-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→15→13→13
* 開始   : 2026-06-10 03:55:00 (UTC)
* 終了   : 2026-06-10 04:10:00 (UTC)
* 現象   : 2026-06-10 04:10:00 (UTC)を境に水準が 14.97から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.84, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host12-002 active_connections の推移](charts/EVT-20260610-host12-002.svg)

# イベントID( EVT-20260614-host12-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→16→16→15→15
* 開始   : 2026-06-14 10:15:00 (UTC)
* 終了   : 2026-06-14 10:35:00 (UTC)
* 現象   : 2026-06-14 10:35:00 (UTC)を境に水準が 11.81から12.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.054, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host12-007 active_connections の推移](charts/EVT-20260614-host12-007.svg)

# イベントID( EVT-20260615-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→16→14→16→…→14→12→13→12
* 開始   : 2026-06-15 01:50:00 (UTC)
* 終了   : 2026-06-15 20:25:00 (UTC)
* 現象   : 2026-06-15 20:25:00 (UTC)を境に水準が 11.74から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.094, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.164, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host12-001 active_connections の推移](charts/EVT-20260615-host12-001.svg)

# イベントID( EVT-20260615-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→11→10→13→12→10→12
* 開始   : 2026-06-15 02:35:00 (UTC)
* 終了   : 2026-06-15 03:20:00 (UTC)
* 現象   : 2026-06-15 03:20:00 (UTC)を境に水準が 11.74から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.476, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host12-003 active_connections の推移](charts/EVT-20260615-host12-003.svg)

# イベントID( EVT-20260615-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→16→17→16→…→15→13→16→14
* 開始   : 2026-06-15 02:55:00 (UTC)
* 終了   : 2026-06-15 21:20:00 (UTC)
* 現象   : 2026-06-15 21:20:00 (UTC)を境に水準が 11.85から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.945, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.917, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host12-004 active_connections の推移](charts/EVT-20260615-host12-004.svg)

# イベントID( EVT-20260615-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→15→17→15→…→13→16→10→13
* 開始   : 2026-06-15 03:10:00 (UTC)
* 終了   : 2026-06-15 21:15:00 (UTC)
* 現象   : 2026-06-15 21:15:00 (UTC)を境に水準が 11.91から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.969σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.193, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.283, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host12-005 active_connections の推移](charts/EVT-20260615-host12-005.svg)

# イベントID( EVT-20260615-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→16→15→16→…→16→14→12→15
* 開始   : 2026-06-15 03:30:00 (UTC)
* 終了   : 2026-06-15 20:25:00 (UTC)
* 現象   : 2026-06-15 20:25:00 (UTC)を境に水準が 11.89から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.891, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.843, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host12-007 active_connections の推移](charts/EVT-20260615-host12-007.svg)

# イベントID( EVT-20260615-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→17→…→14→13→10→13
* 開始   : 2026-06-15 04:30:00 (UTC)
* 終了   : 2026-06-15 20:10:00 (UTC)
* 現象   : 2026-06-15 20:10:00 (UTC)を境に水準が 11.81から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.716, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host12-008 active_connections の推移](charts/EVT-20260615-host12-008.svg)

# イベントID( EVT-20260618-host12-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→9→8→9→7→12
* 開始   : 2026-06-18 22:40:00 (UTC)
* 終了   : 2026-06-18 23:05:00 (UTC)
* 現象   : 2026-06-18 23:05:00 (UTC)を境に水準が 14.95から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.265, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host12-013 active_connections の推移](charts/EVT-20260618-host12-013.svg)

# イベントID( EVT-20260621-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→16→16→16→17→16→16→16→17
* 開始   : 2026-06-21 12:35:00 (UTC)
* 終了   : 2026-06-21 13:20:00 (UTC)
* 現象   : 2026-06-21 13:20:00 (UTC)を境に水準が 11.8から13.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.108, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host12-003 active_connections の推移](charts/EVT-20260621-host12-003.svg)

# イベントID( EVT-20260622-host12-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 10→8→9→11→12→9→9→11→11
* 開始   : 2026-06-22 02:00:00 (UTC)
* 終了   : 2026-06-22 02:50:00 (UTC)
* 現象   : 2026-06-22 02:50:00 (UTC)を境に水準が 11.89から15.19へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.319, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-002 active_connections の推移](charts/EVT-20260622-host12-002.svg)

# イベントID( EVT-20260622-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→14→17→16→…→12→14→12→13
* 開始   : 2026-06-22 02:10:00 (UTC)
* 終了   : 2026-06-22 18:55:00 (UTC)
* 現象   : 2026-06-22 18:55:00 (UTC)を境に水準が 11.93から14.81へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.803, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.648, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-003 active_connections の推移](charts/EVT-20260622-host12-003.svg)

# イベントID( EVT-20260622-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→16→15→16→…→16→17→15→16
* 開始   : 2026-06-22 02:35:00 (UTC)
* 終了   : 2026-06-22 19:35:00 (UTC)
* 現象   : 2026-06-22 19:35:00 (UTC)を境に水準が 11.93から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.938, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.85, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-004 active_connections の推移](charts/EVT-20260622-host12-004.svg)

# イベントID( EVT-20260622-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→13→16→14→…→14→13→14→13
* 開始   : 2026-06-22 02:50:00 (UTC)
* 終了   : 2026-06-22 21:10:00 (UTC)
* 現象   : 2026-06-22 21:10:00 (UTC)を境に水準が 11.9から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.556σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.672, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.12, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-006 active_connections の推移](charts/EVT-20260622-host12-006.svg)

# イベントID( EVT-20260622-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→15→16→15→…→15→14→10→14
* 開始   : 2026-06-22 02:55:00 (UTC)
* 終了   : 2026-06-22 20:05:00 (UTC)
* 現象   : 2026-06-22 20:05:00 (UTC)を境に水準が 11.83から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 4.229σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.755, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.787, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-007 active_connections の推移](charts/EVT-20260622-host12-007.svg)

# イベントID( EVT-20260622-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 14→16→15→14→…→12→13→12→11
* 開始   : 2026-06-22 03:55:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 11.97から15.21へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.137, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-008 active_connections の推移](charts/EVT-20260622-host12-008.svg)

# イベントID( EVT-20260623-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 14→15→14→14→16→16→17
* 開始   : 2026-06-23 05:10:00 (UTC)
* 終了   : 2026-06-23 05:40:00 (UTC)
* 現象   : 2026-06-23 05:40:00 (UTC)を境に水準が 15.2から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host12-003 active_connections の推移](charts/EVT-20260623-host12-003.svg)

# イベントID( EVT-20260624-host12-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→18→18→18→18
* 開始   : 2026-06-24 06:30:00 (UTC)
* 終了   : 2026-06-24 06:50:00 (UTC)
* 現象   : 2026-06-24 06:50:00 (UTC)を境に水準が 14.96から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.054, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host12-007 active_connections の推移](charts/EVT-20260624-host12-007.svg)

# イベントID( EVT-20260626-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 20→19→19→21→19→18→21→21→20
* 開始   : 2026-06-26 07:35:00 (UTC)
* 終了   : 2026-06-26 08:50:00 (UTC)
* 現象   : 2026-06-26 08:50:00 (UTC)を境に水準が 15から14.18へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.906σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.319, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host12-006 active_connections の推移](charts/EVT-20260626-host12-006.svg)

# イベントID( EVT-20260626-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 24→21→26→24
* 開始   : 2026-06-26 10:35:00 (UTC)
* 終了   : 2026-06-26 10:50:00 (UTC)
* 現象   : 2026-06-26 10:50:00 (UTC)を境に水準が 15.06から13.66へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.843, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host12-008 active_connections の推移](charts/EVT-20260626-host12-008.svg)

# イベントID( EVT-20260628-host12-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 16→17→16→15→14→16→17→16
* 開始   : 2026-06-28 14:05:00 (UTC)
* 終了   : 2026-06-28 14:40:00 (UTC)
* 現象   : 2026-06-28 14:40:00 (UTC)を境に水準が 11.76から14.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.686, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→16→15→12→…→16→11→15→13
* 開始   : 2026-06-29 01:45:00 (UTC)
* 終了   : 2026-06-29 20:50:00 (UTC)
* 現象   : 2026-06-29 20:50:00 (UTC)を境に水準が 11.69から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.779, 限界=2.691)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.74, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host12-001 active_connections の推移](charts/EVT-20260629-host12-001.svg)

# イベントID( EVT-20260629-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→14→16→14→…→14→15→12→11
* 開始   : 2026-06-29 02:50:00 (UTC)
* 終了   : 2026-06-29 20:30:00 (UTC)
* 現象   : 2026-06-29 20:30:00 (UTC)を境に水準が 11.84から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.673σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.64, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.254, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host12-002 active_connections の推移](charts/EVT-20260629-host12-002.svg)

# イベントID( EVT-20260629-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→14→16→15→…→15→16→13→15
* 開始   : 2026-06-29 02:50:00 (UTC)
* 終了   : 2026-06-29 20:55:00 (UTC)
* 現象   : 2026-06-29 20:55:00 (UTC)を境に水準が 11.81から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.779, 限界=2.669)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.405, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host12-003 active_connections の推移](charts/EVT-20260629-host12-003.svg)

# イベントID( EVT-20260629-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→13→14→13→…→15→10→11→12
* 開始   : 2026-06-29 02:55:00 (UTC)
* 終了   : 2026-06-29 20:25:00 (UTC)
* 現象   : 2026-06-29 20:25:00 (UTC)を境に水準が 11.77から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.29, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.93, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host12-004 active_connections の推移](charts/EVT-20260629-host12-004.svg)

# イベントID( EVT-20260629-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→15→17→15→…→16→15→16→14
* 開始   : 2026-06-29 03:10:00 (UTC)
* 終了   : 2026-06-29 20:15:00 (UTC)
* 現象   : 2026-06-29 20:15:00 (UTC)を境に水準が 11.98から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.811, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host12-005 active_connections の推移](charts/EVT-20260629-host12-005.svg)

# イベントID( EVT-20260629-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→14→16→17→…→13→15→13→14
* 開始   : 2026-06-29 03:45:00 (UTC)
* 終了   : 2026-06-29 20:10:00 (UTC)
* 現象   : 2026-06-29 20:10:00 (UTC)を境に水準が 12.01から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.009, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.78, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host12-006 active_connections の推移](charts/EVT-20260629-host12-006.svg)

# イベントID( EVT-20260630-host12-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 19→22→21→22→21→22→20→21
* 開始   : 2026-06-30 14:55:00 (UTC)
* 終了   : 2026-06-30 15:30:00 (UTC)
* 現象   : 2026-06-30 15:30:00 (UTC)を境に水準が 14.88から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.686, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host12-007 active_connections の推移](charts/EVT-20260630-host12-007.svg)

# イベントID( EVT-20260630-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→19→17→17→17→17→17→19→19
* 開始   : 2026-06-30 16:40:00 (UTC)
* 終了   : 2026-06-30 18:05:00 (UTC)
* 現象   : 2026-06-30 18:05:00 (UTC)を境に水準が 14.92から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.897, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host12-009 active_connections の推移](charts/EVT-20260630-host12-009.svg)

# イベントID( EVT-20260601-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→14→17→13→14
* 開始   : 2026-06-01 05:20:00 (UTC)
* 終了   : 2026-06-01 05:20:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 22→21→17→21→19
* 開始   : 2026-06-01 14:50:00 (UTC)
* 終了   : 2026-06-01 14:50:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-042 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260601-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→9→5→11→9
* 開始   : 2026-06-01 21:20:00 (UTC)
* 終了   : 2026-06-01 21:20:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.4762(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.823σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host12-010 active_connections の推移](charts/EVT-20260601-host12-010.svg)

# イベントID( EVT-20260601-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→10→5→9→9
* 開始   : 2026-06-01 22:10:00 (UTC)
* 終了   : 2026-06-01 22:10:00 (UTC)
* 現象   : 平常時(9.667)に対し 0.5172(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→17→20→18→16
* 開始   : 2026-06-02 06:50:00 (UTC)
* 終了   : 2026-06-02 06:50:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 20→18→24→20→19
* 開始   : 2026-06-02 08:55:00 (UTC)
* 終了   : 2026-06-02 08:55:00 (UTC)
* 現象   : 平常時(19)に対し 1.263倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-038 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→14→17→13→12
* 開始   : 2026-06-03 04:55:00 (UTC)
* 終了   : 2026-06-03 04:55:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.378倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.25σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host12-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260603-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→16→19→16→16
* 開始   : 2026-06-03 06:15:00 (UTC)
* 終了   : 2026-06-03 06:15:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→20→24→21→20
* 開始   : 2026-06-03 09:05:00 (UTC)
* 終了   : 2026-06-03 09:05:00 (UTC)
* 現象   : 平常時(19.33)に対し 1.241倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.266σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260603-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 19→22→25→21→19
* 開始   : 2026-06-03 10:15:00 (UTC)
* 終了   : 2026-06-03 10:15:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.261倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host12-008 active_connections の推移](charts/EVT-20260603-host12-008.svg)

# イベントID( EVT-20260603-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 21→23→26→23→24
* 開始   : 2026-06-03 11:45:00 (UTC)
* 終了   : 2026-06-03 11:45:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-036 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260603-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260603-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→16→13→18→17
* 開始   : 2026-06-03 17:20:00 (UTC)
* 終了   : 2026-06-03 17:20:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host12-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260603-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 12→14→9→11→12
* 開始   : 2026-06-03 19:20:00 (UTC)
* 終了   : 2026-06-03 19:20:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.6545(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host12-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→11→7→12→12
* 開始   : 2026-06-03 20:10:00 (UTC)
* 終了   : 2026-06-03 20:10:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.5676(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.715σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-071 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260603-host12-016 active_connections の推移](charts/EVT-20260603-host12-016.svg)

# イベントID( EVT-20260604-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 8→9→12→11→…→12→11→8→9
* 開始   : 2026-06-04 01:35:00 (UTC)
* 終了   : 2026-06-04 01:40:00 (UTC)
* 現象   : 平常時(7.333)に対し 1.636倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-007 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260604-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 10→10→13→11→11
* 開始   : 2026-06-04 02:30:00 (UTC)
* 終了   : 2026-06-04 02:30:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→20→23→19→20
* 開始   : 2026-06-04 09:05:00 (UTC)
* 終了   : 2026-06-04 09:05:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 18→17→14→16→16
* 開始   : 2026-06-04 17:00:00 (UTC)
* 終了   : 2026-06-04 17:00:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→11→10→12→11→10→12
* 開始   : 2026-06-04 19:25:00 (UTC)
* 終了   : 2026-06-04 20:20:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host03-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260604-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260604-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→13→16→13→11
* 開始   : 2026-06-05 04:30:00 (UTC)
* 終了   : 2026-06-05 04:30:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.391倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.134σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260605-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→8→4→10→8
* 開始   : 2026-06-05 22:40:00 (UTC)
* 終了   : 2026-06-05 22:40:00 (UTC)
* 現象   : 平常時(9.25)に対し 0.4324(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.673σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host12-007 active_connections の推移](charts/EVT-20260605-host12-007.svg)

# イベントID( EVT-20260606-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 8→9→3→8→7
* 開始   : 2026-06-06 00:55:00 (UTC)
* 終了   : 2026-06-06 00:55:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.3636(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.657σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host12-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→11→12→13→…→14→9→12→11
* 開始   : 2026-06-06 05:15:00 (UTC)
* 終了   : 2026-06-06 18:25:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.854, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host12-002 active_connections の推移](charts/EVT-20260606-host12-002.svg)

# イベントID( EVT-20260606-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→10→11→12→…→12→9→13→12
* 開始   : 2026-06-06 05:25:00 (UTC)
* 終了   : 2026-06-06 18:20:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.079, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260606-host12-003 active_connections の推移](charts/EVT-20260606-host12-003.svg)

# イベントID( EVT-20260606-host12-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 12→13→12→14→…→12→13→12→11
* 開始   : 2026-06-06 05:25:00 (UTC)
* 終了   : 2026-06-06 18:50:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.253, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260606-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260606-host12-004 active_connections の推移](charts/EVT-20260606-host12-004.svg)

# イベントID( EVT-20260606-host12-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→11→10→11→…→10→11→12→10
* 開始   : 2026-06-06 05:30:00 (UTC)
* 終了   : 2026-06-06 18:35:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.932, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260606-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260606-host12-005 active_connections の推移](charts/EVT-20260606-host12-005.svg)

# イベントID( EVT-20260606-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→14→12→11→…→13→12→13→14
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 19:40:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.134σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.812, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260606-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260606-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→11→13→11→…→11→10→13→11
* 開始   : 2026-06-06 06:00:00 (UTC)
* 終了   : 2026-06-06 19:15:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.27σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.829, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260606-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260606-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260606-host12-007 active_connections の推移](charts/EVT-20260606-host12-007.svg)

# イベントID( EVT-20260606-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→10→6→10→10
* 開始   : 2026-06-06 20:20:00 (UTC)
* 終了   : 2026-06-06 20:20:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260606-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→11→6→8→9
* 開始   : 2026-06-06 20:55:00 (UTC)
* 終了   : 2026-06-06 20:55:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260606-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 10→10→15→10→13
* 開始   : 2026-06-07 05:35:00 (UTC)
* 終了   : 2026-06-07 05:35:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260607-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→12→8→15→13
* 開始   : 2026-06-07 07:55:00 (UTC)
* 終了   : 2026-06-07 07:55:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.6038(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.674σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host12-003 active_connections の推移](charts/EVT-20260607-host12-003.svg)

# イベントID( EVT-20260607-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→8→4→8→9
* 開始   : 2026-06-07 22:40:00 (UTC)
* 終了   : 2026-06-07 22:40:00 (UTC)
* 現象   : 平常時(9)に対し 0.4444(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.498σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→13→17→14→15
* 開始   : 2026-06-09 05:15:00 (UTC)
* 終了   : 2026-06-09 05:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.36倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host12-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260609-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 22→21→19→21→…→21→25→20→23
* 開始   : 2026-06-09 13:00:00 (UTC)
* 終了   : 2026-06-09 13:50:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-043 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260609-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 19→16→20→19→16→20
* 開始   : 2026-06-09 15:40:00 (UTC)
* 終了   : 2026-06-09 15:45:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→13→9→11→11
* 開始   : 2026-06-09 19:20:00 (UTC)
* 終了   : 2026-06-09 19:20:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→11→8→12→12
* 開始   : 2026-06-09 20:00:00 (UTC)
* 終了   : 2026-06-09 20:00:00 (UTC)
* 現象   : 平常時(12.33)に対し 0.6486(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→12→6→13→9
* 開始   : 2026-06-09 21:15:00 (UTC)
* 終了   : 2026-06-09 21:15:00 (UTC)
* 現象   : 平常時(11)に対し 0.5455(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.498σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-075 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 8→11→6→10→8
* 開始   : 2026-06-09 21:30:00 (UTC)
* 終了   : 2026-06-09 21:30:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→16→19→16→16
* 開始   : 2026-06-10 06:15:00 (UTC)
* 終了   : 2026-06-10 06:15:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→17→20→16→18
* 開始   : 2026-06-10 06:35:00 (UTC)
* 終了   : 2026-06-10 06:35:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.326倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.44σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 17→16→14→20→16→14→20→16→19
* 開始   : 2026-06-10 17:15:00 (UTC)
* 終了   : 2026-06-10 18:05:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 40 分
  - EVT-20260610-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260610-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260610-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 50 分
  - EVT-20260610-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→15→10→11→…→10→11→12→13
* 開始   : 2026-06-10 19:20:00 (UTC)
* 終了   : 2026-06-10 19:25:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host07-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→12→13→10→10→12→14→13→14
* 開始   : 2026-06-11 03:20:00 (UTC)
* 終了   : 2026-06-11 04:05:00 (UTC)
* 現象   : 2026-06-11 04:05:00 (UTC)を境に水準が 15.08から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.201σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.405, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→16→21→19→17
* 開始   : 2026-06-11 07:20:00 (UTC)
* 終了   : 2026-06-11 07:20:00 (UTC)
* 現象   : 平常時(16.25)に対し 1.292倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.324σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 21→20→17→21→20
* 開始   : 2026-06-11 13:55:00 (UTC)
* 終了   : 2026-06-11 13:55:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 21→22→26→20→22
* 開始   : 2026-06-11 14:15:00 (UTC)
* 終了   : 2026-06-11 14:15:00 (UTC)
* 現象   : 平常時(21.5)に対し 1.209倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 12→12→8→13→12
* 開始   : 2026-06-11 19:55:00 (UTC)
* 終了   : 2026-06-11 19:55:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.6275(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.318σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 16→14→18→14→14
* 開始   : 2026-06-12 05:40:00 (UTC)
* 終了   : 2026-06-12 05:40:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 18→16→13→15→13→15→13→15→17
* 開始   : 2026-06-12 17:30:00 (UTC)
* 終了   : 2026-06-12 17:40:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.7464(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→10→13→11→…→13→9→11→10
* 開始   : 2026-06-13 05:00:00 (UTC)
* 終了   : 2026-06-13 18:55:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.266σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.98, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260613-host12-001 active_connections の推移](charts/EVT-20260613-host12-001.svg)

# イベントID( EVT-20260613-host12-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→11→12→13→…→14→12→14→12
* 開始   : 2026-06-13 05:00:00 (UTC)
* 終了   : 2026-06-13 19:10:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.774, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260613-host12-002 active_connections の推移](charts/EVT-20260613-host12-002.svg)

# イベントID( EVT-20260613-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→10→11→13→…→11→12→14→12
* 開始   : 2026-06-13 05:30:00 (UTC)
* 終了   : 2026-06-13 19:45:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.803, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260613-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260613-host12-003 active_connections の推移](charts/EVT-20260613-host12-003.svg)

# イベントID( EVT-20260613-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→12→10→12→…→9→13→12→11
* 開始   : 2026-06-13 05:35:00 (UTC)
* 終了   : 2026-06-13 18:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.118, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260613-host12-004 active_connections の推移](charts/EVT-20260613-host12-004.svg)

# イベントID( EVT-20260613-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→13→11→13→…→12→10→11→12
* 開始   : 2026-06-13 05:45:00 (UTC)
* 終了   : 2026-06-13 18:40:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.725, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260613-host12-005 active_connections の推移](charts/EVT-20260613-host12-005.svg)

# イベントID( EVT-20260613-host12-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→11→13→12→…→14→12→11→12
* 開始   : 2026-06-13 06:30:00 (UTC)
* 終了   : 2026-06-13 18:30:00 (UTC)
* 現象   : 12.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.73, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間

![EVT-20260613-host12-006 active_connections の推移](charts/EVT-20260613-host12-006.svg)

# イベントID( EVT-20260614-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→8→13→9→10
* 開始   : 2026-06-14 04:05:00 (UTC)
* 終了   : 2026-06-14 04:05:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→12→15→12→13
* 開始   : 2026-06-14 05:50:00 (UTC)
* 終了   : 2026-06-14 05:50:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host12-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260614-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→12→16→13→15→13→13→13→14
* 開始   : 2026-06-14 06:40:00 (UTC)
* 終了   : 2026-06-14 10:05:00 (UTC)
* 現象   : 2026-06-14 10:05:00 (UTC)を境に水準が 11.75から12.44へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.508, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→11→18→13→13
* 開始   : 2026-06-14 16:35:00 (UTC)
* 終了   : 2026-06-14 16:35:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→10→5→11→8
* 開始   : 2026-06-14 21:25:00 (UTC)
* 終了   : 2026-06-14 21:25:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.4878(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.649σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 8→9→4→9→7
* 開始   : 2026-06-14 23:00:00 (UTC)
* 終了   : 2026-06-14 23:00:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host12-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→13→15→14→…→15→14→17→14
* 開始   : 2026-06-15 03:20:00 (UTC)
* 終了   : 2026-06-15 19:30:00 (UTC)
* 現象   : 2026-06-15 19:30:00 (UTC)を境に水準が 11.97から14.95へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.022, 限界=2.659)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→6→12→10→…→10→11→9→10
* 開始   : 2026-06-16 01:10:00 (UTC)
* 終了   : 2026-06-16 01:20:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 8→9→13→9→9
* 開始   : 2026-06-16 01:50:00 (UTC)
* 終了   : 2026-06-16 01:50:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→16→19→14→14
* 開始   : 2026-06-16 06:05:00 (UTC)
* 終了   : 2026-06-16 06:05:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.326倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260616-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 19→20→25→20→23
* 開始   : 2026-06-16 10:10:00 (UTC)
* 終了   : 2026-06-16 10:10:00 (UTC)
* 現象   : 平常時(20.33)に対し 1.23倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260616-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 21→20→26→22→21
* 開始   : 2026-06-16 11:55:00 (UTC)
* 終了   : 2026-06-16 11:55:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260616-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→18→14→19→17
* 開始   : 2026-06-16 16:30:00 (UTC)
* 終了   : 2026-06-16 16:30:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.7336(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.557σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host12-012 active_connections の推移](charts/EVT-20260616-host12-012.svg)

# イベントID( EVT-20260616-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→16→11→14→16
* 開始   : 2026-06-16 18:15:00 (UTC)
* 終了   : 2026-06-16 18:15:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260616-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→14→8→10→14→8→10
* 開始   : 2026-06-16 19:30:00 (UTC)
* 終了   : 2026-06-16 20:30:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260616-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260616-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-062 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260616-host12-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→11→6→10→11
* 開始   : 2026-06-16 21:00:00 (UTC)
* 終了   : 2026-06-16 21:00:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.5496(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.441σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host01-014 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260616-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host12-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 11→10→5→9→9
* 開始   : 2026-06-16 21:10:00 (UTC)
* 終了   : 2026-06-16 21:10:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.4688(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.939σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host12-017 active_connections の推移](charts/EVT-20260616-host12-017.svg)

# イベントID( EVT-20260617-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→7→13→7→9
* 開始   : 2026-06-17 02:10:00 (UTC)
* 終了   : 2026-06-17 03:00:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-009 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260617-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260617-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→11→14→13→11
* 開始   : 2026-06-17 03:30:00 (UTC)
* 終了   : 2026-06-17 03:30:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 16→17→16→19→17→16→19→14→16
* 開始   : 2026-06-17 06:25:00 (UTC)
* 終了   : 2026-06-17 06:35:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→17→20→16→17
* 開始   : 2026-06-17 07:15:00 (UTC)
* 終了   : 2026-06-17 07:15:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 19→18→14→17→19
* 開始   : 2026-06-17 16:25:00 (UTC)
* 終了   : 2026-06-17 16:25:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.7568(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 8→8→3→9→7
* 開始   : 2026-06-17 23:05:00 (UTC)
* 終了   : 2026-06-17 23:05:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.3564(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.789σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-084 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-086 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-087 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260617-host12-013 active_connections の推移](charts/EVT-20260617-host12-013.svg)

# イベントID( EVT-20260618-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→15→18→15→14
* 開始   : 2026-06-18 05:40:00 (UTC)
* 終了   : 2026-06-18 05:40:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 20→19→16→21→22
* 開始   : 2026-06-18 15:25:00 (UTC)
* 終了   : 2026-06-18 15:25:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→17→13→16→18
* 開始   : 2026-06-18 17:05:00 (UTC)
* 終了   : 2026-06-18 17:05:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7256(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.417σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host12-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-042 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 19→19→14→16→16
* 開始   : 2026-06-18 17:05:00 (UTC)
* 終了   : 2026-06-18 17:05:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host12-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-042 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260618-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→10→6→9→8
* 開始   : 2026-06-18 21:10:00 (UTC)
* 終了   : 2026-06-18 21:10:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.5294(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.731σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host12-012 active_connections の推移](charts/EVT-20260618-host12-012.svg)

# イベントID( EVT-20260619-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→15→19→16→16
* 開始   : 2026-06-19 06:45:00 (UTC)
* 終了   : 2026-06-19 06:45:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→13→9→8→…→11→14→13→11
* 開始   : 2026-06-20 05:15:00 (UTC)
* 終了   : 2026-06-20 18:40:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.838, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.4 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260620-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260620-host12-002 active_connections の推移](charts/EVT-20260620-host12-002.svg)

# イベントID( EVT-20260620-host12-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→12→10→12→…→10→11→12→11
* 開始   : 2026-06-20 05:25:00 (UTC)
* 終了   : 2026-06-20 18:55:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.94, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.5 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260620-host12-003 active_connections の推移](charts/EVT-20260620-host12-003.svg)

# イベントID( EVT-20260620-host12-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 12→11→13→11→…→14→9→12→11
* 開始   : 2026-06-20 05:35:00 (UTC)
* 終了   : 2026-06-20 18:30:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.753, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260620-host12-004 active_connections の推移](charts/EVT-20260620-host12-004.svg)

# イベントID( EVT-20260620-host12-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→14→13→14→…→12→13→11→12
* 開始   : 2026-06-20 05:40:00 (UTC)
* 終了   : 2026-06-20 19:10:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.832, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260620-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260620-host12-005 active_connections の推移](charts/EVT-20260620-host12-005.svg)

# イベントID( EVT-20260620-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 11→12→13→10→…→13→11→14→12
* 開始   : 2026-06-20 05:50:00 (UTC)
* 終了   : 2026-06-20 19:35:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.779, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260620-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260620-host12-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260620-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260620-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260620-host12-006 active_connections の推移](charts/EVT-20260620-host12-006.svg)

# イベントID( EVT-20260620-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→11→12→11→…→11→13→15→13
* 開始   : 2026-06-20 06:00:00 (UTC)
* 終了   : 2026-06-20 19:00:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.887, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260620-host12-007 active_connections の推移](charts/EVT-20260620-host12-007.svg)

# イベントID( EVT-20260620-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→11→5→9→9
* 開始   : 2026-06-20 20:50:00 (UTC)
* 終了   : 2026-06-20 20:50:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.5085(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.359σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→14→18→13→13
* 開始   : 2026-06-21 08:15:00 (UTC)
* 終了   : 2026-06-21 08:30:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.358倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260621-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260621-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260621-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260621-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260621-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host12-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→14→16→17→…→13→16→14→15
* 開始   : 2026-06-22 02:35:00 (UTC)
* 終了   : 2026-06-22 20:30:00 (UTC)
* 現象   : 2026-06-22 20:30:00 (UTC)を境に水準が 11.87から15.01へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.43, 限界=2.69)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.633, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 16→15→21→16→16
* 開始   : 2026-06-23 07:15:00 (UTC)
* 終了   : 2026-06-23 07:15:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.362倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.906σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host12-006 active_connections の推移](charts/EVT-20260623-host12-006.svg)

# イベントID( EVT-20260623-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 20→20→25→23→22
* 開始   : 2026-06-23 10:25:00 (UTC)
* 終了   : 2026-06-23 10:25:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 23→23→18→22→23
* 開始   : 2026-06-23 11:40:00 (UTC)
* 終了   : 2026-06-23 11:40:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 21→18→25→19→21→18→25→19→20
* 開始   : 2026-06-23 15:00:00 (UTC)
* 終了   : 2026-06-23 15:05:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.8538(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 19→18→15→17→…→17→16→19→16
* 開始   : 2026-06-23 16:20:00 (UTC)
* 終了   : 2026-06-23 16:30:00 (UTC)
* 現象   : 平常時(19.67)に対し 0.7627(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→14→17→12→14→17→12→15
* 開始   : 2026-06-23 17:20:00 (UTC)
* 終了   : 2026-06-23 17:30:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.785(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.682σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host12-015 active_connections の推移](charts/EVT-20260623-host12-015.svg)

# イベントID( EVT-20260623-host12-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→11→8→9→…→9→6→11→8
* 開始   : 2026-06-23 21:20:00 (UTC)
* 終了   : 2026-06-23 21:30:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host12-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→8→13→10→10
* 開始   : 2026-06-24 01:10:00 (UTC)
* 終了   : 2026-06-24 01:10:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.608倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.424σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→9→13→11→…→10→11→13→10
* 開始   : 2026-06-24 02:55:00 (UTC)
* 終了   : 2026-06-24 04:05:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.794σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 40 分
  - EVT-20260624-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host02-004 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260624-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→13→15→12→10→13→15→12→10
* 開始   : 2026-06-24 03:45:00 (UTC)
* 終了   : 2026-06-24 03:50:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→13→15→10→12
* 開始   : 2026-06-24 04:00:00 (UTC)
* 終了   : 2026-06-24 04:00:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260624-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→13→18→13→16
* 開始   : 2026-06-24 06:20:00 (UTC)
* 終了   : 2026-06-24 06:20:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 23→21→17→22→20
* 開始   : 2026-06-24 14:45:00 (UTC)
* 終了   : 2026-06-24 14:45:00 (UTC)
* 現象   : 平常時(21.58)に対し 0.7876(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.202σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-048 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 22→21→16→21→22
* 開始   : 2026-06-24 14:50:00 (UTC)
* 終了   : 2026-06-24 14:50:00 (UTC)
* 現象   : 平常時(20.83)に対し 0.768(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 19→19→15→19→18
* 開始   : 2026-06-24 16:15:00 (UTC)
* 終了   : 2026-06-24 16:15:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→17→14→17→18
* 開始   : 2026-06-24 16:45:00 (UTC)
* 終了   : 2026-06-24 16:45:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.7602(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-053 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260624-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→16→13→12→…→13→12→15→14
* 開始   : 2026-06-24 18:05:00 (UTC)
* 終了   : 2026-06-24 18:10:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7839(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-015 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host12-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→7→5→8→10→7→5→8
* 開始   : 2026-06-24 22:05:00 (UTC)
* 終了   : 2026-06-24 22:10:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-018 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host12-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 16→15→20→17→16
* 開始   : 2026-06-25 07:10:00 (UTC)
* 終了   : 2026-06-25 07:10:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 22→19→26→19→21
* 開始   : 2026-06-25 11:45:00 (UTC)
* 終了   : 2026-06-25 11:45:00 (UTC)
* 現象   : 平常時(21.17)に対し 1.228倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→14→18→13→13
* 開始   : 2026-06-26 05:15:00 (UTC)
* 終了   : 2026-06-26 05:15:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.412倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.657σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host12-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host12-002 active_connections の推移](charts/EVT-20260626-host12-002.svg)

# イベントID( EVT-20260626-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 17→16→19→18→…→19→18→15→17
* 開始   : 2026-06-26 06:25:00 (UTC)
* 終了   : 2026-06-26 06:30:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host12-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260626-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 19→19→25→22→20
* 開始   : 2026-06-26 10:05:00 (UTC)
* 終了   : 2026-06-26 10:05:00 (UTC)
* 現象   : 平常時(20.42)に対し 1.224倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.192σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 21→23→18→21→23
* 開始   : 2026-06-26 12:10:00 (UTC)
* 終了   : 2026-06-26 12:10:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→21→16→18→18
* 開始   : 2026-06-26 15:30:00 (UTC)
* 終了   : 2026-06-26 15:30:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→10→6→12→11
* 開始   : 2026-06-26 20:40:00 (UTC)
* 終了   : 2026-06-26 20:40:00 (UTC)
* 現象   : 平常時(11.08)に対し 0.5414(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.54σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 8→8→5→8→8
* 開始   : 2026-06-26 22:40:00 (UTC)
* 終了   : 2026-06-26 22:40:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→12→13→12→…→14→12→14→11
* 開始   : 2026-06-27 04:55:00 (UTC)
* 終了   : 2026-06-27 20:25:00 (UTC)
* 現象   : 15.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.91, 限界=2.669)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.7 時間
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260627-host12-001 active_connections の推移](charts/EVT-20260627-host12-001.svg)

# イベントID( EVT-20260627-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→14→11→13→…→12→13→12→13
* 開始   : 2026-06-27 05:05:00 (UTC)
* 終了   : 2026-06-27 19:30:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.275, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260627-host12-002 active_connections の推移](charts/EVT-20260627-host12-002.svg)

# イベントID( EVT-20260627-host12-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→11→14→12→…→12→10→15→11
* 開始   : 2026-06-27 05:10:00 (UTC)
* 終了   : 2026-06-27 19:20:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.9, 限界=2.659)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.2 時間

![EVT-20260627-host12-003 active_connections の推移](charts/EVT-20260627-host12-003.svg)

# イベントID( EVT-20260627-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→13→10→14→…→13→10→14→13
* 開始   : 2026-06-27 05:15:00 (UTC)
* 終了   : 2026-06-27 18:35:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.786σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.406, 限界=2.69)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260627-host12-004 active_connections の推移](charts/EVT-20260627-host12-004.svg)

# イベントID( EVT-20260627-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→12→11→12→…→11→13→14→12
* 開始   : 2026-06-27 05:45:00 (UTC)
* 終了   : 2026-06-27 17:55:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.729, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host12-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260627-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260627-host12-005 active_connections の推移](charts/EVT-20260627-host12-005.svg)

# イベントID( EVT-20260627-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→10→12→10→…→11→12→10→11
* 開始   : 2026-06-27 05:50:00 (UTC)
* 終了   : 2026-06-27 19:50:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.754, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host12-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260627-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 14.0 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260627-host12-006 active_connections の推移](charts/EVT-20260627-host12-006.svg)

# イベントID( EVT-20260628-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 16→13→19→14→15
* 開始   : 2026-06-28 10:05:00 (UTC)
* 終了   : 2026-06-28 10:05:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→12→8→11→14
* 開始   : 2026-06-28 17:25:00 (UTC)
* 終了   : 2026-06-28 17:25:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.6115(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.54σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 12→11→7→12→10
* 開始   : 2026-06-28 19:10:00 (UTC)
* 終了   : 2026-06-28 19:10:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260628-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 22→19→23→24→…→23→24→20→19
* 開始   : 2026-06-30 09:50:00 (UTC)
* 終了   : 2026-06-30 10:30:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.145倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 22→18→24→21→21
* 開始   : 2026-06-30 10:05:00 (UTC)
* 終了   : 2026-06-30 10:05:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.236倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→14→9→10→…→9→10→13→12
* 開始   : 2026-06-30 19:20:00 (UTC)
* 終了   : 2026-06-30 19:25:00 (UTC)
* 現象   : 平常時(14)に対し 0.6429(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 9→10→6→10→9
* 開始   : 2026-06-30 21:10:00 (UTC)
* 終了   : 2026-06-30 21:10:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→11→13→8→13→8→13→10→9
* 開始   : 2026-06-01 03:00:00 (UTC)
* 終了   : 2026-06-01 03:10:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.357倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260601-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 16→17→19→18→…→18→20→19→18
* 開始   : 2026-06-01 07:15:00 (UTC)
* 終了   : 2026-06-01 07:25:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260601-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 21→19→23→21→23→21→23→21→20
* 開始   : 2026-06-01 09:20:00 (UTC)
* 終了   : 2026-06-01 09:30:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260601-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 21→18→16→18→16→18→16→20→17
* 開始   : 2026-06-01 16:10:00 (UTC)
* 終了   : 2026-06-01 16:20:00 (UTC)
* 現象   : 平常時(19.83)に対し 0.8067(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.67σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 18→17→16→15→17→16→15→17
* 開始   : 2026-06-01 16:15:00 (UTC)
* 終了   : 2026-06-01 16:20:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host12-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→17→13→12→…→12→13→12→15
* 開始   : 2026-06-01 18:20:00 (UTC)
* 終了   : 2026-06-01 18:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260601-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260601-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260601-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→16→12→13→16→12→13→15
* 開始   : 2026-06-01 18:50:00 (UTC)
* 終了   : 2026-06-01 18:55:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260601-host04-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260601-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 19→20→23→19→23→19→23→21→20
* 開始   : 2026-06-02 09:15:00 (UTC)
* 終了   : 2026-06-02 09:25:00 (UTC)
* 現象   : 平常時(19.17)に対し 1.2倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.67σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260602-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 19→20→17→18→16→17→18→16→18
* 開始   : 2026-06-02 16:00:00 (UTC)
* 終了   : 2026-06-02 16:10:00 (UTC)
* 現象   : 平常時(20.08)に対し 0.8465(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 20→19→16→18→18→19→19→19
* 開始   : 2026-06-02 16:05:00 (UTC)
* 終了   : 2026-06-02 16:40:00 (UTC)
* 現象   : 2026-06-02 16:40:00 (UTC)を境に水準が 14.89から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.59, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host12-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 16→19→17→17→18
* 開始   : 2026-06-02 17:30:00 (UTC)
* 終了   : 2026-06-02 17:50:00 (UTC)
* 現象   : 2026-06-02 17:50:00 (UTC)を境に水準が 15.04から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.896, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 10→12→8→11→12→8→11
* 開始   : 2026-06-02 20:10:00 (UTC)
* 終了   : 2026-06-02 20:15:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.6575(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.916σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260602-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 7→10→9→10
* 開始   : 2026-06-02 23:35:00 (UTC)
* 終了   : 2026-06-02 23:50:00 (UTC)
* 現象   : 2026-06-02 23:50:00 (UTC)を境に水準が 14.89から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.794, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260602-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→10→10→9→11
* 開始   : 2026-06-03 01:00:00 (UTC)
* 終了   : 2026-06-03 01:20:00 (UTC)
* 現象   : 2026-06-03 01:20:00 (UTC)を境に水準が 14.93から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.917, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→12→15→16→13→12→15→16→13
* 開始   : 2026-06-03 04:55:00 (UTC)
* 終了   : 2026-06-03 05:00:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host12-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260603-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→14→15→16→13→14→15→16→13
* 開始   : 2026-06-03 05:15:00 (UTC)
* 終了   : 2026-06-03 06:00:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 45 分
  - EVT-20260603-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260603-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260603-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 19→18→22→18→22→19
* 開始   : 2026-06-03 09:15:00 (UTC)
* 終了   : 2026-06-03 09:20:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260603-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 23→22→25→20→26→25→20→26→22
* 開始   : 2026-06-03 12:50:00 (UTC)
* 終了   : 2026-06-03 13:00:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-041 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-039 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260603-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 20→21→17→16→19→21→17→16→19
* 開始   : 2026-06-03 15:15:00 (UTC)
* 終了   : 2026-06-03 15:20:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-046 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-047 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→18→14→15→18→14→15→17
* 開始   : 2026-06-03 17:20:00 (UTC)
* 終了   : 2026-06-03 17:25:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host12-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260603-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260603-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host12-014 )

* イベント種別 : ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→16→18→13→16→18→13→14
* 開始   : 2026-06-03 18:00:00 (UTC)
* 終了   : 2026-06-03 18:05:00 (UTC)
* 現象   : 水曜18時台の平常値(14.3)に対し 18であった
* 説明   : ALG-A5: 同じ曜日・時刻帯の平常値から 3.263σ 外れた (平常値=14.3)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260603-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 9→8→12→11→8→12→11→12
* 開始   : 2026-06-04 02:45:00 (UTC)
* 終了   : 2026-06-04 02:50:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→13→16→17→…→16→17→12→16
* 開始   : 2026-06-04 05:15:00 (UTC)
* 終了   : 2026-06-04 05:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260604-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 18→20→15→20→22→15→20→22→19
* 開始   : 2026-06-04 08:40:00 (UTC)
* 終了   : 2026-06-04 08:50:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.7826(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.91σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260604-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 14→13→11→14→…→14→11→15→13
* 開始   : 2026-06-04 18:25:00 (UTC)
* 終了   : 2026-06-04 18:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.682σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260604-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→14→11→13→…→11→10→14→13
* 開始   : 2026-06-04 19:15:00 (UTC)
* 終了   : 2026-06-04 19:35:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260604-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 9→7→12→9→7→12→9→10
* 開始   : 2026-06-05 03:10:00 (UTC)
* 終了   : 2026-06-05 03:15:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260605-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260605-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260605-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 17→21→20→21→20→21→19→20
* 開始   : 2026-06-05 08:15:00 (UTC)
* 終了   : 2026-06-05 08:25:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.212倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260605-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260605-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 19→20→24→19→24→19→24→22→21
* 開始   : 2026-06-05 10:45:00 (UTC)
* 終了   : 2026-06-05 10:55:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.166倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-lsfhost01-039 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260605-lsfhost01-038 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260605-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260605-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 22→19→17→19→17→19
* 開始   : 2026-06-05 15:30:00 (UTC)
* 終了   : 2026-06-05 15:35:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.8226(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.561σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host12-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 10→9→7→9→…→7→9→8→9
* 開始   : 2026-06-06 20:10:00 (UTC)
* 終了   : 2026-06-06 20:15:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.733, 限界=2.691)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260606-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260606-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260606-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host12-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 14→14→13→15→14
* 開始   : 2026-06-07 06:15:00 (UTC)
* 終了   : 2026-06-07 07:00:00 (UTC)
* 現象   : 2026-06-07 07:00:00 (UTC)を境に水準が 11.82から12.31へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.896, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 16→13→17→14→17→14→17→12→17
* 開始   : 2026-06-07 08:55:00 (UTC)
* 終了   : 2026-06-07 09:05:00 (UTC)
* 現象   : 平常時(13.92)に対し 1.222倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260607-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260607-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 19→17→15→16
* 開始   : 2026-06-07 14:20:00 (UTC)
* 終了   : 2026-06-07 14:35:00 (UTC)
* 現象   : 2026-06-07 14:35:00 (UTC)を境に水準が 11.88から14.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.794, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→9→10→12→9→10→12→13
* 開始   : 2026-06-07 17:45:00 (UTC)
* 終了   : 2026-06-07 17:50:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.6835(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.902σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→6→10→6→10→6→10→11
* 開始   : 2026-06-07 20:50:00 (UTC)
* 終了   : 2026-06-07 21:00:00 (UTC)
* 現象   : 平常時(9.667)に対し 0.6207(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.549σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260607-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260607-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260607-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 5→9→11→5→…→11→5→10→7
* 開始   : 2026-06-08 00:15:00 (UTC)
* 終了   : 2026-06-08 00:20:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.435倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260608-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260608-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→15→17→16→…→16→11→12→16
* 開始   : 2026-06-09 05:05:00 (UTC)
* 終了   : 2026-06-09 06:55:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.306倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host12-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260609-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260609-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 15→16→14→15→16→14
* 開始   : 2026-06-09 05:40:00 (UTC)
* 終了   : 2026-06-09 05:45:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host12-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host12-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260609-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→15→16→17→…→16→17→14→16
* 開始   : 2026-06-09 05:45:00 (UTC)
* 終了   : 2026-06-09 05:50:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host12-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host12-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260609-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 19→17→16→15→…→16→15→19→16
* 開始   : 2026-06-09 16:20:00 (UTC)
* 終了   : 2026-06-09 16:25:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 17→18→15→18→15→18→15→17
* 開始   : 2026-06-09 16:40:00 (UTC)
* 終了   : 2026-06-09 16:50:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.8(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260609-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 17→13→17→13→17→13→16→15
* 開始   : 2026-06-09 17:15:00 (UTC)
* 終了   : 2026-06-09 17:25:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.7536(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.973σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260609-host15-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260609-lsfhost01-047 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 15→16→12→14→12→14→12→15→14
* 開始   : 2026-06-09 18:05:00 (UTC)
* 終了   : 2026-06-09 18:15:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7701(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-lsfhost01-055 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260609-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260609-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host12-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→8→12→9→…→9→5→7→8
* 開始   : 2026-06-09 23:15:00 (UTC)
* 終了   : 2026-06-09 23:25:00 (UTC)
* 現象   : 平常時(8.167)に対し 1.469倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.678σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host12-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 8→5→8→11→5→8→11→9→7
* 開始   : 2026-06-10 00:50:00 (UTC)
* 終了   : 2026-06-10 01:00:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.6122(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260610-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→14→15→10→15→10→15→10→13
* 開始   : 2026-06-10 04:50:00 (UTC)
* 終了   : 2026-06-10 05:00:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260610-host02-003 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260610-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→12→17→14→12→17→14
* 開始   : 2026-06-10 05:50:00 (UTC)
* 終了   : 2026-06-10 05:55:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 16→18→19→13→…→19→13→17→16
* 開始   : 2026-06-10 07:10:00 (UTC)
* 終了   : 2026-06-10 07:15:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 16→18→20→19→…→19→21→20→18
* 開始   : 2026-06-10 08:00:00 (UTC)
* 終了   : 2026-06-10 08:10:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 23→19→24→21→17→24→21→17→20
* 開始   : 2026-06-10 14:25:00 (UTC)
* 終了   : 2026-06-10 14:35:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.171倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260610-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 16→16→16→14→14→15→15→15→13
* 開始   : 2026-06-10 17:50:00 (UTC)
* 終了   : 2026-06-10 19:20:00 (UTC)
* 現象   : 2026-06-10 19:20:00 (UTC)を境に水準が 15.02から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.769, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→14→11→14→11→14→11→13→15
* 開始   : 2026-06-10 18:40:00 (UTC)
* 終了   : 2026-06-10 18:50:00 (UTC)
* 現象   : 平常時(14.75)に対し 0.7458(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-lsfhost01-063 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host12-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→10→11→10→8→7→9→9→8
* 開始   : 2026-06-10 21:10:00 (UTC)
* 終了   : 2026-06-10 22:10:00 (UTC)
* 現象   : 2026-06-10 22:10:00 (UTC)を境に水準が 14.95から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.329, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→10→12→10→12→10→12→11→10
* 開始   : 2026-06-11 02:00:00 (UTC)
* 終了   : 2026-06-11 02:10:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.385倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260611-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→13→…→13→16→17→14
* 開始   : 2026-06-11 05:15:00 (UTC)
* 終了   : 2026-06-11 05:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.503σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260611-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 19→18→22→21→…→21→23→21→22
* 開始   : 2026-06-11 09:05:00 (UTC)
* 終了   : 2026-06-11 09:15:00 (UTC)
* 現象   : 平常時(19)に対し 1.158倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-036 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-035 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260611-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→13→11→12→13→11→12→11
* 開始   : 2026-06-11 19:10:00 (UTC)
* 終了   : 2026-06-11 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-host04-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host13-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→8→6→9→…→8→6→8→9
* 開始   : 2026-06-11 22:00:00 (UTC)
* 終了   : 2026-06-11 22:25:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-081 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260611-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 8→12→7→12→7→12→10
* 開始   : 2026-06-12 02:05:00 (UTC)
* 終了   : 2026-06-12 02:15:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.485倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.728σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-006 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→12→15→13→12→15→13→14
* 開始   : 2026-06-12 04:45:00 (UTC)
* 終了   : 2026-06-12 04:50:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 11→14→16→15→16→15→16→14→15
* 開始   : 2026-06-12 05:00:00 (UTC)
* 終了   : 2026-06-12 05:10:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.343倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.857σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→17→15→17→15→17→14→15
* 開始   : 2026-06-12 05:45:00 (UTC)
* 終了   : 2026-06-12 05:55:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.316倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.857σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host12-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 12→13→16→15→13→16→15→14
* 開始   : 2026-06-12 05:45:00 (UTC)
* 終了   : 2026-06-12 05:50:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host12-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→16→20→16→20→16
* 開始   : 2026-06-12 07:35:00 (UTC)
* 終了   : 2026-06-12 07:40:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.218倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→21→20→18→21→20
* 開始   : 2026-06-12 08:00:00 (UTC)
* 終了   : 2026-06-12 08:05:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 20→19→17→20→…→21→16→21→19
* 開始   : 2026-06-12 15:15:00 (UTC)
* 終了   : 2026-06-12 15:35:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260612-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-062 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260612-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→15→13→16→…→13→12→16→13
* 開始   : 2026-06-12 18:15:00 (UTC)
* 終了   : 2026-06-12 18:35:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.328σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260612-host11-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-077 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-079 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260612-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-078 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-080 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260612-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→12→8→12→8→12→11
* 開始   : 2026-06-12 20:40:00 (UTC)
* 終了   : 2026-06-12 20:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-086 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-087 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 11→9→13→8→9→13→8→11
* 開始   : 2026-06-14 04:20:00 (UTC)
* 終了   : 2026-06-14 04:25:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260614-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→11→14→13→14→13→14→11→12
* 開始   : 2026-06-14 05:45:00 (UTC)
* 終了   : 2026-06-14 05:55:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host12-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260614-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260614-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 17→16→11→17→18→11→17→18→14
* 開始   : 2026-06-14 09:35:00 (UTC)
* 終了   : 2026-06-14 09:45:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.7416(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.683σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-host02-002 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分

![EVT-20260614-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 16→16→15→17→15
* 開始   : 2026-06-14 13:50:00 (UTC)
* 終了   : 2026-06-14 14:10:00 (UTC)
* 現象   : 2026-06-14 14:10:00 (UTC)を境に水準が 11.67から13.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.993, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260614-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 11→10→6→9→6→9→6→9
* 開始   : 2026-06-14 21:00:00 (UTC)
* 終了   : 2026-06-14 21:10:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.605(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.736σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260614-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260614-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host12-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 11→10→10→9→11
* 開始   : 2026-06-15 01:55:00 (UTC)
* 終了   : 2026-06-15 02:15:00 (UTC)
* 現象   : 2026-06-15 02:15:00 (UTC)を境に水準が 11.9から14.92へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.896, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 16→15→17→16→16→17→18→17→17
* 開始   : 2026-06-16 05:40:00 (UTC)
* 終了   : 2026-06-16 06:45:00 (UTC)
* 現象   : 2026-06-16 06:45:00 (UTC)を境に水準が 14.97から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.508, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→13→17→15→…→15→18→16→15
* 開始   : 2026-06-16 06:00:00 (UTC)
* 終了   : 2026-06-16 06:10:00 (UTC)
* 現象   : 平常時(14)に対し 1.214倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分

![EVT-20260616-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 17→20→15→17→21→15→17→21→19
* 開始   : 2026-06-16 08:10:00 (UTC)
* 終了   : 2026-06-16 08:20:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260616-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 19→18→22→20→22→20→22→18→19
* 開始   : 2026-06-16 08:20:00 (UTC)
* 終了   : 2026-06-16 08:30:00 (UTC)
* 現象   : 平常時(18.17)に対し 1.211倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.678σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 22→24→22→23→23→23
* 開始   : 2026-06-16 12:00:00 (UTC)
* 終了   : 2026-06-16 12:25:00 (UTC)
* 現象   : 2026-06-16 12:25:00 (UTC)を境に水準が 15.13から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.19, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 22→19→20→22→19→20→21
* 開始   : 2026-06-16 12:35:00 (UTC)
* 終了   : 2026-06-16 12:40:00 (UTC)
* 現象   : 平常時(22.58)に対し 0.8413(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host16-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260616-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 14→10→12→14→10→12
* 開始   : 2026-06-16 19:15:00 (UTC)
* 終了   : 2026-06-16 19:20:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.7362(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.508σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260616-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host01-010 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260616-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 13→14→17→16→14→17→16→14
* 開始   : 2026-06-17 05:35:00 (UTC)
* 終了   : 2026-06-17 05:40:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.283倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 18→19→21→19→…→19→22→21→22
* 開始   : 2026-06-17 08:25:00 (UTC)
* 終了   : 2026-06-17 08:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260617-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260617-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260617-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 22→21→24→19→24→19→24→21→20
* 開始   : 2026-06-17 10:45:00 (UTC)
* 終了   : 2026-06-17 10:55:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260617-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 21→23→19→25→…→25→19→21→22
* 開始   : 2026-06-17 11:30:00 (UTC)
* 終了   : 2026-06-17 11:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.096σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 16→18→14→16→18→14→16→17
* 開始   : 2026-06-17 17:00:00 (UTC)
* 終了   : 2026-06-17 17:05:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 17→20→15→16→14→15→16→14→17
* 開始   : 2026-06-17 17:05:00 (UTC)
* 終了   : 2026-06-17 17:15:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host12-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→15→12→11→15→12→11→15→14
* 開始   : 2026-06-17 18:40:00 (UTC)
* 終了   : 2026-06-17 18:45:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260617-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 13→10→15→12→15→12→15→14→12
* 開始   : 2026-06-18 04:30:00 (UTC)
* 終了   : 2026-06-18 04:40:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.333倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.619σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260618-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 15→16→16→15→17→17→16→15→19
* 開始   : 2026-06-18 05:10:00 (UTC)
* 終了   : 2026-06-18 06:45:00 (UTC)
* 現象   : 2026-06-18 06:45:00 (UTC)を境に水準が 14.98から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.986, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260618-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 15→16→18→17→16→18→17→16
* 開始   : 2026-06-18 06:20:00 (UTC)
* 終了   : 2026-06-18 06:25:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 21→19→23→22→19→23→22→20
* 開始   : 2026-06-18 09:15:00 (UTC)
* 終了   : 2026-06-18 09:20:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.205倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.736σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 19→20→17→16→20→17→16→20→18
* 開始   : 2026-06-18 16:00:00 (UTC)
* 終了   : 2026-06-18 16:05:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→15→13→15→…→15→12→15→16
* 開始   : 2026-06-18 18:10:00 (UTC)
* 終了   : 2026-06-18 18:20:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 14→13→12→13→12→13
* 開始   : 2026-06-18 18:45:00 (UTC)
* 終了   : 2026-06-18 18:50:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260618-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 8→9→11→5→…→11→5→11→8
* 開始   : 2026-06-19 02:15:00 (UTC)
* 終了   : 2026-06-19 02:20:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.361倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.037σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260619-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 8→10→13→14→…→13→14→9→11
* 開始   : 2026-06-19 03:25:00 (UTC)
* 終了   : 2026-06-19 03:30:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.289倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260619-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→16→12→13→16→12→16
* 開始   : 2026-06-19 05:25:00 (UTC)
* 終了   : 2026-06-19 05:30:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260619-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 17→21→22→19→22→19→22→18→20
* 開始   : 2026-06-19 08:35:00 (UTC)
* 終了   : 2026-06-19 08:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.2倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 21→19→24→21→24→21→24→21→20
* 開始   : 2026-06-19 10:00:00 (UTC)
* 終了   : 2026-06-19 10:10:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.215倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.96σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260619-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 20→21→18→21→18→21→18→21→19
* 開始   : 2026-06-19 14:30:00 (UTC)
* 終了   : 2026-06-19 14:40:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→10→10→10→10→10→11
* 開始   : 2026-06-19 21:10:00 (UTC)
* 終了   : 2026-06-19 22:25:00 (UTC)
* 現象   : 2026-06-19 22:25:00 (UTC)を境に水準が 14.92から11.86へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.254, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260620-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 9→7→11→6→11→6→11→9→8
* 開始   : 2026-06-20 00:45:00 (UTC)
* 終了   : 2026-06-20 00:55:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260620-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 7→5→11→7→5→11→7→9
* 開始   : 2026-06-21 00:00:00 (UTC)
* 終了   : 2026-06-21 00:05:00 (UTC)
* 現象   : 平常時(7.917)に対し 0.6316(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-lsfhost01-002 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260621-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host12-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 12→13→11→12→12→12→9→10→11
* 開始   : 2026-06-21 18:55:00 (UTC)
* 終了   : 2026-06-21 19:55:00 (UTC)
* 現象   : 2026-06-21 19:55:00 (UTC)を境に水準が 11.83から14.74へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.329, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host12-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→7→9→9→9→10→8→10→9
* 開始   : 2026-06-21 23:15:00 (UTC)
* 終了   : 2026-06-21 23:55:00 (UTC)
* 現象   : 2026-06-21 23:55:00 (UTC)を境に水準が 11.82から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→8→9→9→10→11
* 開始   : 2026-06-22 01:05:00 (UTC)
* 終了   : 2026-06-22 01:30:00 (UTC)
* 現象   : 2026-06-22 01:30:00 (UTC)を境に水準が 11.74から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.192, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host12-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→9→9→11→10
* 開始   : 2026-06-22 21:45:00 (UTC)
* 終了   : 2026-06-22 22:05:00 (UTC)
* 現象   : 2026-06-22 22:05:00 (UTC)を境に水準が 15.02から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.993, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host12-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 11→11→10→9→11
* 開始   : 2026-06-22 21:55:00 (UTC)
* 終了   : 2026-06-22 22:15:00 (UTC)
* 現象   : 2026-06-22 22:15:00 (UTC)を境に水準が 14.82から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.917, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 9→7→5→7→…→7→12→9→7
* 開始   : 2026-06-22 23:20:00 (UTC)
* 終了   : 2026-06-22 23:30:00 (UTC)
* 現象   : 平常時(8.75)に対し 0.5714(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.606σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260622-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 7→8→11→10→…→10→12→9→8
* 開始   : 2026-06-23 01:25:00 (UTC)
* 終了   : 2026-06-23 01:35:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-002 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260623-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→12→15→13→…→13→16→12→14
* 開始   : 2026-06-23 05:05:00 (UTC)
* 終了   : 2026-06-23 05:15:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.268倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260623-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-lsfhost01-013 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260623-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 14→17→16→14→17→16→13
* 開始   : 2026-06-23 05:45:00 (UTC)
* 終了   : 2026-06-23 05:50:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.333倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.954σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260623-host08-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 17→15→18→16→18→16→18→16
* 開始   : 2026-06-23 06:50:00 (UTC)
* 終了   : 2026-06-23 07:00:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260623-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 18→16→21→18→16→21→18→19
* 開始   : 2026-06-23 08:05:00 (UTC)
* 終了   : 2026-06-23 08:10:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.194倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260623-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 22→21→21→21→21→20→22→21→23
* 開始   : 2026-06-23 09:05:00 (UTC)
* 終了   : 2026-06-23 10:00:00 (UTC)
* 現象   : 2026-06-23 10:00:00 (UTC)を境に水準が 14.87から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.202, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 18→15→17→15→17→15→17→16
* 開始   : 2026-06-23 16:50:00 (UTC)
* 終了   : 2026-06-23 17:00:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host01-009 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260623-host08-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host02-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host12-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 17→16→18→18→17→17→17→16→14
* 開始   : 2026-06-23 16:55:00 (UTC)
* 終了   : 2026-06-23 17:50:00 (UTC)
* 現象   : 2026-06-23 17:50:00 (UTC)を境に水準が 14.94から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.835, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 11→12→9→10→12→9→10→12
* 開始   : 2026-06-23 20:15:00 (UTC)
* 終了   : 2026-06-23 20:20:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host12-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host12-017 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 12→12→9→9→11→11→11→11
* 開始   : 2026-06-23 20:55:00 (UTC)
* 終了   : 2026-06-23 21:30:00 (UTC)
* 現象   : 2026-06-23 21:30:00 (UTC)を境に水準が 14.95から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.468, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260623-host12-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→15→16→13→…→16→13→16→14
* 開始   : 2026-06-24 05:20:00 (UTC)
* 終了   : 2026-06-24 05:40:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260624-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 19→21→23→18→17→23→18→17→19
* 開始   : 2026-06-24 15:15:00 (UTC)
* 終了   : 2026-06-24 15:25:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.145倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host02-009 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260624-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 19→23→19→17→23→19→17→19
* 開始   : 2026-06-24 15:25:00 (UTC)
* 終了   : 2026-06-24 15:35:00 (UTC)
* 現象   : 平常時(19.92)に対し 1.155倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host02-009 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260624-host10-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 17→19→19→18→18→15→18→17→18
* 開始   : 2026-06-24 16:45:00 (UTC)
* 終了   : 2026-06-24 17:25:00 (UTC)
* 現象   : 2026-06-24 17:25:00 (UTC)を境に水準が 14.91から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host12-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→17→17→18→17
* 開始   : 2026-06-24 17:35:00 (UTC)
* 終了   : 2026-06-24 17:55:00 (UTC)
* 現象   : 2026-06-24 17:55:00 (UTC)を境に水準が 14.98から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.913, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host12-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→12→10→11→12→10→11→14
* 開始   : 2026-06-24 19:35:00 (UTC)
* 終了   : 2026-06-24 19:40:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.7317(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-017 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260624-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host12-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host12-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→6→7→6→7→6→9→10
* 開始   : 2026-06-24 22:00:00 (UTC)
* 終了   : 2026-06-24 22:10:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.605(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.722σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host12-019 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-075 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260624-host12-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 10→9→12→8→…→8→13→11→9
* 開始   : 2026-06-25 02:35:00 (UTC)
* 終了   : 2026-06-25 02:45:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260625-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→11→14→11→14→11→14→13→11
* 開始   : 2026-06-25 04:10:00 (UTC)
* 終了   : 2026-06-25 04:20:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.366倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.607σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260625-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260625-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-016 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260625-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-012 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260625-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 20→22→23→22→17→23→22→17→22
* 開始   : 2026-06-25 09:50:00 (UTC)
* 終了   : 2026-06-25 10:00:00 (UTC)
* 現象   : 平常時(19.92)に対し 1.155倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-lsfhost01-038 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 22→20→24→25→…→24→25→23→21
* 開始   : 2026-06-25 11:25:00 (UTC)
* 終了   : 2026-06-25 11:30:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 18→16→15→19→15→19→15→18→17
* 開始   : 2026-06-25 16:30:00 (UTC)
* 終了   : 2026-06-25 16:40:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.154σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260625-lsfhost01-062 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260625-host12-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 16→15→17→14→15→17→14→17→19
* 開始   : 2026-06-25 17:05:00 (UTC)
* 終了   : 2026-06-25 17:15:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 15→14→12→14→12→14
* 開始   : 2026-06-25 18:25:00 (UTC)
* 終了   : 2026-06-25 18:30:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260625-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host12-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 15→17→13→12→…→13→12→14→13
* 開始   : 2026-06-25 18:30:00 (UTC)
* 終了   : 2026-06-25 18:35:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host12-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260625-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260625-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260625-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 13→11→9→10→11→9→10→9
* 開始   : 2026-06-25 20:00:00 (UTC)
* 終了   : 2026-06-25 20:05:00 (UTC)
* 現象   : 平常時(12.83)に対し 0.7013(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.67σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host01-012 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260625-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host12-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 8→11→6→11→6→8→6→8→7
* 開始   : 2026-06-25 22:15:00 (UTC)
* 終了   : 2026-06-25 22:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.678σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host09-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260625-host12-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 13→14→16→14→16→14
* 開始   : 2026-06-26 05:15:00 (UTC)
* 終了   : 2026-06-26 05:20:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.306倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.607σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host12-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260626-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 16→17→15→16→17→15→14
* 開始   : 2026-06-26 05:55:00 (UTC)
* 終了   : 2026-06-26 06:00:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 13→15→18→17→15→18→17→15
* 開始   : 2026-06-26 06:20:00 (UTC)
* 終了   : 2026-06-26 06:25:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.256倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.566σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host12-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260626-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 18→20→15→17→15→17→15→17
* 開始   : 2026-06-26 16:45:00 (UTC)
* 終了   : 2026-06-26 16:55:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.8(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260626-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 10→8→10→9→8→8→10→9→11
* 開始   : 2026-06-28 01:10:00 (UTC)
* 終了   : 2026-06-28 02:05:00 (UTC)
* 現象   : 2026-06-28 02:05:00 (UTC)を境に水準が 11.82から11.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.383, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host12-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 10→11→10→9→9→12
* 開始   : 2026-06-28 01:45:00 (UTC)
* 終了   : 2026-06-28 02:10:00 (UTC)
* 現象   : 2026-06-28 02:10:00 (UTC)を境に水準が 11.73から11.81へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.243, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host12-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_5
* 値     : 9→8→11→8→11→8→11→9→11
* 開始   : 2026-06-28 02:10:00 (UTC)
* 終了   : 2026-06-28 02:20:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host12-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 10→11→7→10→14→7→10→14→12
* 開始   : 2026-06-28 04:10:00 (UTC)
* 終了   : 2026-06-28 04:20:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-006 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260628-host12-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host12-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→13→14→15→16→13
* 開始   : 2026-06-28 06:55:00 (UTC)
* 終了   : 2026-06-28 07:00:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.095σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260628-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host12-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host12-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 9→10→10→7→6→10→10→8→10
* 開始   : 2026-06-28 23:45:00 (UTC)
* 終了   : 2026-06-29 01:10:00 (UTC)
* 現象   : 2026-06-29 01:10:00 (UTC)を境に水準が 11.79から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.225, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260628-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 18→18→20→20→21→18→19→21
* 開始   : 2026-06-30 08:00:00 (UTC)
* 終了   : 2026-06-30 08:35:00 (UTC)
* 現象   : 2026-06-30 08:35:00 (UTC)を境に水準が 14.97から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.468, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host12-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 18→20→21→19→22→21→19→22→20
* 開始   : 2026-06-30 08:30:00 (UTC)
* 終了   : 2026-06-30 08:40:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host12-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 23→21→22→21
* 開始   : 2026-06-30 08:50:00 (UTC)
* 終了   : 2026-06-30 09:05:00 (UTC)
* 現象   : 2026-06-30 09:05:00 (UTC)を境に水準が 15.05から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.72, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host12-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 22→23→18→24→…→18→24→21→23
* 開始   : 2026-06-30 10:45:00 (UTC)
* 終了   : 2026-06-30 10:50:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8606(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host12-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_3
* 値     : 18→19→17→18→17→17→16→17→17
* 開始   : 2026-06-30 16:40:00 (UTC)
* 終了   : 2026-06-30 17:20:00 (UTC)
* 現象   : 2026-06-30 17:20:00 (UTC)を境に水準が 14.83から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.79, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host12-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_2
* 値     : 17→16→14→15→16→14→15→17
* 開始   : 2026-06-30 17:30:00 (UTC)
* 終了   : 2026-06-30 17:35:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260630-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host12-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_6
* 値     : 17→18→14→15→14→15→14→17
* 開始   : 2026-06-30 17:40:00 (UTC)
* 終了   : 2026-06-30 17:50:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260630-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host12-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host12-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host12, port=7003, datasource=OraclePool_1
* 値     : 13→12→10→11→…→11→9→11→10
* 開始   : 2026-06-30 20:00:00 (UTC)
* 終了   : 2026-06-30 20:10:00 (UTC)
* 現象   : 平常時(13)に対し 0.7692(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-host08-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-059 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260630-host12-013 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
