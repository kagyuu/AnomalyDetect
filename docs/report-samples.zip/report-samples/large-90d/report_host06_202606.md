# host06 2026-06 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host06 |
| 対象年月 | 2026-06 |
| 検知イベント数 | 302 (SEVERE: 20, FATAL: 137, WARN: 145, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 20 | 137 | 145 | 302 | ALG-A1, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202606.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260608-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 13→18→15→13→…→17→16→13→12
* 開始   : 2026-06-08 01:25:00 (UTC)
* 終了   : 2026-06-08 21:00:00 (UTC)
* 現象   : 2026-06-08 21:00:00 (UTC)を境に水準が 11.77から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.287, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.661, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host06-002 active_connections の推移](charts/EVT-20260608-host06-002.svg)

# イベントID( EVT-20260608-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→15→14→15→…→15→14→13→14
* 開始   : 2026-06-08 02:45:00 (UTC)
* 終了   : 2026-06-08 20:35:00 (UTC)
* 現象   : 2026-06-08 20:35:00 (UTC)を境に水準が 11.77から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.955σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.886, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host06-004 active_connections の推移](charts/EVT-20260608-host06-004.svg)

# イベントID( EVT-20260608-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→14→15→17→…→13→14→9→11
* 開始   : 2026-06-08 03:05:00 (UTC)
* 終了   : 2026-06-08 20:35:00 (UTC)
* 現象   : 2026-06-08 20:35:00 (UTC)を境に水準が 11.91から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.266σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.821, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.918, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host06-006 active_connections の推移](charts/EVT-20260608-host06-006.svg)

# イベントID( EVT-20260615-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→15→12→15→…→13→16→14→13
* 開始   : 2026-06-15 01:35:00 (UTC)
* 終了   : 2026-06-15 21:05:00 (UTC)
* 現象   : 2026-06-15 21:05:00 (UTC)を境に水準が 11.72から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.689, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.918, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host06-002 active_connections の推移](charts/EVT-20260615-host06-002.svg)

# イベントID( EVT-20260615-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→16→18→19→…→13→12→13→12
* 開始   : 2026-06-15 02:10:00 (UTC)
* 終了   : 2026-06-15 19:55:00 (UTC)
* 現象   : 2026-06-15 19:55:00 (UTC)を境に水準が 11.8から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.193, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.632, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host06-003 active_connections の推移](charts/EVT-20260615-host06-003.svg)

# イベントID( EVT-20260615-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→17→16→17→…→13→16→13→14
* 開始   : 2026-06-15 02:20:00 (UTC)
* 終了   : 2026-06-15 20:35:00 (UTC)
* 現象   : 2026-06-15 20:35:00 (UTC)を境に水準が 11.78から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.614σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.116, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.513, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host06-004 active_connections の推移](charts/EVT-20260615-host06-004.svg)

# イベントID( EVT-20260615-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→14→15→14→…→15→14→12→13
* 開始   : 2026-06-15 02:40:00 (UTC)
* 終了   : 2026-06-15 20:30:00 (UTC)
* 現象   : 2026-06-15 20:30:00 (UTC)を境に水準が 11.76から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.898, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.327, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host06-005 active_connections の推移](charts/EVT-20260615-host06-005.svg)

# イベントID( EVT-20260615-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→17→14→18→…→14→13→11→9
* 開始   : 2026-06-15 03:05:00 (UTC)
* 終了   : 2026-06-15 21:10:00 (UTC)
* 現象   : 2026-06-15 21:10:00 (UTC)を境に水準が 11.8から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.398σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.168, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host06-006 active_connections の推移](charts/EVT-20260615-host06-006.svg)

# イベントID( EVT-20260615-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→16→14→13→…→13→15→12→14
* 開始   : 2026-06-15 03:15:00 (UTC)
* 終了   : 2026-06-15 21:30:00 (UTC)
* 現象   : 2026-06-15 21:30:00 (UTC)を境に水準が 11.85から15.14へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.121, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.119, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260615-host06-007 active_connections の推移](charts/EVT-20260615-host06-007.svg)

# イベントID( EVT-20260622-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→18→20→18→…→11→12→9→12
* 開始   : 2026-06-22 01:55:00 (UTC)
* 終了   : 2026-06-22 20:10:00 (UTC)
* 現象   : 2026-06-22 20:10:00 (UTC)を境に水準が 11.82から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.95, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.77, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host06-001 active_connections の推移](charts/EVT-20260622-host06-001.svg)

# イベントID( EVT-20260622-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 15→16→18→19→…→14→15→16→15
* 開始   : 2026-06-22 02:25:00 (UTC)
* 終了   : 2026-06-22 20:20:00 (UTC)
* 現象   : 2026-06-22 20:20:00 (UTC)を境に水準が 11.79から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.94, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.214, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host06-002 active_connections の推移](charts/EVT-20260622-host06-002.svg)

# イベントID( EVT-20260622-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→13→15→16→…→11→13→11→13
* 開始   : 2026-06-22 02:30:00 (UTC)
* 終了   : 2026-06-22 20:30:00 (UTC)
* 現象   : 2026-06-22 20:30:00 (UTC)を境に水準が 11.93から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.764, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host06-003 active_connections の推移](charts/EVT-20260622-host06-003.svg)

# イベントID( EVT-20260622-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 14→13→16→18→…→14→13→15→14
* 開始   : 2026-06-22 03:05:00 (UTC)
* 終了   : 2026-06-22 20:25:00 (UTC)
* 現象   : 2026-06-22 20:25:00 (UTC)を境に水準が 11.92から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.614σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.707, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.538, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host06-004 active_connections の推移](charts/EVT-20260622-host06-004.svg)

# イベントID( EVT-20260622-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→16→15→16→…→15→14→12→13
* 開始   : 2026-06-22 03:20:00 (UTC)
* 終了   : 2026-06-22 19:05:00 (UTC)
* 現象   : 2026-06-22 19:05:00 (UTC)を境に水準が 11.85から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.822, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.816, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host06-005 active_connections の推移](charts/EVT-20260622-host06-005.svg)

# イベントID( EVT-20260622-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→15→18→15→…→13→11→10→14
* 開始   : 2026-06-22 03:25:00 (UTC)
* 終了   : 2026-06-22 22:20:00 (UTC)
* 現象   : 2026-06-22 22:20:00 (UTC)を境に水準が 11.88から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.751σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.876, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.152, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host06-006 active_connections の推移](charts/EVT-20260622-host06-006.svg)

# イベントID( EVT-20260629-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 14→15→16→15→…→11→13→12→13
* 開始   : 2026-06-29 02:40:00 (UTC)
* 終了   : 2026-06-29 20:30:00 (UTC)
* 現象   : 2026-06-29 20:30:00 (UTC)を境に水準が 11.81から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.253σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.813, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.769, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host06-002 active_connections の推移](charts/EVT-20260629-host06-002.svg)

# イベントID( EVT-20260629-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→16→17→16→…→11→13→11→10
* 開始   : 2026-06-29 02:45:00 (UTC)
* 終了   : 2026-06-29 21:35:00 (UTC)
* 現象   : 2026-06-29 21:35:00 (UTC)を境に水準が 11.85から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.699, 限界=2.7)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.438, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host06-003 active_connections の推移](charts/EVT-20260629-host06-003.svg)

# イベントID( EVT-20260629-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→15→16→14→…→13→11→10→13
* 開始   : 2026-06-29 03:00:00 (UTC)
* 終了   : 2026-06-29 20:25:00 (UTC)
* 現象   : 2026-06-29 20:25:00 (UTC)を境に水準が 11.78から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.764, 限界=2.682)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.73, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host06-004 active_connections の推移](charts/EVT-20260629-host06-004.svg)

# イベントID( EVT-20260629-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→15→16→15→…→12→14→12→14
* 開始   : 2026-06-29 03:00:00 (UTC)
* 終了   : 2026-06-29 20:55:00 (UTC)
* 現象   : 2026-06-29 20:55:00 (UTC)を境に水準が 11.76から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.7, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host06-005 active_connections の推移](charts/EVT-20260629-host06-005.svg)

# イベントID( EVT-20260629-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→16→15→14→…→13→15→13→14
* 開始   : 2026-06-29 03:40:00 (UTC)
* 終了   : 2026-06-29 20:00:00 (UTC)
* 現象   : 2026-06-29 20:00:00 (UTC)を境に水準が 11.85から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.977σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.851, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.443, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host06-007 active_connections の推移](charts/EVT-20260629-host06-007.svg)

# イベントID( EVT-20260601-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→15→19→15→18
* 開始   : 2026-06-01 06:25:00 (UTC)
* 終了   : 2026-06-01 06:25:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host06-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 18→16→21→19→17
* 開始   : 2026-06-01 07:30:00 (UTC)
* 終了   : 2026-06-01 07:30:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.083σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-024 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→14→10→12→9→10→12→9→14
* 開始   : 2026-06-01 19:05:00 (UTC)
* 終了   : 2026-06-01 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 9→9→14→10→12
* 開始   : 2026-06-02 03:40:00 (UTC)
* 終了   : 2026-06-02 03:40:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260602-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→17→20→17→15
* 開始   : 2026-06-02 06:50:00 (UTC)
* 終了   : 2026-06-02 06:50:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-031 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-032 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 19→18→22→20→20
* 開始   : 2026-06-02 08:40:00 (UTC)
* 終了   : 2026-06-02 08:40:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 20→21→26→23→22
* 開始   : 2026-06-02 10:20:00 (UTC)
* 終了   : 2026-06-02 10:20:00 (UTC)
* 現象   : 平常時(21)に対し 1.238倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260602-host06-008 active_connections の推移](charts/EVT-20260602-host06-008.svg)

# イベントID( EVT-20260602-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 23→22→25→18→23→22→25→18→23
* 開始   : 2026-06-02 11:55:00 (UTC)
* 終了   : 2026-06-02 12:00:00 (UTC)
* 現象   : 平常時(22)に対し 1.136倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260602-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→11→6→10→12
* 開始   : 2026-06-02 20:45:00 (UTC)
* 終了   : 2026-06-02 20:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.5294(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.722σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260602-host06-011 active_connections の推移](charts/EVT-20260602-host06-011.svg)

# イベントID( EVT-20260602-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→10→5→8→11
* 開始   : 2026-06-02 21:00:00 (UTC)
* 終了   : 2026-06-02 21:00:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.4615(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-070 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260602-host06-012 active_connections の推移](charts/EVT-20260602-host06-012.svg)

# イベントID( EVT-20260602-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 10→8→5→9→7
* 開始   : 2026-06-02 21:35:00 (UTC)
* 終了   : 2026-06-02 21:35:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.48(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.798σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-078 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260602-host06-013 active_connections の推移](charts/EVT-20260602-host06-013.svg)

# イベントID( EVT-20260602-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 8→10→5→9→9
* 開始   : 2026-06-02 22:00:00 (UTC)
* 終了   : 2026-06-02 22:00:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.5128(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.336σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-081 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-083 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 18→19→21→19→…→19→22→18→19
* 開始   : 2026-06-03 08:15:00 (UTC)
* 終了   : 2026-06-03 08:25:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.248倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.924σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host06-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260603-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260603-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 18→20→23→18→20
* 開始   : 2026-06-03 08:20:00 (UTC)
* 終了   : 2026-06-03 08:20:00 (UTC)
* 現象   : 平常時(18.08)に対し 1.272倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.427σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host06-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→19→14→18→16
* 開始   : 2026-06-03 16:25:00 (UTC)
* 終了   : 2026-06-03 16:25:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.024σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→13→10→13→11
* 開始   : 2026-06-03 18:55:00 (UTC)
* 終了   : 2026-06-03 18:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→11→9→13→12
* 開始   : 2026-06-03 19:35:00 (UTC)
* 終了   : 2026-06-03 19:35:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host01-009 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260603-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 8→8→12→7→8
* 開始   : 2026-06-04 00:50:00 (UTC)
* 終了   : 2026-06-04 00:50:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260604-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 6→7→12→8→9
* 開始   : 2026-06-04 01:00:00 (UTC)
* 終了   : 2026-06-04 01:00:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-004 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→16→19→16→15
* 開始   : 2026-06-04 06:35:00 (UTC)
* 終了   : 2026-06-04 06:35:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.102σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260604-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 22→21→26→22→21
* 開始   : 2026-06-04 10:40:00 (UTC)
* 終了   : 2026-06-04 10:40:00 (UTC)
* 現象   : 平常時(20.75)に対し 1.253倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.674σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260604-host06-008 active_connections の推移](charts/EVT-20260604-host06-008.svg)

# イベントID( EVT-20260604-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 20→22→26→20→19
* 開始   : 2026-06-04 12:40:00 (UTC)
* 終了   : 2026-06-04 12:40:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260604-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→10→8→11→12
* 開始   : 2026-06-04 19:50:00 (UTC)
* 終了   : 2026-06-04 19:50:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-lsfhost01-067 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260604-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→14→10→12→…→10→11→12→11
* 開始   : 2026-06-06 04:30:00 (UTC)
* 終了   : 2026-06-06 19:30:00 (UTC)
* 現象   : 15.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.884, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host06-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260606-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260606-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間

![EVT-20260606-host06-001 active_connections の推移](charts/EVT-20260606-host06-001.svg)

# イベントID( EVT-20260606-host06-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→12→14→12→…→12→11→10→11
* 開始   : 2026-06-06 05:10:00 (UTC)
* 終了   : 2026-06-06 19:10:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.865, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260606-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260606-host06-002 active_connections の推移](charts/EVT-20260606-host06-002.svg)

# イベントID( EVT-20260606-host06-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→10→12→13→…→12→11→13→12
* 開始   : 2026-06-06 05:15:00 (UTC)
* 終了   : 2026-06-06 18:05:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.937, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260606-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260606-host06-003 active_connections の推移](charts/EVT-20260606-host06-003.svg)

# イベントID( EVT-20260606-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→11→10→11→…→11→12→11→13
* 開始   : 2026-06-06 05:25:00 (UTC)
* 終了   : 2026-06-06 19:35:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.764, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260606-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260606-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260606-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host06-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260606-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260606-host06-004 active_connections の推移](charts/EVT-20260606-host06-004.svg)

# イベントID( EVT-20260606-host06-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→11→9→10→…→9→13→9→11
* 開始   : 2026-06-06 05:35:00 (UTC)
* 終了   : 2026-06-06 19:15:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.989, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260606-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260606-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260606-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260606-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260606-host06-005 active_connections の推移](charts/EVT-20260606-host06-005.svg)

# イベントID( EVT-20260606-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→13→11→12→…→11→13→14→11
* 開始   : 2026-06-06 05:55:00 (UTC)
* 終了   : 2026-06-06 18:00:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.74, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host09-004 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.1 時間
  - EVT-20260606-host01-001 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260606-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260606-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260606-host06-006 active_connections の推移](charts/EVT-20260606-host06-006.svg)

# イベントID( EVT-20260607-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 8→8→12→8→7
* 開始   : 2026-06-07 00:05:00 (UTC)
* 終了   : 2026-06-07 00:05:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.194σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 7→9→14→8→10
* 開始   : 2026-06-07 02:40:00 (UTC)
* 終了   : 2026-06-07 02:40:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.585倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.629σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260607-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→16→21→16→15
* 開始   : 2026-06-07 11:50:00 (UTC)
* 終了   : 2026-06-07 11:50:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.34倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.732σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260607-host06-004 active_connections の推移](charts/EVT-20260607-host06-004.svg)

# イベントID( EVT-20260608-host06-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→16→14→16→…→15→14→12→13
* 開始   : 2026-06-08 02:30:00 (UTC)
* 終了   : 2026-06-08 20:00:00 (UTC)
* 現象   : 2026-06-08 20:00:00 (UTC)を境に水準が 11.91から14.95へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.869, 限界=2.697)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.31, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host06-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→14→17→14→…→14→15→14→13
* 開始   : 2026-06-08 02:50:00 (UTC)
* 終了   : 2026-06-08 20:20:00 (UTC)
* 現象   : 2026-06-08 20:20:00 (UTC)を境に水準が 11.76から14.99へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.686, 限界=2.678)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.098, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host06-005 active_connections の推移](charts/EVT-20260608-host06-005.svg)

# イベントID( EVT-20260608-host06-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→14→15→14→…→14→15→11→14
* 開始   : 2026-06-08 03:45:00 (UTC)
* 終了   : 2026-06-08 22:10:00 (UTC)
* 現象   : 2026-06-08 22:10:00 (UTC)を境に水準が 11.93から15.05へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.717, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.728, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260608-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→8→13→7→6
* 開始   : 2026-06-09 01:20:00 (UTC)
* 終了   : 2026-06-09 01:20:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.253σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-003 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260609-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→14→18→16→16
* 開始   : 2026-06-09 05:45:00 (UTC)
* 終了   : 2026-06-09 05:45:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→16→11→16→14
* 開始   : 2026-06-09 18:25:00 (UTC)
* 終了   : 2026-06-09 18:25:00 (UTC)
* 現象   : 平常時(15.58)に対し 0.7059(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260609-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 12→12→10→14→14
* 開始   : 2026-06-09 19:15:00 (UTC)
* 終了   : 2026-06-09 19:15:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 9→9→5→11→9
* 開始   : 2026-06-09 22:05:00 (UTC)
* 終了   : 2026-06-09 22:05:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.5085(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260609-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 11→12→15→12→12
* 開始   : 2026-06-10 04:20:00 (UTC)
* 終了   : 2026-06-10 04:20:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 13→12→17→15→13
* 開始   : 2026-06-10 05:05:00 (UTC)
* 終了   : 2026-06-10 05:05:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.427倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-lsfhost01-014 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260610-host06-005 active_connections の推移](charts/EVT-20260610-host06-005.svg)

# イベントID( EVT-20260610-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→18→23→21→21
* 開始   : 2026-06-10 09:00:00 (UTC)
* 終了   : 2026-06-10 09:00:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.284倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.568σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-035 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260610-host06-009 active_connections の推移](charts/EVT-20260610-host06-009.svg)

# イベントID( EVT-20260610-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 21→21→14→19→17
* 開始   : 2026-06-10 16:20:00 (UTC)
* 終了   : 2026-06-10 16:20:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.7179(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.863σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host06-011 active_connections の推移](charts/EVT-20260610-host06-011.svg)

# イベントID( EVT-20260610-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 10→13→6→10→11
* 開始   : 2026-06-10 21:10:00 (UTC)
* 終了   : 2026-06-10 21:10:00 (UTC)
* 現象   : 平常時(11)に対し 0.5455(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.49σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260610-host06-014 active_connections の推移](charts/EVT-20260610-host06-014.svg)

# イベントID( EVT-20260610-host06-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→10→5→9→9
* 開始   : 2026-06-10 22:10:00 (UTC)
* 終了   : 2026-06-10 22:10:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host10-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260610-host06-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→12→15→10→12
* 開始   : 2026-06-11 03:55:00 (UTC)
* 終了   : 2026-06-11 03:55:00 (UTC)
* 現象   : 平常時(10.33)に対し 1.452倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 17→19→22→18→16
* 開始   : 2026-06-11 07:50:00 (UTC)
* 終了   : 2026-06-11 07:50:00 (UTC)
* 現象   : 平常時(17.17)に対し 1.282倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 18→20→15→19→18
* 開始   : 2026-06-11 15:50:00 (UTC)
* 終了   : 2026-06-11 15:50:00 (UTC)
* 現象   : 平常時(20)に対し 0.75(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host06-010 active_connections の推移](charts/EVT-20260611-host06-010.svg)

# イベントID( EVT-20260612-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 10→10→14→10→9
* 開始   : 2026-06-12 03:00:00 (UTC)
* 終了   : 2026-06-12 03:00:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.447σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-008 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 11→13→16→12→13
* 開始   : 2026-06-12 04:20:00 (UTC)
* 終了   : 2026-06-12 04:20:00 (UTC)
* 現象   : 平常時(11)に対し 1.455倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host06-003 active_connections の推移](charts/EVT-20260612-host06-003.svg)

# イベントID( EVT-20260612-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→16→20→14→15
* 開始   : 2026-06-12 06:30:00 (UTC)
* 終了   : 2026-06-12 06:30:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.326倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.427σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-035 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 19→20→16→20→19
* 開始   : 2026-06-12 15:25:00 (UTC)
* 終了   : 2026-06-12 15:25:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260612-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 18→17→15→19→…→14→17→14→17
* 開始   : 2026-06-12 16:50:00 (UTC)
* 終了   : 2026-06-12 17:30:00 (UTC)
* 現象   : 40分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260612-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260612-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→11→9→7→…→7→10→8→10
* 開始   : 2026-06-12 20:45:00 (UTC)
* 終了   : 2026-06-12 21:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host03-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260612-lsfhost01-089 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260612-host01-019 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-087 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-088 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260612-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-086 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260612-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→8→13→10→9
* 開始   : 2026-06-13 02:05:00 (UTC)
* 終了   : 2026-06-13 02:05:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.158σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-lsfhost01-006 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260613-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260613-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→12→14→10→…→11→12→13→10
* 開始   : 2026-06-13 05:25:00 (UTC)
* 終了   : 2026-06-13 18:25:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.856, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260613-host06-003 active_connections の推移](charts/EVT-20260613-host06-003.svg)

# イベントID( EVT-20260613-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→12→11→13→…→11→10→11→10
* 開始   : 2026-06-13 05:50:00 (UTC)
* 終了   : 2026-06-13 19:30:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.311σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.812, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260613-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260613-host06-004 active_connections の推移](charts/EVT-20260613-host06-004.svg)

# イベントID( EVT-20260613-host06-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→12→11→12→…→14→15→11→13
* 開始   : 2026-06-13 06:00:00 (UTC)
* 終了   : 2026-06-13 19:15:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.967, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260613-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260613-host06-005 active_connections の推移](charts/EVT-20260613-host06-005.svg)

# イベントID( EVT-20260613-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 14→13→11→13→…→13→9→11→10
* 開始   : 2026-06-13 06:05:00 (UTC)
* 終了   : 2026-06-13 20:00:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.275, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260613-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260613-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260613-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間

![EVT-20260613-host06-006 active_connections の推移](charts/EVT-20260613-host06-006.svg)

# イベントID( EVT-20260613-host06-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→13→…→11→13→12→13
* 開始   : 2026-06-13 06:10:00 (UTC)
* 終了   : 2026-06-13 19:20:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.041, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260613-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260613-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260613-host06-007 active_connections の推移](charts/EVT-20260613-host06-007.svg)

# イベントID( EVT-20260613-host06-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→14→11→13→…→12→11→12→14
* 開始   : 2026-06-13 06:20:00 (UTC)
* 終了   : 2026-06-13 18:35:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.77, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260613-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260613-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260613-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260613-host06-008 active_connections の推移](charts/EVT-20260613-host06-008.svg)

# イベントID( EVT-20260613-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 8→5→11→8→5→11→8
* 開始   : 2026-06-13 23:00:00 (UTC)
* 終了   : 2026-06-13 23:30:00 (UTC)
* 現象   : 平常時(8.167)に対し 1.592倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260613-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260613-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→12→16→13→12
* 開始   : 2026-06-14 17:55:00 (UTC)
* 終了   : 2026-06-14 17:55:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260614-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 8→10→4→8→8
* 開始   : 2026-06-15 22:55:00 (UTC)
* 終了   : 2026-06-15 22:55:00 (UTC)
* 現象   : 平常時(8.833)に対し 0.4528(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260615-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 20→21→24→19→21
* 開始   : 2026-06-16 09:00:00 (UTC)
* 終了   : 2026-06-16 09:00:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.236倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.213σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 17→17→12→16→18
* 開始   : 2026-06-16 17:15:00 (UTC)
* 終了   : 2026-06-16 17:15:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.6923(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.743σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host06-006 active_connections の推移](charts/EVT-20260616-host06-006.svg)

# イベントID( EVT-20260616-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 18→17→12→18→14
* 開始   : 2026-06-16 17:35:00 (UTC)
* 終了   : 2026-06-16 18:00:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.731(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.079σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 20 分
  - EVT-20260616-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-053 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260616-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 17→16→13→14→16
* 開始   : 2026-06-16 17:40:00 (UTC)
* 終了   : 2026-06-16 17:40:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.75(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-051 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 10→11→15→10→10
* 開始   : 2026-06-17 03:30:00 (UTC)
* 終了   : 2026-06-17 03:30:00 (UTC)
* 現象   : 平常時(10)に対し 1.5倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host06-001 active_connections の推移](charts/EVT-20260617-host06-001.svg)

# イベントID( EVT-20260617-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→12→16→10→11
* 開始   : 2026-06-17 03:50:00 (UTC)
* 終了   : 2026-06-17 03:50:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.524倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.833σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host06-002 active_connections の推移](charts/EVT-20260617-host06-002.svg)

# イベントID( EVT-20260617-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→17→19→17→16
* 開始   : 2026-06-17 06:15:00 (UTC)
* 終了   : 2026-06-17 06:15:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.136σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260617-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 17→18→22→18→18
* 開始   : 2026-06-17 07:50:00 (UTC)
* 終了   : 2026-06-17 07:50:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.3倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.571σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host06-006 active_connections の推移](charts/EVT-20260617-host06-006.svg)

# イベントID( EVT-20260617-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 18→18→22→19→19
* 開始   : 2026-06-17 08:05:00 (UTC)
* 終了   : 2026-06-17 08:05:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.257倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.136σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260617-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 16→14→8→14→13
* 開始   : 2026-06-17 19:35:00 (UTC)
* 終了   : 2026-06-17 19:35:00 (UTC)
* 現象   : 平常時(13.25)に対し 0.6038(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.685σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-071 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-host13-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-host16-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260617-host06-013 active_connections の推移](charts/EVT-20260617-host06-013.svg)

# イベントID( EVT-20260618-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→18→14→17→18→14→17→15→17
* 開始   : 2026-06-18 06:00:00 (UTC)
* 終了   : 2026-06-18 06:10:00 (UTC)
* 現象   : 平常時(13.67)に対し 1.317倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.025σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260618-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 22→22→17→19→21
* 開始   : 2026-06-18 14:20:00 (UTC)
* 終了   : 2026-06-18 14:20:00 (UTC)
* 現象   : 平常時(21.5)に対し 0.7907(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→16→9→13→13
* 開始   : 2026-06-18 18:55:00 (UTC)
* 終了   : 2026-06-18 18:55:00 (UTC)
* 現象   : 平常時(14.83)に対し 0.6067(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.066σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-lsfhost01-051 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260618-host06-007 active_connections の推移](charts/EVT-20260618-host06-007.svg)

# イベントID( EVT-20260619-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 16→17→20→15→17
* 開始   : 2026-06-19 06:55:00 (UTC)
* 終了   : 2026-06-19 06:55:00 (UTC)
* 現象   : 平常時(15.17)に対し 1.319倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260619-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 18→16→21→13→…→21→13→15→17
* 開始   : 2026-06-19 17:05:00 (UTC)
* 終了   : 2026-06-19 17:10:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host06-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host06-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→9→7→11→12→9→7→11→12
* 開始   : 2026-06-19 20:10:00 (UTC)
* 終了   : 2026-06-19 20:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host06-009 active_connections の推移](charts/EVT-20260619-host06-009.svg)

# イベントID( EVT-20260620-host06-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 8→12→9→11→…→11→12→10→11
* 開始   : 2026-06-20 05:15:00 (UTC)
* 終了   : 2026-06-20 18:55:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.838, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260620-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260620-host06-001 active_connections の推移](charts/EVT-20260620-host06-001.svg)

# イベントID( EVT-20260620-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→12→13→15→…→11→12→11→12
* 開始   : 2026-06-20 05:25:00 (UTC)
* 終了   : 2026-06-20 20:05:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.308, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260620-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260620-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260620-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260620-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260620-host06-002 active_connections の推移](charts/EVT-20260620-host06-002.svg)

# イベントID( EVT-20260620-host06-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→11→13→11→…→12→10→12→11
* 開始   : 2026-06-20 05:40:00 (UTC)
* 終了   : 2026-06-20 18:40:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.892, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260620-host06-003 active_connections の推移](charts/EVT-20260620-host06-003.svg)

# イベントID( EVT-20260620-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→11→12→13→…→10→11→13→11
* 開始   : 2026-06-20 06:00:00 (UTC)
* 終了   : 2026-06-20 19:35:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.937, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260620-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260620-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260620-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260620-host06-004 active_connections の推移](charts/EVT-20260620-host06-004.svg)

# イベントID( EVT-20260620-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 13→11→12→13→…→10→12→11→12
* 開始   : 2026-06-20 06:30:00 (UTC)
* 終了   : 2026-06-20 19:00:00 (UTC)
* 現象   : 12.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.943, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260620-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260620-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.5 時間
  - EVT-20260620-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260620-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間

![EVT-20260620-host06-005 active_connections の推移](charts/EVT-20260620-host06-005.svg)

# イベントID( EVT-20260620-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→11→12→11→…→13→9→12→13
* 開始   : 2026-06-20 06:40:00 (UTC)
* 終了   : 2026-06-20 18:35:00 (UTC)
* 現象   : 11.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.884, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-002 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間

![EVT-20260620-host06-006 active_connections の推移](charts/EVT-20260620-host06-006.svg)

# イベントID( EVT-20260620-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→10→6→10→10
* 開始   : 2026-06-20 19:40:00 (UTC)
* 終了   : 2026-06-20 19:40:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.5294(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.722σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260620-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260620-host06-007 active_connections の推移](charts/EVT-20260620-host06-007.svg)

# イベントID( EVT-20260620-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→12→5→11→9
* 開始   : 2026-06-20 20:55:00 (UTC)
* 終了   : 2026-06-20 20:55:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.427σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260620-host02-009 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260620-lsfhost01-058 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260620-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260620-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 10→13→11→14→13→11→14→11→10
* 開始   : 2026-06-21 04:15:00 (UTC)
* 終了   : 2026-06-21 04:25:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.381倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.515σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260621-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260621-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260621-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→11→16→13→13
* 開始   : 2026-06-21 06:45:00 (UTC)
* 終了   : 2026-06-21 06:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.078σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→10→9→10→10→10→10→11
* 開始   : 2026-06-21 21:05:00 (UTC)
* 終了   : 2026-06-21 22:40:00 (UTC)
* 現象   : 2026-06-21 22:40:00 (UTC)を境に水準が 11.78から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.141σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.885, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→9→10→10→9→10→9
* 開始   : 2026-06-21 22:30:00 (UTC)
* 終了   : 2026-06-21 23:40:00 (UTC)
* 現象   : 2026-06-21 23:40:00 (UTC)を境に水準が 11.75から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.392σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.775, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→13→17→10→…→17→10→14→13
* 開始   : 2026-06-23 04:40:00 (UTC)
* 終了   : 2026-06-23 05:10:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.478倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.856σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 30 分
  - EVT-20260623-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260623-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260623-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host06-001 active_connections の推移](charts/EVT-20260623-host06-001.svg)

# イベントID( EVT-20260623-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→14→20→16→17
* 開始   : 2026-06-23 07:00:00 (UTC)
* 終了   : 2026-06-23 07:00:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.326倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.432σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→17→19→17→…→17→21→16→19
* 開始   : 2026-06-23 07:05:00 (UTC)
* 終了   : 2026-06-23 07:15:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260623-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 19→19→23→17→19
* 開始   : 2026-06-23 08:25:00 (UTC)
* 終了   : 2026-06-23 08:25:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.257σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 22→21→25→21→21
* 開始   : 2026-06-23 10:20:00 (UTC)
* 終了   : 2026-06-23 10:20:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 22→21→27→22→21
* 開始   : 2026-06-23 11:25:00 (UTC)
* 終了   : 2026-06-23 11:25:00 (UTC)
* 現象   : 平常時(22)に対し 1.227倍(27)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 7→6→12→10→10
* 開始   : 2026-06-24 00:20:00 (UTC)
* 終了   : 2026-06-24 00:20:00 (UTC)
* 現象   : 平常時(7.417)に対し 1.618倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.219σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 17→12→14→15→15→16
* 開始   : 2026-06-24 05:10:00 (UTC)
* 終了   : 2026-06-24 05:35:00 (UTC)
* 現象   : 2026-06-24 05:35:00 (UTC)を境に水準が 15.03から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260624-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 17→16→19→21→…→19→21→17→19
* 開始   : 2026-06-24 07:10:00 (UTC)
* 終了   : 2026-06-24 07:15:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260624-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 20→19→22→23→…→22→23→20→21
* 開始   : 2026-06-24 09:10:00 (UTC)
* 終了   : 2026-06-24 09:15:00 (UTC)
* 現象   : 平常時(18)に対し 1.222倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.792σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 20→22→24→21→20→22→24→21→20
* 開始   : 2026-06-24 09:15:00 (UTC)
* 終了   : 2026-06-24 09:20:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260624-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 20→22→25→19→21
* 開始   : 2026-06-24 09:25:00 (UTC)
* 終了   : 2026-06-24 09:25:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.261倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.615σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260624-host06-007 active_connections の推移](charts/EVT-20260624-host06-007.svg)

# イベントID( EVT-20260624-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 20→21→25→24→…→25→24→20→22
* 開始   : 2026-06-24 10:20:00 (UTC)
* 終了   : 2026-06-24 10:25:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→18→13→16→17
* 開始   : 2026-06-24 17:00:00 (UTC)
* 終了   : 2026-06-24 17:00:00 (UTC)
* 現象   : 平常時(17.75)に対し 0.7324(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→16→11→14→16
* 開始   : 2026-06-24 18:15:00 (UTC)
* 終了   : 2026-06-24 18:15:00 (UTC)
* 現象   : 平常時(15.75)に対し 0.6984(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260624-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→11→7→11→11
* 開始   : 2026-06-24 20:10:00 (UTC)
* 終了   : 2026-06-24 20:10:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.56(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.834σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260624-host06-014 active_connections の推移](charts/EVT-20260624-host06-014.svg)

# イベントID( EVT-20260624-host06-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→11→7→10→10
* 開始   : 2026-06-24 21:00:00 (UTC)
* 終了   : 2026-06-24 21:00:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host10-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host06-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→11→5→10→10
* 開始   : 2026-06-24 21:35:00 (UTC)
* 終了   : 2026-06-24 21:35:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.4762(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.834σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host06-016 active_connections の推移](charts/EVT-20260624-host06-016.svg)

# イベントID( EVT-20260625-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→9→13→8→8
* 開始   : 2026-06-25 01:35:00 (UTC)
* 終了   : 2026-06-25 01:35:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.608倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.447σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-lsfhost01-003 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260625-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 10→11→15→9→10
* 開始   : 2026-06-25 03:05:00 (UTC)
* 終了   : 2026-06-25 03:05:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.579倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.856σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host06-002 active_connections の推移](charts/EVT-20260625-host06-002.svg)

# イベントID( EVT-20260625-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→12→16→12→14
* 開始   : 2026-06-25 04:55:00 (UTC)
* 終了   : 2026-06-25 04:55:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.044σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260625-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 18→16→21→17→19
* 開始   : 2026-06-25 07:35:00 (UTC)
* 終了   : 2026-06-25 07:35:00 (UTC)
* 現象   : 平常時(16.17)に対し 1.299倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-lsfhost01-030 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260625-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 22→20→26→23→22
* 開始   : 2026-06-25 13:00:00 (UTC)
* 終了   : 2026-06-25 13:00:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.02σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 13→12→8→14→13
* 開始   : 2026-06-25 19:20:00 (UTC)
* 終了   : 2026-06-25 19:20:00 (UTC)
* 現象   : 平常時(13.75)に対し 0.5818(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260625-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host06-008 active_connections の推移](charts/EVT-20260625-host06-008.svg)

# イベントID( EVT-20260625-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→9→4→10→10
* 開始   : 2026-06-25 22:10:00 (UTC)
* 終了   : 2026-06-25 22:10:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.4211(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.86σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260625-host06-009 active_connections の推移](charts/EVT-20260625-host06-009.svg)

# イベントID( EVT-20260626-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→12→17→13→11
* 開始   : 2026-06-26 04:40:00 (UTC)
* 終了   : 2026-06-26 04:40:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.389σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 24→21→18→24→20
* 開始   : 2026-06-26 12:05:00 (UTC)
* 終了   : 2026-06-26 12:05:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 23→23→18→22→20
* 開始   : 2026-06-26 13:00:00 (UTC)
* 終了   : 2026-06-26 13:00:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.803(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260626-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 16→13→14→13→14→13→15
* 開始   : 2026-06-26 18:00:00 (UTC)
* 終了   : 2026-06-26 18:45:00 (UTC)
* 現象   : 平常時(16.42)に対し 0.7919(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→8→4→6→9
* 開始   : 2026-06-26 22:30:00 (UTC)
* 終了   : 2026-06-26 22:30:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.4404(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.548σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-079 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260626-host06-015 active_connections の推移](charts/EVT-20260626-host06-015.svg)

# イベントID( EVT-20260627-host06-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 12→11→12→10→…→10→13→11→10
* 開始   : 2026-06-27 04:55:00 (UTC)
* 終了   : 2026-06-27 19:00:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.786, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260627-host06-002 active_connections の推移](charts/EVT-20260627-host06-002.svg)

# イベントID( EVT-20260627-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 14→13→12→14→…→14→15→12→14
* 開始   : 2026-06-27 05:10:00 (UTC)
* 終了   : 2026-06-27 19:30:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.136σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.756, 限界=2.697)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260627-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間

![EVT-20260627-host06-003 active_connections の推移](charts/EVT-20260627-host06-003.svg)

# イベントID( EVT-20260627-host06-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→12→14→13→…→9→11→10→12
* 開始   : 2026-06-27 05:20:00 (UTC)
* 終了   : 2026-06-27 19:00:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.759, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.7 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260627-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260627-host06-004 active_connections の推移](charts/EVT-20260627-host06-004.svg)

# イベントID( EVT-20260627-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→14→12→10→…→12→11→13→12
* 開始   : 2026-06-27 05:20:00 (UTC)
* 終了   : 2026-06-27 18:30:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.315σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.915, 限界=2.7)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260627-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260627-host06-005 active_connections の推移](charts/EVT-20260627-host06-005.svg)

# イベントID( EVT-20260627-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 12→11→9→11→…→14→10→11→12
* 開始   : 2026-06-27 05:25:00 (UTC)
* 終了   : 2026-06-27 19:50:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.828, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260627-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260627-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260627-host12-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260627-lsfhost01-019 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260627-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 14.2 時間

![EVT-20260627-host06-006 active_connections の推移](charts/EVT-20260627-host06-006.svg)

# イベントID( EVT-20260627-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→10→…→10→11→10→11
* 開始   : 2026-06-27 06:10:00 (UTC)
* 終了   : 2026-06-27 19:40:00 (UTC)
* 現象   : 13.5時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.038σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.891, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260627-host06-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260627-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260627-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260627-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間

![EVT-20260627-host06-007 active_connections の推移](charts/EVT-20260627-host06-007.svg)

# イベントID( EVT-20260628-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→10→16→11→12
* 開始   : 2026-06-28 05:50:00 (UTC)
* 終了   : 2026-06-28 05:50:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.477倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.601σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host06-001 active_connections の推移](charts/EVT-20260628-host06-001.svg)

# イベントID( EVT-20260628-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→12→16→13→13
* 開始   : 2026-06-28 06:55:00 (UTC)
* 終了   : 2026-06-28 06:55:00 (UTC)
* 現象   : 平常時(11.33)に対し 1.412倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.253σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260628-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→16→11→15→14
* 開始   : 2026-06-28 15:10:00 (UTC)
* 終了   : 2026-06-28 15:10:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.137σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 11→6→13→9→11→6→13→9
* 開始   : 2026-06-28 20:05:00 (UTC)
* 終了   : 2026-06-28 20:10:00 (UTC)
* 現象   : 日曜20時台の平常値(9.566)に対し 6であった
* 説明   : ALG-A1: 移動平均からの残差が 3.091σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.141σ 外れた (平常値=9.566)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260628-host01-007 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260628-lsfhost01-037 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260628-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260628-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260629-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→8→3→7→8
* 開始   : 2026-06-29 00:55:00 (UTC)
* 終了   : 2026-06-29 00:55:00 (UTC)
* 現象   : 平常時(8.167)に対し 0.3673(3)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260629-host06-001 active_connections の推移](charts/EVT-20260629-host06-001.svg)

# イベントID( EVT-20260629-host06-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→16→15→14→…→11→13→11→12
* 開始   : 2026-06-29 03:25:00 (UTC)
* 終了   : 2026-06-29 19:35:00 (UTC)
* 現象   : 2026-06-29 19:35:00 (UTC)を境に水準が 11.71から14.9へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.315, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.48, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260629-host06-006 active_connections の推移](charts/EVT-20260629-host06-006.svg)

# イベントID( EVT-20260630-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→11→15→12→13
* 開始   : 2026-06-30 04:05:00 (UTC)
* 終了   : 2026-06-30 04:05:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 21→22→16→20→18
* 開始   : 2026-06-30 15:30:00 (UTC)
* 終了   : 2026-06-30 15:30:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.7773(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host06-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 11→14→11→14→11→14→11→14→12
* 開始   : 2026-06-01 03:55:00 (UTC)
* 終了   : 2026-06-01 04:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.576σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-005 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260601-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260601-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-013 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260601-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→11→15→16→…→15→16→15→11
* 開始   : 2026-06-01 04:45:00 (UTC)
* 終了   : 2026-06-01 04:50:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260601-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→12→17→15→17→15→17→16→17
* 開始   : 2026-06-01 05:55:00 (UTC)
* 終了   : 2026-06-01 06:05:00 (UTC)
* 現象   : 平常時(13.17)に対し 1.291倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.672σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260601-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→18→19→16→15→18→19→16→17
* 開始   : 2026-06-01 06:25:00 (UTC)
* 終了   : 2026-06-01 06:30:00 (UTC)
* 現象   : 平常時(15.08)に対し 1.193倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.041σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260601-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 22→24→19→26→…→19→26→21→20
* 開始   : 2026-06-01 11:25:00 (UTC)
* 終了   : 2026-06-01 11:30:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.045σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260601-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→22→19→16→22→19→16→18→17
* 開始   : 2026-06-01 16:05:00 (UTC)
* 終了   : 2026-06-01 16:15:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260601-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260601-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260601-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260601-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 10→11→8→14→…→8→14→10→9
* 開始   : 2026-06-01 20:30:00 (UTC)
* 終了   : 2026-06-01 20:35:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260601-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260601-host04-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260601-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260601-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→11→8→5→11→8→5→7→10
* 開始   : 2026-06-02 00:55:00 (UTC)
* 終了   : 2026-06-02 01:05:00 (UTC)
* 現象   : 平常時(7.917)に対し 1.389倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-lsfhost01-003 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 8→12→11→8→12→11→8
* 開始   : 2026-06-02 01:40:00 (UTC)
* 終了   : 2026-06-02 01:45:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.532倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.904σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-004 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260602-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→12→16→14→12→16→14→13
* 開始   : 2026-06-02 05:15:00 (UTC)
* 終了   : 2026-06-02 05:20:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.343倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.85σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260602-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260602-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260602-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 13→16→14→16→…→14→17→15→14
* 開始   : 2026-06-02 05:25:00 (UTC)
* 終了   : 2026-06-02 05:45:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.395σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260602-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260602-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260602-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260602-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260602-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260602-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 17→15→13→14→15→13→14
* 開始   : 2026-06-02 18:15:00 (UTC)
* 終了   : 2026-06-02 18:20:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260602-lsfhost01-061 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260602-host01-014 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260602-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→15→10→15→10→15→14→13
* 開始   : 2026-06-03 04:35:00 (UTC)
* 終了   : 2026-06-03 04:45:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 18→19→18→18→20→21→20
* 開始   : 2026-06-03 07:40:00 (UTC)
* 終了   : 2026-06-03 08:10:00 (UTC)
* 現象   : 2026-06-03 08:10:00 (UTC)を境に水準が 15から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260603-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 17→19→21→18→21→18→21→18→20
* 開始   : 2026-06-03 08:15:00 (UTC)
* 終了   : 2026-06-03 08:25:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host06-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260603-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 16→17→14→16→14→16→14→15→16
* 開始   : 2026-06-03 17:20:00 (UTC)
* 終了   : 2026-06-03 17:30:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260603-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260603-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260603-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260603-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260603-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 18→16→14→17→…→17→13→16→15
* 開始   : 2026-06-03 17:30:00 (UTC)
* 終了   : 2026-06-03 17:40:00 (UTC)
* 現象   : 平常時(17)に対し 0.8235(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-host06-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260603-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-host02-008 (他ホスト) jvm_gc / ou : FATAL / 重なり 10 分
  - EVT-20260603-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260603-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260603-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260603-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260603-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260603-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→12→8→11→12→8→11→9
* 開始   : 2026-06-03 21:15:00 (UTC)
* 終了   : 2026-06-03 21:20:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260603-lsfhost01-078 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260603-host09-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260603-lsfhost01-077 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分
  - EVT-20260603-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260603-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→11→14→15→11→14→15→11
* 開始   : 2026-06-04 04:25:00 (UTC)
* 終了   : 2026-06-04 04:30:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.047σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260604-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260604-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 14→13→16→14→17→16→14→17→13
* 開始   : 2026-06-04 05:30:00 (UTC)
* 終了   : 2026-06-04 05:40:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260604-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260604-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260604-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→15→17→14→15→17→14→16
* 開始   : 2026-06-04 05:55:00 (UTC)
* 終了   : 2026-06-04 06:00:00 (UTC)
* 現象   : 平常時(13.25)に対し 1.283倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260604-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→16→18→19→15→16→18→19→20
* 開始   : 2026-06-04 06:45:00 (UTC)
* 終了   : 2026-06-04 07:55:00 (UTC)
* 現象   : 2026-06-04 07:55:00 (UTC)を境に水準が 15.04から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.661, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260604-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→21→18→21→…→21→24→22→20
* 開始   : 2026-06-04 13:50:00 (UTC)
* 終了   : 2026-06-04 14:00:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260604-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260604-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→10→9→13→12→10→9→13→10
* 開始   : 2026-06-04 19:30:00 (UTC)
* 終了   : 2026-06-04 19:35:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260604-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260604-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→12→9→11→12→9→11→13
* 開始   : 2026-06-04 19:40:00 (UTC)
* 終了   : 2026-06-04 19:45:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.7059(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.632σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260604-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260604-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260604-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260604-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 8→11→9→11→9→11→7→8
* 開始   : 2026-06-05 00:40:00 (UTC)
* 終了   : 2026-06-05 00:50:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→10→12→9→12→9→12→10→12
* 開始   : 2026-06-05 02:45:00 (UTC)
* 終了   : 2026-06-05 02:55:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260605-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 17→14→18→15→17→15→15
* 開始   : 2026-06-05 05:45:00 (UTC)
* 終了   : 2026-06-05 06:15:00 (UTC)
* 現象   : 2026-06-05 06:15:00 (UTC)を境に水準が 14.99から14.73へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.265σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.256, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260605-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 18→17→21→20→17→21→20→17
* 開始   : 2026-06-05 08:00:00 (UTC)
* 終了   : 2026-06-05 08:05:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260605-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260605-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260605-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 21→25→21→18→25→21→18→22→20
* 開始   : 2026-06-05 13:20:00 (UTC)
* 終了   : 2026-06-05 13:30:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260605-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260605-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260605-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260606-host06-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 10→9→10→9→…→8→10→12→13
* 開始   : 2026-06-06 19:20:00 (UTC)
* 終了   : 2026-06-06 19:45:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.729, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260606-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260606-host06-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260606-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260606-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260606-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260606-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260606-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260606-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260606-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260606-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分

![EVT-20260606-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 10→11→12→11→10→11→11→12→11
* 開始   : 2026-06-07 04:05:00 (UTC)
* 終了   : 2026-06-07 04:45:00 (UTC)
* 現象   : 2026-06-07 04:45:00 (UTC)を境に水準が 11.74から12.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.918, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→12→17→12→17→12→13→15
* 開始   : 2026-06-07 15:15:00 (UTC)
* 終了   : 2026-06-07 15:25:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.337σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260607-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 10→9→7→13→…→7→13→7→9
* 開始   : 2026-06-07 20:40:00 (UTC)
* 終了   : 2026-06-07 20:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260607-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260607-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260607-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260607-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260607-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→11→8→10→10→11
* 開始   : 2026-06-07 21:10:00 (UTC)
* 終了   : 2026-06-07 21:35:00 (UTC)
* 現象   : 2026-06-07 21:35:00 (UTC)を境に水準が 11.82から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260607-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260608-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 6→8→11→8→11→8→7
* 開始   : 2026-06-08 01:05:00 (UTC)
* 終了   : 2026-06-08 01:10:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260608-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 9→10→12→11→12→11→12→9→12
* 開始   : 2026-06-09 03:00:00 (UTC)
* 終了   : 2026-06-09 03:10:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host06-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-lsfhost01-011 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260609-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 10→8→12→10→…→10→13→12→11
* 開始   : 2026-06-09 03:10:00 (UTC)
* 終了   : 2026-06-09 03:20:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host06-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260609-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260609-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→13→15→13→…→13→16→14→15
* 開始   : 2026-06-09 04:45:00 (UTC)
* 終了   : 2026-06-09 04:55:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260609-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260609-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→13→16→13→16→13→14
* 開始   : 2026-06-09 05:15:00 (UTC)
* 終了   : 2026-06-09 05:20:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.315倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.676σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260609-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260609-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260609-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260609-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 18→17→15→17→15→17→16
* 開始   : 2026-06-09 16:55:00 (UTC)
* 終了   : 2026-06-09 17:00:00 (UTC)
* 現象   : 平常時(19)に対し 0.7895(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.792σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260609-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260609-lsfhost01-045 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260609-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260609-host06-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→12→10→11→9→10→11→9→12
* 開始   : 2026-06-09 20:50:00 (UTC)
* 終了   : 2026-06-09 21:40:00 (UTC)
* 現象   : 2026-06-09 21:40:00 (UTC)を境に水準が 14.99から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.974, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260609-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→7→10→9→9→11→11→8→11
* 開始   : 2026-06-10 01:25:00 (UTC)
* 終了   : 2026-06-10 02:35:00 (UTC)
* 現象   : 2026-06-10 02:35:00 (UTC)を境に水準が 15.02から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.69, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 8→12→11→13→12→11→13→11→10
* 開始   : 2026-06-10 02:55:00 (UTC)
* 終了   : 2026-06-10 03:05:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.107σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-lsfhost01-006 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 9→10→12→11→13→12→11→13→11
* 開始   : 2026-06-10 03:05:00 (UTC)
* 終了   : 2026-06-10 03:55:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-007 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260610-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 14→15→18→19→…→18→19→18→14
* 開始   : 2026-06-10 06:30:00 (UTC)
* 終了   : 2026-06-10 06:35:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260610-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 17→20→18→20→18→20→18→17
* 開始   : 2026-06-10 07:25:00 (UTC)
* 終了   : 2026-06-10 07:35:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.224倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-lsfhost01-028 (他ホスト) lsf_queue / run : WARN / 重なり 10 分

![EVT-20260610-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→19→20→17→15→19→20→17→18
* 開始   : 2026-06-10 07:35:00 (UTC)
* 終了   : 2026-06-10 08:25:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260610-lsfhost01-033 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260610-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260610-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260610-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260610-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 21→22→21→22→22→21→21→20→22
* 開始   : 2026-06-10 14:00:00 (UTC)
* 終了   : 2026-06-10 14:45:00 (UTC)
* 現象   : 2026-06-10 14:45:00 (UTC)を境に水準が 14.98から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.02, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260610-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 16→17→13→12→…→13→12→16→14
* 開始   : 2026-06-10 17:55:00 (UTC)
* 終了   : 2026-06-10 18:00:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7761(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.624σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260610-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 16→14→13→16→13→16→13→16→13
* 開始   : 2026-06-10 18:00:00 (UTC)
* 終了   : 2026-06-10 18:10:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.8041(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.223σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260610-host06-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260610-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260610-lsfhost01-057 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260610-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260610-lsfhost01-062 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260610-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260610-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260610-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→17→14→17→14→17→16→15
* 開始   : 2026-06-11 06:00:00 (UTC)
* 終了   : 2026-06-11 06:10:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host06-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 15→14→17→15→17→15→17→15
* 開始   : 2026-06-11 06:05:00 (UTC)
* 終了   : 2026-06-11 06:15:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.229倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host06-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260611-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 15→16→18→17→16→18→17→18
* 開始   : 2026-06-11 06:35:00 (UTC)
* 終了   : 2026-06-11 06:40:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-026 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260611-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260611-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260611-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 19→18→18→19→19→19→18→19→23
* 開始   : 2026-06-11 07:30:00 (UTC)
* 終了   : 2026-06-11 08:40:00 (UTC)
* 現象   : 2026-06-11 08:40:00 (UTC)を境に水準が 14.96から15.12へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.661, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 17→20→21→19→21→19→21→19
* 開始   : 2026-06-11 08:25:00 (UTC)
* 終了   : 2026-06-11 08:35:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.212倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 20→23→19→20→23→19→20
* 開始   : 2026-06-11 09:30:00 (UTC)
* 終了   : 2026-06-11 09:35:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260611-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 21→24→19→24→…→24→18→22→21
* 開始   : 2026-06-11 13:15:00 (UTC)
* 終了   : 2026-06-11 13:25:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260611-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260611-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 20→19→15→18→15→18→15→16→17
* 開始   : 2026-06-11 16:40:00 (UTC)
* 終了   : 2026-06-11 16:50:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.512σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260611-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260611-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 17→15→17→15→15→14→14→17→16
* 開始   : 2026-06-11 17:55:00 (UTC)
* 終了   : 2026-06-11 18:45:00 (UTC)
* 現象   : 2026-06-11 18:45:00 (UTC)を境に水準が 15.07から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.218, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260611-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 10→11→9→11→9→11→9→11
* 開始   : 2026-06-11 20:20:00 (UTC)
* 終了   : 2026-06-11 20:30:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.283σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260611-lsfhost01-073 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260611-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260611-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 10 分
  - EVT-20260611-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260611-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260611-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→8→9→8→…→9→8→10→9
* 開始   : 2026-06-11 21:00:00 (UTC)
* 終了   : 2026-06-11 21:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.675σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260611-lsfhost01-078 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260611-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260611-host13-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260611-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 10→10→11→9→12→12→12
* 開始   : 2026-06-12 02:45:00 (UTC)
* 終了   : 2026-06-12 03:15:00 (UTC)
* 現象   : 2026-06-12 03:15:00 (UTC)を境に水準が 14.81から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.774, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→18→17→15→18→17→16
* 開始   : 2026-06-12 06:35:00 (UTC)
* 終了   : 2026-06-12 06:40:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.4σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-lsfhost01-036 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260612-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260612-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260612-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-035 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260612-lsfhost01-038 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260612-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 17→16→19→16→…→16→20→19→18
* 開始   : 2026-06-12 07:20:00 (UTC)
* 終了   : 2026-06-12 07:30:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260612-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 21→23→21→20→23→22→25→22→24
* 開始   : 2026-06-12 09:40:00 (UTC)
* 終了   : 2026-06-12 10:50:00 (UTC)
* 現象   : 2026-06-12 10:50:00 (UTC)を境に水準が 14.93から13.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.66, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260612-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 21→19→17→20→17→20→17→21→20
* 開始   : 2026-06-12 14:50:00 (UTC)
* 終了   : 2026-06-12 15:00:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.8063(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.846σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260612-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260612-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260612-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260612-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 9→10→6→9→10→6→9→11
* 開始   : 2026-06-12 23:05:00 (UTC)
* 終了   : 2026-06-12 23:10:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260612-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→10→13→10→13→10→13→11→10
* 開始   : 2026-06-13 04:20:00 (UTC)
* 終了   : 2026-06-13 04:30:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.106σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260613-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260613-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260613-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260613-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host06-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 10→9→7→8→…→7→8→9→8
* 開始   : 2026-06-13 20:25:00 (UTC)
* 終了   : 2026-06-13 20:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.774, 限界=2.682)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260613-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260613-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260613-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260613-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 8→11→6→8→11→6→8→7
* 開始   : 2026-06-13 22:35:00 (UTC)
* 終了   : 2026-06-13 22:40:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.166σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260613-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260613-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260613-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 8→5→8→5→8→9
* 開始   : 2026-06-14 00:35:00 (UTC)
* 終了   : 2026-06-14 00:40:00 (UTC)
* 現象   : 平常時(8.25)に対し 0.6061(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260614-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260614-lsfhost01-001 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260614-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 13→11→7→14→11→7→14→11
* 開始   : 2026-06-14 05:10:00 (UTC)
* 終了   : 2026-06-14 05:15:00 (UTC)
* 現象   : 平常時(10.5)に対し 0.6667(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.458σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260614-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260614-lsfhost01-009 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260614-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→11→14→15→11→14→15→11→13
* 開始   : 2026-06-14 06:30:00 (UTC)
* 終了   : 2026-06-14 06:35:00 (UTC)
* 現象   : 平常時(10.83)に対し 1.292倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260614-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260614-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→7→11→7→11→7→8→11
* 開始   : 2026-06-14 20:10:00 (UTC)
* 終了   : 2026-06-14 20:20:00 (UTC)
* 現象   : 平常時(10.58)に対し 0.6614(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.498σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260614-lsfhost01-040 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分

![EVT-20260614-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260615-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 9→7→11→10→7→11→10→8
* 開始   : 2026-06-15 00:55:00 (UTC)
* 終了   : 2026-06-15 01:00:00 (UTC)
* 現象   : 平常時(7.833)に対し 1.404倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.207σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260615-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 13→12→15→12→…→12→16→13→14
* 開始   : 2026-06-16 05:15:00 (UTC)
* 終了   : 2026-06-16 05:25:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260616-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-lsfhost01-023 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260616-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260616-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260616-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260616-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→15→16→13→16→13→16→13→16
* 開始   : 2026-06-16 05:30:00 (UTC)
* 終了   : 2026-06-16 05:40:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.385σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260616-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260616-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260616-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 19→20→22→23→…→22→23→22→21
* 開始   : 2026-06-16 08:55:00 (UTC)
* 終了   : 2026-06-16 09:00:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host06-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260616-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 22→22→24→23→21→24→23→22→24
* 開始   : 2026-06-16 12:05:00 (UTC)
* 終了   : 2026-06-16 13:05:00 (UTC)
* 現象   : 2026-06-16 13:05:00 (UTC)を境に水準が 14.99から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.439, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260616-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260616-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→12→8→9→12→8→9
* 開始   : 2026-06-16 20:55:00 (UTC)
* 終了   : 2026-06-16 21:00:00 (UTC)
* 現象   : 平常時(11.42)に対し 0.7007(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.382σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260616-host12-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260616-host01-014 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260616-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 14→13→16→15→16→15→16→13→12
* 開始   : 2026-06-17 05:05:00 (UTC)
* 終了   : 2026-06-17 05:15:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.306倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.629σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 12→16→12→16→14→16→14→15
* 開始   : 2026-06-17 05:20:00 (UTC)
* 終了   : 2026-06-17 05:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.916σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 22→20→18→22→22→19→22
* 開始   : 2026-06-17 08:30:00 (UTC)
* 終了   : 2026-06-17 09:00:00 (UTC)
* 現象   : 2026-06-17 09:00:00 (UTC)を境に水準が 14.97から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.774, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260617-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 19→21→23→21→…→21→24→20→22
* 開始   : 2026-06-17 09:45:00 (UTC)
* 終了   : 2026-06-17 09:55:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.179倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260617-lsfhost01-040 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260617-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 20→21→18→19→21→18→19
* 開始   : 2026-06-17 14:20:00 (UTC)
* 終了   : 2026-06-17 14:25:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-045 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260617-lsfhost01-046 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260617-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 18→15→20→15→20→15→18
* 開始   : 2026-06-17 16:30:00 (UTC)
* 終了   : 2026-06-17 16:40:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.396σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260617-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260617-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→16→12→14→12→14→12→15→12
* 開始   : 2026-06-17 18:40:00 (UTC)
* 終了   : 2026-06-17 18:50:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7784(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.4σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260617-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260617-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host08-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260617-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260617-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 10→12→7→8→12→7→8→9
* 開始   : 2026-06-17 21:35:00 (UTC)
* 終了   : 2026-06-17 21:40:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.333σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260617-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260617-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260617-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260617-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→10→14→13→…→13→15→14→15
* 開始   : 2026-06-18 04:40:00 (UTC)
* 終了   : 2026-06-18 04:50:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260618-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→13→16→14→13→16→14→15
* 開始   : 2026-06-18 05:20:00 (UTC)
* 終了   : 2026-06-18 05:25:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.28倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260618-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 22→23→25→19→…→25→19→25→22
* 開始   : 2026-06-18 12:40:00 (UTC)
* 終了   : 2026-06-18 12:50:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.091σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260618-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→13→12→15→13→12→15→14
* 開始   : 2026-06-18 18:10:00 (UTC)
* 終了   : 2026-06-18 18:15:00 (UTC)
* 現象   : 平常時(15.25)に対し 0.7869(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.268σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host08-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260618-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260618-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→12→10→12→10→12→13
* 開始   : 2026-06-18 19:35:00 (UTC)
* 終了   : 2026-06-18 19:40:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260618-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260618-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260618-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260618-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→11→8→9→…→9→7→12→11
* 開始   : 2026-06-18 20:35:00 (UTC)
* 終了   : 2026-06-18 20:45:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260618-host16-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260618-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260618-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 11→14→12→15→14→12→15→11
* 開始   : 2026-06-19 04:10:00 (UTC)
* 終了   : 2026-06-19 04:20:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260619-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-010 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260619-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-011 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 20→18→22→19→…→19→23→18→22
* 開始   : 2026-06-19 08:45:00 (UTC)
* 終了   : 2026-06-19 08:55:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.2倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.573σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260619-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 24→23→22→23→21→21→23→23
* 開始   : 2026-06-19 13:05:00 (UTC)
* 終了   : 2026-06-19 13:40:00 (UTC)
* 現象   : 2026-06-19 13:40:00 (UTC)を境に水準が 14.93から13.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.436, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260619-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 18→15→14→19→18→15→14→19
* 開始   : 2026-06-19 17:00:00 (UTC)
* 終了   : 2026-06-19 17:05:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260619-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 17→18→15→14→…→15→14→16→18
* 開始   : 2026-06-19 17:10:00 (UTC)
* 終了   : 2026-06-19 17:15:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host06-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260619-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260619-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260619-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260619-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260619-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 15→12→15→11→12→15→11→13→14
* 開始   : 2026-06-19 18:15:00 (UTC)
* 終了   : 2026-06-19 18:25:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.454σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260619-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260619-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260619-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 11→7→13→10→…→10→6→11→9
* 開始   : 2026-06-19 21:35:00 (UTC)
* 終了   : 2026-06-19 21:45:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260619-host01-015 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260619-lsfhost01-077 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260619-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 11→13→14→10→14→10→14→12→13
* 開始   : 2026-06-21 05:50:00 (UTC)
* 終了   : 2026-06-21 06:00:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.281σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260621-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host06-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 14→15→16→13→14→15→14→12→16
* 開始   : 2026-06-21 07:05:00 (UTC)
* 終了   : 2026-06-21 07:50:00 (UTC)
* 現象   : 2026-06-21 07:50:00 (UTC)を境に水準が 11.84から12.4へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.106, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host06-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→16→14→17→17→13→15→15→16
* 開始   : 2026-06-21 14:55:00 (UTC)
* 終了   : 2026-06-21 15:40:00 (UTC)
* 現象   : 2026-06-21 15:40:00 (UTC)を境に水準が 11.94から14.27へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.96, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260621-host06-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→14→16→15→14→13→14→14→14
* 開始   : 2026-06-21 15:00:00 (UTC)
* 終了   : 2026-06-21 16:15:00 (UTC)
* 現象   : 2026-06-21 16:15:00 (UTC)を境に水準が 11.74から14.43へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.633, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260621-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260622-host06-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 10→9→11→10→8→10→10→10
* 開始   : 2026-06-22 21:25:00 (UTC)
* 終了   : 2026-06-22 22:00:00 (UTC)
* 現象   : 2026-06-22 22:00:00 (UTC)を境に水準が 14.92から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.816, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260622-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→14→17→14→…→14→17→18→16
* 開始   : 2026-06-23 06:10:00 (UTC)
* 終了   : 2026-06-23 06:30:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.682σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260623-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260623-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260623-host06-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 18→19→22→19→22→19→21
* 開始   : 2026-06-23 09:00:00 (UTC)
* 終了   : 2026-06-23 09:05:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.149σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260623-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 21→20→25→23→…→23→18→23→21
* 開始   : 2026-06-23 14:00:00 (UTC)
* 終了   : 2026-06-23 14:10:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.341σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260623-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 16→17→14→18→14→18→14→15
* 開始   : 2026-06-23 17:15:00 (UTC)
* 終了   : 2026-06-23 17:25:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.7742(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.857σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host12-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→17→12→15→12→15→12→15→14
* 開始   : 2026-06-23 17:55:00 (UTC)
* 終了   : 2026-06-23 18:05:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.7539(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.734σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-053 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260623-lsfhost01-052 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260623-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 13→15→11→14→11→14→11→13
* 開始   : 2026-06-23 18:55:00 (UTC)
* 終了   : 2026-06-23 19:05:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.7586(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.449σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260623-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260623-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→13→…→13→10→13→11
* 開始   : 2026-06-23 19:05:00 (UTC)
* 終了   : 2026-06-23 19:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.573σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260623-host06-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260623-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260623-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260623-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260623-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260623-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260623-host08-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260623-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260623-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260623-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→16→17→15→…→15→18→15→16
* 開始   : 2026-06-24 06:00:00 (UTC)
* 終了   : 2026-06-24 06:10:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.036σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260624-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260624-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260624-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 18→23→17→22→23→17→22→18→19
* 開始   : 2026-06-24 15:50:00 (UTC)
* 終了   : 2026-06-24 16:00:00 (UTC)
* 現象   : 水曜15時台の平常値(19.16)に対し 23であった
* 説明   : ALG-A1: 移動平均からの残差が 2.857σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.056σ 外れた (平常値=19.16)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260624-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 16→15→12→15→12→15
* 開始   : 2026-06-24 17:55:00 (UTC)
* 終了   : 2026-06-24 18:00:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.7423(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.927σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-host01-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260624-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260624-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 16→12→16→12→16→12→16→13
* 開始   : 2026-06-24 18:30:00 (UTC)
* 終了   : 2026-06-24 18:40:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.21σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260624-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-063 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260624-lsfhost01-065 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260624-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260624-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260624-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260624-lsfhost01-064 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260624-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 17→20→21→18→21→18→21→18→19
* 開始   : 2026-06-25 08:25:00 (UTC)
* 終了   : 2026-06-25 08:35:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.269σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260625-lsfhost01-034 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260625-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260625-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260625-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 18→19→16→19→16→19→18
* 開始   : 2026-06-25 16:20:00 (UTC)
* 終了   : 2026-06-25 16:25:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.391σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260625-host03-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260625-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 10→8→9→9→11→10
* 開始   : 2026-06-26 01:35:00 (UTC)
* 終了   : 2026-06-26 02:00:00 (UTC)
* 現象   : 2026-06-26 02:00:00 (UTC)を境に水準が 14.98から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.612, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 12→13→16→17→…→16→17→15→16
* 開始   : 2026-06-26 05:40:00 (UTC)
* 終了   : 2026-06-26 05:45:00 (UTC)
* 現象   : 平常時(13.08)に対し 1.223倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.033σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260626-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 18→16→20→16→20→18→20→18
* 開始   : 2026-06-26 07:20:00 (UTC)
* 終了   : 2026-06-26 07:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.573σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260626-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-lsfhost01-029 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260626-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 20→18→22→21→18→22→21
* 開始   : 2026-06-26 09:20:00 (UTC)
* 終了   : 2026-06-26 09:25:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 21→23→19→21→…→21→25→23→22
* 開始   : 2026-06-26 12:00:00 (UTC)
* 終了   : 2026-06-26 12:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.152σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host06-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 22→22→20→19→21→22→22
* 開始   : 2026-06-26 14:35:00 (UTC)
* 終了   : 2026-06-26 15:05:00 (UTC)
* 現象   : 2026-06-26 15:05:00 (UTC)を境に水準が 15.02から12.74へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.71, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 22→21→18→20→18→20→18→19
* 開始   : 2026-06-26 14:55:00 (UTC)
* 終了   : 2026-06-26 15:05:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.8438(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.34σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260626-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260626-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 20→16→18
* 開始   : 2026-06-26 17:40:00 (UTC)
* 終了   : 2026-06-26 17:50:00 (UTC)
* 現象   : 2026-06-26 17:50:00 (UTC)を境に水準が 14.94から12.24へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.288, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260626-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 12→11→9→14→9→14→9→13→12
* 開始   : 2026-06-26 19:45:00 (UTC)
* 終了   : 2026-06-26 20:15:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host11-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260626-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260626-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260626-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260626-host06-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260626-host06-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 12→9→15→9→…→9→8→9→8
* 開始   : 2026-06-26 20:55:00 (UTC)
* 終了   : 2026-06-26 21:05:00 (UTC)
* 現象   : 平常時(11)に対し 1.364倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.792σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260626-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-host10-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260626-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260626-host06-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host06-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_6
* 値     : 9→10→11→13→10→11→13→11
* 開始   : 2026-06-27 04:40:00 (UTC)
* 終了   : 2026-06-27 04:45:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(11)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.967, 限界=2.678)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260627-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260627-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260627-lsfhost01-012 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260627-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260627-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260627-lsfhost01-008 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260627-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260627-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260627-host06-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 11→9→8→8→8→11→9→9→10
* 開始   : 2026-06-27 23:10:00 (UTC)
* 終了   : 2026-06-27 23:50:00 (UTC)
* 現象   : 2026-06-27 23:50:00 (UTC)を境に水準が 11.76から11.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.995, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260627-host06-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 15→12→16→12→17→16→12→17→14
* 開始   : 2026-06-28 07:40:00 (UTC)
* 終了   : 2026-06-28 07:50:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.327σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260628-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260628-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260628-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 14→19→13→15→14→19→13→15→17
* 開始   : 2026-06-28 12:25:00 (UTC)
* 終了   : 2026-06-28 12:30:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.216σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260628-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 8→12→11→13→12→11→13→9
* 開始   : 2026-06-30 02:40:00 (UTC)
* 終了   : 2026-06-30 02:50:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260630-host06-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 10→11→15→13→11→15→13→14
* 開始   : 2026-06-30 04:50:00 (UTC)
* 終了   : 2026-06-30 04:55:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.314倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.501σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260630-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260630-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260630-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host06-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 15→16→17→15
* 開始   : 2026-06-30 05:10:00 (UTC)
* 終了   : 2026-06-30 05:25:00 (UTC)
* 現象   : 2026-06-30 05:25:00 (UTC)を境に水準が 14.9から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.4σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.384, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host06-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→12→17→15→…→14→18→15→14
* 開始   : 2026-06-30 05:50:00 (UTC)
* 終了   : 2026-06-30 06:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.398σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-lsfhost01-020 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260630-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260630-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260630-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host06-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_4
* 値     : 19→16→20→17→…→22→16→19→17
* 開始   : 2026-06-30 07:30:00 (UTC)
* 終了   : 2026-06-30 08:05:00 (UTC)
* 現象   : 2026-06-30 08:05:00 (UTC)を境に水準が 15.02から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.714, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host06-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 21→20→17→20→17→20→17→20→21
* 開始   : 2026-06-30 15:20:00 (UTC)
* 終了   : 2026-06-30 15:30:00 (UTC)
* 現象   : 平常時(20.58)に対し 0.8259(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.498σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host06-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260630-host06-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 19→20→17→21→16→17→21→16→20
* 開始   : 2026-06-30 15:45:00 (UTC)
* 終了   : 2026-06-30 15:55:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.094σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260630-host06-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_1
* 値     : 14→12→11→10→…→11→10→14→13
* 開始   : 2026-06-30 18:55:00 (UTC)
* 終了   : 2026-06-30 19:00:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.164σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260630-lsfhost01-057 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260630-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260630-host06-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_5
* 値     : 13→12→11→10→…→11→10→13→12
* 開始   : 2026-06-30 19:15:00 (UTC)
* 終了   : 2026-06-30 19:20:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260630-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260630-host06-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_3
* 値     : 9→7→10→13→7→10→13→8→9
* 開始   : 2026-06-30 21:40:00 (UTC)
* 終了   : 2026-06-30 21:50:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.7059(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.049σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260630-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260630-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260630-host14-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260630-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260630-host06-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260630-host06-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host06, port=7003, datasource=OraclePool_2
* 値     : 10→8→10→9→9→9
* 開始   : 2026-06-30 22:15:00 (UTC)
* 終了   : 2026-06-30 22:40:00 (UTC)
* 現象   : 2026-06-30 22:40:00 (UTC)を境に水準が 15から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.077, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260630-host06-013 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
