# host15 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host15 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 275 (SEVERE: 22, FATAL: 124, WARN: 129, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 22 | 124 | 129 | 275 | ALG-A1, ALG-A2, ALG-A4, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260803-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→16→15→16→…→13→16→13→11
* 開始   : 2026-08-03 00:55:00 (UTC)
* 終了   : 2026-08-03 20:00:00 (UTC)
* 現象   : 2026-08-03 20:00:00 (UTC)を境に水準が 11.75から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.868, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.5, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host15-001 active_connections の推移](charts/EVT-20260803-host15-001.svg)

# イベントID( EVT-20260803-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→14→16→15→…→16→13→15→12
* 開始   : 2026-08-03 01:30:00 (UTC)
* 終了   : 2026-08-03 20:15:00 (UTC)
* 現象   : 2026-08-03 20:15:00 (UTC)を境に水準が 11.76から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.105, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.718, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host15-002 active_connections の推移](charts/EVT-20260803-host15-002.svg)

# イベントID( EVT-20260803-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→15→16→15→…→16→15→12→13
* 開始   : 2026-08-03 02:15:00 (UTC)
* 終了   : 2026-08-03 20:55:00 (UTC)
* 現象   : 2026-08-03 20:55:00 (UTC)を境に水準が 11.9から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.723, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host15-003 active_connections の推移](charts/EVT-20260803-host15-003.svg)

# イベントID( EVT-20260803-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→14→15→14→…→15→13→15→13
* 開始   : 2026-08-03 02:50:00 (UTC)
* 終了   : 2026-08-03 20:45:00 (UTC)
* 現象   : 2026-08-03 20:45:00 (UTC)を境に水準が 11.89から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.839, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.751, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host15-004 active_connections の推移](charts/EVT-20260803-host15-004.svg)

# イベントID( EVT-20260803-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 12→16→18→16→…→14→13→14→12
* 開始   : 2026-08-03 03:25:00 (UTC)
* 終了   : 2026-08-03 20:45:00 (UTC)
* 現象   : 2026-08-03 20:45:00 (UTC)を境に水準が 11.9から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.69, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.878, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host15-005 active_connections の推移](charts/EVT-20260803-host15-005.svg)

# イベントID( EVT-20260803-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→17→16→15→…→13→14→11→10
* 開始   : 2026-08-03 03:35:00 (UTC)
* 終了   : 2026-08-03 21:10:00 (UTC)
* 現象   : 2026-08-03 21:10:00 (UTC)を境に水準が 11.93から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.616σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.688, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.973, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host15-006 active_connections の推移](charts/EVT-20260803-host15-006.svg)

# イベントID( EVT-20260810-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→16→17→16→…→14→12→13→12
* 開始   : 2026-08-10 02:05:00 (UTC)
* 終了   : 2026-08-10 20:15:00 (UTC)
* 現象   : 2026-08-10 20:15:00 (UTC)を境に水準が 11.72から14.86へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.025, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.793, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host15-001 active_connections の推移](charts/EVT-20260810-host15-001.svg)

# イベントID( EVT-20260810-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→15→14→13→…→14→16→12→14
* 開始   : 2026-08-10 02:10:00 (UTC)
* 終了   : 2026-08-10 20:15:00 (UTC)
* 現象   : 2026-08-10 20:15:00 (UTC)を境に水準が 11.77から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.805, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.733, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host15-002 active_connections の推移](charts/EVT-20260810-host15-002.svg)

# イベントID( EVT-20260810-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→14→15→16→…→16→14→12→14
* 開始   : 2026-08-10 02:35:00 (UTC)
* 終了   : 2026-08-10 20:15:00 (UTC)
* 現象   : 2026-08-10 20:15:00 (UTC)を境に水準が 11.84から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.429σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.976, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.88, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host15-003 active_connections の推移](charts/EVT-20260810-host15-003.svg)

# イベントID( EVT-20260810-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→15→16→15→…→12→14→12→15
* 開始   : 2026-08-10 03:30:00 (UTC)
* 終了   : 2026-08-10 19:45:00 (UTC)
* 現象   : 2026-08-10 19:45:00 (UTC)を境に水準が 11.95から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.681, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host15-004 active_connections の推移](charts/EVT-20260810-host15-004.svg)

# イベントID( EVT-20260810-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 14→15→16→15→…→14→12→11→13
* 開始   : 2026-08-10 04:00:00 (UTC)
* 終了   : 2026-08-10 20:25:00 (UTC)
* 現象   : 2026-08-10 20:25:00 (UTC)を境に水準が 11.91から14.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.06, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.45, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host15-005 active_connections の推移](charts/EVT-20260810-host15-005.svg)

# イベントID( EVT-20260810-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 15→18→15→16→…→14→12→11→14
* 開始   : 2026-08-10 04:10:00 (UTC)
* 終了   : 2026-08-10 20:55:00 (UTC)
* 現象   : 2026-08-10 20:55:00 (UTC)を境に水準が 11.85から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.688σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.8, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.608, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host15-006 active_connections の推移](charts/EVT-20260810-host15-006.svg)

# イベントID( EVT-20260817-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 18→16→17→16→…→16→15→11→12
* 開始   : 2026-08-17 02:35:00 (UTC)
* 終了   : 2026-08-17 20:55:00 (UTC)
* 現象   : 2026-08-17 20:55:00 (UTC)を境に水準が 11.85から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.009, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.203, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host15-002 active_connections の推移](charts/EVT-20260817-host15-002.svg)

# イベントID( EVT-20260817-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→15→14→15→…→13→14→11→12
* 開始   : 2026-08-17 02:35:00 (UTC)
* 終了   : 2026-08-17 20:15:00 (UTC)
* 現象   : 2026-08-17 20:15:00 (UTC)を境に水準が 11.75から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.214σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.779, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host15-003 active_connections の推移](charts/EVT-20260817-host15-003.svg)

# イベントID( EVT-20260817-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 15→14→19→17→…→16→15→11→13
* 開始   : 2026-08-17 03:10:00 (UTC)
* 終了   : 2026-08-17 19:55:00 (UTC)
* 現象   : 2026-08-17 19:55:00 (UTC)を境に水準が 11.92から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.264, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host15-004 active_connections の推移](charts/EVT-20260817-host15-004.svg)

# イベントID( EVT-20260817-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→16→15→16→…→16→15→11→14
* 開始   : 2026-08-17 03:30:00 (UTC)
* 終了   : 2026-08-17 23:10:00 (UTC)
* 現象   : 2026-08-17 23:10:00 (UTC)を境に水準が 11.94から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.799, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host15-005 active_connections の推移](charts/EVT-20260817-host15-005.svg)

# イベントID( EVT-20260817-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→19→15→17→…→15→14→12→14
* 開始   : 2026-08-17 04:00:00 (UTC)
* 終了   : 2026-08-17 19:10:00 (UTC)
* 現象   : 2026-08-17 19:10:00 (UTC)を境に水準が 11.9から15.08へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.047, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host15-006 active_connections の推移](charts/EVT-20260817-host15-006.svg)

# イベントID( EVT-20260824-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 16→17→15→17→…→13→12→11→13
* 開始   : 2026-08-24 01:50:00 (UTC)
* 終了   : 2026-08-24 20:20:00 (UTC)
* 現象   : 2026-08-24 20:20:00 (UTC)を境に水準が 11.86から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.22σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.701, 限界=2.674)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host15-001 active_connections の推移](charts/EVT-20260824-host15-001.svg)

# イベントID( EVT-20260824-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 13→14→16→14→…→14→13→14→12
* 開始   : 2026-08-24 02:20:00 (UTC)
* 終了   : 2026-08-24 20:35:00 (UTC)
* 現象   : 2026-08-24 20:35:00 (UTC)を境に水準が 11.82から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.742, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.85, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host15-002 active_connections の推移](charts/EVT-20260824-host15-002.svg)

# イベントID( EVT-20260824-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→16→18→17→…→8→12→8→11
* 開始   : 2026-08-24 02:55:00 (UTC)
* 終了   : 2026-08-24 20:25:00 (UTC)
* 現象   : 2026-08-24 20:25:00 (UTC)を境に水準が 11.81から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.035 倍に達した (閾値 3)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.711, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=13.04, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host15-003 active_connections の推移](charts/EVT-20260824-host15-003.svg)

# イベントID( EVT-20260824-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→13→17→18→…→15→13→12→14
* 開始   : 2026-08-24 03:10:00 (UTC)
* 終了   : 2026-08-24 21:15:00 (UTC)
* 現象   : 2026-08-24 21:15:00 (UTC)を境に水準が 11.84から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.672σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.199, 限界=2.685)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.556, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host15-005 active_connections の推移](charts/EVT-20260824-host15-005.svg)

# イベントID( EVT-20260824-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→13→16→13→…→11→13→11→13
* 開始   : 2026-08-24 03:25:00 (UTC)
* 終了   : 2026-08-24 20:45:00 (UTC)
* 現象   : 2026-08-24 20:45:00 (UTC)を境に水準が 11.8から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.061, 限界=2.687)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host15-006 active_connections の推移](charts/EVT-20260824-host15-006.svg)

# イベントID( EVT-20260801-host15-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→14→…→12→13→12→13
* 開始   : 2026-08-01 04:30:00 (UTC)
* 終了   : 2026-08-01 18:45:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.231, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 14.2 時間

![EVT-20260801-host15-001 active_connections の推移](charts/EVT-20260801-host15-001.svg)

# イベントID( EVT-20260801-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→8→11→12→…→11→12→14→13
* 開始   : 2026-08-01 04:35:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.011, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260801-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 14.8 時間

![EVT-20260801-host15-002 active_connections の推移](charts/EVT-20260801-host15-002.svg)

# イベントID( EVT-20260801-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→12→11→12→…→8→11→12→11
* 開始   : 2026-08-01 05:45:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.871, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260801-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.0 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.9 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260801-host15-003 active_connections の推移](charts/EVT-20260801-host15-003.svg)

# イベントID( EVT-20260801-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 11→12→11→12→…→12→11→12→13
* 開始   : 2026-08-01 06:00:00 (UTC)
* 終了   : 2026-08-01 18:35:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.761, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260801-host15-004 active_connections の推移](charts/EVT-20260801-host15-004.svg)

# イベントID( EVT-20260801-host15-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→12→11→12→…→10→11→12→9
* 開始   : 2026-08-01 06:10:00 (UTC)
* 終了   : 2026-08-01 18:50:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.138, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260801-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260801-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.6 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.5 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260801-host15-005 active_connections の推移](charts/EVT-20260801-host15-005.svg)

# イベントID( EVT-20260801-host15-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→13→12→14→…→12→10→12→11
* 開始   : 2026-08-01 06:25:00 (UTC)
* 終了   : 2026-08-01 18:45:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.735, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.3 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.2 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260801-host15-006 active_connections の推移](charts/EVT-20260801-host15-006.svg)

# イベントID( EVT-20260802-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 8→6→12→7→7
* 開始   : 2026-08-02 01:25:00 (UTC)
* 終了   : 2026-08-02 01:25:00 (UTC)
* 現象   : 平常時(7.167)に対し 1.674倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-lsfhost01-004 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260802-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→14→8→15→11
* 開始   : 2026-08-02 04:10:00 (UTC)
* 終了   : 2026-08-02 04:30:00 (UTC)
* 現象   : 2026-08-02 04:30:00 (UTC)を境に水準が 11.71から12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.183, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→10→13→9→8
* 開始   : 2026-08-04 02:25:00 (UTC)
* 終了   : 2026-08-04 02:25:00 (UTC)
* 現象   : 平常時(8.333)に対し 1.56倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-004 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→11→16→12→12
* 開始   : 2026-08-04 04:40:00 (UTC)
* 終了   : 2026-08-04 04:40:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260804-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 21→21→16→22→20
* 開始   : 2026-08-04 15:05:00 (UTC)
* 終了   : 2026-08-04 15:05:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-037 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260804-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 16→14→10→15→17
* 開始   : 2026-08-04 18:05:00 (UTC)
* 終了   : 2026-08-04 18:05:00 (UTC)
* 現象   : 平常時(15.83)に対し 0.6316(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260804-host15-011 active_connections の推移](charts/EVT-20260804-host15-011.svg)

# イベントID( EVT-20260804-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 17→14→11→14→13
* 開始   : 2026-08-04 18:10:00 (UTC)
* 終了   : 2026-08-04 18:10:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260804-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260804-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 20→22→21→22→20→22→26→21→24
* 開始   : 2026-08-05 09:30:00 (UTC)
* 終了   : 2026-08-05 10:20:00 (UTC)
* 現象   : 2026-08-05 10:20:00 (UTC)を境に水準が 14.91から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.673σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.827, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 19→20→16→17→16→17→16→20→18
* 開始   : 2026-08-05 15:35:00 (UTC)
* 終了   : 2026-08-05 15:45:00 (UTC)
* 現象   : 平常時(20.33)に対し 0.7869(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-045 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260805-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 17→16→14→16→16→12→15→14→16
* 開始   : 2026-08-05 17:50:00 (UTC)
* 終了   : 2026-08-05 19:05:00 (UTC)
* 現象   : 2026-08-05 19:05:00 (UTC)を境に水準が 14.92から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→13→11→12→13→11→12→13
* 開始   : 2026-08-05 18:40:00 (UTC)
* 終了   : 2026-08-05 18:45:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host01-015 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260805-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260805-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→12→9→14→…→14→10→14→12
* 開始   : 2026-08-05 19:25:00 (UTC)
* 終了   : 2026-08-05 19:35:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.6626(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host03-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 21→22→25→23→22
* 開始   : 2026-08-06 10:10:00 (UTC)
* 終了   : 2026-08-06 10:10:00 (UTC)
* 現象   : 平常時(20.58)に対し 1.215倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-035 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260806-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 20→17→19→15→17→19→15→20→19
* 開始   : 2026-08-06 15:45:00 (UTC)
* 終了   : 2026-08-06 15:55:00 (UTC)
* 現象   : 平常時(20.17)に対し 0.843(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260806-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260806-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 19→19→15→19→17
* 開始   : 2026-08-06 16:25:00 (UTC)
* 終了   : 2026-08-06 16:25:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260806-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→10→8→12→11
* 開始   : 2026-08-06 20:05:00 (UTC)
* 終了   : 2026-08-06 20:05:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-065 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-066 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260806-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→11→14→11→12
* 開始   : 2026-08-07 03:45:00 (UTC)
* 終了   : 2026-08-07 03:45:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→11→17→12→12
* 開始   : 2026-08-07 04:55:00 (UTC)
* 終了   : 2026-08-07 04:55:00 (UTC)
* 現象   : 平常時(11.83)に対し 1.437倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host15-003 active_connections の推移](charts/EVT-20260807-host15-003.svg)

# イベントID( EVT-20260807-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→14→18→15→14
* 開始   : 2026-08-07 05:45:00 (UTC)
* 終了   : 2026-08-07 05:45:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260807-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 17→15→19→16→17
* 開始   : 2026-08-07 06:35:00 (UTC)
* 終了   : 2026-08-07 06:35:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-020 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260807-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 20→21→25→21→20
* 開始   : 2026-08-07 09:40:00 (UTC)
* 終了   : 2026-08-07 09:40:00 (UTC)
* 現象   : 平常時(20)に対し 1.25倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host15-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host15-007 active_connections の推移](charts/EVT-20260807-host15-007.svg)

# イベントID( EVT-20260807-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 17→16→12→18→15
* 開始   : 2026-08-07 17:40:00 (UTC)
* 終了   : 2026-08-07 17:40:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.7094(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.435σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host15-010 active_connections の推移](charts/EVT-20260807-host15-010.svg)

# イベントID( EVT-20260807-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→7→5→8→5→8→5→8→9
* 開始   : 2026-08-07 22:35:00 (UTC)
* 終了   : 2026-08-07 22:45:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host10-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-084 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260807-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→10→14→8→9
* 開始   : 2026-08-08 04:15:00 (UTC)
* 終了   : 2026-08-08 04:15:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260808-lsfhost01-006 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260808-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260808-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260808-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host15-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→12→11→13→…→11→13→11→13
* 開始   : 2026-08-08 05:20:00 (UTC)
* 終了   : 2026-08-08 18:20:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.744, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260808-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260808-host15-003 active_connections の推移](charts/EVT-20260808-host15-003.svg)

# イベントID( EVT-20260808-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→11→8→10→…→10→11→13→11
* 開始   : 2026-08-08 05:25:00 (UTC)
* 終了   : 2026-08-08 19:15:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.675, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260808-host15-004 active_connections の推移](charts/EVT-20260808-host15-004.svg)

# イベントID( EVT-20260808-host15-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→9→11→13→…→12→11→13→11
* 開始   : 2026-08-08 05:40:00 (UTC)
* 終了   : 2026-08-08 18:35:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.914, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260808-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260808-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260808-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260808-host15-005 active_connections の推移](charts/EVT-20260808-host15-005.svg)

# イベントID( EVT-20260808-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→9→11→10→…→12→13→12→13
* 開始   : 2026-08-08 05:45:00 (UTC)
* 終了   : 2026-08-08 19:45:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.969, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260808-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260808-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260808-host15-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間

![EVT-20260808-host15-006 active_connections の推移](charts/EVT-20260808-host15-006.svg)

# イベントID( EVT-20260808-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→13→12→13→…→12→10→16→9
* 開始   : 2026-08-08 06:30:00 (UTC)
* 終了   : 2026-08-08 18:45:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.371σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.98, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260808-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260808-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260808-host15-007 active_connections の推移](charts/EVT-20260808-host15-007.svg)

# イベントID( EVT-20260808-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→14→10→14→…→13→12→14→12
* 開始   : 2026-08-08 06:45:00 (UTC)
* 終了   : 2026-08-08 18:00:00 (UTC)
* 現象   : 11.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.366, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260808-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260808-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260808-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260808-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260808-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 11.2 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間

![EVT-20260808-host15-008 active_connections の推移](charts/EVT-20260808-host15-008.svg)

# イベントID( EVT-20260808-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 12→9→7→10→9→7→10→11
* 開始   : 2026-08-08 19:25:00 (UTC)
* 終了   : 2026-08-08 19:30:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.6176(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.745, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260808-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260808-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 11→7→14→10→…→10→7→9→11
* 開始   : 2026-08-09 03:55:00 (UTC)
* 終了   : 2026-08-09 04:05:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-lsfhost01-009 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260809-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 13→12→16→11→12
* 開始   : 2026-08-11 04:35:00 (UTC)
* 終了   : 2026-08-11 04:35:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.08σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 20→20→23→20→20
* 開始   : 2026-08-11 08:35:00 (UTC)
* 終了   : 2026-08-11 08:35:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.243倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.155σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-027 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260811-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 23→22→26→22→22
* 開始   : 2026-08-11 10:55:00 (UTC)
* 終了   : 2026-08-11 10:55:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.248倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.603σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 22→21→17→23→23
* 開始   : 2026-08-11 12:10:00 (UTC)
* 終了   : 2026-08-11 12:10:00 (UTC)
* 現象   : 平常時(21.75)に対し 0.7816(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host02-006 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260811-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 17→15→10→15→13
* 開始   : 2026-08-11 18:10:00 (UTC)
* 終了   : 2026-08-11 18:10:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.6122(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.425σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host15-010 active_connections の推移](charts/EVT-20260811-host15-010.svg)

# イベントID( EVT-20260811-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→13→10→14→12
* 開始   : 2026-08-11 19:00:00 (UTC)
* 終了   : 2026-08-11 19:00:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.6936(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-054 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host15-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 9→10→5→9→10
* 開始   : 2026-08-11 21:50:00 (UTC)
* 終了   : 2026-08-11 21:50:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.48(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.789σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host08-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host16-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host15-014 active_connections の推移](charts/EVT-20260811-host15-014.svg)

# イベントID( EVT-20260812-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 11→13→16→12→13
* 開始   : 2026-08-12 04:40:00 (UTC)
* 終了   : 2026-08-12 05:40:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260812-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260812-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260812-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 18→20→23→25→23→25→20→21
* 開始   : 2026-08-12 09:45:00 (UTC)
* 終了   : 2026-08-12 09:55:00 (UTC)
* 現象   : 平常時(19.75)に対し 1.165倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-032 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260812-host09-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 21→20→16→22→20
* 開始   : 2026-08-12 14:40:00 (UTC)
* 終了   : 2026-08-12 14:40:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.7837(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260812-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→12→15→12→11
* 開始   : 2026-08-13 03:55:00 (UTC)
* 終了   : 2026-08-13 04:10:00 (UTC)
* 現象   : 平常時(9.833)に対し 1.525倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260813-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host15-002 active_connections の推移](charts/EVT-20260813-host15-002.svg)

# イベントID( EVT-20260813-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→15→19→14→16
* 開始   : 2026-08-13 06:25:00 (UTC)
* 終了   : 2026-08-13 06:25:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.333倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260813-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→12→7→12→10
* 開始   : 2026-08-13 20:35:00 (UTC)
* 終了   : 2026-08-13 20:35:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.5874(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.435σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host15-011 active_connections の推移](charts/EVT-20260813-host15-011.svg)

# イベントID( EVT-20260813-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 7→8→5→9→8
* 開始   : 2026-08-13 22:45:00 (UTC)
* 終了   : 2026-08-13 22:45:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260813-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→14→17→14→15
* 開始   : 2026-08-14 05:15:00 (UTC)
* 終了   : 2026-08-14 06:00:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.457倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.74σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260814-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260814-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260814-host15-001 active_connections の推移](charts/EVT-20260814-host15-001.svg)

# イベントID( EVT-20260814-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→13→15→14→…→14→17→15→13
* 開始   : 2026-08-14 05:25:00 (UTC)
* 終了   : 2026-08-14 05:35:00 (UTC)
* 現象   : 平常時(12)に対し 1.25倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260814-lsfhost01-017 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260814-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host08-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 22→21→17→18→…→17→18→19→21
* 開始   : 2026-08-14 14:50:00 (UTC)
* 終了   : 2026-08-14 14:55:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260814-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 18→14→12→15→…→15→13→15→17
* 開始   : 2026-08-14 17:00:00 (UTC)
* 終了   : 2026-08-14 18:05:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7091(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.731σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 30 分
  - EVT-20260814-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260814-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host08-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 35 分
  - EVT-20260814-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host08-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260814-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260814-host15-008 active_connections の推移](charts/EVT-20260814-host15-008.svg)

# イベントID( EVT-20260815-host15-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→13→11→12→…→12→13→12→13
* 開始   : 2026-08-15 05:15:00 (UTC)
* 終了   : 2026-08-15 18:55:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.791, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260815-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260815-host15-002 active_connections の推移](charts/EVT-20260815-host15-002.svg)

# イベントID( EVT-20260815-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→11→9→11→…→12→11→13→12
* 開始   : 2026-08-15 05:20:00 (UTC)
* 終了   : 2026-08-15 18:40:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.832, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260815-host15-003 active_connections の推移](charts/EVT-20260815-host15-003.svg)

# イベントID( EVT-20260815-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→11→13→12→…→13→14→13→12
* 開始   : 2026-08-15 05:20:00 (UTC)
* 終了   : 2026-08-15 18:00:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.895, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260815-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260815-host15-004 active_connections の推移](charts/EVT-20260815-host15-004.svg)

# イベントID( EVT-20260815-host15-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→14→12→14→…→15→13→12→14
* 開始   : 2026-08-15 05:35:00 (UTC)
* 終了   : 2026-08-15 20:30:00 (UTC)
* 現象   : 14.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.734, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260815-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.9 時間
  - EVT-20260815-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260815-host15-005 active_connections の推移](charts/EVT-20260815-host15-005.svg)

# イベントID( EVT-20260815-host15-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→13→12→13→…→12→9→13→11
* 開始   : 2026-08-15 05:50:00 (UTC)
* 終了   : 2026-08-15 19:05:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.907, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260815-host15-006 active_connections の推移](charts/EVT-20260815-host15-006.svg)

# イベントID( EVT-20260815-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→13→…→10→12→10→11
* 開始   : 2026-08-15 06:00:00 (UTC)
* 終了   : 2026-08-15 19:10:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.565σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.948, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260815-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260815-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260815-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260815-host15-007 active_connections の推移](charts/EVT-20260815-host15-007.svg)

# イベントID( EVT-20260816-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→17→14
* 開始   : 2026-08-16 16:25:00 (UTC)
* 終了   : 2026-08-16 17:00:00 (UTC)
* 現象   : 2026-08-16 17:00:00 (UTC)を境に水準が 11.95から14.52へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.086σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.34, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host15-007 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→16→15→16→…→14→12→16→13
* 開始   : 2026-08-17 04:10:00 (UTC)
* 終了   : 2026-08-17 20:10:00 (UTC)
* 現象   : 2026-08-17 20:10:00 (UTC)を境に水準が 12.06から15.08へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.925, 限界=2.694)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.906, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 9→8→13→8→9
* 開始   : 2026-08-18 01:50:00 (UTC)
* 終了   : 2026-08-18 01:50:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.214σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→14→19→15→16
* 開始   : 2026-08-18 06:25:00 (UTC)
* 終了   : 2026-08-18 06:25:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.022σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 18→18→21→16→16
* 開始   : 2026-08-18 07:25:00 (UTC)
* 終了   : 2026-08-18 07:25:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.306倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host15-004 active_connections の推移](charts/EVT-20260818-host15-004.svg)

# イベントID( EVT-20260818-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 18→21→14→19→16
* 開始   : 2026-08-18 16:10:00 (UTC)
* 終了   : 2026-08-18 16:10:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.7336(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.556σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host15-007 active_connections の推移](charts/EVT-20260818-host15-007.svg)

# イベントID( EVT-20260818-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→16→11→15→16
* 開始   : 2026-08-18 17:55:00 (UTC)
* 終了   : 2026-08-18 17:55:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.6735(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.731σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host15-008 active_connections の推移](charts/EVT-20260818-host15-008.svg)

# イベントID( EVT-20260818-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→14→16→11→14→14→15
* 開始   : 2026-08-18 18:40:00 (UTC)
* 終了   : 2026-08-18 19:40:00 (UTC)
* 現象   : 2026-08-18 19:40:00 (UTC)を境に水準が 14.94から14.93へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.53, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 13→11→9→10→…→9→10→16→12
* 開始   : 2026-08-18 19:15:00 (UTC)
* 終了   : 2026-08-18 19:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260818-host15-010 active_connections の推移](charts/EVT-20260818-host15-010.svg)

# イベントID( EVT-20260819-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 7→8→14→8→10
* 開始   : 2026-08-19 02:20:00 (UTC)
* 終了   : 2026-08-19 02:20:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.615倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.726σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260819-host15-001 active_connections の推移](charts/EVT-20260819-host15-001.svg)

# イベントID( EVT-20260819-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 11→10→14→10→10
* 開始   : 2026-08-19 03:15:00 (UTC)
* 終了   : 2026-08-19 03:15:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→16→14→22→16→14→22→16→18
* 開始   : 2026-08-19 07:20:00 (UTC)
* 終了   : 2026-08-19 07:25:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260819-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host15-007 active_connections の推移](charts/EVT-20260819-host15-007.svg)

# イベントID( EVT-20260819-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 21→21→17→19→20
* 開始   : 2026-08-19 14:45:00 (UTC)
* 終了   : 2026-08-19 14:45:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260819-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→14→12→15→10→12→15→10→13
* 開始   : 2026-08-19 18:00:00 (UTC)
* 終了   : 2026-08-19 18:40:00 (UTC)
* 現象   : 平常時(16.75)に対し 0.7164(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.323σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260819-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260819-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 22→20→17→21→22
* 開始   : 2026-08-20 14:05:00 (UTC)
* 終了   : 2026-08-20 14:05:00 (UTC)
* 現象   : 平常時(22)に対し 0.7727(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.497σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host01-012 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260820-host15-005 active_connections の推移](charts/EVT-20260820-host15-005.svg)

# イベントID( EVT-20260820-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 21→19→16→20→20
* 開始   : 2026-08-20 14:55:00 (UTC)
* 終了   : 2026-08-20 14:55:00 (UTC)
* 現象   : 平常時(20.67)に対し 0.7742(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.261σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-040 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260820-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 19→19→15→16→19
* 開始   : 2026-08-20 16:00:00 (UTC)
* 終了   : 2026-08-20 16:00:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.7725(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.097σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260820-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 19→17→14→17→18
* 開始   : 2026-08-20 16:45:00 (UTC)
* 終了   : 2026-08-20 16:45:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.7534(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-045 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260820-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 18→16→12→17→16
* 開始   : 2026-08-20 17:55:00 (UTC)
* 終了   : 2026-08-20 17:55:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host15-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→13→10→13→12
* 開始   : 2026-08-20 19:00:00 (UTC)
* 終了   : 2026-08-20 19:00:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host07-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 18→16→21→18→19
* 開始   : 2026-08-21 07:25:00 (UTC)
* 終了   : 2026-08-21 07:25:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.26σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 18→21→23→20→21
* 開始   : 2026-08-21 08:45:00 (UTC)
* 終了   : 2026-08-21 08:45:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 18→20→19→18→20
* 開始   : 2026-08-21 16:35:00 (UTC)
* 終了   : 2026-08-21 17:05:00 (UTC)
* 現象   : 2026-08-21 17:05:00 (UTC)を境に水準が 15.08から12.4へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.566, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 18→16→13→17→15
* 開始   : 2026-08-21 17:25:00 (UTC)
* 終了   : 2026-08-21 17:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260821-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 16→14→15→16→12→16→14→14→15
* 開始   : 2026-08-21 18:25:00 (UTC)
* 終了   : 2026-08-21 19:25:00 (UTC)
* 現象   : 2026-08-21 19:25:00 (UTC)を境に水準が 15.01から12.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.513σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.743, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→13→9→11→…→12→16→14→12
* 開始   : 2026-08-22 04:15:00 (UTC)
* 終了   : 2026-08-22 19:25:00 (UTC)
* 現象   : 15.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.811, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260822-host15-001 active_connections の推移](charts/EVT-20260822-host15-001.svg)

# イベントID( EVT-20260822-host15-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→12→11→13→…→10→11→14→9
* 開始   : 2026-08-22 05:00:00 (UTC)
* 終了   : 2026-08-22 18:35:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.882, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260822-host15-002 active_connections の推移](charts/EVT-20260822-host15-002.svg)

# イベントID( EVT-20260822-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→13→12→14→…→11→12→11→13
* 開始   : 2026-08-22 05:35:00 (UTC)
* 終了   : 2026-08-22 19:15:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.556σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.789, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260822-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260822-host15-003 active_connections の推移](charts/EVT-20260822-host15-003.svg)

# イベントID( EVT-20260822-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 12→10→12→14→…→12→13→12→13
* 開始   : 2026-08-22 05:55:00 (UTC)
* 終了   : 2026-08-22 19:45:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.855, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260822-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260822-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260822-host15-004 active_connections の推移](charts/EVT-20260822-host15-004.svg)

# イベントID( EVT-20260822-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→11→14→12→…→11→13→11→12
* 開始   : 2026-08-22 06:10:00 (UTC)
* 終了   : 2026-08-22 18:30:00 (UTC)
* 現象   : 12.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.023σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.06, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.3 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間

![EVT-20260822-host15-005 active_connections の推移](charts/EVT-20260822-host15-005.svg)

# イベントID( EVT-20260822-host15-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→11→13→14→…→9→12→11→10
* 開始   : 2026-08-22 06:15:00 (UTC)
* 終了   : 2026-08-22 19:15:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.458, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host15-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.3 時間
  - EVT-20260822-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260822-host15-006 active_connections の推移](charts/EVT-20260822-host15-006.svg)

# イベントID( EVT-20260824-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→13→15→14→…→14→13→11→12
* 開始   : 2026-08-24 03:05:00 (UTC)
* 終了   : 2026-08-24 19:50:00 (UTC)
* 現象   : 2026-08-24 19:50:00 (UTC)を境に水準が 11.82から14.96へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.274, 限界=2.696)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 7→9→12→7→8
* 開始   : 2026-08-25 00:30:00 (UTC)
* 終了   : 2026-08-25 00:30:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.6倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.144σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260825-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→15→18→15→18→15→18→16→15
* 開始   : 2026-08-25 04:55:00 (UTC)
* 終了   : 2026-08-25 06:25:00 (UTC)
* 現象   : 平常時(11.75)に対し 1.447倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.673σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host15-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host15-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260825-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260825-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260825-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260825-host15-003 active_connections の推移](charts/EVT-20260825-host15-003.svg)

# イベントID( EVT-20260825-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→12→19→15→15
* 開始   : 2026-08-25 05:05:00 (UTC)
* 終了   : 2026-08-25 05:05:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.53倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.592σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 4.721 倍に達した (閾値 3)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host15-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host15-004 active_connections の推移](charts/EVT-20260825-host15-004.svg)

# イベントID( EVT-20260825-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 19→16→18→16→18→16→20→16
* 開始   : 2026-08-25 15:15:00 (UTC)
* 終了   : 2026-08-25 16:00:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260825-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260825-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 19→20→15→19→21
* 開始   : 2026-08-25 15:45:00 (UTC)
* 終了   : 2026-08-25 15:45:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.7531(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260825-host15-009 active_connections の推移](charts/EVT-20260825-host15-009.svg)

# イベントID( EVT-20260825-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 16→15→13→16→15→13→16
* 開始   : 2026-08-25 17:05:00 (UTC)
* 終了   : 2026-08-25 17:10:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.8182(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.338σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host08-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host15-010 active_connections の推移](charts/EVT-20260825-host15-010.svg)

# イベントID( EVT-20260826-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→11→16→13→14
* 開始   : 2026-08-26 04:30:00 (UTC)
* 終了   : 2026-08-26 04:30:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.488倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.662σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260826-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host15-002 active_connections の推移](charts/EVT-20260826-host15-002.svg)

# イベントID( EVT-20260826-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→15→17→13→16
* 開始   : 2026-08-26 05:25:00 (UTC)
* 終了   : 2026-08-26 05:25:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260826-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 14→16→19→18→21→19→18→21→18
* 開始   : 2026-08-26 07:15:00 (UTC)
* 終了   : 2026-08-26 07:25:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260826-host02-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 17→18→22→18→…→18→21→17→19
* 開始   : 2026-08-26 08:15:00 (UTC)
* 終了   : 2026-08-26 08:25:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host02-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 23→23→18→22→24
* 開始   : 2026-08-26 12:00:00 (UTC)
* 終了   : 2026-08-26 12:00:00 (UTC)
* 現象   : 平常時(22.42)に対し 0.803(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 21→19→15→19→19
* 開始   : 2026-08-26 16:15:00 (UTC)
* 終了   : 2026-08-26 16:15:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.7759(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-050 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260826-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→13→17→13→13
* 開始   : 2026-08-27 05:05:00 (UTC)
* 終了   : 2026-08-27 05:05:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.351倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 17→15→20→19→17→15→20→19→17
* 開始   : 2026-08-27 06:40:00 (UTC)
* 終了   : 2026-08-27 06:45:00 (UTC)
* 現象   : 平常時(15)に対し 1.333倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.493σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host15-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260827-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260827-host15-004 active_connections の推移](charts/EVT-20260827-host15-004.svg)

# イベントID( EVT-20260827-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→16→20→16→18
* 開始   : 2026-08-27 06:55:00 (UTC)
* 終了   : 2026-08-27 06:55:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.197σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host15-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host15-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→16→10→15→13
* 開始   : 2026-08-27 18:25:00 (UTC)
* 終了   : 2026-08-27 18:25:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.6383(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.953σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host08-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260827-host15-014 active_connections の推移](charts/EVT-20260827-host15-014.svg)

# イベントID( EVT-20260828-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 8→8→13→10→10
* 開始   : 2026-08-28 02:45:00 (UTC)
* 終了   : 2026-08-28 02:45:00 (UTC)
* 現象   : 平常時(8.667)に対し 1.5倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260828-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→15→17→13→13
* 開始   : 2026-08-28 05:20:00 (UTC)
* 終了   : 2026-08-28 05:20:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.342倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-017 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 16→20→18→19→20→18→19→18→17
* 開始   : 2026-08-28 07:10:00 (UTC)
* 終了   : 2026-08-28 07:20:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.297倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260828-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→16→13→15→16
* 開始   : 2026-08-28 17:20:00 (UTC)
* 終了   : 2026-08-28 17:20:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.255σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260828-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 15→15→11→15→14
* 開始   : 2026-08-28 18:30:00 (UTC)
* 終了   : 2026-08-28 18:30:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host16-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 14→12→9→10→11→12→9→10→11
* 開始   : 2026-08-28 19:55:00 (UTC)
* 終了   : 2026-08-28 20:00:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.039σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host13-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-062 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-063 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260828-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→11→6→9→10
* 開始   : 2026-08-28 21:45:00 (UTC)
* 終了   : 2026-08-28 21:45:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-018 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 8→7→13→11→9
* 開始   : 2026-08-29 03:25:00 (UTC)
* 終了   : 2026-08-29 03:25:00 (UTC)
* 現象   : 平常時(8.417)に対し 1.545倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260829-lsfhost01-008 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260829-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→12→13→12→…→11→12→11→12
* 開始   : 2026-08-29 04:30:00 (UTC)
* 終了   : 2026-08-29 18:35:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.11, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260829-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host15-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260829-host15-002 active_connections の推移](charts/EVT-20260829-host15-002.svg)

# イベントID( EVT-20260829-host15-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→12→14→13→…→14→12→14→13
* 開始   : 2026-08-29 05:30:00 (UTC)
* 終了   : 2026-08-29 18:50:00 (UTC)
* 現象   : 13.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.187, 限界=2.687)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.3 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間

![EVT-20260829-host15-004 active_connections の推移](charts/EVT-20260829-host15-004.svg)

# イベントID( EVT-20260829-host15-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 13→11→13→14→…→11→14→11→14
* 開始   : 2026-08-29 05:35:00 (UTC)
* 終了   : 2026-08-29 18:10:00 (UTC)
* 現象   : 12.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.333, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260829-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.6 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間

![EVT-20260829-host15-005 active_connections の推移](charts/EVT-20260829-host15-005.svg)

# イベントID( EVT-20260829-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→12→10→11→…→12→13→14→13
* 開始   : 2026-08-29 05:45:00 (UTC)
* 終了   : 2026-08-29 18:50:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.969σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.522, 限界=2.694)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260829-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260829-host15-006 active_connections の推移](charts/EVT-20260829-host15-006.svg)

# イベントID( EVT-20260829-host15-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→13→14→15→…→13→10→14→11
* 開始   : 2026-08-29 05:50:00 (UTC)
* 終了   : 2026-08-29 17:55:00 (UTC)
* 現象   : 12.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.772, 限界=2.685)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host15-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.1 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間

![EVT-20260829-host15-007 active_connections の推移](charts/EVT-20260829-host15-007.svg)

# イベントID( EVT-20260829-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 15→14→13→10→…→15→16→15→14
* 開始   : 2026-08-29 06:10:00 (UTC)
* 終了   : 2026-08-29 19:35:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.044, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260829-host15-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260829-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260829-host15-008 active_connections の推移](charts/EVT-20260829-host15-008.svg)

# イベントID( EVT-20260801-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 11→7→8→7→…→9→11→9→11
* 開始   : 2026-08-01 20:00:00 (UTC)
* 終了   : 2026-08-01 20:25:00 (UTC)
* 現象   : 25分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.571σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.076, 限界=2.674)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host08-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260801-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260801-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260801-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260801-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260801-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260801-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host15-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 8→7→8→7→8→7→9→10
* 開始   : 2026-08-01 20:35:00 (UTC)
* 終了   : 2026-08-01 20:45:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(7)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.802, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260801-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260801-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260801-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260801-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host15-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→10→10→11→9
* 開始   : 2026-08-01 23:15:00 (UTC)
* 終了   : 2026-08-01 23:35:00 (UTC)
* 現象   : 2026-08-01 23:35:00 (UTC)を境に水準が 11.83から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.973, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260801-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 14→14→13→14→13→15→14
* 開始   : 2026-08-02 06:10:00 (UTC)
* 終了   : 2026-08-02 06:40:00 (UTC)
* 現象   : 2026-08-02 06:40:00 (UTC)を境に水準が 11.88から12.19へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.681, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host15-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 17→16→12→13→17→16→17→17
* 開始   : 2026-08-02 08:15:00 (UTC)
* 終了   : 2026-08-02 08:50:00 (UTC)
* 現象   : 2026-08-02 08:50:00 (UTC)を境に水準が 11.9から12.57へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.78, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→12→12→11→12→13→13
* 開始   : 2026-08-02 18:35:00 (UTC)
* 終了   : 2026-08-02 19:05:00 (UTC)
* 現象   : 2026-08-02 19:05:00 (UTC)を境に水準が 11.79から14.75へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.66, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 7→11→9→10
* 開始   : 2026-08-04 00:15:00 (UTC)
* 終了   : 2026-08-04 00:30:00 (UTC)
* 現象   : 2026-08-04 00:30:00 (UTC)を境に水準が 14.89から14.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.947, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→12→11→13→12→11→13→10
* 開始   : 2026-08-04 02:55:00 (UTC)
* 終了   : 2026-08-04 03:05:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.208σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host02-004 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260804-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host15-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→15→11→14→12→15→14→13→16
* 開始   : 2026-08-04 04:20:00 (UTC)
* 終了   : 2026-08-04 05:30:00 (UTC)
* 現象   : 2026-08-04 05:30:00 (UTC)を境に水準が 15.02から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.46, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 13→15→16→12→13→15→16→12→14
* 開始   : 2026-08-04 04:55:00 (UTC)
* 終了   : 2026-08-04 05:00:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→14→18→16→14→18→16→18
* 開始   : 2026-08-04 06:35:00 (UTC)
* 終了   : 2026-08-04 06:40:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260804-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 23→25→19→21→23→25→19→21
* 開始   : 2026-08-04 12:40:00 (UTC)
* 終了   : 2026-08-04 12:45:00 (UTC)
* 現象   : 平常時(21.92)に対し 1.141倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260804-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 21→22→17→16→…→17→16→20→17
* 開始   : 2026-08-04 14:55:00 (UTC)
* 終了   : 2026-08-04 15:00:00 (UTC)
* 現象   : 平常時(20.25)に対し 0.8395(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260804-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→9→11→10→9
* 開始   : 2026-08-05 01:50:00 (UTC)
* 終了   : 2026-08-05 02:10:00 (UTC)
* 現象   : 2026-08-05 02:10:00 (UTC)を境に水準が 14.81から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.38, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 12→14→16→14→16→14→16
* 開始   : 2026-08-05 05:45:00 (UTC)
* 終了   : 2026-08-05 05:55:00 (UTC)
* 現象   : 平常時(12.75)に対し 1.255倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260805-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 20→22→17→23→…→17→23→21→20
* 開始   : 2026-08-05 09:35:00 (UTC)
* 終了   : 2026-08-05 09:40:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.046σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260805-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→13→9→11→12→10→8→11→9
* 開始   : 2026-08-05 20:20:00 (UTC)
* 終了   : 2026-08-05 21:35:00 (UTC)
* 現象   : 2026-08-05 21:35:00 (UTC)を境に水準が 14.92から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.918, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→10→13→7→…→13→7→9→8
* 開始   : 2026-08-06 03:15:00 (UTC)
* 終了   : 2026-08-06 03:20:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host08-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 18→17→21→19→21→19→21→18
* 開始   : 2026-08-06 07:55:00 (UTC)
* 終了   : 2026-08-06 08:05:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260806-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260806-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260806-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260806-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 21→17→18→23→17→18→23→19→21
* 開始   : 2026-08-06 09:10:00 (UTC)
* 終了   : 2026-08-06 09:20:00 (UTC)
* 現象   : 平常時(19.92)に対し 0.8536(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260806-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260806-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 21→19→23→21→19→23→21→20
* 開始   : 2026-08-06 09:45:00 (UTC)
* 終了   : 2026-08-06 09:50:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 23→20→22→23→22
* 開始   : 2026-08-06 09:55:00 (UTC)
* 終了   : 2026-08-06 10:15:00 (UTC)
* 現象   : 2026-08-06 10:15:00 (UTC)を境に水準が 14.99から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.973, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 16→17→14→16→17→14→16→15
* 開始   : 2026-08-06 17:35:00 (UTC)
* 終了   : 2026-08-06 17:40:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260806-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→14→11→13→…→13→10→12→11
* 開始   : 2026-08-06 19:35:00 (UTC)
* 終了   : 2026-08-06 19:45:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.221σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260806-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→12→14→10→14→10→14→13→14
* 開始   : 2026-08-07 04:00:00 (UTC)
* 終了   : 2026-08-07 04:10:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.333倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260807-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 21→18→23→21→…→21→17→20→21
* 開始   : 2026-08-07 09:40:00 (UTC)
* 終了   : 2026-08-07 09:50:00 (UTC)
* 現象   : 平常時(19.58)に対し 1.174倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host15-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260807-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host15-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 20→23→21→22→22→21→22→20→21
* 開始   : 2026-08-07 13:45:00 (UTC)
* 終了   : 2026-08-07 14:35:00 (UTC)
* 現象   : 2026-08-07 14:35:00 (UTC)を境に水準が 14.97から12.73へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.246, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 24→20→22→22→21→20→21→22
* 開始   : 2026-08-07 14:30:00 (UTC)
* 終了   : 2026-08-07 15:40:00 (UTC)
* 現象   : 2026-08-07 15:40:00 (UTC)を境に水準が 14.98から12.59へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.104σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→16→13→15→…→15→12→14→13
* 開始   : 2026-08-07 18:10:00 (UTC)
* 終了   : 2026-08-07 18:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-069 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260807-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 9→8→10→11
* 開始   : 2026-08-08 00:20:00 (UTC)
* 終了   : 2026-08-08 00:35:00 (UTC)
* 現象   : 2026-08-08 00:35:00 (UTC)を境に水準が 14.88から11.79へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.778, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260808-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→8→8→9→11→9→9→9→10
* 開始   : 2026-08-09 02:05:00 (UTC)
* 終了   : 2026-08-09 03:20:00 (UTC)
* 現象   : 2026-08-09 03:20:00 (UTC)を境に水準が 11.78から11.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.112, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 15→16→19→15→13→19→15→13→15
* 開始   : 2026-08-09 11:55:00 (UTC)
* 終了   : 2026-08-09 12:05:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260809-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260809-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 14→13→11→10→…→11→10→12→13
* 開始   : 2026-08-09 16:45:00 (UTC)
* 終了   : 2026-08-09 16:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260809-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260809-lsfhost01-041 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260809-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260809-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260809-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→12→11→9→9
* 開始   : 2026-08-10 21:25:00 (UTC)
* 終了   : 2026-08-10 21:45:00 (UTC)
* 現象   : 2026-08-10 21:45:00 (UTC)を境に水準が 14.98から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.183, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host15-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 9→9→9→10→9→9→8→10
* 開始   : 2026-08-10 23:10:00 (UTC)
* 終了   : 2026-08-10 23:45:00 (UTC)
* 現象   : 2026-08-10 23:45:00 (UTC)を境に水準が 14.9から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 7→8→11→10→…→10→12→9→10
* 開始   : 2026-08-11 02:10:00 (UTC)
* 終了   : 2026-08-11 02:20:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-009 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260811-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host08-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 20→19→19→19→19→22
* 開始   : 2026-08-11 07:50:00 (UTC)
* 終了   : 2026-08-11 08:15:00 (UTC)
* 現象   : 2026-08-11 08:15:00 (UTC)を境に水準が 14.97から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.451, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host15-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 22→24→22→21→23→22→23→24→24
* 開始   : 2026-08-11 10:55:00 (UTC)
* 終了   : 2026-08-11 11:35:00 (UTC)
* 現象   : 2026-08-11 11:35:00 (UTC)を境に水準が 15.05から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.608, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 21→21→24→22→25→24→24→23
* 開始   : 2026-08-11 11:45:00 (UTC)
* 終了   : 2026-08-11 12:20:00 (UTC)
* 現象   : 2026-08-11 12:20:00 (UTC)を境に水準が 15から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.601, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 16→17→14→13→…→15→14→13→15
* 開始   : 2026-08-11 17:45:00 (UTC)
* 終了   : 2026-08-11 17:55:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260811-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260811-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260811-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 14→13→10→13→10→13→10→12
* 開始   : 2026-08-11 19:45:00 (UTC)
* 終了   : 2026-08-11 19:55:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.455σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-060 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260811-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260811-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260811-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 9→11→7→9→7→9→7→9→10
* 開始   : 2026-08-11 21:20:00 (UTC)
* 終了   : 2026-08-11 21:30:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.6562(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.562σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260811-host16-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260811-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 9→10→14→12→14→12→14→12→13
* 開始   : 2026-08-12 04:05:00 (UTC)
* 終了   : 2026-08-12 04:15:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.387σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-012 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260812-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host15-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 22→23→24→23
* 開始   : 2026-08-12 12:50:00 (UTC)
* 終了   : 2026-08-12 13:05:00 (UTC)
* 現象   : 2026-08-12 13:05:00 (UTC)を境に水準が 15.03から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.778, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 22→21→20→22→18→19→18→17→20
* 開始   : 2026-08-12 14:10:00 (UTC)
* 終了   : 2026-08-12 16:30:00 (UTC)
* 現象   : 2026-08-12 16:30:00 (UTC)を境に水準が 14.94から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.863, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→11→13→10→…→10→14→10→8
* 開始   : 2026-08-12 21:30:00 (UTC)
* 終了   : 2026-08-12 21:40:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.311倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260812-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260812-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 10→9→13→9→13→9→13→11→12
* 開始   : 2026-08-13 03:25:00 (UTC)
* 終了   : 2026-08-13 03:35:00 (UTC)
* 現象   : 平常時(9.25)に対し 1.405倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.629σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260813-host09-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-010 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260813-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→15→17→18→15→17→18→15→17
* 開始   : 2026-08-13 06:05:00 (UTC)
* 終了   : 2026-08-13 06:10:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260813-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 23→22→23→22→23
* 開始   : 2026-08-13 10:55:00 (UTC)
* 終了   : 2026-08-13 11:15:00 (UTC)
* 現象   : 2026-08-13 11:15:00 (UTC)を境に水準が 15.08から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.183, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 24→20→25→21→…→21→19→20→21
* 開始   : 2026-08-13 13:10:00 (UTC)
* 終了   : 2026-08-13 13:20:00 (UTC)
* 現象   : 平常時(21.75)に対し 1.149倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260813-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 23→23→24→21→23→23
* 開始   : 2026-08-13 13:40:00 (UTC)
* 終了   : 2026-08-13 14:05:00 (UTC)
* 現象   : 2026-08-13 14:05:00 (UTC)を境に水準が 15.03から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.405, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 16→17→13→14→…→13→12→14→16
* 開始   : 2026-08-13 17:50:00 (UTC)
* 終了   : 2026-08-13 18:05:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.922σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260813-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260813-lsfhost01-044 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260813-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→14→12→11→14→12→11→14→16
* 開始   : 2026-08-13 18:30:00 (UTC)
* 終了   : 2026-08-13 18:35:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host11-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-049 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→15→11→10→…→11→10→13→14
* 開始   : 2026-08-13 19:05:00 (UTC)
* 終了   : 2026-08-13 19:10:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host06-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-051 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260813-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 21→20→24→22→24→22→24→21→23
* 開始   : 2026-08-14 10:10:00 (UTC)
* 終了   : 2026-08-14 10:20:00 (UTC)
* 現象   : 平常時(20.08)に対し 1.195倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.74σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260814-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host15-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 23→23→23→24→24→23→23→22→23
* 開始   : 2026-08-14 11:20:00 (UTC)
* 終了   : 2026-08-14 13:25:00 (UTC)
* 現象   : 2026-08-14 13:25:00 (UTC)を境に水準が 14.97から13.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 22→25→24→19→25→24→19→21→22
* 開始   : 2026-08-14 12:00:00 (UTC)
* 終了   : 2026-08-14 12:10:00 (UTC)
* 現象   : 平常時(21.92)に対し 1.141倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260814-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 23→20→17→19→17→19→17→22
* 開始   : 2026-08-14 15:10:00 (UTC)
* 終了   : 2026-08-14 15:20:00 (UTC)
* 現象   : 平常時(20.92)に対し 0.8127(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.732σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260814-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 12→15→11→12→15→11→12→13
* 開始   : 2026-08-14 19:05:00 (UTC)
* 終了   : 2026-08-14 19:10:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260814-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-070 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260814-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 12→15→10→13→15→10→13→11
* 開始   : 2026-08-14 19:20:00 (UTC)
* 終了   : 2026-08-14 19:25:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260814-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host08-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260814-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 8→10→12→8→12→8→12→8→11
* 開始   : 2026-08-15 02:05:00 (UTC)
* 終了   : 2026-08-15 02:15:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host08-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260815-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260815-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260815-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-lsfhost01-005 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260815-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 6→7→11→9→7→11→9→10
* 開始   : 2026-08-16 01:10:00 (UTC)
* 終了   : 2026-08-16 01:15:00 (UTC)
* 現象   : 平常時(7.75)に対し 1.419倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.267σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host02-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260816-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 10→11→6→12→11→6→12→11→9
* 開始   : 2026-08-16 03:05:00 (UTC)
* 終了   : 2026-08-16 03:10:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.038σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 14→12→12→12→12
* 開始   : 2026-08-16 05:10:00 (UTC)
* 終了   : 2026-08-16 05:30:00 (UTC)
* 現象   : 2026-08-16 05:30:00 (UTC)を境に水準が 11.9から12.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.376, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→13→10→11
* 開始   : 2026-08-16 20:00:00 (UTC)
* 終了   : 2026-08-16 20:15:00 (UTC)
* 現象   : 2026-08-16 20:15:00 (UTC)を境に水準が 11.82から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.947, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 9→6→9→6→…→9→6→8→9
* 開始   : 2026-08-16 22:40:00 (UTC)
* 終了   : 2026-08-16 22:55:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260816-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260816-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→9→10→8→11→11
* 開始   : 2026-08-17 02:05:00 (UTC)
* 終了   : 2026-08-17 02:30:00 (UTC)
* 現象   : 2026-08-17 02:30:00 (UTC)を境に水準が 11.81から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.584, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host15-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 7→9→8→10→9→9→9→9→9
* 開始   : 2026-08-17 23:55:00 (UTC)
* 終了   : 2026-08-18 00:35:00 (UTC)
* 現象   : 2026-08-18 00:35:00 (UTC)を境に水準が 15から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 8→9→12→13→…→12→13→11→10
* 開始   : 2026-08-18 03:00:00 (UTC)
* 終了   : 2026-08-18 03:05:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.321倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260818-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-007 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 19→20→22→19→22→19→22→18
* 開始   : 2026-08-18 08:50:00 (UTC)
* 終了   : 2026-08-18 09:00:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.189倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260818-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260818-host08-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-030 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260818-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host15-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 24→22→22→22→19→23→23→22→21
* 開始   : 2026-08-18 13:10:00 (UTC)
* 終了   : 2026-08-18 13:55:00 (UTC)
* 現象   : 2026-08-18 13:55:00 (UTC)を境に水準が 15.04から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.945, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host15-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 11→9→9→10
* 開始   : 2026-08-18 22:35:00 (UTC)
* 終了   : 2026-08-18 22:50:00 (UTC)
* 現象   : 2026-08-18 22:50:00 (UTC)を境に水準が 14.95から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.947, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→13→12→14→13→13→13
* 開始   : 2026-08-19 04:00:00 (UTC)
* 終了   : 2026-08-19 04:30:00 (UTC)
* 現象   : 2026-08-19 04:30:00 (UTC)を境に水準が 14.98から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.656, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 13→14→16→14→16→14→13
* 開始   : 2026-08-19 05:00:00 (UTC)
* 終了   : 2026-08-19 05:05:00 (UTC)
* 現象   : 平常時(12.25)に対し 1.306倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.629σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host08-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260819-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260819-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 13→16→15→13→16→15→16
* 開始   : 2026-08-19 05:30:00 (UTC)
* 終了   : 2026-08-19 05:35:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260819-host08-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260819-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host15-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 18→19→17→18→18→20→19→19→20
* 開始   : 2026-08-19 07:15:00 (UTC)
* 終了   : 2026-08-19 08:20:00 (UTC)
* 現象   : 2026-08-19 08:20:00 (UTC)を境に水準が 15.01から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.723, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 17→16→14→16→14→17
* 開始   : 2026-08-19 17:25:00 (UTC)
* 終了   : 2026-08-19 17:30:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→14→11→12→…→12→10→12→13
* 開始   : 2026-08-19 19:25:00 (UTC)
* 終了   : 2026-08-19 19:35:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260819-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host08-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260819-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-056 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260819-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 11→9→11→9→11
* 開始   : 2026-08-19 20:15:00 (UTC)
* 終了   : 2026-08-19 20:20:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-063 (他ホスト) lsf_queue / susp : WARN / 重なり 5 分

![EVT-20260819-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host15-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 8→7→10→11→9→8→10→10→8
* 開始   : 2026-08-19 22:45:00 (UTC)
* 終了   : 2026-08-19 23:30:00 (UTC)
* 現象   : 2026-08-19 23:30:00 (UTC)を境に水準が 15.03から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.945, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 11→12→14→15→12→14→15→12→11
* 開始   : 2026-08-20 04:30:00 (UTC)
* 終了   : 2026-08-20 04:35:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 18→17→19→20→17→19→20→17→16
* 開始   : 2026-08-20 07:05:00 (UTC)
* 終了   : 2026-08-20 07:10:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.162σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260820-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 16→19→20→19→20→17→19
* 開始   : 2026-08-20 07:20:00 (UTC)
* 終了   : 2026-08-20 07:30:00 (UTC)
* 現象   : 平常時(15.83)に対し 1.2倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.212σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host08-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260820-host07-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 22→20→24→23→20→24→23→20
* 開始   : 2026-08-20 10:55:00 (UTC)
* 終了   : 2026-08-20 11:00:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260820-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 19→18→21→20→20→18→18→19→20
* 開始   : 2026-08-20 15:40:00 (UTC)
* 終了   : 2026-08-20 16:25:00 (UTC)
* 現象   : 2026-08-20 16:25:00 (UTC)を境に水準が 15.01から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.945, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host15-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 19→17→14→16→20→14→16→20→16
* 開始   : 2026-08-20 17:00:00 (UTC)
* 終了   : 2026-08-20 17:10:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-047 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-046 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→16→14→12→14→12→18→13
* 開始   : 2026-08-20 17:50:00 (UTC)
* 終了   : 2026-08-20 18:00:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host15-012 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host10-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260820-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host15-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 11→13→8→15→11→13→8→15→11
* 開始   : 2026-08-21 04:20:00 (UTC)
* 終了   : 2026-08-21 04:25:00 (UTC)
* 現象   : 平常時(11.58)に対し 0.6906(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.499σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→18→19→18→…→18→20→18→17
* 開始   : 2026-08-21 07:40:00 (UTC)
* 終了   : 2026-08-21 07:50:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260821-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260821-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host15-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 22→24→24→23→23
* 開始   : 2026-08-21 11:20:00 (UTC)
* 終了   : 2026-08-21 11:40:00 (UTC)
* 現象   : 2026-08-21 11:40:00 (UTC)を境に水準が 14.99から13.57へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 20→18→16→15→16→15→17→18
* 開始   : 2026-08-21 16:20:00 (UTC)
* 終了   : 2026-08-21 16:30:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.8458(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260821-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260821-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 17→15→16→14→16→15→17→13→17
* 開始   : 2026-08-21 17:20:00 (UTC)
* 終了   : 2026-08-21 18:55:00 (UTC)
* 現象   : 2026-08-21 18:55:00 (UTC)を境に水準が 15.09から11.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.13, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 11→12→8→11→8→11→8→12→10
* 開始   : 2026-08-21 20:45:00 (UTC)
* 終了   : 2026-08-21 20:55:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.7111(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host02-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host06-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 9→8→13→11→…→11→6→10→9
* 開始   : 2026-08-21 21:55:00 (UTC)
* 終了   : 2026-08-21 22:05:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host12-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host08-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host11-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 8→5→11→8→5→11→8→7
* 開始   : 2026-08-22 23:50:00 (UTC)
* 終了   : 2026-08-22 23:55:00 (UTC)
* 現象   : 平常時(7.917)に対し 0.6316(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260822-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 12→11→12→10→11→11→12→9→12
* 開始   : 2026-08-23 18:50:00 (UTC)
* 終了   : 2026-08-23 20:00:00 (UTC)
* 現象   : 2026-08-23 20:00:00 (UTC)を境に水準が 11.73から14.9へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.55, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 10→9→8→7→…→8→7→10→12
* 開始   : 2026-08-23 19:20:00 (UTC)
* 終了   : 2026-08-23 19:25:00 (UTC)
* 現象   : 平常時(11)に対し 0.7273(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.093σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260823-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260823-lsfhost01-043 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260823-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host15-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 10→9→11
* 開始   : 2026-08-23 22:55:00 (UTC)
* 終了   : 2026-08-23 23:05:00 (UTC)
* 現象   : 2026-08-23 23:05:00 (UTC)を境に水準が 11.8から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.584, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260824-host15-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 11→9→11→10→7→11→9→10→11
* 開始   : 2026-08-24 21:15:00 (UTC)
* 終了   : 2026-08-24 22:15:00 (UTC)
* 現象   : 2026-08-24 22:15:00 (UTC)を境に水準が 14.92から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.08, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 14→12→9→13→15→9→13→15→12
* 開始   : 2026-08-25 04:55:00 (UTC)
* 終了   : 2026-08-25 05:05:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.7552(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host08-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260825-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 10→11→15→13→15→13→15→13→14
* 開始   : 2026-08-25 05:10:00 (UTC)
* 終了   : 2026-08-25 05:20:00 (UTC)
* 現象   : 平常時(11.17)に対し 1.343倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.682σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-lsfhost01-017 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260825-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 21→20→24→23→20→24→23→20
* 開始   : 2026-08-25 10:00:00 (UTC)
* 終了   : 2026-08-25 10:05:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.171倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.445σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260825-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 22→23→25→23→…→23→19→24→21
* 開始   : 2026-08-25 12:15:00 (UTC)
* 終了   : 2026-08-25 12:25:00 (UTC)
* 現象   : 平常時(21.92)に対し 1.141倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-044 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-043 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 15→14→11→10→…→11→10→12→14
* 開始   : 2026-08-25 19:15:00 (UTC)
* 終了   : 2026-08-25 19:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260825-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 13→12→10→12→10→12→10→13→10
* 開始   : 2026-08-25 19:40:00 (UTC)
* 終了   : 2026-08-25 19:50:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.75(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host01-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260825-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 10→6→8→10→6→8
* 開始   : 2026-08-25 22:00:00 (UTC)
* 終了   : 2026-08-25 22:05:00 (UTC)
* 現象   : 平常時(9.75)に対し 0.6154(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.63σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260825-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→8→8→9→9→11
* 開始   : 2026-08-26 00:20:00 (UTC)
* 終了   : 2026-08-26 00:45:00 (UTC)
* 現象   : 2026-08-26 00:45:00 (UTC)を境に水準が 14.97から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.42, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 15→14→18→17→14→18→17
* 開始   : 2026-08-26 06:45:00 (UTC)
* 終了   : 2026-08-26 06:50:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.271σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 23→20→24→22→22→21→21→23→23
* 開始   : 2026-08-26 10:15:00 (UTC)
* 終了   : 2026-08-26 11:20:00 (UTC)
* 現象   : 2026-08-26 11:20:00 (UTC)を境に水準が 14.96から15.1へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.053, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host15-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 13→14→14→11→12→14→14
* 開始   : 2026-08-26 19:15:00 (UTC)
* 終了   : 2026-08-26 19:45:00 (UTC)
* 現象   : 2026-08-26 19:45:00 (UTC)を境に水準が 14.99から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.656, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host15-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 12→7→8→10→12→7→8→10
* 開始   : 2026-08-26 21:05:00 (UTC)
* 終了   : 2026-08-26 21:10:00 (UTC)
* 現象   : 平常時(11.25)に対し 0.6222(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.973σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-072 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260826-host06-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host15-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 10→11→10→9→12→9
* 開始   : 2026-08-27 01:25:00 (UTC)
* 終了   : 2026-08-27 01:50:00 (UTC)
* 現象   : 2026-08-27 01:50:00 (UTC)を境に水準が 14.89から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.405, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host15-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host15-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 12→13→15→11→15→11→15→12→10
* 開始   : 2026-08-27 04:00:00 (UTC)
* 終了   : 2026-08-27 04:10:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.353倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.746σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分

![EVT-20260827-host15-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host15-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_4
* 値     : 17→19→18→19→18→19→16→18
* 開始   : 2026-08-27 06:45:00 (UTC)
* 終了   : 2026-08-27 06:55:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host15-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host15-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-028 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260827-host15-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host15-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 18→17→20→21→17→20→21→17→19
* 開始   : 2026-08-27 07:35:00 (UTC)
* 終了   : 2026-08-27 07:40:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host15-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 19→20→22→17→22→17→22→21
* 開始   : 2026-08-27 08:50:00 (UTC)
* 終了   : 2026-08-27 09:00:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.184倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.383σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host15-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 18→22→18→22→20
* 開始   : 2026-08-27 08:55:00 (UTC)
* 終了   : 2026-08-27 09:00:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host15-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host15-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 22→23→22→23→23→21→22
* 開始   : 2026-08-27 10:00:00 (UTC)
* 終了   : 2026-08-27 10:30:00 (UTC)
* 現象   : 2026-08-27 10:30:00 (UTC)を境に水準が 15から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.79, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host15-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host15-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 21→23→19→21→21→23→22→22→21
* 開始   : 2026-08-27 13:55:00 (UTC)
* 終了   : 2026-08-27 14:50:00 (UTC)
* 現象   : 2026-08-27 14:50:00 (UTC)を境に水準が 14.99から15.08へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.17, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host15-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host15-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_5
* 値     : 21→22→18→19→22→18→19→21
* 開始   : 2026-08-27 14:30:00 (UTC)
* 終了   : 2026-08-27 14:35:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.279σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-lsfhost01-049 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260827-host15-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host15-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 18→15→16→15→16→15→17→16
* 開始   : 2026-08-27 16:50:00 (UTC)
* 終了   : 2026-08-27 17:00:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host08-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-060 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260827-host15-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host15-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 16→15→11→13→…→11→13→11→13
* 開始   : 2026-08-27 18:50:00 (UTC)
* 終了   : 2026-08-27 20:10:00 (UTC)
* 現象   : 1.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.911σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host04-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260827-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host10-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-073 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260827-host15-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host15-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 14→13→17→15→13→17→15
* 開始   : 2026-08-28 06:10:00 (UTC)
* 終了   : 2026-08-28 06:15:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.267倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.504σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260828-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host15-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 16→15→19→16→19→16→19→18→16
* 開始   : 2026-08-28 06:55:00 (UTC)
* 終了   : 2026-08-28 07:05:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.246倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260828-host08-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260828-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260828-host15-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host15-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 18→17→20→21→20→21→20→19
* 開始   : 2026-08-28 07:55:00 (UTC)
* 終了   : 2026-08-28 08:05:00 (UTC)
* 現象   : 平常時(17)に対し 1.176倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260828-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host15-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host15-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_6
* 値     : 18→15→13→16→…→13→16→13→17
* 開始   : 2026-08-28 17:25:00 (UTC)
* 終了   : 2026-08-28 17:40:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.853σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260828-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-054 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-057 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host15-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host15-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_1
* 値     : 18→14→13→14→13→14→16
* 開始   : 2026-08-28 17:55:00 (UTC)
* 終了   : 2026-08-28 18:00:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260828-host15-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host15-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_2
* 値     : 10→9→10→14→9→10→14→11
* 開始   : 2026-08-29 04:50:00 (UTC)
* 終了   : 2026-08-29 04:55:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(10)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.75, 限界=2.696)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host15-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260829-host15-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host15-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host15, port=7003, datasource=OraclePool_3
* 値     : 8→9→10→9→…→11→9→11→8
* 開始   : 2026-08-29 19:40:00 (UTC)
* 終了   : 2026-08-29 20:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.752, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-lsfhost01-037 (他ホスト) lsf_queue / run : FATAL / 重なり 20 分
  - EVT-20260829-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260829-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260829-host15-009 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
