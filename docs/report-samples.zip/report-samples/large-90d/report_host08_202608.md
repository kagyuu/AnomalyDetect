# host08 2026-08 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host08 |
| 対象年月 | 2026-08 |
| 検知イベント数 | 317 (SEVERE: 33, FATAL: 131, WARN: 153, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 33 | 131 | 153 | 317 | ALG-A1, ALG-A2, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202608.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260802-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→15→14→16→12→13→14→14
* 開始   : 2026-08-02 07:00:00 (UTC)
* 終了   : 2026-08-02 07:35:00 (UTC)
* 現象   : 2026-08-02 07:35:00 (UTC)を境に水準が 11.8から12.41へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host08-005 active_connections の推移](charts/EVT-20260802-host08-005.svg)

# イベントID( EVT-20260803-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→16→19→16→…→15→14→15→13
* 開始   : 2026-08-03 01:45:00 (UTC)
* 終了   : 2026-08-03 21:35:00 (UTC)
* 現象   : 2026-08-03 21:35:00 (UTC)を境に水準が 11.74から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.711, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.47, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host08-001 active_connections の推移](charts/EVT-20260803-host08-001.svg)

# イベントID( EVT-20260803-host08-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→16→17→16→…→13→14→12→15
* 開始   : 2026-08-03 02:10:00 (UTC)
* 終了   : 2026-08-03 19:35:00 (UTC)
* 現象   : 2026-08-03 19:35:00 (UTC)を境に水準が 11.88から14.91へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.899, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.114, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host08-003 active_connections の推移](charts/EVT-20260803-host08-003.svg)

# イベントID( EVT-20260803-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→15→16→15→…→14→15→13→12
* 開始   : 2026-08-03 02:35:00 (UTC)
* 終了   : 2026-08-03 19:40:00 (UTC)
* 現象   : 2026-08-03 19:40:00 (UTC)を境に水準が 11.82から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.869, 限界=2.709)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.29, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host08-004 active_connections の推移](charts/EVT-20260803-host08-004.svg)

# イベントID( EVT-20260803-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→18→19→17→…→13→14→13→10
* 開始   : 2026-08-03 02:40:00 (UTC)
* 終了   : 2026-08-03 22:20:00 (UTC)
* 現象   : 2026-08-03 22:20:00 (UTC)を境に水準が 11.83から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.853, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.821, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host08-005 active_connections の推移](charts/EVT-20260803-host08-005.svg)

# イベントID( EVT-20260803-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→15→14→15→…→14→13→12→14
* 開始   : 2026-08-03 03:35:00 (UTC)
* 終了   : 2026-08-03 21:45:00 (UTC)
* 現象   : 2026-08-03 21:45:00 (UTC)を境に水準が 11.83から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.951, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host08-006 active_connections の推移](charts/EVT-20260803-host08-006.svg)

# イベントID( EVT-20260803-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 15→16→17→15→…→16→15→12→13
* 開始   : 2026-08-03 04:10:00 (UTC)
* 終了   : 2026-08-03 19:50:00 (UTC)
* 現象   : 2026-08-03 19:50:00 (UTC)を境に水準が 11.87から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.378σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.268, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.75, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host08-007 active_connections の推移](charts/EVT-20260803-host08-007.svg)

# イベントID( EVT-20260804-host08-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 23→24→21→23→23→24→25→22
* 開始   : 2026-08-04 11:55:00 (UTC)
* 終了   : 2026-08-04 12:30:00 (UTC)
* 現象   : 2026-08-04 12:30:00 (UTC)を境に水準が 14.88から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host08-003 active_connections の推移](charts/EVT-20260804-host08-003.svg)

# イベントID( EVT-20260806-host08-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 23→22→22→22→20→24→21→22
* 開始   : 2026-08-06 13:25:00 (UTC)
* 終了   : 2026-08-06 14:00:00 (UTC)
* 現象   : 2026-08-06 14:00:00 (UTC)を境に水準が 14.87から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.49, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host08-005 active_connections の推移](charts/EVT-20260806-host08-005.svg)

# イベントID( EVT-20260806-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 20→17→18→19→18→14→18→18→18
* 開始   : 2026-08-06 15:15:00 (UTC)
* 終了   : 2026-08-06 17:25:00 (UTC)
* 現象   : 2026-08-06 17:25:00 (UTC)を境に水準が 14.91から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host08-006 active_connections の推移](charts/EVT-20260806-host08-006.svg)

# イベントID( EVT-20260807-host08-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→12→12→13→12→10→12
* 開始   : 2026-08-07 20:05:00 (UTC)
* 終了   : 2026-08-07 20:35:00 (UTC)
* 現象   : 2026-08-07 20:35:00 (UTC)を境に水準が 14.92から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.18, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260807-host08-011 active_connections の推移](charts/EVT-20260807-host08-011.svg)

# イベントID( EVT-20260810-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→14→16→14→…→14→17→13→16
* 開始   : 2026-08-10 02:55:00 (UTC)
* 終了   : 2026-08-10 20:40:00 (UTC)
* 現象   : 2026-08-10 20:40:00 (UTC)を境に水準が 11.9から14.89へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.727, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.94, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host08-003 active_connections の推移](charts/EVT-20260810-host08-003.svg)

# イベントID( EVT-20260810-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→16→…→14→15→12→13
* 開始   : 2026-08-10 03:20:00 (UTC)
* 終了   : 2026-08-10 21:25:00 (UTC)
* 現象   : 2026-08-10 21:25:00 (UTC)を境に水準が 11.85から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.074, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.606, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host08-004 active_connections の推移](charts/EVT-20260810-host08-004.svg)

# イベントID( EVT-20260810-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→15→19→17→…→16→14→13→12
* 開始   : 2026-08-10 03:30:00 (UTC)
* 終了   : 2026-08-10 19:50:00 (UTC)
* 現象   : 2026-08-10 19:50:00 (UTC)を境に水準が 11.9から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.841, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.821, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host08-005 active_connections の推移](charts/EVT-20260810-host08-005.svg)

# イベントID( EVT-20260810-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→14→17→16→…→16→12→11→13
* 開始   : 2026-08-10 04:00:00 (UTC)
* 終了   : 2026-08-10 21:20:00 (UTC)
* 現象   : 2026-08-10 21:20:00 (UTC)を境に水準が 11.92から14.94へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.711σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.676, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.874, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host08-006 active_connections の推移](charts/EVT-20260810-host08-006.svg)

# イベントID( EVT-20260812-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 10→8→8→12→10→10→10→11→9
* 開始   : 2026-08-12 01:20:00 (UTC)
* 終了   : 2026-08-12 02:10:00 (UTC)
* 現象   : 2026-08-12 02:10:00 (UTC)を境に水準が 15.06から14.97へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.426, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host08-002 active_connections の推移](charts/EVT-20260812-host08-002.svg)

# イベントID( EVT-20260813-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 17→19→20→20
* 開始   : 2026-08-13 15:55:00 (UTC)
* 終了   : 2026-08-13 16:10:00 (UTC)
* 現象   : 2026-08-13 16:10:00 (UTC)を境に水準が 14.92から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.246, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host08-014 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→9→8→10→8→9→9→9→10
* 開始   : 2026-08-14 23:15:00 (UTC)
* 終了   : 2026-08-15 00:00:00 (UTC)
* 現象   : 2026-08-15 00:00:00 (UTC)を境に水準が 14.89から11.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host08-014 active_connections の推移](charts/EVT-20260814-host08-014.svg)

# イベントID( EVT-20260817-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 15→13→14→13→…→12→14→12→11
* 開始   : 2026-08-17 00:05:00 (UTC)
* 終了   : 2026-08-17 20:25:00 (UTC)
* 現象   : 2026-08-17 20:25:00 (UTC)を境に水準が 11.62から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.915σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.677, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host08-001 active_connections の推移](charts/EVT-20260817-host08-001.svg)

# イベントID( EVT-20260817-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→17→18→14→…→14→13→14→13
* 開始   : 2026-08-17 01:30:00 (UTC)
* 終了   : 2026-08-17 20:25:00 (UTC)
* 現象   : 2026-08-17 20:25:00 (UTC)を境に水準が 11.96から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.407, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.737, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host08-002 active_connections の推移](charts/EVT-20260817-host08-002.svg)

# イベントID( EVT-20260817-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 16→15→16→15→…→14→16→13→14
* 開始   : 2026-08-17 01:35:00 (UTC)
* 終了   : 2026-08-17 21:50:00 (UTC)
* 現象   : 2026-08-17 21:50:00 (UTC)を境に水準が 11.93から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.378σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.852, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.567, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host08-003 active_connections の推移](charts/EVT-20260817-host08-003.svg)

# イベントID( EVT-20260817-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→16→…→15→14→11→16
* 開始   : 2026-08-17 02:30:00 (UTC)
* 終了   : 2026-08-17 21:15:00 (UTC)
* 現象   : 2026-08-17 21:15:00 (UTC)を境に水準が 11.87から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.543σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.101, 限界=2.709)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=12.14, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host08-004 active_connections の推移](charts/EVT-20260817-host08-004.svg)

# イベントID( EVT-20260819-host08-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→16→17→17→16→17→18→18→17
* 開始   : 2026-08-19 05:55:00 (UTC)
* 終了   : 2026-08-19 07:00:00 (UTC)
* 現象   : 2026-08-19 07:00:00 (UTC)を境に水準が 14.91から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.36, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host08-009 active_connections の推移](charts/EVT-20260819-host08-009.svg)

# イベントID( EVT-20260820-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A2 Hampel フィルタ, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→16→14→14
* 開始   : 2026-08-20 19:25:00 (UTC)
* 終了   : 2026-08-20 20:00:00 (UTC)
* 現象   : 2026-08-20 20:00:00 (UTC)を境に水準が 14.9から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
             ALG-A2: 移動中央値からの残差が MAD の 3.372 倍に達した (閾値 3)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.328, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host08-011 active_connections の推移](charts/EVT-20260820-host08-011.svg)

# イベントID( EVT-20260823-host08-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→14→14→14→15→15→16→14→15
* 開始   : 2026-08-23 14:25:00 (UTC)
* 終了   : 2026-08-23 15:25:00 (UTC)
* 現象   : 2026-08-23 15:25:00 (UTC)を境に水準が 11.74から14.26へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.05, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host08-006 active_connections の推移](charts/EVT-20260823-host08-006.svg)

# イベントID( EVT-20260824-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→17→18→17→…→15→11→13→15
* 開始   : 2026-08-24 00:35:00 (UTC)
* 終了   : 2026-08-24 20:05:00 (UTC)
* 現象   : 2026-08-24 20:05:00 (UTC)を境に水準が 11.83から15.14へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.138σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.159, 限界=2.709)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.63, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host08-001 active_connections の推移](charts/EVT-20260824-host08-001.svg)

# イベントID( EVT-20260824-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 15→17→15→16→…→12→14→12→13
* 開始   : 2026-08-24 02:05:00 (UTC)
* 終了   : 2026-08-24 21:20:00 (UTC)
* 現象   : 2026-08-24 21:20:00 (UTC)を境に水準が 11.8から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.658, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.855, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host08-002 active_connections の推移](charts/EVT-20260824-host08-002.svg)

# イベントID( EVT-20260824-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→16→15→16→…→9→12→9→12
* 開始   : 2026-08-24 02:15:00 (UTC)
* 終了   : 2026-08-24 20:20:00 (UTC)
* 現象   : 2026-08-24 20:20:00 (UTC)を境に水準が 11.74から15.03へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.116, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.869, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host08-003 active_connections の推移](charts/EVT-20260824-host08-003.svg)

# イベントID( EVT-20260824-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→15→17→14→…→13→14→12→13
* 開始   : 2026-08-24 02:40:00 (UTC)
* 終了   : 2026-08-24 19:45:00 (UTC)
* 現象   : 2026-08-24 19:45:00 (UTC)を境に水準が 11.81から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.858, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.804, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host08-004 active_connections の推移](charts/EVT-20260824-host08-004.svg)

# イベントID( EVT-20260824-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 15→18→16→14→…→13→12→13→12
* 開始   : 2026-08-24 03:35:00 (UTC)
* 終了   : 2026-08-24 19:50:00 (UTC)
* 現象   : 2026-08-24 19:50:00 (UTC)を境に水準が 11.96から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.146σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.725, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.86, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host08-005 active_connections の推移](charts/EVT-20260824-host08-005.svg)

# イベントID( EVT-20260824-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→16→15→16→…→16→15→13→14
* 開始   : 2026-08-24 03:55:00 (UTC)
* 終了   : 2026-08-24 19:50:00 (UTC)
* 現象   : 2026-08-24 19:50:00 (UTC)を境に水準が 11.78から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.684σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.908, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.067, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260824-host08-006 active_connections の推移](charts/EVT-20260824-host08-006.svg)

# イベントID( EVT-20260827-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→15→15→15→15→15→18→15→18
* 開始   : 2026-08-27 05:30:00 (UTC)
* 終了   : 2026-08-27 06:15:00 (UTC)
* 現象   : 2026-08-27 06:15:00 (UTC)を境に水準が 14.98から15.14へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.114, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260827-host08-002 active_connections の推移](charts/EVT-20260827-host08-002.svg)

# イベントID( EVT-20260828-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→10→8→10→10→9→9→8→10
* 開始   : 2026-08-28 01:00:00 (UTC)
* 終了   : 2026-08-28 01:50:00 (UTC)
* 現象   : 2026-08-28 01:50:00 (UTC)を境に水準が 15.07から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.43, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host08-001 active_connections の推移](charts/EVT-20260828-host08-001.svg)

# イベントID( EVT-20260801-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 9→12→11→12→…→13→10→13→9
* 開始   : 2026-08-01 04:45:00 (UTC)
* 終了   : 2026-08-01 19:20:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.769, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260801-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260801-host08-001 active_connections の推移](charts/EVT-20260801-host08-001.svg)

# イベントID( EVT-20260801-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→10→11→12→…→11→12→13→11
* 開始   : 2026-08-01 04:55:00 (UTC)
* 終了   : 2026-08-01 19:10:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.801, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.7 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.6 時間
  - EVT-20260801-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260801-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260801-host08-002 active_connections の推移](charts/EVT-20260801-host08-002.svg)

# イベントID( EVT-20260801-host08-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→12→13→11→…→10→11→10→11
* 開始   : 2026-08-01 05:20:00 (UTC)
* 終了   : 2026-08-01 19:00:00 (UTC)
* 現象   : 13.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.866, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260801-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260801-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.4 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.3 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260801-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間

![EVT-20260801-host08-003 active_connections の推移](charts/EVT-20260801-host08-003.svg)

# イベントID( EVT-20260801-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→10→9→12→…→12→10→12→10
* 開始   : 2026-08-01 05:35:00 (UTC)
* 終了   : 2026-08-01 20:20:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.15σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.082, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260801-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260801-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host08-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260801-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260801-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 14.2 時間

![EVT-20260801-host08-004 active_connections の推移](charts/EVT-20260801-host08-004.svg)

# イベントID( EVT-20260801-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→12→14→13→…→11→8→12→9
* 開始   : 2026-08-01 05:35:00 (UTC)
* 終了   : 2026-08-01 20:20:00 (UTC)
* 現象   : 14.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.788, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間
  - EVT-20260801-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260801-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260801-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260801-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host08-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.2 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 13.1 時間
  - EVT-20260801-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260801-lsfhost01-018 (他ホスト) lsf_queue / run : FATAL / 重なり 14.2 時間

![EVT-20260801-host08-005 active_connections の推移](charts/EVT-20260801-host08-005.svg)

# イベントID( EVT-20260801-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→11→9→10→…→14→11→13→12
* 開始   : 2026-08-01 05:40:00 (UTC)
* 終了   : 2026-08-01 18:25:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.305σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.748, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host03-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260801-host16-003 (他ホスト) db_connection / active_connections : SEVERE / 重なり 12.8 時間
  - EVT-20260801-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260801-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260801-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→15→19→15→15
* 開始   : 2026-08-02 09:45:00 (UTC)
* 終了   : 2026-08-02 09:45:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.31倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260802-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 8→7→4→8→10
* 開始   : 2026-08-03 22:50:00 (UTC)
* 終了   : 2026-08-03 22:50:00 (UTC)
* 現象   : 平常時(9.167)に対し 0.4364(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.591σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260803-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260803-host08-008 active_connections の推移](charts/EVT-20260803-host08-008.svg)

# イベントID( EVT-20260804-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→14→18→14→13
* 開始   : 2026-08-04 05:50:00 (UTC)
* 終了   : 2026-08-04 06:40:00 (UTC)
* 現象   : 平常時(13.33)に対し 1.35倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260804-host01-002 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260804-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260804-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→15→13→15→18
* 開始   : 2026-08-04 17:20:00 (UTC)
* 終了   : 2026-08-04 17:20:00 (UTC)
* 現象   : 平常時(17.5)に対し 0.7429(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host12-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-045 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260804-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260804-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→15→11→15→14
* 開始   : 2026-08-04 18:25:00 (UTC)
* 終了   : 2026-08-04 18:25:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-050 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260804-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260804-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→11→17→14→…→14→18→15→16
* 開始   : 2026-08-05 05:55:00 (UTC)
* 終了   : 2026-08-05 07:10:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260805-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260805-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260805-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→16→19→15→19→15→19→16
* 開始   : 2026-08-05 06:25:00 (UTC)
* 終了   : 2026-08-05 07:00:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.295倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260805-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-lsfhost01-025 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 35 分
  - EVT-20260805-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260805-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260805-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 16→18→21→16→18
* 開始   : 2026-08-05 07:10:00 (UTC)
* 終了   : 2026-08-05 07:10:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 20→19→24→21→22
* 開始   : 2026-08-05 09:10:00 (UTC)
* 終了   : 2026-08-05 09:10:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.269倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.537σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260805-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 21→22→18→20→22
* 開始   : 2026-08-05 12:40:00 (UTC)
* 終了   : 2026-08-05 12:40:00 (UTC)
* 現象   : 平常時(22.33)に対し 0.806(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260805-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 20→23→17→20→20
* 開始   : 2026-08-05 15:05:00 (UTC)
* 終了   : 2026-08-05 15:05:00 (UTC)
* 現象   : 平常時(21.33)に対し 0.7969(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260805-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 20→20→14→20→19
* 開始   : 2026-08-05 15:35:00 (UTC)
* 終了   : 2026-08-05 15:35:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.6857(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260805-host08-009 active_connections の推移](charts/EVT-20260805-host08-009.svg)

# イベントID( EVT-20260805-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 19→18→18→16→18→17→19→16→17
* 開始   : 2026-08-05 16:40:00 (UTC)
* 終了   : 2026-08-05 17:50:00 (UTC)
* 現象   : 2026-08-05 17:50:00 (UTC)を境に水準が 15.01から15.05へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.489, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→13→8→10→11
* 開始   : 2026-08-05 20:05:00 (UTC)
* 終了   : 2026-08-05 20:05:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.6316(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.247σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260805-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 9→8→6→7→8→6→7→8→10
* 開始   : 2026-08-05 21:35:00 (UTC)
* 終了   : 2026-08-05 21:40:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host08-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 8→7→4→9→7
* 開始   : 2026-08-05 23:35:00 (UTC)
* 終了   : 2026-08-05 23:35:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260805-host08-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 18→19→15→16→17→16
* 開始   : 2026-08-06 17:25:00 (UTC)
* 終了   : 2026-08-06 18:35:00 (UTC)
* 現象   : 2026-08-06 18:35:00 (UTC)を境に水準が 15.04から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.73σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.903, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→15→10→9→12→15→10→9→12
* 開始   : 2026-08-06 19:25:00 (UTC)
* 終了   : 2026-08-06 19:30:00 (UTC)
* 現象   : 平常時(13.58)に対し 0.7362(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.494σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-lsfhost01-061 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260806-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 10→8→14→10→10
* 開始   : 2026-08-07 02:45:00 (UTC)
* 終了   : 2026-08-07 02:45:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.425σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260807-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→14→11→14→14
* 開始   : 2026-08-07 18:20:00 (UTC)
* 終了   : 2026-08-07 18:20:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-070 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260807-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→11→7→11→10
* 開始   : 2026-08-07 20:30:00 (UTC)
* 終了   : 2026-08-07 20:30:00 (UTC)
* 現象   : 平常時(11.67)に対し 0.6(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.237σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-079 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260807-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-080 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 10→9→4→7→10
* 開始   : 2026-08-08 02:15:00 (UTC)
* 終了   : 2026-08-08 02:15:00 (UTC)
* 現象   : 平常時(8.5)に対し 0.4706(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260808-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host08-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→12→11→13→…→12→11→15→10
* 開始   : 2026-08-08 04:50:00 (UTC)
* 終了   : 2026-08-08 19:25:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.827, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260808-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260808-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260808-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.4 時間

![EVT-20260808-host08-003 active_connections の推移](charts/EVT-20260808-host08-003.svg)

# イベントID( EVT-20260808-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→11→10→9→…→10→12→13→11
* 開始   : 2026-08-08 05:25:00 (UTC)
* 終了   : 2026-08-08 20:00:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.931, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.6 時間
  - EVT-20260808-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.5 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260808-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.3 時間

![EVT-20260808-host08-004 active_connections の推移](charts/EVT-20260808-host08-004.svg)

# イベントID( EVT-20260808-host08-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 9→12→11→9→…→9→12→9→11
* 開始   : 2026-08-08 05:45:00 (UTC)
* 終了   : 2026-08-08 19:45:00 (UTC)
* 現象   : 14.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.023, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.7 時間
  - EVT-20260808-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-host15-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.0 時間
  - EVT-20260808-lsfhost01-009 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.0 時間

![EVT-20260808-host08-005 active_connections の推移](charts/EVT-20260808-host08-005.svg)

# イベントID( EVT-20260808-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→11→12→11→…→12→14→11→13
* 開始   : 2026-08-08 06:00:00 (UTC)
* 終了   : 2026-08-08 19:05:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.795, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260808-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260808-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260808-host08-006 active_connections の推移](charts/EVT-20260808-host08-006.svg)

# イベントID( EVT-20260808-host08-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→11→10→11→…→9→11→12→10
* 開始   : 2026-08-08 06:05:00 (UTC)
* 終了   : 2026-08-08 19:30:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.237, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260808-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260808-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260808-host08-007 active_connections の推移](charts/EVT-20260808-host08-007.svg)

# イベントID( EVT-20260808-host08-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→11→12→11→…→9→10→11→9
* 開始   : 2026-08-08 06:15:00 (UTC)
* 終了   : 2026-08-08 19:15:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.789, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260808-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260808-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260808-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260808-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260808-host08-008 active_connections の推移](charts/EVT-20260808-host08-008.svg)

# イベントID( EVT-20260809-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 10→11→15→11→13
* 開始   : 2026-08-09 05:35:00 (UTC)
* 終了   : 2026-08-09 05:35:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260809-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 10→11→5→7→9
* 開始   : 2026-08-09 20:30:00 (UTC)
* 終了   : 2026-08-09 20:30:00 (UTC)
* 現象   : 平常時(9.833)に対し 0.5085(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.367σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host08-001 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 17→16→15→17→…→16→14→15→13
* 開始   : 2026-08-10 01:30:00 (UTC)
* 終了   : 2026-08-10 20:15:00 (UTC)
* 現象   : 2026-08-10 20:15:00 (UTC)を境に水準が 11.95から14.94へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.71, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.247, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host08-002 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→13→16→15→…→12→14→12→13
* 開始   : 2026-08-10 02:50:00 (UTC)
* 終了   : 2026-08-10 22:45:00 (UTC)
* 現象   : 2026-08-10 22:45:00 (UTC)を境に水準が 11.76から14.97へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.71, 限界=2.709)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.601, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260810-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→13→15→14→13→15→14→15
* 開始   : 2026-08-11 05:20:00 (UTC)
* 終了   : 2026-08-11 06:10:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host08-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260811-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260811-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260811-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260811-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→14→19→16→16
* 開始   : 2026-08-11 06:15:00 (UTC)
* 終了   : 2026-08-11 06:15:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.407倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.831σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260811-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host08-005 active_connections の推移](charts/EVT-20260811-host08-005.svg)

# イベントID( EVT-20260811-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 17→18→22→19→17
* 開始   : 2026-08-11 07:55:00 (UTC)
* 終了   : 2026-08-11 07:55:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.269倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 23→23→23→23→21→23→24→21→21
* 開始   : 2026-08-11 12:00:00 (UTC)
* 終了   : 2026-08-11 14:00:00 (UTC)
* 現象   : 2026-08-11 14:00:00 (UTC)を境に水準が 14.91から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.475, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→14→10→15→13
* 開始   : 2026-08-11 18:45:00 (UTC)
* 終了   : 2026-08-11 18:45:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.6704(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.425σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host01-012 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260811-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 8→10→5→9→10
* 開始   : 2026-08-11 21:40:00 (UTC)
* 終了   : 2026-08-11 21:40:00 (UTC)
* 現象   : 平常時(9.667)に対し 0.5172(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.237σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host16-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host16-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 8→8→12→8→7
* 開始   : 2026-08-12 00:40:00 (UTC)
* 終了   : 2026-08-12 00:40:00 (UTC)
* 現象   : 平常時(7.667)に対し 1.565倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.016σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host02-011 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260812-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→8→15→11→12
* 開始   : 2026-08-12 04:00:00 (UTC)
* 終了   : 2026-08-12 04:00:00 (UTC)
* 現象   : 平常時(10.25)に対し 1.463倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.294σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 18→17→21→18→21→18→21→18→19
* 開始   : 2026-08-12 08:10:00 (UTC)
* 終了   : 2026-08-12 08:45:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 35 分
  - EVT-20260812-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260812-host01-006 (他ホスト) jvm_gc / eu : WARN / 重なり 10 分
  - EVT-20260812-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260812-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→11→8→10→13
* 開始   : 2026-08-12 19:40:00 (UTC)
* 終了   : 2026-08-12 19:40:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.6194(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.418σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→12→6→11→9
* 開始   : 2026-08-12 21:00:00 (UTC)
* 終了   : 2026-08-12 21:00:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.5496(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.421σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260812-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→11→6→9→10
* 開始   : 2026-08-12 21:15:00 (UTC)
* 終了   : 2026-08-12 21:15:00 (UTC)
* 現象   : 平常時(10.83)に対し 0.5538(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.36σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host07-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host08-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 9→9→14→10→10
* 開始   : 2026-08-12 21:45:00 (UTC)
* 終了   : 2026-08-12 21:45:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.585倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.617σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-lsfhost01-072 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-074 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host08-017 active_connections の推移](charts/EVT-20260812-host08-017.svg)

# イベントID( EVT-20260813-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 10→9→15→10→11
* 開始   : 2026-08-13 03:00:00 (UTC)
* 終了   : 2026-08-13 03:00:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.579倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.823σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host08-001 active_connections の推移](charts/EVT-20260813-host08-001.svg)

# イベントID( EVT-20260813-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→12→16→14→14
* 開始   : 2026-08-13 04:45:00 (UTC)
* 終了   : 2026-08-13 04:45:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.371倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260813-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→17→20→15→16
* 開始   : 2026-08-14 06:45:00 (UTC)
* 終了   : 2026-08-14 06:45:00 (UTC)
* 現象   : 平常時(15.25)に対し 1.311倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-027 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260814-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 23→22→25→22→21
* 開始   : 2026-08-14 10:20:00 (UTC)
* 終了   : 2026-08-14 10:20:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.21倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 18→15→12→16→13
* 開始   : 2026-08-14 17:55:00 (UTC)
* 終了   : 2026-08-14 17:55:00 (UTC)
* 現象   : 平常時(16.5)に対し 0.7273(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.131σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260814-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→14→11→13→…→13→12→15→14
* 開始   : 2026-08-14 18:05:00 (UTC)
* 終了   : 2026-08-14 18:15:00 (UTC)
* 現象   : 平常時(16.17)に対し 0.6804(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.599σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260814-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-065 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host08-010 active_connections の推移](charts/EVT-20260814-host08-010.svg)

# イベントID( EVT-20260814-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 9→8→5→9→10
* 開始   : 2026-08-14 22:15:00 (UTC)
* 終了   : 2026-08-14 22:15:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.179σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host11-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→8→13→8→10
* 開始   : 2026-08-15 02:15:00 (UTC)
* 終了   : 2026-08-15 02:15:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.529倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.132σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-lsfhost01-006 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260815-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260815-lsfhost01-005 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260815-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host08-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 11→13→10→11→…→12→10→11→12
* 開始   : 2026-08-15 04:30:00 (UTC)
* 終了   : 2026-08-15 19:10:00 (UTC)
* 現象   : 14.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.879, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host08-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host08-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260815-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260815-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260815-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間

![EVT-20260815-host08-004 active_connections の推移](charts/EVT-20260815-host08-004.svg)

# イベントID( EVT-20260815-host08-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→10→12→10→…→9→10→13→12
* 開始   : 2026-08-15 04:35:00 (UTC)
* 終了   : 2026-08-15 19:00:00 (UTC)
* 現象   : 14.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.933, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260815-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host08-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間
  - EVT-20260815-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260815-host13-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260815-host08-005 active_connections の推移](charts/EVT-20260815-host08-005.svg)

# イベントID( EVT-20260815-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→12→13→11→…→12→11→12→11
* 開始   : 2026-08-15 04:55:00 (UTC)
* 終了   : 2026-08-15 20:00:00 (UTC)
* 現象   : 15.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.607σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.502, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260815-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260815-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host08-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host08-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260815-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.1 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.7 時間
  - EVT-20260815-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260815-host08-006 active_connections の推移](charts/EVT-20260815-host08-006.svg)

# イベントID( EVT-20260815-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→12→11→12→…→14→12→14→12
* 開始   : 2026-08-15 05:00:00 (UTC)
* 終了   : 2026-08-15 18:00:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.541σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.241, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host08-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260815-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260815-host08-007 active_connections の推移](charts/EVT-20260815-host08-007.svg)

# イベントID( EVT-20260815-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→13→12→15→…→11→12→11→12
* 開始   : 2026-08-15 05:30:00 (UTC)
* 終了   : 2026-08-15 18:20:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.922, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host08-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260815-host08-008 active_connections の推移](charts/EVT-20260815-host08-008.svg)

# イベントID( EVT-20260815-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→10→9→10→…→12→14→15→12
* 開始   : 2026-08-15 05:35:00 (UTC)
* 終了   : 2026-08-15 18:30:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.498, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260815-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260815-host08-009 active_connections の推移](charts/EVT-20260815-host08-009.svg)

# イベントID( EVT-20260816-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→8→10→9→9→8→10→9→11
* 開始   : 2026-08-16 01:45:00 (UTC)
* 終了   : 2026-08-16 03:10:00 (UTC)
* 現象   : 2026-08-16 03:10:00 (UTC)を境に水準が 11.73から11.87へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.325σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.739, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→9→14→7→10
* 開始   : 2026-08-16 04:15:00 (UTC)
* 終了   : 2026-08-16 04:15:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.541倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260816-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→10→15→11→10
* 開始   : 2026-08-16 04:50:00 (UTC)
* 終了   : 2026-08-16 04:50:00 (UTC)
* 現象   : 平常時(9.917)に対し 1.513倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.559σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 8→8→5→9→8
* 開始   : 2026-08-16 21:30:00 (UTC)
* 終了   : 2026-08-16 21:30:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-lsfhost01-039 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260816-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host08-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→16→17→16→…→13→12→13→11
* 開始   : 2026-08-17 03:10:00 (UTC)
* 終了   : 2026-08-17 21:40:00 (UTC)
* 現象   : 2026-08-17 21:40:00 (UTC)を境に水準が 11.78から14.93へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.857, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.547, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260817-host08-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→16→14→16→…→14→17→15→13
* 開始   : 2026-08-17 03:15:00 (UTC)
* 終了   : 2026-08-17 20:05:00 (UTC)
* 現象   : 2026-08-17 20:05:00 (UTC)を境に水準が 11.87から14.86へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.073, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.33, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260817-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→15→18→16→14
* 開始   : 2026-08-18 05:55:00 (UTC)
* 終了   : 2026-08-18 05:55:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.333倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 17→18→21→18→18
* 開始   : 2026-08-18 07:45:00 (UTC)
* 終了   : 2026-08-18 07:45:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host02-006 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分
  - EVT-20260818-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 20→19→24→20→22
* 開始   : 2026-08-18 09:15:00 (UTC)
* 終了   : 2026-08-18 09:15:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.258倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.442σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260818-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 19→20→21→20→20→20→21→19
* 開始   : 2026-08-18 14:30:00 (UTC)
* 終了   : 2026-08-18 16:25:00 (UTC)
* 現象   : 2026-08-18 16:25:00 (UTC)を境に水準が 14.96から15.11へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→9→14→11→10
* 開始   : 2026-08-19 03:30:00 (UTC)
* 終了   : 2026-08-19 03:30:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host04-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260819-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→11→16→12→12
* 開始   : 2026-08-19 04:45:00 (UTC)
* 終了   : 2026-08-19 04:45:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host08-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260819-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→11→18→15→14
* 開始   : 2026-08-19 05:05:00 (UTC)
* 終了   : 2026-08-19 05:05:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.479倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 4.059σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host01-003 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-016 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260819-host08-006 active_connections の推移](charts/EVT-20260819-host08-006.svg)

# イベントID( EVT-20260819-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→18→17→15→12→18→17→15→16
* 開始   : 2026-08-19 05:55:00 (UTC)
* 終了   : 2026-08-19 06:00:00 (UTC)
* 現象   : 平常時(13.42)に対し 1.342倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host08-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260819-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260819-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→15→11→16→15
* 開始   : 2026-08-19 18:20:00 (UTC)
* 終了   : 2026-08-19 18:20:00 (UTC)
* 現象   : 平常時(15.67)に対し 0.7021(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.237σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260819-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→9→10→12→13→9→10→12→11
* 開始   : 2026-08-19 19:35:00 (UTC)
* 終了   : 2026-08-19 19:40:00 (UTC)
* 現象   : 平常時(13.33)に対し 0.675(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260819-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-062 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260819-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host15-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→10→5→10→10
* 開始   : 2026-08-19 21:50:00 (UTC)
* 終了   : 2026-08-19 21:50:00 (UTC)
* 現象   : 平常時(9.917)に対し 0.5042(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.418σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host03-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-073 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260819-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260819-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 11→11→15→13→13
* 開始   : 2026-08-20 04:10:00 (UTC)
* 終了   : 2026-08-20 04:10:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.406倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 16→21→17→16→21→17→16
* 開始   : 2026-08-20 07:20:00 (UTC)
* 終了   : 2026-08-20 07:25:00 (UTC)
* 現象   : 平常時(16.42)に対し 1.279倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260820-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-lsfhost01-026 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260820-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260820-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 20→19→23→20→21
* 開始   : 2026-08-20 08:30:00 (UTC)
* 終了   : 2026-08-20 08:30:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.26倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.294σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→18→14→16→16
* 開始   : 2026-08-20 16:45:00 (UTC)
* 終了   : 2026-08-20 16:45:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host16-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-lsfhost01-045 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260820-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→15→11→15→11→15→14→13
* 開始   : 2026-08-21 03:45:00 (UTC)
* 終了   : 2026-08-21 04:55:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260821-lsfhost01-013 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260821-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 1.1 時間
  - EVT-20260821-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 50 分
  - EVT-20260821-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260821-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 15 分

![EVT-20260821-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→16→19→16→15
* 開始   : 2026-08-21 06:25:00 (UTC)
* 終了   : 2026-08-21 06:25:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 20→19→23→18→21
* 開始   : 2026-08-21 08:40:00 (UTC)
* 終了   : 2026-08-21 08:40:00 (UTC)
* 現象   : 平常時(18.42)に対し 1.249倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.193σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→13→7→12→12
* 開始   : 2026-08-21 20:15:00 (UTC)
* 終了   : 2026-08-21 20:15:00 (UTC)
* 現象   : 平常時(12.67)に対し 0.5526(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.939σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host05-016 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host08-014 active_connections の推移](charts/EVT-20260821-host08-014.svg)

# イベントID( EVT-20260822-host08-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→11→13→11→…→12→11→9→12
* 開始   : 2026-08-22 04:15:00 (UTC)
* 終了   : 2026-08-22 19:55:00 (UTC)
* 現象   : 15.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.057, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host08-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.5 時間
  - EVT-20260822-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.2 時間
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260822-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host08-002 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→11→9→11→…→10→9→13→11
* 開始   : 2026-08-22 05:15:00 (UTC)
* 終了   : 2026-08-22 18:50:00 (UTC)
* 現象   : 13.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.142, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260822-host08-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.6 時間
  - EVT-20260822-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間
  - EVT-20260822-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.6 時間

![EVT-20260822-host08-002 active_connections の推移](charts/EVT-20260822-host08-002.svg)

# イベントID( EVT-20260822-host08-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 11→9→11→9→…→13→14→15→13
* 開始   : 2026-08-22 05:30:00 (UTC)
* 終了   : 2026-08-22 19:45:00 (UTC)
* 現象   : 14.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.068, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.3 時間
  - EVT-20260822-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host08-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260822-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間
  - EVT-20260822-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.2 時間

![EVT-20260822-host08-003 active_connections の推移](charts/EVT-20260822-host08-003.svg)

# イベントID( EVT-20260822-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→14→12→14→…→15→14→13→12
* 開始   : 2026-08-22 05:30:00 (UTC)
* 終了   : 2026-08-22 17:40:00 (UTC)
* 現象   : 12.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.81, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.0 時間
  - EVT-20260822-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.8 時間
  - EVT-20260822-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.2 時間
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間

![EVT-20260822-host08-004 active_connections の推移](charts/EVT-20260822-host08-004.svg)

# イベントID( EVT-20260822-host08-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→12→11→10→…→10→12→10→12
* 開始   : 2026-08-22 06:40:00 (UTC)
* 終了   : 2026-08-22 19:20:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.746, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260822-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260822-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.0 時間
  - EVT-20260822-host08-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260822-host08-005 active_connections の推移](charts/EVT-20260822-host08-005.svg)

# イベントID( EVT-20260822-host08-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→15→12→11→…→13→11→14→12
* 開始   : 2026-08-22 06:55:00 (UTC)
* 終了   : 2026-08-22 19:55:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.064, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260822-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260822-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260822-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10.8 時間
  - EVT-20260822-host08-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260822-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260822-host08-006 active_connections の推移](charts/EVT-20260822-host08-006.svg)

# イベントID( EVT-20260823-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→15→18→11→14
* 開始   : 2026-08-23 07:30:00 (UTC)
* 終了   : 2026-08-23 07:30:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.44倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.827σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260823-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260823-host08-003 active_connections の推移](charts/EVT-20260823-host08-003.svg)

# イベントID( EVT-20260824-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 8→8→13→11→8
* 開始   : 2026-08-24 23:40:00 (UTC)
* 終了   : 2026-08-24 23:40:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.515倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260824-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260824-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 10→9→13→15→…→13→15→11→12
* 開始   : 2026-08-25 03:45:00 (UTC)
* 終了   : 2026-08-25 03:50:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→10→15→12→12
* 開始   : 2026-08-25 03:55:00 (UTC)
* 終了   : 2026-08-25 03:55:00 (UTC)
* 現象   : 平常時(10)に対し 1.5倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.479σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 17→16→20→18→18
* 開始   : 2026-08-25 06:45:00 (UTC)
* 終了   : 2026-08-25 06:45:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.277倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 19→18→23→19→18
* 開始   : 2026-08-25 08:25:00 (UTC)
* 終了   : 2026-08-25 08:25:00 (UTC)
* 現象   : 平常時(18.33)に対し 1.255倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260825-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260825-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 20→20→23→20→20
* 開始   : 2026-08-25 09:10:00 (UTC)
* 終了   : 2026-08-25 09:10:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.232倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-039 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→17→13→15→16
* 開始   : 2026-08-25 17:10:00 (UTC)
* 終了   : 2026-08-25 17:10:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7393(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.179σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→14→18→13→…→13→10→12→13
* 開始   : 2026-08-25 18:35:00 (UTC)
* 終了   : 2026-08-25 18:45:00 (UTC)
* 現象   : 火曜18時台の平常値(14.09)に対し 18であった
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.052σ 外れた (平常値=14.09)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260825-host08-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260825-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260825-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→14→11→15→13
* 開始   : 2026-08-25 18:50:00 (UTC)
* 終了   : 2026-08-25 18:50:00 (UTC)
* 現象   : 平常時(15.42)に対し 0.7135(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host03-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260825-host08-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→11→8→6→8→11→8→6→8
* 開始   : 2026-08-25 21:15:00 (UTC)
* 終了   : 2026-08-25 21:20:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260825-host08-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→14→18→14→15
* 開始   : 2026-08-26 05:20:00 (UTC)
* 終了   : 2026-08-26 05:20:00 (UTC)
* 現象   : 平常時(12.5)に対し 1.44倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.827σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260826-host08-003 active_connections の推移](charts/EVT-20260826-host08-003.svg)

# イベントID( EVT-20260826-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 19→20→22→18→18
* 開始   : 2026-08-26 08:05:00 (UTC)
* 終了   : 2026-08-26 08:05:00 (UTC)
* 現象   : 平常時(17.58)に対し 1.251倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 23→24→18→21→20
* 開始   : 2026-08-26 12:25:00 (UTC)
* 終了   : 2026-08-26 12:25:00 (UTC)
* 現象   : 平常時(22.5)に対し 0.8(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 20→19→15→18→18
* 開始   : 2026-08-26 16:10:00 (UTC)
* 終了   : 2026-08-26 16:10:00 (UTC)
* 現象   : 平常時(19.75)に対し 0.7595(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 16→14→13→15→…→15→14→17→18
* 開始   : 2026-08-26 17:00:00 (UTC)
* 終了   : 2026-08-26 17:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.784σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260826-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-lsfhost01-056 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260826-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260826-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→14→9→14→14
* 開始   : 2026-08-26 19:10:00 (UTC)
* 終了   : 2026-08-26 19:10:00 (UTC)
* 現象   : 平常時(13.67)に対し 0.6585(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.237σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260826-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260826-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 11→9→5→7→…→5→7→11→10
* 開始   : 2026-08-26 21:15:00 (UTC)
* 終了   : 2026-08-26 21:20:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.48(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.793σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-lsfhost01-073 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260826-host08-013 active_connections の推移](charts/EVT-20260826-host08-013.svg)

# イベントID( EVT-20260827-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→13→18→16→15
* 開始   : 2026-08-27 05:35:00 (UTC)
* 終了   : 2026-08-27 05:35:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.325倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host06-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260827-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 20→22→26→20→21
* 開始   : 2026-08-27 11:50:00 (UTC)
* 終了   : 2026-08-27 11:50:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 18→18→13→15→18
* 開始   : 2026-08-27 16:55:00 (UTC)
* 終了   : 2026-08-27 16:55:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.7256(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.421σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host13-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host15-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→15→12→14→15
* 開始   : 2026-08-27 18:00:00 (UTC)
* 終了   : 2026-08-27 18:00:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7347(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.018σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host04-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host09-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-host11-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260827-lsfhost01-065 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260827-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→17→11→14→12→11→14→12→14
* 開始   : 2026-08-27 18:20:00 (UTC)
* 終了   : 2026-08-27 18:30:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7174(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-067 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260827-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 18→16→20→17→18
* 開始   : 2026-08-28 06:55:00 (UTC)
* 終了   : 2026-08-28 06:55:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.283倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260828-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 19→17→14→19→18
* 開始   : 2026-08-28 16:30:00 (UTC)
* 終了   : 2026-08-28 16:30:00 (UTC)
* 現象   : 平常時(18.92)に対し 0.7401(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.442σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 17→18→13→16→17
* 開始   : 2026-08-28 16:50:00 (UTC)
* 終了   : 2026-08-28 16:50:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7393(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host14-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 18→20→14→17→16
* 開始   : 2026-08-28 17:00:00 (UTC)
* 終了   : 2026-08-28 17:00:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 16→15→11→14→13
* 開始   : 2026-08-28 18:35:00 (UTC)
* 終了   : 2026-08-28 18:35:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 9→10→5→9→7
* 開始   : 2026-08-28 21:25:00 (UTC)
* 終了   : 2026-08-28 21:25:00 (UTC)
* 現象   : 平常時(10.25)に対し 0.4878(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.641σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-070 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260828-host08-014 active_connections の推移](charts/EVT-20260828-host08-014.svg)

# イベントID( EVT-20260829-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→11→10→13→…→11→10→9→11
* 開始   : 2026-08-29 04:55:00 (UTC)
* 終了   : 2026-08-29 19:30:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.494σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.93, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host08-001 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260829-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 14.6 時間
  - EVT-20260829-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.5 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.4 時間

![EVT-20260829-host08-002 active_connections の推移](charts/EVT-20260829-host08-002.svg)

# イベントID( EVT-20260829-host08-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→13→12→13→…→11→12→13→11
* 開始   : 2026-08-29 05:05:00 (UTC)
* 終了   : 2026-08-29 18:15:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.304, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260829-host08-003 active_connections の推移](charts/EVT-20260829-host08-003.svg)

# イベントID( EVT-20260829-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→13→10→12→…→13→11→13→11
* 開始   : 2026-08-29 05:30:00 (UTC)
* 終了   : 2026-08-29 18:25:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.834, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260829-host08-004 active_connections の推移](charts/EVT-20260829-host08-004.svg)

# イベントID( EVT-20260829-host08-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→13→15→13→…→11→12→10→13
* 開始   : 2026-08-29 05:35:00 (UTC)
* 終了   : 2026-08-29 19:00:00 (UTC)
* 現象   : 13.4時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.903, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260829-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間
  - EVT-20260829-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.4 時間

![EVT-20260829-host08-005 active_connections の推移](charts/EVT-20260829-host08-005.svg)

# イベントID( EVT-20260829-host08-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 10→12→11→13→…→13→10→11→9
* 開始   : 2026-08-29 06:10:00 (UTC)
* 終了   : 2026-08-29 19:20:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.771, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260829-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260829-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260829-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260829-host05-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260829-host08-006 active_connections の推移](charts/EVT-20260829-host08-006.svg)

# イベントID( EVT-20260829-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→15→14→12→…→11→12→10→11
* 開始   : 2026-08-29 07:00:00 (UTC)
* 終了   : 2026-08-29 18:55:00 (UTC)
* 現象   : 11.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.787, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.4 時間
  - EVT-20260829-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.2 時間
  - EVT-20260829-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間
  - EVT-20260829-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 11.9 時間

![EVT-20260829-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260801-host08-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 9→10→9→10→11→9→10→11→10
* 開始   : 2026-08-01 20:05:00 (UTC)
* 終了   : 2026-08-01 20:15:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.792, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260801-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260801-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260801-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260801-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260801-lsfhost01-063 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260801-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260801-host15-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260801-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 9→10→11→11→8→9→12→9→10
* 開始   : 2026-08-02 02:45:00 (UTC)
* 終了   : 2026-08-02 03:40:00 (UTC)
* 現象   : 2026-08-02 03:40:00 (UTC)を境に水準が 11.69から11.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.806, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 10→12→9→13→12→9→13→9→10
* 開始   : 2026-08-02 03:35:00 (UTC)
* 終了   : 2026-08-02 03:45:00 (UTC)
* 現象   : 平常時(8.917)に対し 1.346倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260802-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→14→12→13→15→16→14→13→14
* 開始   : 2026-08-02 06:20:00 (UTC)
* 終了   : 2026-08-02 07:05:00 (UTC)
* 現象   : 2026-08-02 07:05:00 (UTC)を境に水準が 11.67から12.3へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.821, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→12→15→11→15→11→15→14→12
* 開始   : 2026-08-02 06:25:00 (UTC)
* 終了   : 2026-08-02 06:35:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-lsfhost01-016 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260802-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→15→11→17→14→15→11→17→14
* 開始   : 2026-08-02 15:35:00 (UTC)
* 終了   : 2026-08-02 15:40:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260802-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260802-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260802-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260802-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 9→8→9→12→9→7→7→6→10
* 開始   : 2026-08-02 23:35:00 (UTC)
* 終了   : 2026-08-03 00:15:00 (UTC)
* 現象   : 2026-08-03 00:15:00 (UTC)を境に水準が 11.67から14.96へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.207, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260802-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260803-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→10→9→10→10→10
* 開始   : 2026-08-03 01:50:00 (UTC)
* 終了   : 2026-08-03 02:15:00 (UTC)
* 現象   : 2026-08-03 02:15:00 (UTC)を境に水準が 11.75から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.903, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260803-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 18→20→21→18→20→21→18→20
* 開始   : 2026-08-04 08:10:00 (UTC)
* 終了   : 2026-08-04 08:15:00 (UTC)
* 現象   : 平常時(17.5)に対し 1.2倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260804-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260804-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host08-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 20→19→21→21→20→21→21
* 開始   : 2026-08-04 15:00:00 (UTC)
* 終了   : 2026-08-04 15:30:00 (UTC)
* 現象   : 2026-08-04 15:30:00 (UTC)を境に水準が 15から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260804-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 17→18→16→15→…→16→15→17→18
* 開始   : 2026-08-04 16:35:00 (UTC)
* 終了   : 2026-08-04 16:40:00 (UTC)
* 現象   : 平常時(19.08)に対し 0.8384(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-lsfhost01-042 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260804-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→16→11→12→16→11→12→13
* 開始   : 2026-08-04 19:25:00 (UTC)
* 終了   : 2026-08-04 19:30:00 (UTC)
* 現象   : 平常時(14.17)に対し 0.7765(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host07-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host02-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-host04-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260804-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260804-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→10→8→11→8→11→8→9→11
* 開始   : 2026-08-04 20:55:00 (UTC)
* 終了   : 2026-08-04 21:05:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260804-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260804-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260804-host07-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260804-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260804-host06-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260804-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 13→13→13→13→14→11→11→15
* 開始   : 2026-08-05 04:00:00 (UTC)
* 終了   : 2026-08-05 04:35:00 (UTC)
* 現象   : 2026-08-05 04:35:00 (UTC)を境に水準が 14.93から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.54, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 22→21→22→22→21→24
* 開始   : 2026-08-05 09:40:00 (UTC)
* 終了   : 2026-08-05 10:05:00 (UTC)
* 現象   : 2026-08-05 10:05:00 (UTC)を境に水準が 15.02から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.804, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 21→18→15→17→15→17→15→18→17
* 開始   : 2026-08-05 16:50:00 (UTC)
* 終了   : 2026-08-05 17:00:00 (UTC)
* 現象   : 平常時(18.67)に対し 0.8036(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.543σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260805-host01-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260805-host10-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→12→10→12→…→12→9→11→13
* 開始   : 2026-08-05 19:40:00 (UTC)
* 終了   : 2026-08-05 19:50:00 (UTC)
* 現象   : 平常時(13.17)に対し 0.7595(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host06-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260805-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→10→9→11→9→11→9→10→11
* 開始   : 2026-08-05 20:05:00 (UTC)
* 終了   : 2026-08-05 20:15:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260805-host08-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260805-host09-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260805-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260805-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260805-host10-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-host10-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260805-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260805-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260805-host08-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→10→9→11→11
* 開始   : 2026-08-05 21:50:00 (UTC)
* 終了   : 2026-08-05 22:10:00 (UTC)
* 現象   : 2026-08-05 22:10:00 (UTC)を境に水準が 14.98から14.82へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.429, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260805-host08-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→11→11→11→9→10
* 開始   : 2026-08-06 02:10:00 (UTC)
* 終了   : 2026-08-06 03:05:00 (UTC)
* 現象   : 2026-08-06 03:05:00 (UTC)を境に水準が 14.98から14.82へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.138σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.515, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260806-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 9→10→12→13→…→12→13→10→11
* 開始   : 2026-08-06 03:00:00 (UTC)
* 終了   : 2026-08-06 03:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260806-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260806-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260806-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→18→17→15→18→17
* 開始   : 2026-08-06 06:25:00 (UTC)
* 終了   : 2026-08-06 06:30:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.271倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.659σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host01-005 (他ホスト) jvm_gc / eu : WARN / 重なり 5 分
  - EVT-20260806-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260806-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 17→18→19→16→…→16→20→16→18
* 開始   : 2026-08-06 07:10:00 (UTC)
* 終了   : 2026-08-06 07:20:00 (UTC)
* 現象   : 平常時(16)に対し 1.188倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host07-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-lsfhost01-021 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260806-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260806-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 17→18→15→18→15→18→16
* 開始   : 2026-08-06 16:50:00 (UTC)
* 終了   : 2026-08-06 16:55:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.8219(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.276σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260806-host14-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260806-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260806-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260806-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 18→15→21→19→15→21→19
* 開始   : 2026-08-07 08:15:00 (UTC)
* 終了   : 2026-08-07 08:20:00 (UTC)
* 現象   : 平常時(17.75)に対し 1.183倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-lsfhost01-028 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260807-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host11-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 18→20→23→22→20→23→22→20
* 開始   : 2026-08-07 09:15:00 (UTC)
* 終了   : 2026-08-07 09:20:00 (UTC)
* 現象   : 平常時(19.17)に対し 1.2倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.659σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-034 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260807-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 20→19→17→18→19→17→18→19
* 開始   : 2026-08-07 15:40:00 (UTC)
* 終了   : 2026-08-07 15:45:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-057 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260807-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 18→15→17→15→17→15→18→17
* 開始   : 2026-08-07 16:25:00 (UTC)
* 終了   : 2026-08-07 16:35:00 (UTC)
* 現象   : 平常時(19)に対し 0.7895(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.801σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host04-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 17→15→14→16→…→16→13→14→15
* 開始   : 2026-08-07 17:55:00 (UTC)
* 終了   : 2026-08-07 18:05:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.8276(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host11-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260807-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260807-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→13→11→13→11→13
* 開始   : 2026-08-07 19:15:00 (UTC)
* 終了   : 2026-08-07 19:20:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.7674(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host08-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260807-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→10→12→10→…→12→10→11→12
* 開始   : 2026-08-07 19:20:00 (UTC)
* 終了   : 2026-08-07 19:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.67σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host08-010 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host08-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260807-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260807-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260807-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-lsfhost01-074 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260807-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260807-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→13→10→13→10→13
* 開始   : 2026-08-07 19:30:00 (UTC)
* 終了   : 2026-08-07 19:35:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260807-host08-009 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260807-host02-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-074 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260807-lsfhost01-075 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260807-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260807-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260807-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→7→5→11→…→5→11→6→8
* 開始   : 2026-08-08 00:25:00 (UTC)
* 終了   : 2026-08-08 00:30:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260808-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260808-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 8→7→12→6→7→12→6→7→6
* 開始   : 2026-08-08 22:55:00 (UTC)
* 終了   : 2026-08-08 23:00:00 (UTC)
* 現象   : 平常時(8.5)に対し 1.412倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260808-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→12→14→12→…→12→15→12→13
* 開始   : 2026-08-09 05:55:00 (UTC)
* 終了   : 2026-08-09 06:05:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.282倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260809-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260809-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260809-lsfhost01-012 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260809-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 17→14→18→19→15→14→18→19→15
* 開始   : 2026-08-09 13:25:00 (UTC)
* 終了   : 2026-08-09 13:30:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260809-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host08-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→15→14→12→15→13→13→15→14
* 開始   : 2026-08-09 16:20:00 (UTC)
* 終了   : 2026-08-09 17:30:00 (UTC)
* 現象   : 2026-08-09 17:30:00 (UTC)を境に水準が 11.82から14.76へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.758, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host08-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→13→12→15→12→13
* 開始   : 2026-08-09 17:55:00 (UTC)
* 終了   : 2026-08-09 18:20:00 (UTC)
* 現象   : 2026-08-09 18:20:00 (UTC)を境に水準が 11.9から14.72へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.804, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260809-host08-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→8→8→10→9→8→7→9→10
* 開始   : 2026-08-09 23:00:00 (UTC)
* 終了   : 2026-08-09 23:40:00 (UTC)
* 現象   : 2026-08-09 23:40:00 (UTC)を境に水準が 11.89から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.855, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260809-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260810-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 10→12→8→7→9→12→8→7→9
* 開始   : 2026-08-10 21:00:00 (UTC)
* 終了   : 2026-08-10 21:05:00 (UTC)
* 現象   : 平常時(10.92)に対し 0.7328(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.042σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260810-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 7→9→12→10→9→12→10
* 開始   : 2026-08-11 02:20:00 (UTC)
* 終了   : 2026-08-11 02:25:00 (UTC)
* 現象   : 平常時(8.083)に対し 1.485倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.723σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-lsfhost01-009 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260811-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 10→12→14→11→12→14→11→13
* 開始   : 2026-08-11 03:50:00 (UTC)
* 終了   : 2026-08-11 03:55:00 (UTC)
* 現象   : 平常時(10.08)に対し 1.388倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.742σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-014 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260811-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→14→17→14→17→14→17→16→14
* 開始   : 2026-08-11 05:45:00 (UTC)
* 終了   : 2026-08-11 05:55:00 (UTC)
* 現象   : 平常時(13)に対し 1.308倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.784σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260811-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260811-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 20→24→19→25→20→24→19→25→20
* 開始   : 2026-08-11 11:15:00 (UTC)
* 終了   : 2026-08-11 11:20:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260811-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 23→23→22→23→22→21→25→23→24
* 開始   : 2026-08-11 12:00:00 (UTC)
* 終了   : 2026-08-11 12:40:00 (UTC)
* 現象   : 2026-08-11 12:40:00 (UTC)を境に水準が 15から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.772, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 21→18→16→17→…→17→15→20→18
* 開始   : 2026-08-11 16:35:00 (UTC)
* 終了   : 2026-08-11 16:45:00 (UTC)
* 現象   : 平常時(19.33)に対し 0.8276(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host05-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-045 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260811-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260811-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 16→13→15→16→13→15
* 開始   : 2026-08-11 17:55:00 (UTC)
* 終了   : 2026-08-11 18:00:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host03-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host07-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260811-host04-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-lsfhost01-050 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260811-host04-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-host15-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260811-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260811-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→9→6→12→9→6→12→9
* 開始   : 2026-08-11 21:50:00 (UTC)
* 終了   : 2026-08-11 21:55:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260811-host15-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260811-host16-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260811-lsfhost01-069 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260811-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260811-host08-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→9→11→11→9→7→9→10
* 開始   : 2026-08-11 22:00:00 (UTC)
* 終了   : 2026-08-11 22:35:00 (UTC)
* 現象   : 2026-08-11 22:35:00 (UTC)を境に水準が 14.94から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.073, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260811-host08-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-004 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→15→15→16→15→18→17→20→21
* 開始   : 2026-08-12 04:50:00 (UTC)
* 終了   : 2026-08-12 07:25:00 (UTC)
* 現象   : 2026-08-12 07:25:00 (UTC)を境に水準が 14.88から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.15, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 17→16→20→21→17→16→20→21→17
* 開始   : 2026-08-12 07:30:00 (UTC)
* 終了   : 2026-08-12 07:35:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.206倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260812-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-027 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260812-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 22→23→19→23→25→19→23→25→20
* 開始   : 2026-08-12 11:00:00 (UTC)
* 終了   : 2026-08-12 11:10:00 (UTC)
* 現象   : 平常時(22.17)に対し 0.8571(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host08-008 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260812-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 21→20→24→25→…→24→25→21→22
* 開始   : 2026-08-12 11:10:00 (UTC)
* 終了   : 2026-08-12 11:15:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host08-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-lsfhost01-035 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260812-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 24→23→23→22→23
* 開始   : 2026-08-12 13:20:00 (UTC)
* 終了   : 2026-08-12 13:40:00 (UTC)
* 現象   : 2026-08-12 13:40:00 (UTC)を境に水準が 15.02から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.429, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 19→18→17→19→…→19→16→19→21
* 開始   : 2026-08-12 15:30:00 (UTC)
* 終了   : 2026-08-12 15:40:00 (UTC)
* 現象   : 平常時(20)に対し 0.85(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-043 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260812-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260812-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 18→19→16→19→16
* 開始   : 2026-08-12 15:55:00 (UTC)
* 終了   : 2026-08-12 16:00:00 (UTC)
* 現象   : 平常時(19.25)に対し 0.8312(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260812-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 17→15→14→17→…→15→14→15→17
* 開始   : 2026-08-12 17:05:00 (UTC)
* 終了   : 2026-08-12 17:15:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260812-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260812-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260812-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260812-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-049 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260812-lsfhost01-050 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260812-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260812-host08-016 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→10→11→11→10→10→9→10→11
* 開始   : 2026-08-12 21:25:00 (UTC)
* 終了   : 2026-08-12 22:05:00 (UTC)
* 現象   : 2026-08-12 22:05:00 (UTC)を境に水準が 15.09から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.855, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260812-host08-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→12→14→11
* 開始   : 2026-08-13 03:25:00 (UTC)
* 終了   : 2026-08-13 03:40:00 (UTC)
* 現象   : 2026-08-13 03:40:00 (UTC)を境に水準が 15.06から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.536, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260813-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→14→15→16→…→15→16→15→14
* 開始   : 2026-08-13 05:20:00 (UTC)
* 終了   : 2026-08-13 05:25:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.241倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host05-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 17→16→19→18→16→19→18→16
* 開始   : 2026-08-13 06:55:00 (UTC)
* 終了   : 2026-08-13 07:00:00 (UTC)
* 現象   : 平常時(15.67)に対し 1.213倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260813-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-018 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260813-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 21→22→19→21→22→19→22
* 開始   : 2026-08-13 08:50:00 (UTC)
* 終了   : 2026-08-13 08:55:00 (UTC)
* 現象   : 平常時(18.92)に対し 1.163倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260813-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260813-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 18→19→16→18→16→18→16→19→18
* 開始   : 2026-08-13 15:30:00 (UTC)
* 終了   : 2026-08-13 15:40:00 (UTC)
* 現象   : 平常時(20)に対し 0.8(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.774σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-035 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-lsfhost01-036 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260813-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 18→15→17→18→15→17→16
* 開始   : 2026-08-13 17:20:00 (UTC)
* 終了   : 2026-08-13 17:25:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 17→16→14→18→16→14→18→14
* 開始   : 2026-08-13 17:30:00 (UTC)
* 終了   : 2026-08-13 17:35:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-host14-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260813-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260813-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→12→9→10→12→9→10
* 開始   : 2026-08-13 20:20:00 (UTC)
* 終了   : 2026-08-13 20:25:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.204σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260813-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260813-host03-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-host12-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260813-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260813-host01-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260813-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260813-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→13→11→13→13→11→13→14
* 開始   : 2026-08-14 04:00:00 (UTC)
* 終了   : 2026-08-14 04:35:00 (UTC)
* 現象   : 2026-08-14 04:35:00 (UTC)を境に水準が 14.92から14.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.856, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→14→13→11→14→13→10
* 開始   : 2026-08-14 04:15:00 (UTC)
* 終了   : 2026-08-14 04:20:00 (UTC)
* 現象   : 平常時(10.42)に対し 1.344倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host16-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host08-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→13→14→14→13→15→14→17→15
* 開始   : 2026-08-14 04:30:00 (UTC)
* 終了   : 2026-08-14 07:15:00 (UTC)
* 現象   : 2026-08-14 07:15:00 (UTC)を境に水準が 14.89から14.75へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.547, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260814-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→16→17→14→16→17→14→16
* 開始   : 2026-08-14 05:35:00 (UTC)
* 終了   : 2026-08-14 05:40:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260814-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260814-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 21→22→17→20→17→20→17→18→20
* 開始   : 2026-08-14 15:25:00 (UTC)
* 終了   : 2026-08-14 15:35:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-lsfhost01-056 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260814-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 18→14→17→14→17→14→18→16
* 開始   : 2026-08-14 17:05:00 (UTC)
* 終了   : 2026-08-14 17:15:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.7671(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.954σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host15-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260814-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260814-host13-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260814-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→10→13→12→10→13→11
* 開始   : 2026-08-14 19:25:00 (UTC)
* 終了   : 2026-08-14 19:30:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7186(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.742σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host02-013 (他ホスト) jvm_gc / ou : FATAL / 重なり 5 分
  - EVT-20260814-host11-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260814-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host13-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260814-host15-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260814-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260814-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→10→8→7→…→8→7→9→11
* 開始   : 2026-08-14 20:40:00 (UTC)
* 終了   : 2026-08-14 20:45:00 (UTC)
* 現象   : 平常時(11.33)に対し 0.7059(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260814-host09-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260814-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 10→10→9→10→8
* 開始   : 2026-08-15 00:00:00 (UTC)
* 終了   : 2026-08-15 00:20:00 (UTC)
* 現象   : 2026-08-15 00:20:00 (UTC)を境に水準が 14.98から11.77へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260815-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 8→12→11→13→12→11→13→10
* 開始   : 2026-08-15 03:40:00 (UTC)
* 終了   : 2026-08-15 03:50:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-lsfhost01-008 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260815-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260815-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260815-host08-010 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→11→8→11→…→10→11→12→10
* 開始   : 2026-08-15 19:05:00 (UTC)
* 終了   : 2026-08-15 19:20:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.778, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260815-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260815-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 15 分
  - EVT-20260815-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260815-host04-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260815-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→10→9→10
* 開始   : 2026-08-16 01:55:00 (UTC)
* 終了   : 2026-08-16 02:10:00 (UTC)
* 現象   : 2026-08-16 02:10:00 (UTC)を境に水準が 11.79から11.76へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.536, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260816-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→13→17→16→17→16→17→14→16
* 開始   : 2026-08-16 08:10:00 (UTC)
* 終了   : 2026-08-16 08:20:00 (UTC)
* 現象   : 平常時(13.5)に対し 1.259倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260816-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260816-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→14→12→18→…→18→12→13→14
* 開始   : 2026-08-16 15:35:00 (UTC)
* 終了   : 2026-08-16 15:45:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260816-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260816-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→13→12→13→12→12→14
* 開始   : 2026-08-18 03:50:00 (UTC)
* 終了   : 2026-08-18 04:20:00 (UTC)
* 現象   : 2026-08-18 04:20:00 (UTC)を境に水準が 14.85から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.574, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→14→19→16→19→16→19→18
* 開始   : 2026-08-18 07:00:00 (UTC)
* 終了   : 2026-08-18 07:10:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-lsfhost01-022 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260818-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host04-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 17→18→20→21→…→20→21→20→19
* 開始   : 2026-08-18 07:55:00 (UTC)
* 終了   : 2026-08-18 08:00:00 (UTC)
* 現象   : 平常時(16.92)に対し 1.182倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260818-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260818-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 19→20→22→23→…→22→23→22→20
* 開始   : 2026-08-18 09:00:00 (UTC)
* 終了   : 2026-08-18 09:05:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.153倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-lsfhost01-032 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260818-lsfhost01-031 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260818-host15-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 18→19→23→19→…→19→17→22→19
* 開始   : 2026-08-18 15:30:00 (UTC)
* 終了   : 2026-08-18 15:40:00 (UTC)
* 現象   : 平常時(19.83)に対し 1.16倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260818-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260818-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 20→17→22→15→17→22→15→17
* 開始   : 2026-08-18 16:20:00 (UTC)
* 終了   : 2026-08-18 16:25:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-lsfhost01-044 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→14→16→13→14→16→13→14→15
* 開始   : 2026-08-18 17:40:00 (UTC)
* 終了   : 2026-08-18 17:50:00 (UTC)
* 現象   : 平常時(17.42)に対し 0.8038(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260818-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host09-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260818-host01-008 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260818-lsfhost01-053 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260818-host04-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260818-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260818-lsfhost01-052 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260818-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host08-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 15→15→15→13→13→14→12→11→15
* 開始   : 2026-08-18 18:30:00 (UTC)
* 終了   : 2026-08-18 19:35:00 (UTC)
* 現象   : 2026-08-18 19:35:00 (UTC)を境に水準が 14.94から15.13へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.441, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260818-host08-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 9→10→9→8→9→7→8→9→9
* 開始   : 2026-08-18 22:35:00 (UTC)
* 終了   : 2026-08-18 23:45:00 (UTC)
* 現象   : 2026-08-18 23:45:00 (UTC)を境に水準が 15.03から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.758, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260818-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 8→6→5→6→8→6→5→6→7
* 開始   : 2026-08-19 00:10:00 (UTC)
* 終了   : 2026-08-19 00:15:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260819-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 9→10→10→9→8→10
* 開始   : 2026-08-19 00:55:00 (UTC)
* 終了   : 2026-08-19 01:20:00 (UTC)
* 現象   : 2026-08-19 01:20:00 (UTC)を境に水準が 15.08から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.903, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260819-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→11→14→12→…→12→15→14→13
* 開始   : 2026-08-19 04:40:00 (UTC)
* 終了   : 2026-08-19 04:50:00 (UTC)
* 現象   : 平常時(11)に対し 1.273倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260819-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260819-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→15→16→17→…→15→17→15→14
* 開始   : 2026-08-19 05:35:00 (UTC)
* 終了   : 2026-08-19 05:55:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260819-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260819-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260819-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260819-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 17→21→18→21→18→21→16→19
* 開始   : 2026-08-19 08:10:00 (UTC)
* 終了   : 2026-08-19 08:20:00 (UTC)
* 現象   : 平常時(17.83)に対し 1.178倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260819-host03-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260819-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260819-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→18→14→16→18→14→16→18
* 開始   : 2026-08-19 17:15:00 (UTC)
* 終了   : 2026-08-19 17:20:00 (UTC)
* 現象   : 平常時(17.25)に対し 0.8116(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260819-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260819-lsfhost01-053 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260819-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260819-host04-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260819-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→12→13→11→10→12→13→11
* 開始   : 2026-08-20 02:45:00 (UTC)
* 終了   : 2026-08-20 02:50:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host08-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→12→15→14→15
* 開始   : 2026-08-20 04:40:00 (UTC)
* 終了   : 2026-08-20 05:00:00 (UTC)
* 現象   : 2026-08-20 05:00:00 (UTC)を境に水準が 14.92から14.83へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 13→16→15→17→15→16
* 開始   : 2026-08-20 05:25:00 (UTC)
* 終了   : 2026-08-20 05:50:00 (UTC)
* 現象   : 2026-08-20 05:50:00 (UTC)を境に水準が 15.06から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.099σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.903, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 20→22→20→22→19
* 開始   : 2026-08-20 09:05:00 (UTC)
* 終了   : 2026-08-20 09:10:00 (UTC)
* 現象   : 平常時(18.75)に対し 1.173倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260820-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 21→22→24→21→21→24→22
* 開始   : 2026-08-20 09:50:00 (UTC)
* 終了   : 2026-08-20 10:20:00 (UTC)
* 現象   : 2026-08-20 10:20:00 (UTC)を境に水準が 14.87から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.939, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260820-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 21→23→25→19→23→25→19→23→22
* 開始   : 2026-08-20 12:30:00 (UTC)
* 終了   : 2026-08-20 12:35:00 (UTC)
* 現象   : 平常時(21.92)に対し 1.141倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.138σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260820-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→12→9→10→12→9→10→12
* 開始   : 2026-08-20 20:15:00 (UTC)
* 終了   : 2026-08-20 20:20:00 (UTC)
* 現象   : 平常時(12.58)に対し 0.7152(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.494σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host08-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-lsfhost01-066 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260820-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260820-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→11→9→8→…→12→9→8→12
* 開始   : 2026-08-20 20:20:00 (UTC)
* 終了   : 2026-08-20 20:30:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host08-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host10-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260820-host16-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host10-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260820-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260820-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 9→10→7→10→7→10→12
* 開始   : 2026-08-20 21:35:00 (UTC)
* 終了   : 2026-08-20 21:40:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260820-host09-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260820-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260820-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260820-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→15→16→17→…→17→15→17→15
* 開始   : 2026-08-21 05:30:00 (UTC)
* 終了   : 2026-08-21 05:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.275σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 15 分
  - EVT-20260821-lsfhost01-019 (他ホスト) lsf_queue / njobs : WARN / 重なり 15 分
  - EVT-20260821-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host02-003 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260821-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→15→18→17→19→18→17→19→18
* 開始   : 2026-08-21 06:50:00 (UTC)
* 終了   : 2026-08-21 07:00:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260821-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 17→16→19→18→16→19→18→17
* 開始   : 2026-08-21 07:25:00 (UTC)
* 終了   : 2026-08-21 07:30:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-027 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 20→18→21→22→…→21→22→19→21
* 開始   : 2026-08-21 08:15:00 (UTC)
* 終了   : 2026-08-21 08:20:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-007 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260821-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→18→21→20→21→20→21→20→19
* 開始   : 2026-08-21 08:20:00 (UTC)
* 終了   : 2026-08-21 08:30:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.212倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.549σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260821-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-030 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260821-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 17→18→21→14→…→21→14→16→18
* 開始   : 2026-08-21 16:45:00 (UTC)
* 終了   : 2026-08-21 16:50:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host07-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260821-lsfhost01-049 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260821-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-050 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260821-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 16→14→16→14→16→17
* 開始   : 2026-08-21 17:05:00 (UTC)
* 終了   : 2026-08-21 17:10:00 (UTC)
* 現象   : 平常時(17.58)に対し 0.7962(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-lsfhost01-049 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260821-host06-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260821-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 18→17→14→16→…→16→13→16→15
* 開始   : 2026-08-21 17:35:00 (UTC)
* 終了   : 2026-08-21 17:50:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-012 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 15 分
  - EVT-20260821-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260821-host13-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260821-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260821-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 18→15→14→13→15→14→13→15→16
* 開始   : 2026-08-21 17:40:00 (UTC)
* 終了   : 2026-08-21 17:45:00 (UTC)
* 現象   : 平常時(17.08)に対し 0.8195(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host08-011 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-052 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260821-host05-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-host06-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260821-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→16→12→14→…→16→11→16→13
* 開始   : 2026-08-21 18:50:00 (UTC)
* 終了   : 2026-08-21 19:10:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host13-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260821-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260821-host01-011 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260821-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-lsfhost01-069 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260821-host12-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→9→12→9→10→11
* 開始   : 2026-08-21 21:30:00 (UTC)
* 終了   : 2026-08-21 21:55:00 (UTC)
* 現象   : 2026-08-21 21:55:00 (UTC)を境に水準が 15.01から11.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.903, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260821-host08-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260821-host08-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 10→9→7→8→6→7→8→6→8
* 開始   : 2026-08-21 22:05:00 (UTC)
* 終了   : 2026-08-21 22:15:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260821-host02-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260821-host05-017 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260821-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260821-host08-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260822-host08-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 10→11→10→9→…→12→11→10→9
* 開始   : 2026-08-22 18:50:00 (UTC)
* 終了   : 2026-08-22 19:20:00 (UTC)
* 現象   : 30分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.076, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260822-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260822-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260822-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260822-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260822-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260822-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260822-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260822-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260822-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260822-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分

![EVT-20260822-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 9→10→13→7→11→10→13→7→11
* 開始   : 2026-08-23 03:30:00 (UTC)
* 終了   : 2026-08-23 03:35:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.345倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260823-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→13→12→12→13→15
* 開始   : 2026-08-23 05:35:00 (UTC)
* 終了   : 2026-08-23 06:00:00 (UTC)
* 現象   : 2026-08-23 06:00:00 (UTC)を境に水準が 11.84から12.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.903, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→16→14→14→16→14→16→16→18
* 開始   : 2026-08-23 08:40:00 (UTC)
* 終了   : 2026-08-23 09:35:00 (UTC)
* 現象   : 2026-08-23 09:35:00 (UTC)を境に水準が 11.85から12.72へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.475, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host08-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 15→16→18→17→16→17→17
* 開始   : 2026-08-23 11:15:00 (UTC)
* 終了   : 2026-08-23 11:45:00 (UTC)
* 現象   : 2026-08-23 11:45:00 (UTC)を境に水準が 11.89から13.3へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→11→14→10→11→14→10→14
* 開始   : 2026-08-23 16:00:00 (UTC)
* 終了   : 2026-08-23 16:10:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260823-lsfhost01-035 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260823-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260823-host06-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260823-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→12→9→8→…→9→8→12→10
* 開始   : 2026-08-23 18:25:00 (UTC)
* 終了   : 2026-08-23 18:35:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260823-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260823-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260823-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host08-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→10→11→11→9→12→10
* 開始   : 2026-08-23 20:00:00 (UTC)
* 終了   : 2026-08-23 20:30:00 (UTC)
* 現象   : 2026-08-23 20:30:00 (UTC)を境に水準が 11.78から14.85へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.574, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260823-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 10→9→10→8→9→12→9→9
* 開始   : 2026-08-23 20:50:00 (UTC)
* 終了   : 2026-08-23 22:35:00 (UTC)
* 現象   : 2026-08-23 22:35:00 (UTC)を境に水準が 11.79から15.14へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.686, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260823-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→11→14→12→13→12
* 開始   : 2026-08-25 04:15:00 (UTC)
* 終了   : 2026-08-25 04:40:00 (UTC)
* 現象   : 2026-08-25 04:40:00 (UTC)を境に水準が 15.15から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.515, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260825-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→15→11→15→11→15→13→12
* 開始   : 2026-08-25 04:40:00 (UTC)
* 終了   : 2026-08-25 04:50:00 (UTC)
* 現象   : 平常時(10.92)に対し 1.374倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.859σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host01-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-014 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260825-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→13→15→12→13→15→12→14
* 開始   : 2026-08-25 05:00:00 (UTC)
* 終了   : 2026-08-25 05:05:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260825-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→13→18→16→13→18→16
* 開始   : 2026-08-25 06:05:00 (UTC)
* 終了   : 2026-08-25 06:10:00 (UTC)
* 現象   : 平常時(14)に対し 1.286倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.784σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260825-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-024 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260825-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-023 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260825-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260825-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 17→18→21→17→18→21→17→18
* 開始   : 2026-08-25 08:05:00 (UTC)
* 終了   : 2026-08-25 08:10:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.189倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.334σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260825-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-lsfhost01-031 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260825-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-032 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260825-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 17→14→16→14→16→14→17→16
* 開始   : 2026-08-25 16:55:00 (UTC)
* 終了   : 2026-08-25 17:05:00 (UTC)
* 現象   : 平常時(18.25)に対し 0.7671(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.973σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host14-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260825-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260825-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260825-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260825-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→13→12→13→12→14
* 開始   : 2026-08-25 18:25:00 (UTC)
* 終了   : 2026-08-25 18:35:00 (UTC)
* 現象   : 平常時(16)に対し 0.8125(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.101σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260825-host08-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260825-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260825-lsfhost01-064 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260825-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→9→7→8→9→8→10→10→7
* 開始   : 2026-08-26 00:25:00 (UTC)
* 終了   : 2026-08-26 01:05:00 (UTC)
* 現象   : 2026-08-26 01:05:00 (UTC)を境に水準が 14.88から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.855, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→10→14→13→…→14→13→15→13
* 開始   : 2026-08-26 04:15:00 (UTC)
* 終了   : 2026-08-26 04:30:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-014 (他ホスト) lsf_queue / run : FATAL / 重なり 15 分
  - EVT-20260826-lsfhost01-015 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260826-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→15→16→12→…→12→16→14→16
* 開始   : 2026-08-26 05:55:00 (UTC)
* 終了   : 2026-08-26 06:10:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host06-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260826-host16-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260826-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260826-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 18→19→23→22→19→23→22→19→18
* 開始   : 2026-08-26 08:50:00 (UTC)
* 終了   : 2026-08-26 08:55:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.221倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.915σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260826-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 22→22→22→22→21→22→21→21→21
* 開始   : 2026-08-26 13:25:00 (UTC)
* 終了   : 2026-08-26 14:10:00 (UTC)
* 現象   : 2026-08-26 14:10:00 (UTC)を境に水準が 15から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260826-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 20→17→16→19→…→19→15→17→18
* 開始   : 2026-08-26 16:25:00 (UTC)
* 終了   : 2026-08-26 16:35:00 (UTC)
* 現象   : 平常時(19.17)に対し 0.8348(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260826-lsfhost01-054 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260826-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260826-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 8→6→10→8→6→10→9
* 開始   : 2026-08-26 22:30:00 (UTC)
* 終了   : 2026-08-26 22:35:00 (UTC)
* 現象   : 平常時(9.083)に対し 0.6606(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260826-host13-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260826-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→13→15→16→…→15→16→14→13
* 開始   : 2026-08-27 05:00:00 (UTC)
* 終了   : 2026-08-27 05:05:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 20→24→21→20→24→21→20
* 開始   : 2026-08-27 10:20:00 (UTC)
* 終了   : 2026-08-27 10:25:00 (UTC)
* 現象   : 平常時(20.67)に対し 1.161倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-038 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260827-lsfhost01-039 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260827-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260827-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 21→26→20→25→26→20→25→23
* 開始   : 2026-08-27 12:20:00 (UTC)
* 終了   : 2026-08-27 12:30:00 (UTC)
* 現象   : 平常時(22)に対し 1.182倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.781σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260827-host04-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260827-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 18→19→15→16→…→16→14→15→17
* 開始   : 2026-08-27 17:15:00 (UTC)
* 終了   : 2026-08-27 17:25:00 (UTC)
* 現象   : 平常時(18.17)に対し 0.8257(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260827-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260827-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260827-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260827-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260827-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→8→7→9→11→8→7→9→10
* 開始   : 2026-08-27 21:05:00 (UTC)
* 終了   : 2026-08-27 21:10:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260827-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→14→18→16→14→18→16→17
* 開始   : 2026-08-28 06:45:00 (UTC)
* 終了   : 2026-08-28 06:50:00 (UTC)
* 現象   : 平常時(14.33)に対し 1.256倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.549σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260828-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260828-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260828-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-025 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260828-lsfhost01-026 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260828-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 18→15→22→21→18→15→22→21→19
* 開始   : 2026-08-28 08:35:00 (UTC)
* 終了   : 2026-08-28 08:40:00 (UTC)
* 現象   : 平常時(18.58)に対し 0.8072(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.491σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host14-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-lsfhost01-034 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260828-host03-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260828-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260828-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 21→22→19→19→23→20→22
* 開始   : 2026-08-28 14:45:00 (UTC)
* 終了   : 2026-08-28 16:15:00 (UTC)
* 現象   : 2026-08-28 16:15:00 (UTC)を境に水準が 14.99から12.61へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.6, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 19→17→18→19→17→18
* 開始   : 2026-08-28 15:05:00 (UTC)
* 終了   : 2026-08-28 15:10:00 (UTC)
* 現象   : 平常時(20.42)に対し 0.8327(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260828-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→14→11→12→14→11→12→14
* 開始   : 2026-08-28 18:50:00 (UTC)
* 終了   : 2026-08-28 18:55:00 (UTC)
* 現象   : 平常時(14.42)に対し 0.763(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260828-host14-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host16-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260828-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260828-host01-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260828-host03-017 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260828-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host08-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→13→13
* 開始   : 2026-08-28 20:05:00 (UTC)
* 終了   : 2026-08-28 20:15:00 (UTC)
* 現象   : 2026-08-28 20:15:00 (UTC)を境に水準が 15.08から11.87へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.257, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host08-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 11→14→10→11→11→8→10→9→10
* 開始   : 2026-08-28 21:15:00 (UTC)
* 終了   : 2026-08-28 21:55:00 (UTC)
* 現象   : 2026-08-28 21:55:00 (UTC)を境に水準が 14.98から11.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.739, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260828-host08-015 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 8→8→9→7→9→10→7→10→11
* 開始   : 2026-08-28 23:35:00 (UTC)
* 終了   : 2026-08-29 00:15:00 (UTC)
* 現象   : 2026-08-29 00:15:00 (UTC)を境に水準が 14.85から11.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.207, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260828-host08-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260829-host08-001 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→10→9→10→…→10→11→13→11
* 開始   : 2026-08-29 04:40:00 (UTC)
* 終了   : 2026-08-29 05:00:00 (UTC)
* 現象   : 20分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.325, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260829-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260829-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host14-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260829-lsfhost01-014 (他ホスト) lsf_queue / njobs : FATAL / 重なり 20 分
  - EVT-20260829-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 20 分

![EVT-20260829-host08-001 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
