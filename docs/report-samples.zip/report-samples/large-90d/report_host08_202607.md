# host08 2026-07 の異常検知レポート

## 1. このホストの集計

| 項目 | 値 |
| --- | --- |
| ホスト | host08 |
| 対象年月 | 2026-07 |
| 検知イベント数 | 323 (SEVERE: 38, FATAL: 123, WARN: 162, INFO: 0) |

| メトリクス | SEVERE | FATAL | WARN | 計 | 検知手法 |
| --- | --- | --- | --- | --- | --- |
| active_connections | 38 | 123 | 162 | 323 | ALG-A1, ALG-A4, ALG-A5, ALG-B4 |

## 2. 実行サマリ

| 項目 | 値 |
| --- | --- |
| 実行日時 | 2026-09-06 23:37:14 (UTC) |
| 対象ディレクトリ | (ホームディレクトリ)\AppData\Local\Temp\tmp2e5yoki5\large\logs |
| 対象期間 | 2026-06-01 00:00:00 (UTC) 〜 2026-08-29 23:55:00 (UTC) |
| 読み込んだファイル数 | 360 |
| 総レコード数 | 2,851,200 |
| 系列数(全体) | 156 |
| サマリ | report_summary_202607.md |
| 実行環境の注記 | vendor を使わず環境の DuckDB を使用しています(バージョン 1.5.5)。配布時は vendor/ の同梱が必要です |

## 3. 適用したアルゴリズム

| ID | 名称 | 観点 | 状態 | 主なパラメータ |
| --- | --- | --- | --- | --- |
| ALG-A1 | 移動平均乖離率 | 瞬間的な外れ値 | 有効 | k_fatal=3.0, k_warn=2.0, window_minutes=60 |
| ALG-A2 | Hampel フィルタ | 瞬間的な外れ値 | 有効 | k=3.0, window_minutes=60 |
| ALG-A3 | Tukey の外れ値境界 | 瞬間的な外れ値 | 有効 | iqr_fatal=3.0, iqr_warn=1.5 |
| ALG-A4 | EWMA 管理図 | 瞬間的な外れ値 | 有効 | k=3.0, lambda=0.2 |
| ALG-A5 | 曜日・時刻別ベースライン | 瞬間的な外れ値 | 有効 | min_weeks=2, z=3.0 |
| ALG-B1 | 短期/長期移動平均のクロス継続 | 持続的な増加 | 有効 | long_minutes=1440, min_run=60, short_minutes=60 |
| ALG-B2 | Mann-Kendall 傾向検定 | 持続的な増加 | 有効 | bucket_minutes=60, max_buckets=2000, p_fatal=0.01, p_warn=0.05 |
| ALG-B3 | ローリング最小値の単調増加 | 持続的な増加 | 有効 | min_increases=10, window_minutes=360 |
| ALG-B4 | CUSUM | 持続的な増加 | 有効 | baseline_minutes=1440, h=5.0 |
| ALG-B5 | 線形回帰の傾き | 持続的な増加 | 有効 | min_r2=0.7 |
| ALG-C1 | 上限への張り付き | 上限への張り付き | 有効 | min_minutes=360.0, min_spread=1.5, ratio_pct=90.0 |

## 4. 検知イベント

# イベントID( EVT-20260703-host08-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 20→22→20→21→23→21→21→21→22
* 開始   : 2026-07-03 08:20:00 (UTC)
* 終了   : 2026-07-03 09:45:00 (UTC)
* 現象   : 2026-07-03 09:45:00 (UTC)を境に水準が 15から13.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.606, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host08-010 active_connections の推移](charts/EVT-20260703-host08-010.svg)

# イベントID( EVT-20260706-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→14→15→14→…→17→15→11→13
* 開始   : 2026-07-06 02:05:00 (UTC)
* 終了   : 2026-07-06 21:10:00 (UTC)
* 現象   : 2026-07-06 21:10:00 (UTC)を境に水準が 11.85から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.85, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.61, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host08-001 active_connections の推移](charts/EVT-20260706-host08-001.svg)

# イベントID( EVT-20260706-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→13→14→16→…→12→14→11→15
* 開始   : 2026-07-06 02:20:00 (UTC)
* 終了   : 2026-07-06 19:45:00 (UTC)
* 現象   : 2026-07-06 19:45:00 (UTC)を境に水準が 11.79から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.723, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.11, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host08-002 active_connections の推移](charts/EVT-20260706-host08-002.svg)

# イベントID( EVT-20260706-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→17→16→17→…→16→14→13→14
* 開始   : 2026-07-06 02:55:00 (UTC)
* 終了   : 2026-07-06 20:05:00 (UTC)
* 現象   : 2026-07-06 20:05:00 (UTC)を境に水準が 11.93から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.921, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.39, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host08-003 active_connections の推移](charts/EVT-20260706-host08-003.svg)

# イベントID( EVT-20260706-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→17→15→13→…→13→14→15→14
* 開始   : 2026-07-06 02:55:00 (UTC)
* 終了   : 2026-07-06 20:55:00 (UTC)
* 現象   : 2026-07-06 20:55:00 (UTC)を境に水準が 11.9から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.074σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.749, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.892, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host08-004 active_connections の推移](charts/EVT-20260706-host08-004.svg)

# イベントID( EVT-20260706-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→15→17→15→…→15→13→11→14
* 開始   : 2026-07-06 03:25:00 (UTC)
* 終了   : 2026-07-06 20:00:00 (UTC)
* 現象   : 2026-07-06 20:00:00 (UTC)を境に水準が 11.96から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.756, 限界=2.709)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.03, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host08-005 active_connections の推移](charts/EVT-20260706-host08-005.svg)

# イベントID( EVT-20260706-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→11→14→11→…→12→13→12→15
* 開始   : 2026-07-06 04:10:00 (UTC)
* 終了   : 2026-07-06 20:20:00 (UTC)
* 現象   : 2026-07-06 20:20:00 (UTC)を境に水準が 11.89から14.96へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.819, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.74, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host08-006 active_connections の推移](charts/EVT-20260706-host08-006.svg)

# イベントID( EVT-20260708-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 24→22→22→19→21→19→18→18→19
* 開始   : 2026-07-08 13:10:00 (UTC)
* 終了   : 2026-07-08 18:40:00 (UTC)
* 現象   : 2026-07-08 18:40:00 (UTC)を境に水準が 14.99から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.326, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host08-008 active_connections の推移](charts/EVT-20260708-host08-008.svg)

# イベントID( EVT-20260710-host08-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→12→10→9→9→8→10→12→10
* 開始   : 2026-07-10 20:50:00 (UTC)
* 終了   : 2026-07-10 21:35:00 (UTC)
* 現象   : 2026-07-10 21:35:00 (UTC)を境に水準が 14.92から11.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.114, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260710-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host08-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→17→16→16→18→16
* 開始   : 2026-07-12 09:25:00 (UTC)
* 終了   : 2026-07-12 09:50:00 (UTC)
* 現象   : 2026-07-12 09:50:00 (UTC)を境に水準が 11.77から12.84へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.869, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→13→12→13
* 開始   : 2026-07-12 18:05:00 (UTC)
* 終了   : 2026-07-12 18:20:00 (UTC)
* 現象   : 2026-07-12 18:20:00 (UTC)を境に水準が 11.72から14.74へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260712-host08-008 active_connections の推移](charts/EVT-20260712-host08-008.svg)

# イベントID( EVT-20260713-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 13→15→17→16→…→13→14→13→14
* 開始   : 2026-07-13 01:25:00 (UTC)
* 終了   : 2026-07-13 20:50:00 (UTC)
* 現象   : 2026-07-13 20:50:00 (UTC)を境に水準が 11.8から15.12へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.273σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.901, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host08-001 active_connections の推移](charts/EVT-20260713-host08-001.svg)

# イベントID( EVT-20260713-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→12→16→12→…→14→15→13→14
* 開始   : 2026-07-13 02:25:00 (UTC)
* 終了   : 2026-07-13 21:30:00 (UTC)
* 現象   : 2026-07-13 21:30:00 (UTC)を境に水準が 11.74から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.534σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.818, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.43, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host08-002 active_connections の推移](charts/EVT-20260713-host08-002.svg)

# イベントID( EVT-20260713-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→13→14→15→…→13→12→10→13
* 開始   : 2026-07-13 02:55:00 (UTC)
* 終了   : 2026-07-13 20:20:00 (UTC)
* 現象   : 2026-07-13 20:20:00 (UTC)を境に水準が 11.73から15.06へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.792σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.866, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.656, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host08-003 active_connections の推移](charts/EVT-20260713-host08-003.svg)

# イベントID( EVT-20260713-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→15→17→15→…→13→12→10→11
* 開始   : 2026-07-13 03:15:00 (UTC)
* 終了   : 2026-07-13 21:20:00 (UTC)
* 現象   : 2026-07-13 21:20:00 (UTC)を境に水準が 11.77から15.04へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.212, 限界=2.709)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.429, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host08-004 active_connections の推移](charts/EVT-20260713-host08-004.svg)

# イベントID( EVT-20260713-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→16→14→16→…→14→15→12→13
* 開始   : 2026-07-13 04:10:00 (UTC)
* 終了   : 2026-07-13 19:05:00 (UTC)
* 現象   : 2026-07-13 19:05:00 (UTC)を境に水準が 11.93から15へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.015σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.176, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.856, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host08-005 active_connections の推移](charts/EVT-20260713-host08-005.svg)

# イベントID( EVT-20260713-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→12→19→16→…→12→15→14→13
* 開始   : 2026-07-13 04:10:00 (UTC)
* 終了   : 2026-07-13 20:50:00 (UTC)
* 現象   : 2026-07-13 20:50:00 (UTC)を境に水準が 11.87から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.599σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.906, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.207, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host08-006 active_connections の推移](charts/EVT-20260713-host08-006.svg)

# イベントID( EVT-20260715-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→11→14→12→15→16→14→16→17
* 開始   : 2026-07-15 04:45:00 (UTC)
* 終了   : 2026-07-15 06:10:00 (UTC)
* 現象   : 2026-07-15 06:10:00 (UTC)を境に水準が 14.93から14.99へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.896σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.606, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host08-004 active_connections の推移](charts/EVT-20260715-host08-004.svg)

# イベントID( EVT-20260717-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→15→13→14
* 開始   : 2026-07-17 04:25:00 (UTC)
* 終了   : 2026-07-17 04:40:00 (UTC)
* 現象   : 2026-07-17 04:40:00 (UTC)を境に水準が 15.05から14.82へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.781σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.25, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host08-002 active_connections の推移](charts/EVT-20260717-host08-002.svg)

# イベントID( EVT-20260718-host08-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 10→9→6→9→8→9→8→7→10
* 開始   : 2026-07-18 23:10:00 (UTC)
* 終了   : 2026-07-19 00:20:00 (UTC)
* 現象   : 2026-07-19 00:20:00 (UTC)を境に水準が 11.71から11.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.671, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260718-host08-009 active_connections の推移](charts/EVT-20260718-host08-009.svg)

# イベントID( EVT-20260719-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→11→10→11→11→13→12→11
* 開始   : 2026-07-19 03:30:00 (UTC)
* 終了   : 2026-07-19 04:05:00 (UTC)
* 現象   : 2026-07-19 04:05:00 (UTC)を境に水準が 11.82から12.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.491, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host08-001 active_connections の推移](charts/EVT-20260719-host08-001.svg)

# イベントID( EVT-20260720-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→17→16→15→…→11→15→13→11
* 開始   : 2026-07-20 02:20:00 (UTC)
* 終了   : 2026-07-20 20:10:00 (UTC)
* 現象   : 2026-07-20 20:10:00 (UTC)を境に水準が 11.99から15.02へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.706, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.74, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host08-002 active_connections の推移](charts/EVT-20260720-host08-002.svg)

# イベントID( EVT-20260720-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 13→14→15→14→…→14→15→13→12
* 開始   : 2026-07-20 02:25:00 (UTC)
* 終了   : 2026-07-20 21:45:00 (UTC)
* 現象   : 2026-07-20 21:45:00 (UTC)を境に水準が 11.63から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.701, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.22, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host08-003 active_connections の推移](charts/EVT-20260720-host08-003.svg)

# イベントID( EVT-20260720-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→16→17→18→…→16→12→13→12
* 開始   : 2026-07-20 02:25:00 (UTC)
* 終了   : 2026-07-20 20:30:00 (UTC)
* 現象   : 2026-07-20 20:30:00 (UTC)を境に水準が 11.98から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.872, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.851, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host08-004 active_connections の推移](charts/EVT-20260720-host08-004.svg)

# イベントID( EVT-20260720-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→17→18→17→…→12→15→13→12
* 開始   : 2026-07-20 03:15:00 (UTC)
* 終了   : 2026-07-20 20:35:00 (UTC)
* 現象   : 2026-07-20 20:35:00 (UTC)を境に水準が 11.77から14.92へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.832, 限界=2.709)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.686, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host08-005 active_connections の推移](charts/EVT-20260720-host08-005.svg)

# イベントID( EVT-20260720-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→15→13→15→…→12→14→12→14
* 開始   : 2026-07-20 03:40:00 (UTC)
* 終了   : 2026-07-20 21:15:00 (UTC)
* 現象   : 2026-07-20 21:15:00 (UTC)を境に水準が 11.88から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.935, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.536, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host08-007 active_connections の推移](charts/EVT-20260720-host08-007.svg)

# イベントID( EVT-20260721-host08-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 24→22→22→23→24
* 開始   : 2026-07-21 12:10:00 (UTC)
* 終了   : 2026-07-21 12:30:00 (UTC)
* 現象   : 2026-07-21 12:30:00 (UTC)を境に水準が 15.05から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.557, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host08-005 active_connections の推移](charts/EVT-20260721-host08-005.svg)

# イベントID( EVT-20260721-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→9→9→8→9→10
* 開始   : 2026-07-21 23:15:00 (UTC)
* 終了   : 2026-07-21 23:50:00 (UTC)
* 現象   : 2026-07-21 23:50:00 (UTC)を境に水準が 15.07から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.244σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.869, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host08-013 active_connections の推移](charts/EVT-20260721-host08-013.svg)

# イベントID( EVT-20260723-host08-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→14→13→12→12→11→11→12→12
* 開始   : 2026-07-23 19:40:00 (UTC)
* 終了   : 2026-07-23 20:25:00 (UTC)
* 現象   : 2026-07-23 20:25:00 (UTC)を境に水準が 15.08から15.07へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.114, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host08-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 8→12→9→10→9→10
* 開始   : 2026-07-24 23:00:00 (UTC)
* 終了   : 2026-07-24 23:25:00 (UTC)
* 現象   : 2026-07-24 23:25:00 (UTC)を境に水準が 15.09から11.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.869, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host08-012 active_connections の推移](charts/EVT-20260724-host08-012.svg)

# イベントID( EVT-20260726-host08-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→16→16→16→14→17
* 開始   : 2026-07-26 08:55:00 (UTC)
* 終了   : 2026-07-26 09:20:00 (UTC)
* 現象   : 2026-07-26 09:20:00 (UTC)を境に水準が 11.84から12.72へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.869, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→14→15→13→…→15→16→9→12
* 開始   : 2026-07-27 02:20:00 (UTC)
* 終了   : 2026-07-27 21:05:00 (UTC)
* 現象   : 2026-07-27 21:05:00 (UTC)を境に水準が 11.86から14.97へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.676, 限界=2.695)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.172, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host08-004 active_connections の推移](charts/EVT-20260727-host08-004.svg)

# イベントID( EVT-20260727-host08-005 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→14→16→15→…→14→12→13→12
* 開始   : 2026-07-27 02:35:00 (UTC)
* 終了   : 2026-07-27 21:15:00 (UTC)
* 現象   : 2026-07-27 21:15:00 (UTC)を境に水準が 11.75から15.01へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.847, 限界=2.713)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.557, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host08-005 active_connections の推移](charts/EVT-20260727-host08-005.svg)

# イベントID( EVT-20260727-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→15→16→17→…→14→15→14→15
* 開始   : 2026-07-27 02:55:00 (UTC)
* 終了   : 2026-07-27 19:50:00 (UTC)
* 現象   : 2026-07-27 19:50:00 (UTC)を境に水準が 11.88から14.98へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.41σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.018, 限界=2.709)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.601, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host08-006 active_connections の推移](charts/EVT-20260727-host08-006.svg)

# イベントID( EVT-20260727-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 16→15→17→15→…→14→16→14→15
* 開始   : 2026-07-27 03:00:00 (UTC)
* 終了   : 2026-07-27 19:30:00 (UTC)
* 現象   : 2026-07-27 19:30:00 (UTC)を境に水準が 11.84から15.09へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.309σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.149, 限界=2.705)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.804, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host08-007 active_connections の推移](charts/EVT-20260727-host08-007.svg)

# イベントID( EVT-20260727-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 15→16→15→14→…→13→12→10→13
* 開始   : 2026-07-27 04:25:00 (UTC)
* 終了   : 2026-07-27 20:15:00 (UTC)
* 現象   : 2026-07-27 20:15:00 (UTC)を境に水準が 12.03から15.01へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.653σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=3.111, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.874, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host08-008 active_connections の推移](charts/EVT-20260727-host08-008.svg)

# イベントID( EVT-20260729-host08-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 20→21→19→19→20→21→20→20→24
* 開始   : 2026-07-29 08:00:00 (UTC)
* 終了   : 2026-07-29 09:30:00 (UTC)
* 現象   : 2026-07-29 09:30:00 (UTC)を境に水準が 14.99から15.16へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.917, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : SEVERE
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 23→22→21→23→23→23→22→22→24
* 開始   : 2026-07-31 11:35:00 (UTC)
* 終了   : 2026-07-31 12:30:00 (UTC)
* 現象   : 2026-07-31 12:30:00 (UTC)を境に水準が 15.06から13.32へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.737, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host08-010 active_connections の推移](charts/EVT-20260731-host08-010.svg)

# イベントID( EVT-20260701-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 17→16→21→18→19
* 開始   : 2026-07-01 07:35:00 (UTC)
* 終了   : 2026-07-01 07:35:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-028 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 20→19→23→20→18
* 開始   : 2026-07-01 08:25:00 (UTC)
* 終了   : 2026-07-01 08:25:00 (UTC)
* 現象   : 平常時(18.25)に対し 1.26倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.325σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-033 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 18→19→15→13→…→16→14→17→16
* 開始   : 2026-07-01 17:10:00 (UTC)
* 終了   : 2026-07-01 17:50:00 (UTC)
* 現象   : 40分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host07-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host07-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host16-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-lsfhost01-055 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260701-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 21→22→26→22→22
* 開始   : 2026-07-02 10:35:00 (UTC)
* 終了   : 2026-07-02 10:35:00 (UTC)
* 現象   : 平常時(21)に対し 1.238倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.479σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host12-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-034 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260702-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 10→10→4→8→9
* 開始   : 2026-07-02 22:35:00 (UTC)
* 終了   : 2026-07-02 22:35:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.4486(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.418σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→13→16→14→12
* 開始   : 2026-07-03 04:25:00 (UTC)
* 終了   : 2026-07-03 04:25:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.381倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host07-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260703-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→14→17→11→13
* 開始   : 2026-07-03 04:30:00 (UTC)
* 終了   : 2026-07-03 04:30:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.457倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.711σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-020 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260703-host08-002 active_connections の推移](charts/EVT-20260703-host08-002.svg)

# イベントID( EVT-20260703-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→12→17→13→15
* 開始   : 2026-07-03 05:20:00 (UTC)
* 終了   : 2026-07-03 05:20:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.367σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 16→13→19→15→15
* 開始   : 2026-07-03 06:10:00 (UTC)
* 終了   : 2026-07-03 06:10:00 (UTC)
* 現象   : 平常時(13.83)に対し 1.373倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.595σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host08-005 active_connections の推移](charts/EVT-20260703-host08-005.svg)

# イベントID( EVT-20260703-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→14→19→16→15
* 開始   : 2026-07-03 06:20:00 (UTC)
* 終了   : 2026-07-03 06:20:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 17→17→21→17→18
* 開始   : 2026-07-03 07:40:00 (UTC)
* 終了   : 2026-07-03 07:40:00 (UTC)
* 現象   : 平常時(16.33)に対し 1.286倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.248σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 24→21→26→21→20
* 開始   : 2026-07-03 12:45:00 (UTC)
* 終了   : 2026-07-03 12:45:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.2倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 18→15→18→15→18→16
* 開始   : 2026-07-03 16:50:00 (UTC)
* 終了   : 2026-07-03 17:35:00 (UTC)
* 現象   : 平常時(18.75)に対し 0.8(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.601σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host08-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260703-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 40 分
  - EVT-20260703-host03-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260703-host09-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-lsfhost01-059 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260703-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分
  - EVT-20260703-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host06-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260703-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→16→11→14→16
* 開始   : 2026-07-03 18:00:00 (UTC)
* 終了   : 2026-07-03 18:00:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.6633(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.909σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-064 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260703-host09-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host10-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host08-016 active_connections の推移](charts/EVT-20260703-host08-016.svg)

# イベントID( EVT-20260704-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 7→6→12→9→7
* 開始   : 2026-07-04 01:30:00 (UTC)
* 終了   : 2026-07-04 01:30:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.582倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260704-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→11→12→11→…→12→10→13→12
* 開始   : 2026-07-04 04:15:00 (UTC)
* 終了   : 2026-07-04 20:00:00 (UTC)
* 現象   : 15.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.732, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host08-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host08-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host08-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 30 分
  - EVT-20260704-host08-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.3 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260704-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間

![EVT-20260704-host08-004 active_connections の推移](charts/EVT-20260704-host08-004.svg)

# イベントID( EVT-20260704-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→11→12→11→…→10→9→11→12
* 開始   : 2026-07-04 05:35:00 (UTC)
* 終了   : 2026-07-04 19:40:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.942, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host08-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host08-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260704-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 16→12→10→11→…→12→9→12→9
* 開始   : 2026-07-04 05:35:00 (UTC)
* 終了   : 2026-07-04 18:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.309σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.109, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host08-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host08-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260704-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260704-host08-007 active_connections の推移](charts/EVT-20260704-host08-007.svg)

# イベントID( EVT-20260704-host08-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→11→12→11→…→15→12→13→12
* 開始   : 2026-07-04 05:45:00 (UTC)
* 終了   : 2026-07-04 18:40:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.137, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host08-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host08-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host01-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260704-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260704-host08-008 active_connections の推移](charts/EVT-20260704-host08-008.svg)

# イベントID( EVT-20260704-host08-009 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→12→11→12→…→12→14→10→12
* 開始   : 2026-07-04 06:10:00 (UTC)
* 終了   : 2026-07-04 20:15:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.956, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260704-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260704-host08-010 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260704-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260704-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260704-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260704-host08-009 active_connections の推移](charts/EVT-20260704-host08-009.svg)

# イベントID( EVT-20260704-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→11→10→14→…→11→14→11→10
* 開始   : 2026-07-04 06:40:00 (UTC)
* 終了   : 2026-07-04 19:40:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.09σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.91, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host08-009 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260704-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host04-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260704-host05-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260704-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 10→12→6→8→10
* 開始   : 2026-07-04 20:20:00 (UTC)
* 終了   : 2026-07-04 20:20:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host09-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260704-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→9→5→9→10
* 開始   : 2026-07-04 22:05:00 (UTC)
* 終了   : 2026-07-04 22:05:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260704-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→11→15→12→12
* 開始   : 2026-07-07 04:05:00 (UTC)
* 終了   : 2026-07-07 04:05:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.417倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.074σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-012 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260707-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 20→21→16→22→21
* 開始   : 2026-07-07 14:25:00 (UTC)
* 終了   : 2026-07-07 14:25:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.7529(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.676σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260707-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→11→6→11→8
* 開始   : 2026-07-07 21:25:00 (UTC)
* 終了   : 2026-07-07 21:25:00 (UTC)
* 現象   : 平常時(10.42)に対し 0.576(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host06-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-066 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 8→9→5→9→9
* 開始   : 2026-07-07 22:30:00 (UTC)
* 終了   : 2026-07-07 22:30:00 (UTC)
* 現象   : 平常時(9.583)に対し 0.5217(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.189σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-069 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260707-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 7→6→4→7→8
* 開始   : 2026-07-08 00:25:00 (UTC)
* 終了   : 2026-07-08 00:25:00 (UTC)
* 現象   : 平常時(8.333)に対し 0.48(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.034σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260708-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→13→10→15→16→10→15→16→15
* 開始   : 2026-07-08 05:20:00 (UTC)
* 終了   : 2026-07-08 06:30:00 (UTC)
* 現象   : 平常時(13.08)に対し 0.7643倍(10)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.139σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host08-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-024 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-028 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-029 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260708-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 21→22→26→22→20
* 開始   : 2026-07-08 13:20:00 (UTC)
* 終了   : 2026-07-08 13:20:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 22→21→17→21→23
* 開始   : 2026-07-09 13:40:00 (UTC)
* 終了   : 2026-07-09 13:40:00 (UTC)
* 現象   : 平常時(21.42)に対し 0.7938(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 18→17→14→19→16
* 開始   : 2026-07-09 16:35:00 (UTC)
* 終了   : 2026-07-09 16:35:00 (UTC)
* 現象   : 平常時(18.83)に対し 0.7434(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.352σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260709-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→11→6→8→8
* 開始   : 2026-07-09 21:05:00 (UTC)
* 終了   : 2026-07-09 21:05:00 (UTC)
* 現象   : 平常時(10.75)に対し 0.5581(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260709-lsfhost01-078 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260709-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 18→17→13→17→17
* 開始   : 2026-07-10 17:05:00 (UTC)
* 終了   : 2026-07-10 17:05:00 (UTC)
* 現象   : 平常時(17.67)に対し 0.7358(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host08-006 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260710-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host08-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→13→12→9→…→14→15→13→15
* 開始   : 2026-07-11 04:55:00 (UTC)
* 終了   : 2026-07-11 19:00:00 (UTC)
* 現象   : 14.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.8, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260711-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host10-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間
  - EVT-20260711-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.1 時間

![EVT-20260711-host08-003 active_connections の推移](charts/EVT-20260711-host08-003.svg)

# イベントID( EVT-20260711-host08-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→12→10→11→…→12→13→11→12
* 開始   : 2026-07-11 05:30:00 (UTC)
* 終了   : 2026-07-11 19:15:00 (UTC)
* 現象   : 13.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.065, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.5 時間
  - EVT-20260711-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.8 時間
  - EVT-20260711-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間
  - EVT-20260711-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.8 時間

![EVT-20260711-host08-004 active_connections の推移](charts/EVT-20260711-host08-004.svg)

# イベントID( EVT-20260711-host08-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→12→13→12→…→12→10→11→10
* 開始   : 2026-07-11 05:30:00 (UTC)
* 終了   : 2026-07-11 18:45:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.17, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260711-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260711-host08-005 active_connections の推移](charts/EVT-20260711-host08-005.svg)

# イベントID( EVT-20260711-host08-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→10→9→11→…→13→14→11→13
* 開始   : 2026-07-11 05:40:00 (UTC)
* 終了   : 2026-07-11 18:45:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.975, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260711-host08-006 active_connections の推移](charts/EVT-20260711-host08-006.svg)

# イベントID( EVT-20260711-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→11→13→11→…→12→15→12→10
* 開始   : 2026-07-11 05:40:00 (UTC)
* 終了   : 2026-07-11 18:35:00 (UTC)
* 現象   : 12.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.533σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.845, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.9 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間
  - EVT-20260711-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.9 時間

![EVT-20260711-host08-007 active_connections の推移](charts/EVT-20260711-host08-007.svg)

# イベントID( EVT-20260711-host08-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→10→9→14→…→12→11→12→11
* 開始   : 2026-07-11 05:55:00 (UTC)
* 終了   : 2026-07-11 19:00:00 (UTC)
* 現象   : 13.1時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.937, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260711-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260711-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host01-003 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.1 時間
  - EVT-20260711-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間
  - EVT-20260711-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.1 時間

![EVT-20260711-host08-008 active_connections の推移](charts/EVT-20260711-host08-008.svg)

# イベントID( EVT-20260712-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→12→7→12→14
* 開始   : 2026-07-12 06:10:00 (UTC)
* 終了   : 2026-07-12 06:10:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.5957(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 12→10→9→13→…→13→18→13→12
* 開始   : 2026-07-12 07:20:00 (UTC)
* 終了   : 2026-07-12 07:30:00 (UTC)
* 現象   : 日曜7時台の平常値(13.41)に対し 9であった
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.244σ 外れた (平常値=13.41)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260712-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host08-003 active_connections の推移](charts/EVT-20260712-host08-003.svg)

# イベントID( EVT-20260712-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→13→8→14→13
* 開始   : 2026-07-12 17:50:00 (UTC)
* 終了   : 2026-07-12 17:50:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.64(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260712-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 8→13→12→9→8→13→12→9→12
* 開始   : 2026-07-14 02:20:00 (UTC)
* 終了   : 2026-07-14 02:25:00 (UTC)
* 現象   : 平常時(8.25)に対し 1.576倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260714-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→10→16→12→12
* 開始   : 2026-07-14 05:05:00 (UTC)
* 終了   : 2026-07-14 05:05:00 (UTC)
* 現象   : 平常時(11.25)に対し 1.422倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.302σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host10-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260714-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 18→19→20→18→20→18→20→18→17
* 開始   : 2026-07-14 06:30:00 (UTC)
* 終了   : 2026-07-14 07:40:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.318倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 55 分
  - EVT-20260714-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-020 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-022 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260714-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 25 分
  - EVT-20260714-host04-006 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260714-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 22→22→18→23→22
* 開始   : 2026-07-14 12:35:00 (UTC)
* 終了   : 2026-07-14 12:35:00 (UTC)
* 現象   : 平常時(22.67)に対し 0.7941(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.251σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-lsfhost01-037 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260714-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 10→12→18→13→14
* 開始   : 2026-07-15 05:30:00 (UTC)
* 終了   : 2026-07-15 05:30:00 (UTC)
* 現象   : 平常時(12.33)に対し 1.459倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.947σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host08-007 active_connections の推移](charts/EVT-20260715-host08-007.svg)

# イベントID( EVT-20260715-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 17→19→21→18→19
* 開始   : 2026-07-15 07:50:00 (UTC)
* 終了   : 2026-07-15 07:50:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-lsfhost01-031 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260715-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260715-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 19→19→23→18→19
* 開始   : 2026-07-15 08:40:00 (UTC)
* 終了   : 2026-07-15 08:40:00 (UTC)
* 現象   : 平常時(18.58)に対し 1.238倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.074σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 23→20→26→20→22
* 開始   : 2026-07-15 12:30:00 (UTC)
* 終了   : 2026-07-15 12:30:00 (UTC)
* 現象   : 平常時(21.42)に対し 1.214倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.19σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→11→9→13→…→9→8→12→9
* 開始   : 2026-07-15 19:35:00 (UTC)
* 終了   : 2026-07-15 20:45:00 (UTC)
* 現象   : 1.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.237σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-host16-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-065 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-069 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260715-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 50 分
  - EVT-20260715-lsfhost01-066 (他ホスト) lsf_queue / njobs : WARN / 重なり 30 分
  - EVT-20260715-host06-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260715-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→13→14→15→…→14→15→12→13
* 開始   : 2026-07-16 03:40:00 (UTC)
* 終了   : 2026-07-16 04:10:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260716-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-015 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 20 分
  - EVT-20260716-host09-001 (他ホスト) db_connection / active_connections : WARN / 重なり 15 分
  - EVT-20260716-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host11-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 15→16→19→15→17
* 開始   : 2026-07-16 06:05:00 (UTC)
* 終了   : 2026-07-16 06:05:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.333倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.306σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-025 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260716-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 18→15→12→17→16
* 開始   : 2026-07-16 17:35:00 (UTC)
* 終了   : 2026-07-16 17:35:00 (UTC)
* 現象   : 平常時(16.92)に対し 0.7094(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.442σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-lsfhost01-064 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260716-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 19→19→16→19→19
* 開始   : 2026-07-17 15:35:00 (UTC)
* 終了   : 2026-07-17 15:35:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-lsfhost01-067 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分

![EVT-20260717-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 19→17→13→15→17
* 開始   : 2026-07-17 17:05:00 (UTC)
* 終了   : 2026-07-17 17:05:00 (UTC)
* 現象   : 平常時(17.83)に対し 0.729(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.36σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-071 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260717-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→13→7→11→13
* 開始   : 2026-07-17 19:55:00 (UTC)
* 終了   : 2026-07-17 19:55:00 (UTC)
* 現象   : 平常時(12.92)に対し 0.5419(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 4.104σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host13-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host08-012 active_connections の推移](charts/EVT-20260717-host08-012.svg)

# イベントID( EVT-20260718-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→10→9→12→…→11→13→11→12
* 開始   : 2026-07-18 04:30:00 (UTC)
* 終了   : 2026-07-18 19:05:00 (UTC)
* 現象   : 14.6時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.607σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.869, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260718-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host08-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.6 時間

![EVT-20260718-host08-001 active_connections の推移](charts/EVT-20260718-host08-001.svg)

# イベントID( EVT-20260718-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→10→11→13→…→9→11→12→10
* 開始   : 2026-07-18 04:45:00 (UTC)
* 終了   : 2026-07-18 19:45:00 (UTC)
* 現象   : 15.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.287, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260718-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host08-004 (同一ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15.0 時間
  - EVT-20260718-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.8 時間

![EVT-20260718-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→11→16→11→11
* 開始   : 2026-07-18 04:45:00 (UTC)
* 終了   : 2026-07-18 04:45:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.5倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.711σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260718-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260718-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260718-host08-003 active_connections の推移](charts/EVT-20260718-host08-003.svg)

# イベントID( EVT-20260718-host08-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→10→11→10→…→12→11→13→11
* 開始   : 2026-07-18 05:35:00 (UTC)
* 終了   : 2026-07-18 18:15:00 (UTC)
* 現象   : 12.7時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.894, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260718-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.7 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間

![EVT-20260718-host08-005 active_connections の推移](charts/EVT-20260718-host08-005.svg)

# イベントID( EVT-20260718-host08-006 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→11→10→11→…→9→11→10→11
* 開始   : 2026-07-18 05:50:00 (UTC)
* 終了   : 2026-07-18 19:05:00 (UTC)
* 現象   : 13.2時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.928, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.4 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260718-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間

![EVT-20260718-host08-006 active_connections の推移](charts/EVT-20260718-host08-006.svg)

# イベントID( EVT-20260718-host08-007 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→14→12→13→…→11→13→14→10
* 開始   : 2026-07-18 06:05:00 (UTC)
* 終了   : 2026-07-18 18:55:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.923, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host08-008 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260718-host08-007 active_connections の推移](charts/EVT-20260718-host08-007.svg)

# イベントID( EVT-20260718-host08-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→12→11→13→…→12→11→14→12
* 開始   : 2026-07-18 06:05:00 (UTC)
* 終了   : 2026-07-18 18:50:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.808, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260718-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-005 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260718-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260718-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260718-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→12→17→15→13
* 開始   : 2026-07-19 07:30:00 (UTC)
* 終了   : 2026-07-19 07:30:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.369倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 9→9→4→8→7
* 開始   : 2026-07-19 23:10:00 (UTC)
* 終了   : 2026-07-19 23:10:00 (UTC)
* 現象   : 平常時(8.417)に対し 0.4752(4)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.089σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260719-host12-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260719-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host08-006 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 15→17→16→15→…→15→13→11→15
* 開始   : 2026-07-20 03:40:00 (UTC)
* 終了   : 2026-07-20 19:50:00 (UTC)
* 現象   : 2026-07-20 19:50:00 (UTC)を境に水準が 11.89から15.13へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.736, 限界=2.692)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.838, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260720-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→9→5→9→7
* 開始   : 2026-07-20 22:15:00 (UTC)
* 終了   : 2026-07-20 22:15:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.5357(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260720-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→12→16→15→18→16→15→18→15
* 開始   : 2026-07-21 05:30:00 (UTC)
* 終了   : 2026-07-21 05:40:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host13-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260721-host06-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260721-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260721-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 18→16→21→18→16
* 開始   : 2026-07-21 07:35:00 (UTC)
* 終了   : 2026-07-21 07:35:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.266倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-027 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260721-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 16→16→12→16→17
* 開始   : 2026-07-21 17:30:00 (UTC)
* 終了   : 2026-07-21 17:30:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.699(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.617σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host12-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host02-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host08-008 active_connections の推移](charts/EVT-20260721-host08-008.svg)

# イベントID( EVT-20260721-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→16→11→15→15
* 開始   : 2026-07-21 18:25:00 (UTC)
* 終了   : 2026-07-21 18:25:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7097(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host03-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→10→7→11→10
* 開始   : 2026-07-21 20:20:00 (UTC)
* 終了   : 2026-07-21 20:20:00 (UTC)
* 現象   : 平常時(11.92)に対し 0.5874(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.439σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host09-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-lsfhost01-068 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260721-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→13→9→7→11→13→9→7→11
* 開始   : 2026-07-21 20:35:00 (UTC)
* 終了   : 2026-07-21 20:40:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-070 (他ホスト) lsf_queue / pend : FATAL / 重なり 5 分
  - EVT-20260721-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host09-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host11-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host16-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→9→5→7→9
* 開始   : 2026-07-21 22:55:00 (UTC)
* 終了   : 2026-07-21 22:55:00 (UTC)
* 現象   : 平常時(9.417)に対し 0.531(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.073σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host01-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260721-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→12→16→12→14
* 開始   : 2026-07-22 04:50:00 (UTC)
* 終了   : 2026-07-22 05:05:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260722-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 18→17→21→18→18
* 開始   : 2026-07-22 07:35:00 (UTC)
* 終了   : 2026-07-22 07:35:00 (UTC)
* 現象   : 平常時(16.5)に対し 1.273倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260722-host03-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host05-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host11-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 17→18→22→19→19
* 開始   : 2026-07-22 08:00:00 (UTC)
* 終了   : 2026-07-22 08:00:00 (UTC)
* 現象   : 平常時(17.67)に対し 1.245倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.016σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260722-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 19→18→24→20→20
* 開始   : 2026-07-22 09:00:00 (UTC)
* 終了   : 2026-07-22 09:00:00 (UTC)
* 現象   : 平常時(18.83)に対し 1.274倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.614σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host06-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host08-006 active_connections の推移](charts/EVT-20260722-host08-006.svg)

# イベントID( EVT-20260722-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 19→23→26→22→22
* 開始   : 2026-07-22 12:55:00 (UTC)
* 終了   : 2026-07-22 12:55:00 (UTC)
* 現象   : 平常時(21.58)に対し 1.205倍(26)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-040 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-042 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 17→15→12→16→16
* 開始   : 2026-07-22 17:45:00 (UTC)
* 終了   : 2026-07-22 17:45:00 (UTC)
* 現象   : 平常時(16.58)に対し 0.7236(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host07-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host13-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host16-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260722-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 8→7→13→6→9
* 開始   : 2026-07-22 23:50:00 (UTC)
* 終了   : 2026-07-22 23:50:00 (UTC)
* 現象   : 平常時(8)に対し 1.625倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.479σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host07-019 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A5 曜日・時刻別ベースライン
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→11→15→8→11→15→8→11→12
* 開始   : 2026-07-23 03:55:00 (UTC)
* 終了   : 2026-07-23 04:00:00 (UTC)
* 現象   : 木曜3時台の平常値(10.65)に対し 15であった
* 説明   : ALG-A1: 移動平均からの残差が 3.36σ に達した (閾値 2σ/3σ)
             ALG-A5: 同じ曜日・時刻帯の平常値から 3.391σ 外れた (平常値=10.65)
* 原因候補 : 定期的な処理による周期的な負荷 (確度: 低) — 同じ曜日・時刻帯の平常値から外れているため
* 同時に発生したアノマリー :
  - EVT-20260723-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260723-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-014 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 15→14→18→16→…→16→19→18→16
* 開始   : 2026-07-23 06:30:00 (UTC)
* 終了   : 2026-07-23 07:00:00 (UTC)
* 現象   : 平常時(14.5)に対し 1.241倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260723-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260723-host01-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260723-host01-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 9→6→12→9→6→12→9→10
* 開始   : 2026-07-23 22:35:00 (UTC)
* 終了   : 2026-07-23 23:10:00 (UTC)
* 現象   : 平常時(8.917)に対し 0.6729(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host01-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-083 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260723-host14-018 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-host16-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-lsfhost01-084 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260723-lsfhost01-082 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-085 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260723-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→12→16→12→13
* 開始   : 2026-07-24 04:35:00 (UTC)
* 終了   : 2026-07-24 04:35:00 (UTC)
* 現象   : 平常時(11.42)に対し 1.401倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.209σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host15-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→12→17→13→14
* 開始   : 2026-07-24 04:55:00 (UTC)
* 終了   : 2026-07-24 04:55:00 (UTC)
* 現象   : 平常時(12.17)に対し 1.397倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.381σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host14-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host15-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 21→18→24→19→20
* 開始   : 2026-07-24 09:25:00 (UTC)
* 終了   : 2026-07-24 09:25:00 (UTC)
* 現象   : 平常時(19.5)に対し 1.231倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-lsfhost01-031 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分

![EVT-20260724-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 21→22→25→21→22
* 開始   : 2026-07-24 10:35:00 (UTC)
* 終了   : 2026-07-24 10:35:00 (UTC)
* 現象   : 平常時(20.5)に対し 1.22倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→13→11→14→16→13→11→14
* 開始   : 2026-07-24 18:15:00 (UTC)
* 終了   : 2026-07-24 18:20:00 (UTC)
* 現象   : 平常時(16.08)に対し 0.8083(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host12-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260724-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→12→11→14→9→11→14→9→11
* 開始   : 2026-07-24 19:15:00 (UTC)
* 終了   : 2026-07-24 19:25:00 (UTC)
* 現象   : 平常時(13.92)に対し 0.7904(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-lsfhost01-064 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260724-host16-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260724-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→12→9→10→…→14→10→14→10
* 開始   : 2026-07-25 04:55:00 (UTC)
* 終了   : 2026-07-25 18:50:00 (UTC)
* 現象   : 13.9時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.958, 限界=2.695)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260725-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260725-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.9 時間
  - EVT-20260725-lsfhost01-009 (他ホスト) lsf_queue / run : FATAL / 重なり 13.9 時間
  - EVT-20260725-lsfhost01-010 (他ホスト) lsf_queue / njobs : FATAL / 重なり 13.9 時間

![EVT-20260725-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host08-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→13→11→14→…→12→15→13→12
* 開始   : 2026-07-25 05:10:00 (UTC)
* 終了   : 2026-07-25 18:10:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.961, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host04-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260725-host08-003 active_connections の推移](charts/EVT-20260725-host08-003.svg)

# イベントID( EVT-20260725-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→10→11→13→…→12→10→13→12
* 開始   : 2026-07-25 05:25:00 (UTC)
* 終了   : 2026-07-25 18:25:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.309σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.977, 限界=2.705)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260725-host01-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260725-host08-004 active_connections の推移](charts/EVT-20260725-host08-004.svg)

# イベントID( EVT-20260725-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→10→9→12→…→12→10→13→9
* 開始   : 2026-07-25 05:35:00 (UTC)
* 終了   : 2026-07-25 19:55:00 (UTC)
* 現象   : 14.3時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 3.468σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.903, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.2 時間
  - EVT-20260725-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.6 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 14.3 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 14.3 時間

![EVT-20260725-host08-005 active_connections の推移](charts/EVT-20260725-host08-005.svg)

# イベントID( EVT-20260725-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→13→11→13→…→12→11→12→11
* 開始   : 2026-07-25 06:10:00 (UTC)
* 終了   : 2026-07-25 19:10:00 (UTC)
* 現象   : 13.0時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.769, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.7 時間
  - EVT-20260725-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.2 時間
  - EVT-20260725-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.0 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 13.0 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 13.0 時間

![EVT-20260725-host08-006 active_connections の推移](charts/EVT-20260725-host08-006.svg)

# イベントID( EVT-20260725-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-A4 EWMA 管理図
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→12→11→14→…→13→12→14→15
* 開始   : 2026-07-25 06:20:00 (UTC)
* 終了   : 2026-07-25 19:05:00 (UTC)
* 現象   : 12.8時間にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.552σ に達した (閾値 2σ/3σ)
             ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-3.035, 限界=2.692)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host08-005 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host08-006 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.5 時間
  - EVT-20260725-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 12.1 時間
  - EVT-20260725-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 11.8 時間
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 12.8 時間
  - EVT-20260725-host02-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間
  - EVT-20260725-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 12.8 時間

![EVT-20260725-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→16→20→16→14
* 開始   : 2026-07-26 13:50:00 (UTC)
* 終了   : 2026-07-26 13:50:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.29倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.128σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260726-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host08-003 )

* イベント種別 : ALG-A4 EWMA 管理図, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→16→17→16→…→14→15→12→13
* 開始   : 2026-07-27 02:05:00 (UTC)
* 終了   : 2026-07-27 19:45:00 (UTC)
* 現象   : 2026-07-27 19:45:00 (UTC)を境に水準が 11.84から15.04へ移行し、元に戻らない
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=2.785, 限界=2.693)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.903, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→11→14→13→…→14→13→8→10
* 開始   : 2026-07-28 03:00:00 (UTC)
* 終了   : 2026-07-28 03:05:00 (UTC)
* 現象   : 平常時(9.417)に対し 1.487倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.186σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host03-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→13→19→15→17
* 開始   : 2026-07-28 06:30:00 (UTC)
* 終了   : 2026-07-28 06:30:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.063σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 15→16→18→19→…→18→19→18→17
* 開始   : 2026-07-28 06:30:00 (UTC)
* 終了   : 2026-07-28 06:35:00 (UTC)
* 現象   : 平常時(14.17)に対し 1.271倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.668σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host08-003 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host12-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 20→18→19→19→20→17→17→18→17
* 開始   : 2026-07-28 15:10:00 (UTC)
* 終了   : 2026-07-28 17:25:00 (UTC)
* 現象   : 2026-07-28 17:25:00 (UTC)を境に水準が 15.01から14.9へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.031σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.881, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 20→19→16→20→21
* 開始   : 2026-07-28 15:15:00 (UTC)
* 終了   : 2026-07-28 15:15:00 (UTC)
* 現象   : 平常時(20.75)に対し 0.7711(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.326σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→12→9→13→12
* 開始   : 2026-07-28 19:25:00 (UTC)
* 終了   : 2026-07-28 19:25:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.6708(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.092σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→13→9→12→11
* 開始   : 2026-07-28 19:35:00 (UTC)
* 終了   : 2026-07-28 19:35:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.6667(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host09-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host08-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 11→7→14→12→11
* 開始   : 2026-07-29 03:25:00 (UTC)
* 終了   : 2026-07-29 03:25:00 (UTC)
* 現象   : 平常時(9.667)に対し 1.448倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260729-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→17→19→16→15
* 開始   : 2026-07-29 06:40:00 (UTC)
* 終了   : 2026-07-29 06:40:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.303倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.07σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host10-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260729-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→16→20→17→15
* 開始   : 2026-07-29 06:55:00 (UTC)
* 終了   : 2026-07-29 06:55:00 (UTC)
* 現象   : 平常時(15.33)に対し 1.304倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.265σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-lsfhost01-026 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260729-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 21→21→17→22→21
* 開始   : 2026-07-29 14:20:00 (UTC)
* 終了   : 2026-07-29 14:20:00 (UTC)
* 現象   : 平常時(21.75)に対し 0.7816(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.305σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-048 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260729-lsfhost01-049 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260729-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 20→20→16→19→18
* 開始   : 2026-07-29 15:05:00 (UTC)
* 終了   : 2026-07-29 15:05:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.7805(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.151σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260729-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 18→17→18→15→15→16→15→16
* 開始   : 2026-07-29 17:40:00 (UTC)
* 終了   : 2026-07-29 18:55:00 (UTC)
* 現象   : 2026-07-29 18:55:00 (UTC)を境に水準が 14.93から15.17へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 3.559σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.66, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→16→13→14→…→14→11→14→13
* 開始   : 2026-07-29 18:20:00 (UTC)
* 終了   : 2026-07-29 18:30:00 (UTC)
* 現象   : 平常時(15.92)に対し 0.8168(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.027σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host14-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260729-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260729-host06-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-lsfhost01-056 (他ホスト) lsf_queue / njobs : WARN / 重なり 10 分

![EVT-20260729-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 9→8→5→8→8
* 開始   : 2026-07-29 22:15:00 (UTC)
* 終了   : 2026-07-29 22:15:00 (UTC)
* 現象   : 平常時(9.5)に対し 0.5263(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.135σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host10-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host08-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→9→15→12→13
* 開始   : 2026-07-30 04:00:00 (UTC)
* 終了   : 2026-07-30 04:00:00 (UTC)
* 現象   : 平常時(10.5)に対し 1.429倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.121σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260730-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 17→15→20→16→…→16→21→17→18
* 開始   : 2026-07-30 07:40:00 (UTC)
* 終了   : 2026-07-30 07:50:00 (UTC)
* 現象   : 平常時(16.17)に対し 1.237倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.659σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260730-host02-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 19→20→24→21→21
* 開始   : 2026-07-30 09:45:00 (UTC)
* 終了   : 2026-07-30 09:45:00 (UTC)
* 現象   : 平常時(19.67)に対し 1.22倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.005σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→16→14→17→17
* 開始   : 2026-07-30 16:40:00 (UTC)
* 終了   : 2026-07-30 16:40:00 (UTC)
* 現象   : 平常時(18.33)に対し 0.7636(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host11-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-063 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260730-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→10→6→9→9
* 開始   : 2026-07-30 22:00:00 (UTC)
* 終了   : 2026-07-30 22:00:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.5806(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.012σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host02-018 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-085 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→10→14→10→…→10→13→10→12
* 開始   : 2026-07-31 03:20:00 (UTC)
* 終了   : 2026-07-31 03:30:00 (UTC)
* 現象   : 平常時(9.583)に対し 1.461倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 3.076σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260731-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-016 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→14→10→13→12
* 開始   : 2026-07-31 19:10:00 (UTC)
* 終了   : 2026-07-31 19:10:00 (UTC)
* 現象   : 平常時(14.33)に対し 0.6977(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.006σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host08-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host08-016 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-019 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : FATAL
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→10→7→9→11
* 開始   : 2026-07-31 20:25:00 (UTC)
* 終了   : 2026-07-31 20:25:00 (UTC)
* 現象   : 平常時(11.75)に対し 0.5957(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 3.295σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host09-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host08-019 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→14→17→15→14→17→15→16
* 開始   : 2026-07-01 05:55:00 (UTC)
* 終了   : 2026-07-01 06:00:00 (UTC)
* 現象   : 平常時(13.58)に対し 1.252倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-018 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→18→17→16→18→17→18
* 開始   : 2026-07-01 06:30:00 (UTC)
* 終了   : 2026-07-01 06:35:00 (UTC)
* 現象   : 平常時(14.67)に対し 1.227倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260701-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260701-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260701-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260701-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 22→23→24→23→24→23→24→22→20
* 開始   : 2026-07-01 11:10:00 (UTC)
* 終了   : 2026-07-01 11:20:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260701-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260701-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 21→22→25→21→…→21→19→22→21
* 開始   : 2026-07-01 13:25:00 (UTC)
* 終了   : 2026-07-01 13:35:00 (UTC)
* 現象   : 平常時(22.08)に対し 1.132倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260701-host13-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260701-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260701-lsfhost01-041 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260701-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 8→13→7→8→13→7→11
* 開始   : 2026-07-02 02:35:00 (UTC)
* 終了   : 2026-07-02 02:40:00 (UTC)
* 現象   : 平常時(9.083)に対し 1.431倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.728σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260702-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 12→10→14→9→14→9→14→13
* 開始   : 2026-07-02 04:15:00 (UTC)
* 終了   : 2026-07-02 04:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 1.312倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260702-lsfhost01-016 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260702-host02-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260702-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 15→17→18→13→15→17→18→13→16
* 開始   : 2026-07-02 06:25:00 (UTC)
* 終了   : 2026-07-02 06:30:00 (UTC)
* 現象   : 平常時(14.08)に対し 1.207倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.023σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host06-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host07-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host09-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 17→16→20→18→16→20→18→17
* 開始   : 2026-07-02 07:50:00 (UTC)
* 終了   : 2026-07-02 07:55:00 (UTC)
* 現象   : 平常時(16.58)に対し 1.206倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-host02-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260702-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260702-lsfhost01-026 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260702-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 19→21→22→20→…→20→23→16→22
* 開始   : 2026-07-02 09:00:00 (UTC)
* 終了   : 2026-07-02 09:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260702-lsfhost01-029 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260702-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host08-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 20→22→22→23→23→23→21→23→23
* 開始   : 2026-07-02 10:45:00 (UTC)
* 終了   : 2026-07-02 11:25:00 (UTC)
* 現象   : 2026-07-02 11:25:00 (UTC)を境に水準が 14.99から14.93へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.207, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→18→15→14→…→15→14→17→15
* 開始   : 2026-07-02 17:10:00 (UTC)
* 終了   : 2026-07-02 17:15:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.04σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-host03-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260702-lsfhost01-052 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260702-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-lsfhost01-051 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260702-host07-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host08-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 14→16→15→12→15→15→12→14→14
* 開始   : 2026-07-02 18:20:00 (UTC)
* 終了   : 2026-07-02 19:20:00 (UTC)
* 現象   : 2026-07-02 19:20:00 (UTC)を境に水準が 14.94から14.88へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.123, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260702-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260702-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 16→14→11→14→11→14
* 開始   : 2026-07-02 18:35:00 (UTC)
* 終了   : 2026-07-02 18:40:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7253(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.917σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260702-lsfhost01-061 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260702-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host11-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host14-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host14-012 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260702-host05-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260702-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260702-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→13→16→14→…→14→17→14→15
* 開始   : 2026-07-03 05:35:00 (UTC)
* 終了   : 2026-07-03 05:45:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host01-004 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分

![EVT-20260703-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 16→17→18→16→19→18→16→19→17
* 開始   : 2026-07-03 06:25:00 (UTC)
* 終了   : 2026-07-03 06:35:00 (UTC)
* 現象   : 平常時(14.83)に対し 1.213倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host03-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260703-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host11-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-027 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 17→18→20→16→…→16→21→17→18
* 開始   : 2026-07-03 07:45:00 (UTC)
* 終了   : 2026-07-03 07:55:00 (UTC)
* 現象   : 平常時(16.83)に対し 1.188倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host04-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host06-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-host12-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 21→20→18→19→17→18→19→17→20
* 開始   : 2026-07-03 14:15:00 (UTC)
* 終了   : 2026-07-03 14:25:00 (UTC)
* 現象   : 平常時(21.25)に対し 0.8471(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-lsfhost01-044 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260703-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-013 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 22→21→23→22
* 開始   : 2026-07-03 15:15:00 (UTC)
* 終了   : 2026-07-03 15:30:00 (UTC)
* 現象   : 2026-07-03 15:30:00 (UTC)を境に水準が 14.91から12.57へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.536, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260703-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→18→14→17→14→17→14→15→17
* 開始   : 2026-07-03 17:25:00 (UTC)
* 終了   : 2026-07-03 17:35:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.331σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host08-014 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260703-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-host03-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260703-lsfhost01-061 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260703-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260703-host11-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260703-lsfhost01-060 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260703-host08-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→14→11→12→11→12→11→12→13
* 開始   : 2026-07-03 19:05:00 (UTC)
* 終了   : 2026-07-03 19:15:00 (UTC)
* 現象   : 平常時(14.5)に対し 0.7586(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.451σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260703-host01-013 (他ホスト) jvm_gc / eu : FATAL / 重なり 10 分
  - EVT-20260703-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260703-host08-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260703-host08-018 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 10→8→6→8→12→6→8→12→7
* 開始   : 2026-07-03 22:20:00 (UTC)
* 終了   : 2026-07-03 22:30:00 (UTC)
* 現象   : 平常時(9)に対し 0.6667(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260703-host08-018 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 7→12→7→6→12→7→6→8→10
* 開始   : 2026-07-04 03:00:00 (UTC)
* 終了   : 2026-07-04 03:10:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260704-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分

![EVT-20260704-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host08-003 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→9→8→9→…→8→9→10→11
* 開始   : 2026-07-04 04:15:00 (UTC)
* 終了   : 2026-07-04 04:25:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.897, 限界=2.713)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260704-host08-005 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260704-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260704-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260704-host16-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260704-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260704-host02-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260704-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260704-lsfhost01-011 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260704-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260704-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260704-host08-005 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 10→11→9→11→…→9→10→11→13
* 開始   : 2026-07-04 04:25:00 (UTC)
* 終了   : 2026-07-04 04:55:00 (UTC)
* 現象   : 30分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.813, 限界=2.709)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260704-host08-004 (同一ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260704-host08-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260704-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 30 分
  - EVT-20260704-lsfhost01-012 (他ホスト) lsf_queue / run : FATAL / 重なり 30 分
  - EVT-20260704-host15-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 25 分
  - EVT-20260704-lsfhost01-013 (他ホスト) lsf_queue / run : FATAL / 重なり 25 分
  - EVT-20260704-host01-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260704-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分

![EVT-20260704-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→16→12→16→12→16→14
* 開始   : 2026-07-05 07:20:00 (UTC)
* 終了   : 2026-07-05 07:30:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host11-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260705-host05-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260705-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→14→14→15→16→14→15→16
* 開始   : 2026-07-05 07:40:00 (UTC)
* 終了   : 2026-07-05 08:15:00 (UTC)
* 現象   : 2026-07-05 08:15:00 (UTC)を境に水準が 11.8から12.62へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.07, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260705-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 14→15→18→15→18→15→18→15→16
* 開始   : 2026-07-05 09:20:00 (UTC)
* 終了   : 2026-07-05 09:30:00 (UTC)
* 現象   : 平常時(14.58)に対し 1.234倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260705-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 16→14→12→15→…→15→18→17→13
* 開始   : 2026-07-05 11:20:00 (UTC)
* 終了   : 2026-07-05 11:30:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host02-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260705-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 15→16→13→16→…→16→12→16→13
* 開始   : 2026-07-05 12:05:00 (UTC)
* 終了   : 2026-07-05 12:15:00 (UTC)
* 現象   : 平常時(16.25)に対し 0.8(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host06-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260705-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260705-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→13→9→11→13→9→11
* 開始   : 2026-07-05 19:30:00 (UTC)
* 終了   : 2026-07-05 19:35:00 (UTC)
* 現象   : 平常時(12.5)に対し 0.72(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260705-host04-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260705-lsfhost01-038 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260705-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260706-host08-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 9→9→9→9→8→8→10→9→10
* 開始   : 2026-07-06 23:55:00 (UTC)
* 終了   : 2026-07-07 01:00:00 (UTC)
* 現象   : 2026-07-07 01:00:00 (UTC)を境に水準が 15.03から14.94へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.877, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260706-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 7→10→12→10→12→10
* 開始   : 2026-07-07 03:05:00 (UTC)
* 終了   : 2026-07-07 03:10:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260707-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 16→15→18→14→15→18→14→15
* 開始   : 2026-07-07 05:55:00 (UTC)
* 終了   : 2026-07-07 06:00:00 (UTC)
* 現象   : 平常時(14.25)に対し 1.263倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.61σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260707-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260707-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260707-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 23→21→19→23→…→23→18→21→22
* 開始   : 2026-07-07 14:05:00 (UTC)
* 終了   : 2026-07-07 14:15:00 (UTC)
* 現象   : 平常時(21.92)に対し 0.8669(19)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host02-007 (他ホスト) jvm_gc / ou : WARN / 重なり 5 分
  - EVT-20260707-host07-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host08-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→16→15→14→13→13→14→11→16
* 開始   : 2026-07-07 18:45:00 (UTC)
* 終了   : 2026-07-07 19:25:00 (UTC)
* 現象   : 2026-07-07 19:25:00 (UTC)を境に水準が 14.88から15.11へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.855, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260707-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260707-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→9→7→10→9→7→10→9
* 開始   : 2026-07-07 21:10:00 (UTC)
* 終了   : 2026-07-07 21:15:00 (UTC)
* 現象   : 平常時(10.17)に対し 0.6885(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260707-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260707-host03-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260707-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→13→16→17→13→16→17→13→14
* 開始   : 2026-07-08 05:25:00 (UTC)
* 終了   : 2026-07-08 05:30:00 (UTC)
* 現象   : 平常時(12.58)に対し 1.272倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-020 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-021 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260708-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260708-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 18→16→20→18→20→18→20→17→18
* 開始   : 2026-07-08 07:20:00 (UTC)
* 終了   : 2026-07-08 07:30:00 (UTC)
* 現象   : 平常時(16.08)に対し 1.244倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.742σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分

![EVT-20260708-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 17→18→20→14→…→14→20→19→20
* 開始   : 2026-07-08 07:35:00 (UTC)
* 終了   : 2026-07-08 07:45:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-lsfhost01-030 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260708-host07-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host02-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-033 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host08-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 20→22→21→20→22→22
* 開始   : 2026-07-08 08:50:00 (UTC)
* 終了   : 2026-07-08 09:15:00 (UTC)
* 現象   : 2026-07-08 09:15:00 (UTC)を境に水準が 14.94から15.09へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.804, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 21→23→24→20→23→24→20→22
* 開始   : 2026-07-08 11:00:00 (UTC)
* 終了   : 2026-07-08 11:05:00 (UTC)
* 現象   : 平常時(20.75)に対し 1.157倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host12-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260708-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host08-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 24→23→22→21→22→22→21→21
* 開始   : 2026-07-08 13:35:00 (UTC)
* 終了   : 2026-07-08 14:10:00 (UTC)
* 現象   : 2026-07-08 14:10:00 (UTC)を境に水準が 15から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.538, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host08-011 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 21→20→19→18→20→20→18→20→19
* 開始   : 2026-07-08 15:35:00 (UTC)
* 終了   : 2026-07-08 16:45:00 (UTC)
* 現象   : 2026-07-08 16:45:00 (UTC)を境に水準が 15.05から15.03へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.76, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260708-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→13→11→12→…→12→10→13→12
* 開始   : 2026-07-08 19:30:00 (UTC)
* 終了   : 2026-07-08 19:45:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260708-host06-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-071 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260708-lsfhost01-073 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260708-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260708-host14-014 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-072 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260708-lsfhost01-074 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分

![EVT-20260708-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260708-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→13→9→12→8→9→12→8→9
* 開始   : 2026-07-08 20:20:00 (UTC)
* 終了   : 2026-07-08 20:30:00 (UTC)
* 現象   : 平常時(12.75)に対し 0.7059(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.623σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260708-host01-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260708-host01-016 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260708-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260708-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→12→15→16→…→15→16→10→13
* 開始   : 2026-07-09 04:55:00 (UTC)
* 終了   : 2026-07-09 05:00:00 (UTC)
* 現象   : 平常時(11.67)に対し 1.286倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-lsfhost01-016 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260709-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260709-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 18→21→22→20→…→20→23→21→19
* 開始   : 2026-07-09 09:00:00 (UTC)
* 終了   : 2026-07-09 09:10:00 (UTC)
* 現象   : 平常時(18.67)に対し 1.179倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.332σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host05-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260709-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260709-lsfhost01-039 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260709-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-038 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260709-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260709-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 20→16→18→15→16→18→15→19
* 開始   : 2026-07-09 16:05:00 (UTC)
* 終了   : 2026-07-09 16:15:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260709-host03-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260709-host07-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260709-lsfhost01-055 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260709-host02-008 (他ホスト) jvm_gc / ou : WARN / 重なり 0 分

![EVT-20260709-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 8→10→12→11→13→12→11→13→9
* 開始   : 2026-07-10 03:10:00 (UTC)
* 終了   : 2026-07-10 03:20:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-006 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260710-host15-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260710-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→12→13→11→…→11→14→10→12
* 開始   : 2026-07-10 03:35:00 (UTC)
* 終了   : 2026-07-10 03:45:00 (UTC)
* 現象   : 平常時(10)に対し 1.3倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-008 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260710-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→18→16→18→16→18→16
* 開始   : 2026-07-10 06:45:00 (UTC)
* 終了   : 2026-07-10 06:55:00 (UTC)
* 現象   : 平常時(14.75)に対し 1.22倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.274σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host11-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host01-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host10-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-lsfhost01-021 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260710-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 20→21→18→20→24→18→20→24→22
* 開始   : 2026-07-10 11:00:00 (UTC)
* 終了   : 2026-07-10 11:10:00 (UTC)
* 現象   : 平常時(21.58)に対し 0.834(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.506σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260710-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 23→21→25→21→…→21→26→22→23
* 開始   : 2026-07-10 11:30:00 (UTC)
* 終了   : 2026-07-10 11:40:00 (UTC)
* 現象   : 平常時(21.67)に対し 1.154倍(25)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-047 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260710-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host05-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-lsfhost01-046 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260710-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 16→18→15→20→15→20→15
* 開始   : 2026-07-10 16:55:00 (UTC)
* 終了   : 2026-07-10 17:05:00 (UTC)
* 現象   : 平常時(18)に対し 0.8333(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-host08-007 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-lsfhost01-060 (他ホスト) lsf_queue / pend : FATAL / 重なり 10 分
  - EVT-20260710-lsfhost01-059 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260710-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260710-host10-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260710-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260710-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260710-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→16→10→13→16→10→12
* 開始   : 2026-07-10 19:50:00 (UTC)
* 終了   : 2026-07-10 20:35:00 (UTC)
* 現象   : 平常時(13)に対し 1.231倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.081σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260710-lsfhost01-076 (他ホスト) lsf_queue / pend : FATAL / 重なり 45 分
  - EVT-20260710-host05-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 20 分
  - EVT-20260710-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260710-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260710-host02-012 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260710-host04-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host07-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host10-010 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host12-012 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260710-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260710-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 8→8→9→7→10→10→11→8→9
* 開始   : 2026-07-11 00:00:00 (UTC)
* 終了   : 2026-07-11 00:40:00 (UTC)
* 現象   : 2026-07-11 00:40:00 (UTC)を境に水準が 15.02から11.75へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.207, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260711-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260711-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→6→11→9→12→11→9→12→9
* 開始   : 2026-07-11 03:30:00 (UTC)
* 終了   : 2026-07-11 03:40:00 (UTC)
* 現象   : 平常時(8)に対し 1.375倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.088σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260711-host03-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260711-host04-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260711-lsfhost01-005 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260711-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 10→12→13→9→10→12→13→9→12
* 開始   : 2026-07-12 04:20:00 (UTC)
* 終了   : 2026-07-12 04:25:00 (UTC)
* 現象   : 平常時(9)に対し 1.333倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.1σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260712-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 13→16→15→13→16→15→14
* 開始   : 2026-07-12 08:30:00 (UTC)
* 終了   : 2026-07-12 08:35:00 (UTC)
* 現象   : 平常時(12.92)に対し 1.239倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260712-lsfhost01-020 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260712-host14-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260712-lsfhost01-019 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260712-host14-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260712-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260712-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→14→18→14→18→14→18→13→15
* 開始   : 2026-07-12 09:50:00 (UTC)
* 終了   : 2026-07-12 10:00:00 (UTC)
* 現象   : 平常時(14.42)に対し 1.249倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.509σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260712-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260712-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分

![EVT-20260712-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 10→11→7→8→6→7→8→6→10
* 開始   : 2026-07-13 22:00:00 (UTC)
* 終了   : 2026-07-13 22:10:00 (UTC)
* 現象   : 平常時(10.33)に対し 0.6774(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.322σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260713-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host08-008 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→9→10→8→7→11→9→8
* 開始   : 2026-07-13 22:25:00 (UTC)
* 終了   : 2026-07-13 23:15:00 (UTC)
* 現象   : 2026-07-13 23:15:00 (UTC)を境に水準が 14.99から15.01へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.538, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260713-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260713-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 8→9→6→8→9→6→8→7
* 開始   : 2026-07-13 22:45:00 (UTC)
* 終了   : 2026-07-13 22:50:00 (UTC)
* 現象   : 平常時(9.333)に対し 0.6429(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.32σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260713-host13-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260713-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 7→10→9→8→9→10→10→11→12
* 開始   : 2026-07-14 00:10:00 (UTC)
* 終了   : 2026-07-14 00:55:00 (UTC)
* 現象   : 2026-07-14 00:55:00 (UTC)を境に水準が 14.94から14.91へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.34, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→14→15→12→11→14→15→12→11
* 開始   : 2026-07-14 04:35:00 (UTC)
* 終了   : 2026-07-14 04:40:00 (UTC)
* 現象   : 平常時(11.08)に対し 1.263倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host14-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260714-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→15→13→16→15→13→16→14
* 開始   : 2026-07-14 05:10:00 (UTC)
* 終了   : 2026-07-14 05:20:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host05-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260714-lsfhost01-015 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260714-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260714-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 14→16→14→16→14→16
* 開始   : 2026-07-14 05:25:00 (UTC)
* 終了   : 2026-07-14 05:30:00 (UTC)
* 現象   : 平常時(12.67)に対し 1.263倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host14-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host02-004 (他ホスト) jvm_gc / ou : FATAL / 重なり 0 分
  - EVT-20260714-host15-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260714-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 17→18→21→19→22→21→19→22→20
* 開始   : 2026-07-14 08:30:00 (UTC)
* 終了   : 2026-07-14 08:40:00 (UTC)
* 現象   : 平常時(17.92)に対し 1.172倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.159σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260714-host09-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260714-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host08-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 20→21→21→20→20→20→20→19→21
* 開始   : 2026-07-14 15:05:00 (UTC)
* 終了   : 2026-07-14 15:45:00 (UTC)
* 現象   : 2026-07-14 15:45:00 (UTC)を境に水準が 15.05から15.06へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.855, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260714-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→9→11→8→9→11→8→12→11
* 開始   : 2026-07-14 20:00:00 (UTC)
* 終了   : 2026-07-14 20:10:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.7347(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.262σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260714-host16-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260714-lsfhost01-065 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260714-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260714-host09-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host14-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260714-lsfhost01-063 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260714-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260714-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→10→9→11→8→9→11→8→9
* 開始   : 2026-07-14 20:20:00 (UTC)
* 終了   : 2026-07-14 20:30:00 (UTC)
* 現象   : 平常時(12.08)に対し 0.7448(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260714-host14-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260714-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 9→12→11→9→12→11→10
* 開始   : 2026-07-15 02:30:00 (UTC)
* 終了   : 2026-07-15 02:35:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host10-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host11-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-007 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260715-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 10→12→13→10→12→13→10→11
* 開始   : 2026-07-15 03:20:00 (UTC)
* 終了   : 2026-07-15 03:25:00 (UTC)
* 現象   : 平常時(9.75)に対し 1.333倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.254σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-lsfhost01-010 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-011 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260715-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→8→13→12→8→13→12→13
* 開始   : 2026-07-15 03:45:00 (UTC)
* 終了   : 2026-07-15 03:50:00 (UTC)
* 現象   : 平常時(9.5)に対し 1.368倍(13)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host14-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260715-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→16→15→16→15→16→14→15
* 開始   : 2026-07-15 05:00:00 (UTC)
* 終了   : 2026-07-15 05:10:00 (UTC)
* 現象   : 平常時(12.08)に対し 1.324倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.716σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-015 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260715-host05-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host08-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→14→16→15→16→14→15→17→19
* 開始   : 2026-07-15 05:15:00 (UTC)
* 終了   : 2026-07-15 06:25:00 (UTC)
* 現象   : 2026-07-15 06:25:00 (UTC)を境に水準が 14.94から15へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.23, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260715-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 17→18→15→19→18→15→19→16
* 開始   : 2026-07-15 16:35:00 (UTC)
* 終了   : 2026-07-15 16:40:00 (UTC)
* 現象   : 平常時(18.5)に対し 0.8108(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260715-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260715-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 18→14→15→18→14→15→16
* 開始   : 2026-07-15 17:35:00 (UTC)
* 終了   : 2026-07-15 17:40:00 (UTC)
* 現象   : 平常時(17.33)に対し 0.8077(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.312σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260715-host14-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260715-lsfhost01-055 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260715-lsfhost01-054 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260715-host11-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260715-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260715-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 16→19→17→20→19→17→20→19
* 開始   : 2026-07-16 07:30:00 (UTC)
* 終了   : 2026-07-16 07:40:00 (UTC)
* 現象   : 平常時(15.92)に対し 1.194倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260716-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-030 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-031 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260716-host16-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260716-host01-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host03-007 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→9→8→9→11→9→8→9
* 開始   : 2026-07-16 20:25:00 (UTC)
* 終了   : 2026-07-16 21:20:00 (UTC)
* 現象   : 平常時(12.17)に対し 0.7397(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host02-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260716-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 25 分
  - EVT-20260716-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 20 分
  - EVT-20260716-lsfhost01-079 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260716-lsfhost01-081 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260716-host04-013 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260716-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260716-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→9→6→13→8→9→6→13→8
* 開始   : 2026-07-16 21:35:00 (UTC)
* 終了   : 2026-07-16 21:40:00 (UTC)
* 現象   : 平常時(10.08)に対し 0.595(6)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.841σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260716-host01-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-host15-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-082 (他ホスト) lsf_queue / run : WARN / 重なり 5 分
  - EVT-20260716-lsfhost01-084 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260716-host09-011 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260716-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host08-001 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 12→10→11→12→9→9→12→13→12
* 開始   : 2026-07-17 02:15:00 (UTC)
* 終了   : 2026-07-17 03:05:00 (UTC)
* 現象   : 2026-07-17 03:05:00 (UTC)を境に水準が 15から14.79へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.9, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→14→15→13→14→15→13
* 開始   : 2026-07-17 04:40:00 (UTC)
* 終了   : 2026-07-17 04:45:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.39σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host03-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-lsfhost01-019 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260717-host11-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-014 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-018 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 16→19→20→17→16→19→20→17→18
* 開始   : 2026-07-17 06:55:00 (UTC)
* 終了   : 2026-07-17 07:00:00 (UTC)
* 現象   : 平常時(15.5)に対し 1.226倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.438σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host10-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-host03-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host12-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260717-host14-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host08-005 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 23→23→23→22→22→22→23→22→23
* 開始   : 2026-07-17 12:00:00 (UTC)
* 終了   : 2026-07-17 12:40:00 (UTC)
* 現象   : 2026-07-17 12:40:00 (UTC)を境に水準が 15.06から13.37へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.855, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260717-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 19→17→15→17→15→17→15→16→17
* 開始   : 2026-07-17 16:35:00 (UTC)
* 終了   : 2026-07-17 16:45:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-host01-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host10-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host11-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-068 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260717-lsfhost01-070 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260717-host15-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260717-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→14→12→16→14→12→16→14
* 開始   : 2026-07-17 18:20:00 (UTC)
* 終了   : 2026-07-17 18:25:00 (UTC)
* 現象   : 平常時(15.5)に対し 0.7742(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260717-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-076 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分
  - EVT-20260717-lsfhost01-077 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260717-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→15→12→15→12→15→13
* 開始   : 2026-07-17 18:35:00 (UTC)
* 終了   : 2026-07-17 18:40:00 (UTC)
* 現象   : 平常時(15.17)に対し 0.7912(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260717-lsfhost01-073 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260717-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260717-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 13→15→11→13→…→13→10→12→14
* 開始   : 2026-07-17 19:15:00 (UTC)
* 終了   : 2026-07-17 19:25:00 (UTC)
* 現象   : 平常時(14.08)に対し 0.7811(11)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.146σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260717-host15-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260717-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260717-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260717-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260717-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260718-host08-004 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 11→9→11→9→11→9→11→10
* 開始   : 2026-07-18 04:50:00 (UTC)
* 終了   : 2026-07-18 05:00:00 (UTC)
* 現象   : 10分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.763, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260718-host08-001 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host08-002 (同一ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host03-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host03-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host07-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host09-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-host16-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260718-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分

![EVT-20260718-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→13→15→14→15→14→14→14→14
* 開始   : 2026-07-19 06:40:00 (UTC)
* 終了   : 2026-07-19 07:35:00 (UTC)
* 現象   : 2026-07-19 07:35:00 (UTC)を境に水準が 11.72から12.38へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.609, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→16→12→14→…→14→11→13→14
* 開始   : 2026-07-19 15:50:00 (UTC)
* 終了   : 2026-07-19 16:00:00 (UTC)
* 現象   : 平常時(14.92)に対し 0.8045(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 12→10→12→10→12
* 開始   : 2026-07-19 17:10:00 (UTC)
* 終了   : 2026-07-19 17:15:00 (UTC)
* 現象   : 平常時(13.42)に対し 0.7453(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260719-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260719-host08-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 10→10→8→10→8→7→11→11→10
* 開始   : 2026-07-19 22:15:00 (UTC)
* 終了   : 2026-07-19 23:00:00 (UTC)
* 現象   : 2026-07-19 23:00:00 (UTC)を境に水準が 11.87から14.95へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.821, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260719-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260720-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 8→7→5→11→7→5→11→7→8
* 開始   : 2026-07-20 01:00:00 (UTC)
* 終了   : 2026-07-20 01:05:00 (UTC)
* 現象   : 平常時(8)に対し 0.625(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.085σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260720-lsfhost01-004 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260720-lsfhost01-005 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分

![EVT-20260720-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 9→11→12→11→12→11→10
* 開始   : 2026-07-21 02:20:00 (UTC)
* 終了   : 2026-07-21 02:25:00 (UTC)
* 現象   : 平常時(8.583)に対し 1.398倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-lsfhost01-005 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260721-host13-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260721-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 12→16→13→12→16→13
* 開始   : 2026-07-21 05:05:00 (UTC)
* 終了   : 2026-07-21 05:10:00 (UTC)
* 現象   : 平常時(12.42)に対し 1.289倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.485σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260721-host04-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260721-host09-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260721-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260721-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host08-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 22→21→24→23→22
* 開始   : 2026-07-21 13:25:00 (UTC)
* 終了   : 2026-07-21 13:45:00 (UTC)
* 現象   : 2026-07-21 13:45:00 (UTC)を境に水準が 15.1から15.02へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.429, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260721-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260721-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 21→22→18→17→…→18→17→19→20
* 開始   : 2026-07-21 14:40:00 (UTC)
* 終了   : 2026-07-21 14:45:00 (UTC)
* 現象   : 平常時(21.08)に対し 0.8538(18)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260721-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 7→8→11→10→8→11→10→8
* 開始   : 2026-07-22 01:05:00 (UTC)
* 終了   : 2026-07-22 01:10:00 (UTC)
* 現象   : 平常時(7.583)に対し 1.451倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.38σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host13-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host15-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→18→19→16→18→19→16→17
* 開始   : 2026-07-22 07:10:00 (UTC)
* 終了   : 2026-07-22 07:15:00 (UTC)
* 現象   : 平常時(15.58)に対し 1.219倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host16-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-host07-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-025 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260722-lsfhost01-022 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260722-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260722-lsfhost01-024 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260722-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 19→20→23→21→23→21→23→21→22
* 開始   : 2026-07-22 09:15:00 (UTC)
* 終了   : 2026-07-22 09:25:00 (UTC)
* 現象   : 平常時(19.08)に対し 1.205倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.742σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host05-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260722-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host08-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 22→21→20→21
* 開始   : 2026-07-22 15:15:00 (UTC)
* 終了   : 2026-07-22 15:30:00 (UTC)
* 現象   : 2026-07-22 15:30:00 (UTC)を境に水準が 14.89から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.269, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→12→11→14→15→12→11→14→13
* 開始   : 2026-07-22 18:50:00 (UTC)
* 終了   : 2026-07-22 18:55:00 (UTC)
* 現象   : 平常時(15.33)に対し 0.7826(12)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260722-host09-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260722-lsfhost01-067 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260722-host11-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260722-host07-013 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260722-lsfhost01-068 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260722-host13-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260722-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260722-host08-012 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 9→9→10→9→9→10→7→9→8
* 開始   : 2026-07-22 22:35:00 (UTC)
* 終了   : 2026-07-22 23:25:00 (UTC)
* 現象   : 2026-07-22 23:25:00 (UTC)を境に水準が 14.92から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.489, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260722-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host08-003 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 21→20→22→21→22→21→19→21→22
* 開始   : 2026-07-23 08:40:00 (UTC)
* 終了   : 2026-07-23 09:35:00 (UTC)
* 現象   : 2026-07-23 09:35:00 (UTC)を境に水準が 15.02から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=11.03, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260723-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 22→21→24→20→21→24→20→23
* 開始   : 2026-07-23 10:30:00 (UTC)
* 終了   : 2026-07-23 10:35:00 (UTC)
* 現象   : 平常時(20.92)に対し 1.147倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host10-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host13-006 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260723-host14-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260723-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 16→14→16→14→13→14→13→16→15
* 開始   : 2026-07-23 17:45:00 (UTC)
* 終了   : 2026-07-23 18:00:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.098σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-lsfhost01-058 (他ホスト) lsf_queue / run : FATAL / 重なり 10 分
  - EVT-20260723-host01-010 (他ホスト) jvm_gc / eu : FATAL / 重なり 0 分
  - EVT-20260723-host05-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host14-014 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-lsfhost01-060 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260723-host16-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-lsfhost01-059 (他ホスト) lsf_queue / run : WARN / 重なり 0 分
  - EVT-20260723-lsfhost01-061 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260723-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260723-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 15→16→13→15→13→15→13→15→14
* 開始   : 2026-07-23 18:20:00 (UTC)
* 終了   : 2026-07-23 18:30:00 (UTC)
* 現象   : 平常時(16.33)に対し 0.7959(13)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.317σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260723-host04-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260723-host05-011 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260723-host14-016 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260723-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 15→17→19→17→19→17→19→14→17
* 開始   : 2026-07-24 07:05:00 (UTC)
* 終了   : 2026-07-24 07:50:00 (UTC)
* 現象   : 平常時(15.42)に対し 1.232倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host16-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260724-lsfhost01-021 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260724-host05-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host12-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host04-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-lsfhost01-022 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260724-lsfhost01-023 (他ホスト) lsf_queue / run : WARN / 重なり 10 分
  - EVT-20260724-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260724-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 18→20→16→20→16→20→18
* 開始   : 2026-07-24 16:00:00 (UTC)
* 終了   : 2026-07-24 16:05:00 (UTC)
* 現象   : 平常時(19.5)に対し 0.8205(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host02-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260724-lsfhost01-048 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260724-host05-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260724-host05-010 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260724-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 16→17→14→17→…→17→13→16→14
* 開始   : 2026-07-24 17:35:00 (UTC)
* 終了   : 2026-07-24 17:45:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host05-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host06-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host03-008 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260724-host02-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260724-host01-008 (他ホスト) jvm_gc / eu : WARN / 重なり 0 分
  - EVT-20260724-lsfhost01-055 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260724-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 11→11→13→12→10→8→10→10→11
* 開始   : 2026-07-24 20:35:00 (UTC)
* 終了   : 2026-07-24 21:50:00 (UTC)
* 現象   : 2026-07-24 21:50:00 (UTC)を境に水準が 14.96から11.95へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.496σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.475, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260724-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260724-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 10→9→7→9→7→9→10
* 開始   : 2026-07-24 21:20:00 (UTC)
* 終了   : 2026-07-24 21:25:00 (UTC)
* 現象   : 平常時(10.67)に対し 0.6562(7)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.552σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260724-host07-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260724-host12-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260724-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→12→8→9→12→8→9
* 開始   : 2026-07-25 03:45:00 (UTC)
* 終了   : 2026-07-25 03:50:00 (UTC)
* 現象   : 平常時(8.833)に対し 1.358倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host12-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260725-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host08-008 )

* イベント種別 : ALG-A4 EWMA 管理図
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 9→11→8→9→10→11→8→9→10
* 開始   : 2026-07-25 20:00:00 (UTC)
* 終了   : 2026-07-25 20:05:00 (UTC)
* 現象   : 平常時(不明)に対し 不明(8)に落ち込んだ
* 説明   : ALG-A4: 前日同時刻との差分の指数加重移動平均が管理限界を超えた (z=-2.754, 限界=2.693)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260725-host01-004 (他ホスト) jvm_gc / eu : FATAL / 重なり 5 分
  - EVT-20260725-host02-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host07-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-host15-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260725-lsfhost01-011 (他ホスト) lsf_queue / njobs : FATAL / 重なり 5 分
  - EVT-20260725-lsfhost01-022 (他ホスト) lsf_queue / run : FATAL / 重なり 5 分
  - EVT-20260725-host01-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260725-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260725-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 8→7→10→11→…→10→11→8→6
* 開始   : 2026-07-25 23:35:00 (UTC)
* 終了   : 2026-07-25 23:40:00 (UTC)
* 現象   : 平常時(7.083)に対し 1.412倍(10)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.028σ に達した (閾値 2σ/3σ)
* 原因候補 : 一時的な負荷スパイク、または採取タイミングの揺れ (確度: 低) — 単発の逸脱であり、同時刻に他のアノマリーが検知されていないため
* 同時に発生したアノマリー :
  - (同じ時間帯に検知された他のアノマリーはありません)

![EVT-20260725-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 9→12→14→11→12→14→11
* 開始   : 2026-07-26 05:00:00 (UTC)
* 終了   : 2026-07-26 05:05:00 (UTC)
* 現象   : 平常時(10.17)に対し 1.377倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.665σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260726-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→14→12→12→13
* 開始   : 2026-07-26 05:25:00 (UTC)
* 終了   : 2026-07-26 05:45:00 (UTC)
* 現象   : 2026-07-26 05:45:00 (UTC)を境に水準が 11.86から12.17へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.586, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260726-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 16→13→18→12→…→18→12→16→15
* 開始   : 2026-07-26 11:05:00 (UTC)
* 終了   : 2026-07-26 11:10:00 (UTC)
* 現象   : 平常時(15)に対し 1.2倍(18)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-019 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260726-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260726-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→10→9→11→9→11→9→13→12
* 開始   : 2026-07-26 17:55:00 (UTC)
* 終了   : 2026-07-26 18:05:00 (UTC)
* 現象   : 平常時(12.42)に対し 0.7248(9)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.375σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-lsfhost01-032 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260726-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 8→7→5→8→7→5→8
* 開始   : 2026-07-27 00:20:00 (UTC)
* 終了   : 2026-07-27 00:25:00 (UTC)
* 現象   : 平常時(8.083)に対し 0.6186(5)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.148σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260726-host14-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260727-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host08-002 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→10→7→9→9→10→12→11→12
* 開始   : 2026-07-27 02:00:00 (UTC)
* 終了   : 2026-07-27 02:50:00 (UTC)
* 現象   : 2026-07-27 02:50:00 (UTC)を境に水準が 11.92から14.98へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.801, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host08-009 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 13→11→9→8→8→9→6→8→10
* 開始   : 2026-07-27 21:25:00 (UTC)
* 終了   : 2026-07-27 22:30:00 (UTC)
* 現象   : 2026-07-27 22:30:00 (UTC)を境に水準が 14.97から14.99へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.877, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260727-host08-010 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 11→7→8→9→9→7→10→10→10
* 開始   : 2026-07-27 22:20:00 (UTC)
* 終了   : 2026-07-27 23:25:00 (UTC)
* 現象   : 2026-07-27 23:25:00 (UTC)を境に水準が 14.94から15.1へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.441, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260727-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 16→15→17→13→17→13→17→16
* 開始   : 2026-07-28 06:15:00 (UTC)
* 終了   : 2026-07-28 06:25:00 (UTC)
* 現象   : 平常時(13.75)に対し 1.236倍(17)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host15-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260728-host01-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host01-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host11-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-017 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-018 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260728-host13-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-016 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260728-host14-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-015 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260728-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 18→15→20→17→20→17→20→18→19
* 開始   : 2026-07-28 07:10:00 (UTC)
* 終了   : 2026-07-28 07:20:00 (UTC)
* 現象   : 平常時(16)に対し 1.25倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.8σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host07-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host11-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host03-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host07-006 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host14-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-021 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分
  - EVT-20260728-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 18→16→20→19→20→19→20→16→20
* 開始   : 2026-07-28 07:25:00 (UTC)
* 終了   : 2026-07-28 07:35:00 (UTC)
* 現象   : 平常時(16.17)に対し 1.237倍(20)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.682σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-lsfhost01-022 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-023 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-024 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260728-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 22→22→19→20→21
* 開始   : 2026-07-28 08:20:00 (UTC)
* 終了   : 2026-07-28 08:50:00 (UTC)
* 現象   : 2026-07-28 08:50:00 (UTC)を境に水準が 15.04から15.07へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.09σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=8.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260728-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 20→19→22→21→19→22→21→19
* 開始   : 2026-07-28 08:55:00 (UTC)
* 終了   : 2026-07-28 09:00:00 (UTC)
* 現象   : 平常時(18.5)に対し 1.189倍(22)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.45σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host12-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260728-host16-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-lsfhost01-029 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260728-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 20→22→24→20→…→20→18→21→20
* 開始   : 2026-07-28 14:20:00 (UTC)
* 終了   : 2026-07-28 14:30:00 (UTC)
* 現象   : 平常時(21.08)に対し 1.138倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.032σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-lsfhost01-040 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260728-host06-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 17→19→16→20→15→16→20→15→17
* 開始   : 2026-07-28 16:20:00 (UTC)
* 終了   : 2026-07-28 16:30:00 (UTC)
* 現象   : 平常時(19.42)に対し 0.824(16)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260728-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260728-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 18→19→14→15→19→14→15→16
* 開始   : 2026-07-28 17:35:00 (UTC)
* 終了   : 2026-07-28 17:40:00 (UTC)
* 現象   : 平常時(17.17)に対し 0.8155(14)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.206σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260728-host01-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260728-host16-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260728-host10-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host15-012 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260728-host16-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260728-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-002 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 10→11→14→13→…→13→8→12→13
* 開始   : 2026-07-29 04:10:00 (UTC)
* 終了   : 2026-07-29 04:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.507σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host08-003 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host02-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host01-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260729-host08-002 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 11→12→14→12→14→12→13
* 開始   : 2026-07-29 04:10:00 (UTC)
* 終了   : 2026-07-29 04:15:00 (UTC)
* 現象   : 平常時(10.58)に対し 1.323倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.378σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host08-002 (同一ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host12-002 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 10→13→15→16→…→15→16→15→14
* 開始   : 2026-07-29 05:00:00 (UTC)
* 終了   : 2026-07-29 05:05:00 (UTC)
* 現象   : 平常時(11.58)に対し 1.295倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.37σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host10-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-017 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260729-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-007 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 18→20→19→18→19
* 開始   : 2026-07-29 07:00:00 (UTC)
* 終了   : 2026-07-29 07:20:00 (UTC)
* 現象   : 2026-07-29 07:20:00 (UTC)を境に水準が 15.04から15.05へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.67, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260729-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 17→15→19→16→…→16→20→19→18
* 開始   : 2026-07-29 07:10:00 (UTC)
* 終了   : 2026-07-29 07:25:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.217σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host06-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260729-host06-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host10-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260729-host07-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260729-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260729-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 19→20→23→20→23→20→21
* 開始   : 2026-07-29 09:50:00 (UTC)
* 終了   : 2026-07-29 09:55:00 (UTC)
* 現象   : 平常時(19.42)に対し 1.185倍(23)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.494σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260729-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260729-host08-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→11→8→11→7→8→11→7→9
* 開始   : 2026-07-29 20:45:00 (UTC)
* 終了   : 2026-07-29 20:55:00 (UTC)
* 現象   : 平常時(11.17)に対し 0.7164(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260729-host09-010 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260729-lsfhost01-076 (他ホスト) lsf_queue / run : WARN / 重なり 5 分

![EVT-20260729-host08-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 7→11→9→11→9→11→8→10
* 開始   : 2026-07-30 01:05:00 (UTC)
* 終了   : 2026-07-30 01:15:00 (UTC)
* 現象   : 平常時(7.5)に対し 1.467倍(11)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.427σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host10-001 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 12→15→13→12→15→13→14
* 開始   : 2026-07-30 04:45:00 (UTC)
* 終了   : 2026-07-30 04:50:00 (UTC)
* 現象   : 平常時(11.92)に対し 1.259倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.157σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host09-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host03-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host05-004 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host13-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-028 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分
  - EVT-20260730-host05-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-029 (他ホスト) lsf_queue / susp : WARN / 重なり 0 分
  - EVT-20260730-lsfhost01-030 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260730-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host08-006 )

* イベント種別 : ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 22→21→22→24→24→23→22
* 開始   : 2026-07-30 12:25:00 (UTC)
* 終了   : 2026-07-30 12:55:00 (UTC)
* 現象   : 2026-07-30 12:55:00 (UTC)を境に水準が 15.15から15.04へ移行し、元に戻らない
* 説明   : ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.57, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260730-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 20→19→17→19→17→19→20
* 開始   : 2026-07-30 15:05:00 (UTC)
* 終了   : 2026-07-30 15:10:00 (UTC)
* 現象   : 平常時(20.5)に対し 0.8293(17)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.433σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host12-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260730-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 16→14→12→15→…→12→11→12→13
* 開始   : 2026-07-30 18:20:00 (UTC)
* 終了   : 2026-07-30 18:35:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.665σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-lsfhost01-066 (他ホスト) lsf_queue / njobs : FATAL / 重なり 15 分
  - EVT-20260730-host01-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host12-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-075 (他ホスト) lsf_queue / pend : WARN / 重なり 10 分
  - EVT-20260730-lsfhost01-074 (他ホスト) lsf_queue / pend : WARN / 重なり 5 分

![EVT-20260730-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host08-010 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_2
* 値     : 13→15→10→11→…→11→9→11→10
* 開始   : 2026-07-30 20:00:00 (UTC)
* 終了   : 2026-07-30 20:15:00 (UTC)
* 現象   : 15分にわたり平常範囲を上回った状態が継続した
* 説明   : ALG-A1: 移動平均からの残差が 2.196σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 15 分
  - EVT-20260730-host16-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260730-host03-015 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-host14-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260730-lsfhost01-081 (他ホスト) lsf_queue / pend : FATAL / 重なり 0 分
  - EVT-20260730-host05-015 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260730-host11-011 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260730-host05-014 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260730-host08-010 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260730-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 11→12→8→9→…→8→9→10→12
* 開始   : 2026-07-30 20:35:00 (UTC)
* 終了   : 2026-07-30 20:40:00 (UTC)
* 現象   : 平常時(12.25)に対し 0.6531(8)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.954σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260730-host03-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分

![EVT-20260730-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-001 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 7→12→8→7→12→8→11
* 開始   : 2026-07-31 02:35:00 (UTC)
* 終了   : 2026-07-31 02:40:00 (UTC)
* 現象   : 平常時(8.75)に対し 1.371倍(12)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host01-001 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host05-003 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分

![EVT-20260731-host08-001 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-003 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 13→12→14→11→12→14→11→14
* 開始   : 2026-07-31 04:10:00 (UTC)
* 終了   : 2026-07-31 04:15:00 (UTC)
* 現象   : 平常時(10.75)に対し 1.302倍(14)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.259σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host02-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host12-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-013 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host08-003 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-004 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 13→15→12→15→12→15→12→14
* 開始   : 2026-07-31 04:35:00 (UTC)
* 終了   : 2026-07-31 04:45:00 (UTC)
* 現象   : 平常時(11.5)に対し 1.304倍(15)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.448σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 10 分
  - EVT-20260731-host14-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-015 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host01-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host02-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-014 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260731-host08-004 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-005 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→11→16→12→16→12→16→14
* 開始   : 2026-07-31 05:20:00 (UTC)
* 終了   : 2026-07-31 05:30:00 (UTC)
* 現象   : 平常時(12.83)に対し 1.247倍(16)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.201σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host02-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host12-002 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host13-002 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host11-002 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260731-host08-005 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-006 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 15→14→19→14→19→14→19→16→15
* 開始   : 2026-07-31 07:00:00 (UTC)
* 終了   : 2026-07-31 07:10:00 (UTC)
* 現象   : 平常時(15)に対し 1.267倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.8σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-lsfhost01-023 (他ホスト) lsf_queue / njobs : FATAL / 重なり 10 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host10-005 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-host11-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host02-009 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host07-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host09-003 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host08-006 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-007 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 14→16→19→20→…→19→20→19→18
* 開始   : 2026-07-31 07:20:00 (UTC)
* 終了   : 2026-07-31 07:25:00 (UTC)
* 現象   : 平常時(15.75)に対し 1.206倍(19)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host06-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host04-005 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host07-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host16-001 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-025 (他ホスト) lsf_queue / run : WARN / 重なり 0 分

![EVT-20260731-host08-007 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-008 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 19→18→21→18→21→18→21→20→17
* 開始   : 2026-07-31 08:00:00 (UTC)
* 終了   : 2026-07-31 08:10:00 (UTC)
* 現象   : 平常時(17.33)に対し 1.212倍(21)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.552σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host10-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host13-003 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host09-004 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分

![EVT-20260731-host08-008 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-009 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_3
* 値     : 22→20→24→23→20→24→23→22
* 開始   : 2026-07-31 10:50:00 (UTC)
* 終了   : 2026-07-31 12:00:00 (UTC)
* 現象   : 平常時(20.83)に対し 1.152倍(24)に跳ね上がった。前後の点は平常範囲
* 説明   : ALG-A1: 移動平均からの残差が 2.215σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host04-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host15-007 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host06-007 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host07-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host13-004 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host06-008 (他ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-lsfhost01-035 (他ホスト) lsf_queue / pend : WARN / 重なり 0 分

![EVT-20260731-host08-009 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-011 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_6
* 値     : 22→22→23→21→23→22→21→22→22
* 開始   : 2026-07-31 13:40:00 (UTC)
* 終了   : 2026-07-31 15:10:00 (UTC)
* 現象   : 2026-07-31 15:10:00 (UTC)を境に水準が 15から12.88へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.264σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=10.34, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host08-011 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-012 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 16→17→15→16→17→15→16→17
* 開始   : 2026-07-31 16:55:00 (UTC)
* 終了   : 2026-07-31 17:00:00 (UTC)
* 現象   : 平常時(18.42)に対し 0.8145(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host05-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host13-005 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host13-006 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-043 (他ホスト) lsf_queue / run : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-044 (他ホスト) lsf_queue / njobs : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260731-host08-012 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-013 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 19→18→15→14→18→15→14→18→17
* 開始   : 2026-07-31 17:05:00 (UTC)
* 終了   : 2026-07-31 17:10:00 (UTC)
* 現象   : 平常時(18.08)に対し 0.8295(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.143σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host08-014 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260731-host08-013 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-014 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 17→18→15→14→…→15→14→16→18
* 開始   : 2026-07-31 17:10:00 (UTC)
* 終了   : 2026-07-31 17:15:00 (UTC)
* 現象   : 平常時(17.92)に対し 0.8372(15)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.03σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host08-013 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host11-008 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host15-013 (他ホスト) db_connection / active_connections : FATAL / 重なり 5 分
  - EVT-20260731-host04-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host04-010 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-lsfhost01-041 (他ホスト) lsf_queue / njobs : WARN / 重なり 5 分

![EVT-20260731-host08-014 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-015 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_4
* 値     : 14→13→10→14→10→14→10→13→12
* 開始   : 2026-07-31 19:05:00 (UTC)
* 終了   : 2026-07-31 19:15:00 (UTC)
* 現象   : 平常時(13.83)に対し 0.7229(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.665σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host08-016 (同一ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host08-017 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host01-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分
  - EVT-20260731-host13-008 (他ホスト) db_connection / active_connections : WARN / 重なり 5 分

![EVT-20260731-host08-015 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-017 )

* イベント種別 : ALG-A1 移動平均乖離率
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_5
* 値     : 14→11→10→11→9→10→11→9→12
* 開始   : 2026-07-31 19:15:00 (UTC)
* 終了   : 2026-07-31 19:25:00 (UTC)
* 現象   : 平常時(13.5)に対し 0.7407(10)に落ち込んだ
* 説明   : ALG-A1: 移動平均からの残差が 2.436σ に達した (閾値 2σ/3σ)
* 原因候補 : 該当する候補なし (確度: —)
* 同時に発生したアノマリー :
  - EVT-20260731-host08-015 (同一ホスト) db_connection / active_connections : WARN / 重なり 0 分
  - EVT-20260731-host06-011 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host13-009 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host14-012 (他ホスト) db_connection / active_connections : FATAL / 重なり 0 分
  - EVT-20260731-host03-009 (他ホスト) db_connection / active_connections : WARN / 重なり 10 分
  - EVT-20260731-lsfhost01-058 (他ホスト) lsf_queue / njobs : WARN / 重なり 0 分

![EVT-20260731-host08-017 チャートなし](charts/no-chart.svg)

# イベントID( EVT-20260731-host08-018 )

* イベント種別 : ALG-A1 移動平均乖離率, ALG-B4 CUSUM
* 脅威度 : WARN
* データ : db_connection / active_connections (アクティブコネクション数) / host=host08, port=7003, datasource=OraclePool_1
* 値     : 13→13→12→13→13→13→14→11→12
* 開始   : 2026-07-31 19:20:00 (UTC)
* 終了   : 2026-07-31 21:05:00 (UTC)
* 現象   : 2026-07-31 21:05:00 (UTC)を境に水準が 15から11.8へ移行し、元に戻らない
* 説明   : ALG-A1: 移動平均からの残差が 2.392σ に達した (閾値 2σ/3σ)
             ALG-B4: 前日同時刻との差分の累積和が閾値を超えた (S+=9.149, h=5)
* 原因候補 : 設定変更・負荷段階の変化 (確度: 中) — ある時刻を境に水準が移り、元に戻っていないため

![EVT-20260731-host08-018 チャートなし](charts/no-chart.svg)

## 5. 実行時の注意事項

### 5.1 読み飛ばした行

(なし)

### 5.2 点数不足でスキップした系列

| アルゴリズム | 理由 | スキップ系列数 |
| --- | --- | --- |
| ALG-A3 | 分布が広く適用不可 | 1 |
| ALG-C1 | 分布が広く適用不可 | 15 |

### 5.3 失敗したアルゴリズム

(なし)
